project_root <- normalizePath(".")
lib <- file.path(project_root, "environment", "R_libs")
dir.create(lib, recursive = TRUE, showWarnings = FALSE)
.libPaths(c(lib, .libPaths()))

options(repos = c(CRAN = "https://cloud.r-project.org"), Ncpus = max(1L, parallel::detectCores(logical = FALSE) - 1L))
if (!requireNamespace("BiocManager", quietly = TRUE)) install.packages("BiocManager", lib = lib)

cran <- c("metafor", "matrixStats", "data.table", "ggplot2", "jsonlite", "yaml")
missing_cran <- cran[!vapply(cran, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing_cran)) install.packages(missing_cran, lib = lib)

bioc <- c("limma", "edgeR", "GEOquery", "Biobase", "sva", "affy", "oligo")
missing_bioc <- bioc[!vapply(bioc, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing_bioc)) BiocManager::install(missing_bioc, lib = lib, ask = FALSE, update = FALSE)

session <- capture.output(sessionInfo())
writeLines(session, file.path(project_root, "logs", "R_session_after_install.txt"))
