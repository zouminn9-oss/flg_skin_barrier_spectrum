#!/usr/bin/env python3
"""Gate 1-2 artifact audit only; performs no data download or analysis."""

from __future__ import annotations

import csv
import pathlib
import re
import sys


ROOT = pathlib.Path(__file__).resolve().parents[1]
REQUIRED = [
    "00_project_plan.md",
    "01_novelty_review.md",
    "01_literature_matrix.csv",
    "02_dataset_inventory.csv",
    "03_inclusion_exclusion_log.csv",
    "04_qc_report.md",
    "05_analysis_plan.md",
    "06_gate_decision_log.md",
    "records/search_log.csv",
    "records/reproducibility.md",
    "logs/execution_log.md",
    "logs/amendments.md",
]

CSV_REQUIRED_COLUMNS = {
    "01_literature_matrix.csv": {"record_id", "diseases", "methods", "identifier", "url"},
    "02_dataset_inventory.csv": {
        "record_id",
        "accession_or_id",
        "disease",
        "samples",
        "independent_subjects",
        "inclusion_status",
        "source_url",
    },
    "03_inclusion_exclusion_log.csv": {"decision_id", "item", "decision", "reason"},
    "records/search_log.csv": {"search_id", "database_or_site", "query_or_action", "date", "key_url"},
}


def audit() -> list[str]:
    errors: list[str] = []
    for rel in REQUIRED:
        path = ROOT / rel
        if not path.is_file() or path.stat().st_size == 0:
            errors.append(f"missing-or-empty: {rel}")

    for rel, required in CSV_REQUIRED_COLUMNS.items():
        path = ROOT / rel
        if not path.is_file():
            continue
        with path.open(newline="", encoding="utf-8") as handle:
            reader = csv.DictReader(handle)
            columns = set(reader.fieldnames or [])
            missing = required - columns
            if missing:
                errors.append(f"missing-columns: {rel}: {sorted(missing)}")
            ids: set[str] = set()
            for line_number, row in enumerate(reader, start=2):
                first_column = (reader.fieldnames or [""])[0]
                row_id = (row.get(first_column) or "").strip()
                if not row_id:
                    errors.append(f"blank-id: {rel}:{line_number}")
                elif row_id in ids:
                    errors.append(f"duplicate-id: {rel}:{line_number}:{row_id}")
                ids.add(row_id)
                for key in ("url", "source_url", "key_url"):
                    value = (row.get(key) or "").strip()
                    if value and not re.match(r"^https://", value):
                        errors.append(f"non-https-url: {rel}:{line_number}:{key}")
    return errors


if __name__ == "__main__":
    findings = audit()
    if findings:
        print("AUDIT_FAIL")
        print("\n".join(findings))
        sys.exit(1)
    print("AUDIT_OK: required files, CSV schemas, IDs and HTTPS link fields passed")
