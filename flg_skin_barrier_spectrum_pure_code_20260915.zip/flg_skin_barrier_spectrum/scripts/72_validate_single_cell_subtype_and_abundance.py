#!/usr/bin/env python3
"""Validate fine-state and paired-abundance outputs."""

from __future__ import annotations

import csv
import math
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
OUT = (
    ROOT
    / "results/exploratory_snf/selected_positive_reml_z_q05"
    / "optimized_AD_ACD_branch/mechanism/single_cell_subtype_robustness"
)


def read_rows(name: str) -> list[dict[str, str]]:
    with (OUT / name).open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


subtypes = read_rows("subtype_program_summary.tsv")
null_rows = read_rows("subtype_label_swap_null.tsv")
loo = read_rows("subtype_leave_one_donor_out.tsv")
abundance = read_rows("paired_differential_abundance.tsv")

checks: list[tuple[str, bool]] = []
checks.append(("five_eligible_subtypes", len(subtypes) == 5))
checks.append(("expected_subtypes", {r["subtype"] for r in subtypes} == {"LC", "Myeloid-1", "KRT-sp", "KRT-b2", "KRT-a"}))
checks.append(("seventeen_abundance_features", len(abundance) == 17))
checks.append(("all_q_values_bounded", all(0 <= float(r["q_directional_BH_all_subtypes"]) <= 1 for r in subtypes)))
checks.append(("all_abundance_q_values_bounded", all(0 <= float(r["q_BH_within_level"]) <= 1 for r in abundance)))

for record in subtypes:
    subtype = record["subtype"]
    n = int(record["n_paired_donors"])
    observed = float(record["observed_score"])
    null = [float(r["score"]) for r in null_rows if r["subtype"] == subtype]
    checks.append((f"{subtype}_complete_exact_grid", len(null) == 2**n))
    checks.append((f"{subtype}_observed_in_null", any(math.isclose(x, observed, abs_tol=1e-12) for x in null)))
    checks.append((f"{subtype}_sign_symmetric_null", all(any(math.isclose(-x, y, abs_tol=1e-8) for y in null) for x in null)))
    p_two = sum(abs(x) >= abs(observed) - 1e-12 for x in null) / len(null)
    checks.append((f"{subtype}_two_sided_p_recomputed", math.isclose(p_two, float(record["exact_p_two_sided"]), abs_tol=1e-12)))

for record in abundance:
    checks.append((f"abundance_{record['feature']}_32_permutations", int(record["exact_permutations"]) == 32))
    checks.append((f"abundance_{record['feature']}_five_loo_directions", 0 <= int(record["loo_same_direction"]) <= 5))

failed = [name for name, passed in checks if not passed]
with (OUT / "VALIDATION_SUMMARY.tsv").open("w", newline="", encoding="utf-8") as handle:
    writer = csv.writer(handle, delimiter="\t")
    writer.writerow(["check", "passed"])
    writer.writerows((name, str(passed).upper()) for name, passed in checks)

print(f"Validated {len(checks)} checks; failures={len(failed)}")
if failed:
    raise SystemExit("Failed checks: " + ", ".join(failed))
