#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(Matrix)
  library(ggplot2)
})

mode <- Sys.getenv("TRAJECTORY_MODE", "both")
if (!mode %in% c("monocle", "vector", "both")) stop("TRAJECTORY_MODE must be monocle, vector, or both")
if (mode %in% c("monocle", "both")) suppressPackageStartupMessages(library(monocle))
if (mode %in% c("vector", "both")) suppressPackageStartupMessages(library(Seurat))

set.seed(20260910)
input_root <- "data/processed/advanced_single_cell_inputs"
output_root <- "results/advanced_single_cell/trajectory"
vector_source <- "external_tools/VECTOR/Vector.R"
condition_order <- c("Nonlesional", "Irritant", "Day2_Allergy", "Day4_Allergy")

read_bundle <- function(lineage) {
  bundle <- file.path(input_root, paste0("state_continuum_", lineage))
  counts <- readMM(file.path(bundle, "counts_genes_by_cells.mtx"))
  genes <- read.delim(file.path(bundle, "genes.tsv"), check.names = FALSE)[[1]]
  cells <- read.delim(file.path(bundle, "barcodes.tsv"), check.names = FALSE)[[1]]
  meta <- read.delim(file.path(bundle, "metadata.tsv"), row.names = 1, check.names = FALSE)
  rownames(counts) <- make.unique(as.character(genes))
  colnames(counts) <- as.character(cells)
  sc_file <- file.path(output_root, lineage, "scTour", "sctour_cell_pseudotime.tsv")
  if (!file.exists(sc_file)) stop("scTour cell manifest is required: ", sc_file)
  sc <- read.delim(sc_file, row.names = 1, check.names = FALSE)
  keep <- intersect(rownames(sc), colnames(counts))
  list(counts = as(counts[, keep, drop = FALSE], "dgCMatrix"), meta = meta[keep, , drop = FALSE], sctour = sc[keep, , drop = FALSE])
}

orient_time <- function(x, lesion) {
  flip <- median(x[lesion == "Nonlesional"], na.rm = TRUE) > median(x[lesion == "Day4_Allergy"], na.rm = TRUE)
  list(value = if (isTRUE(flip)) max(x, na.rm = TRUE) - x else x, flipped = isTRUE(flip))
}

summarise_donor_time <- function(out, value_col) {
  groups <- split(seq_len(nrow(out)), interaction(out$Patient, out$Lesion, drop = TRUE))
  rows <- lapply(groups, function(ix) {
    x <- out[[value_col]][ix]
    data.frame(
      Patient = as.character(out$Patient[ix[1]]),
      Lesion = as.character(out$Lesion[ix[1]]),
      median = median(x, na.rm = TRUE),
      mean = mean(x, na.rm = TRUE),
      count = sum(is.finite(x)),
      stringsAsFactors = FALSE
    )
  })
  do.call(rbind, rows)
}

run_monocle2 <- function(dat, out_dir) {
  dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
  pd <- new("AnnotatedDataFrame", data = dat$meta)
  fd <- new("AnnotatedDataFrame", data = data.frame(gene_short_name = rownames(dat$counts), row.names = rownames(dat$counts)))
  cds <- newCellDataSet(dat$counts, phenoData = pd, featureData = fd, expressionFamily = negbinomial.size())
  cds <- estimateSizeFactors(cds)
  cds <- estimateDispersions(cds)
  cds <- detectGenes(cds, min_expr = 0.1)
  disp <- dispersionTable(cds)
  disp <- disp[is.finite(disp$dispersion_empirical) & disp$mean_expression >= 0.05, , drop = FALSE]
  disp <- disp[order(disp$dispersion_empirical, decreasing = TRUE), , drop = FALSE]
  ordering <- head(disp$gene_id, 1200)
  if (length(ordering) < 100) stop("Too few ordering genes for Monocle2")
  cds <- setOrderingFilter(cds, ordering)
  cds <- reduceDimension(cds, max_components = 2, method = "DDRTree", norm_method = "log")
  cds <- orderCells(cds)
  first <- pData(cds)
  root_state <- as.numeric(names(which.max(tapply(first$Lesion == "Nonlesional", first$State, mean))))
  cds <- orderCells(cds, root_state = root_state)
  ph <- pData(cds)
  oriented <- orient_time(ph$Pseudotime, ph$Lesion)
  out <- cbind(ph, Monocle2_pseudotime = oriented$value, Monocle2_state = ph$State)
  write.table(out, file.path(out_dir, "monocle2_cell_pseudotime.tsv"), sep = "\t", quote = FALSE, col.names = NA)
  donor <- summarise_donor_time(out, "Monocle2_pseudotime")
  write.table(donor, file.path(out_dir, "monocle2_donor_condition_summary.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
  reduced <- t(reducedDimS(cds))
  plot_df <- data.frame(
    Component_1 = reduced[rownames(ph), 1],
    Component_2 = reduced[rownames(ph), 2],
    Lesion = ph$Lesion,
    stringsAsFactors = FALSE
  )
  png(file.path(out_dir, "monocle2_trajectory.png"), width = 2200, height = 1000, res = 180)
  print(ggplot(plot_df, aes(Component_1, Component_2, colour = Lesion)) +
          geom_point(size = 0.65, alpha = 0.72) +
          coord_equal() +
          theme_classic() +
          ggtitle("Monocle2 DDRTree: condition"))
  dev.off()
  saveRDS(cds, file.path(out_dir, "monocle2_cds.rds"))
  writeLines(c(
    paste0("monocle_version\t", as.character(packageVersion("monocle"))),
    paste0("cells\t", ncol(cds)),
    paste0("genes\t", nrow(cds)),
    paste0("ordering_genes\t", length(ordering)),
    paste0("root_state\t", root_state),
    paste0("orientation_flipped\t", oriented$flipped)
  ), file.path(out_dir, "monocle2_run_metadata.tsv"))
  out
}

run_vector <- function(dat, out_dir) {
  dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
  seu <- CreateSeuratObject(counts = dat$counts, min.cells = 0, min.features = 0, meta.data = dat$meta)
  seu <- NormalizeData(seu, verbose = FALSE)
  seu <- FindVariableFeatures(seu, selection.method = "vst", nfeatures = 2500, verbose = FALSE)
  seu <- ScaleData(seu, features = VariableFeatures(seu), verbose = FALSE)
  seu <- RunPCA(seu, features = VariableFeatures(seu), npcs = 50, verbose = FALSE)
  seu <- RunUMAP(seu, dims = 1:30, n.neighbors = 30, min.dist = 0.3, seed.use = 20260910, verbose = FALSE)
  VEC <- Embeddings(seu, "umap")
  PCA <- Embeddings(seu, "pca")
  source(vector_source, local = TRUE)
  PCA <- vector.rankPCA(PCA)
  png(file.path(out_dir, "vector_trajectory.png"), width = 1400, height = 1200, res = 180)
  OUT <- vector.buildGrid(VEC, N = 24, SHOW = FALSE)
  OUT <- vector.buildNet(OUT, CUT = 2, SHOW = FALSE)
  OUT <- vector.getValue(OUT, PCA, SHOW = FALSE)
  OUT <- vector.gridValue(OUT, SHOW = FALSE)
  OUT <- vector.autoCenter(OUT, UP = 0.9, SHOW = FALSE)
  OUT <- vector.drawArrow(OUT, P = 0.9, SHOW = TRUE, COL = OUT$COL, SHOW.SUMMIT = TRUE)
  dev.off()
  pt <- OUT$P.PS
  oriented <- orient_time(pt, dat$meta$Lesion)
  out <- cbind(dat$meta, VECTOR_pseudotime = oriented$value)
  write.table(out, file.path(out_dir, "vector_cell_pseudotime.tsv"), sep = "\t", quote = FALSE, col.names = NA)
  donor <- summarise_donor_time(out, "VECTOR_pseudotime")
  write.table(donor, file.path(out_dir, "vector_donor_condition_summary.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
  saveRDS(OUT, file.path(out_dir, "vector_output.rds"))
  writeLines(c(
    "method\tVECTOR",
    "source_version\tGitHub source retrieved 2026-09-10",
    paste0("cells\t", nrow(VEC)),
    paste0("pca_components\t", ncol(PCA)),
    "grid_N\t24",
    "network_min_cells\t2",
    paste0("orientation_flipped\t", oriented$flipped)
  ), file.path(out_dir, "vector_run_metadata.tsv"))
  out
}

for (lineage in c("APC", "KRT")) {
  message("Running trajectory methods for ", lineage)
  dat <- read_bundle(lineage)
  if (mode %in% c("monocle", "both")) {
    run_monocle2(dat, file.path(output_root, lineage, "Monocle2"))
  }
  if (!mode %in% c("vector", "both")) next
  vec <- run_vector(dat, file.path(output_root, lineage, "VECTOR"))
  mono_file <- file.path(output_root, lineage, "Monocle2", "monocle2_cell_pseudotime.tsv")
  if (!file.exists(mono_file)) stop("Run TRAJECTORY_MODE=monocle first: ", mono_file)
  mono <- read.delim(mono_file, row.names = 1, check.names = FALSE)
  common <- Reduce(intersect, list(rownames(dat$sctour), rownames(mono), rownames(vec)))
  merged <- data.frame(
    barcode = common,
    Patient = dat$meta[common, "Patient"],
    Lesion = dat$meta[common, "Lesion"],
    scTour = dat$sctour[common, "scTour_consensus_rank"],
    Monocle2 = mono[common, "Monocle2_pseudotime"],
    VECTOR = vec[common, "VECTOR_pseudotime"],
    row.names = NULL
  )
  write.table(merged, file.path(output_root, lineage, "trajectory_method_cell_merge.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
  cors <- cor(merged[c("scTour", "Monocle2", "VECTOR")], method = "spearman", use = "pairwise.complete.obs")
  write.table(cors, file.path(output_root, lineage, "trajectory_method_spearman.tsv"), sep = "\t", quote = FALSE, col.names = NA)
  donor <- aggregate(cbind(scTour, Monocle2, VECTOR) ~ Patient + Lesion, merged, median, na.rm = TRUE)
  donor$Lesion <- factor(donor$Lesion, condition_order)
  donor <- donor[order(donor$Patient, donor$Lesion), ]
  write.table(donor, file.path(output_root, lineage, "trajectory_method_donor_medians.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
}
