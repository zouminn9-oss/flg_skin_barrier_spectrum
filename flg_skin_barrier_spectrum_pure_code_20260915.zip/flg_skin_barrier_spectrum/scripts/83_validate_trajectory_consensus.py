#!/usr/bin/env python3
"""Donor-paired validation and cross-method consensus for trajectory outputs."""

from __future__ import annotations

from itertools import product
from pathlib import Path

import numpy as np
import pandas as pd


ROOT = Path("results/advanced_single_cell/trajectory")
METHOD_FILES = {
    "scTour": ("scTour/sctour_donor_condition_summary.tsv", "median"),
    "Monocle2": ("Monocle2/monocle2_donor_condition_summary.tsv", "median"),
    "VECTOR": ("VECTOR/vector_donor_condition_summary.tsv", "median"),
}
CONTRASTS = {
    "Irritant_vs_Nonlesional": ("Irritant", "Nonlesional"),
    "Day2_vs_Nonlesional": ("Day2_Allergy", "Nonlesional"),
    "Day4_vs_Nonlesional": ("Day4_Allergy", "Nonlesional"),
    "Day4_vs_Irritant": ("Day4_Allergy", "Irritant"),
}


def sign_flip_pvalue(delta: np.ndarray) -> float:
    delta = np.asarray(delta, dtype=float)
    delta = delta[np.isfinite(delta)]
    if not len(delta):
        return np.nan
    observed = abs(delta.mean())
    null = [abs(np.mean(delta * np.asarray(signs))) for signs in product((-1.0, 1.0), repeat=len(delta))]
    return float(np.mean(np.asarray(null) >= observed - 1e-12))


def bh(values: pd.Series) -> pd.Series:
    p = values.to_numpy(dtype=float)
    out = np.full(len(p), np.nan)
    ok = np.isfinite(p)
    vals = p[ok]
    order = np.argsort(vals)
    q = vals[order] * len(vals) / np.arange(1, len(vals) + 1)
    q = np.minimum.accumulate(q[::-1])[::-1]
    inverse = np.empty(len(vals), dtype=float)
    inverse[order] = np.minimum(q, 1.0)
    out[ok] = inverse
    return pd.Series(out, index=values.index)


rows = []
for lineage in ("APC", "KRT"):
    for method, (relative, value_col) in METHOD_FILES.items():
        frame = pd.read_csv(ROOT / lineage / relative, sep="\t")
        wide = frame.pivot(index="Patient", columns="Lesion", values=value_col)
        for contrast, (numerator, denominator) in CONTRASTS.items():
            if numerator not in wide or denominator not in wide:
                continue
            delta = (wide[numerator] - wide[denominator]).dropna().to_numpy(dtype=float)
            rows.append(
                {
                    "lineage": lineage,
                    "method": method,
                    "contrast": contrast,
                    "n_paired_donors": len(delta),
                    "mean_paired_delta": delta.mean(),
                    "median_paired_delta": np.median(delta),
                    "positive_donors": int((delta > 0).sum()),
                    "negative_donors": int((delta < 0).sum()),
                    "exact_signflip_p": sign_flip_pvalue(delta),
                }
            )

tests = pd.DataFrame(rows)
tests["q_BH_within_lineage_method"] = tests.groupby(["lineage", "method"], group_keys=False)["exact_signflip_p"].apply(bh)
tests.to_csv(ROOT / "trajectory_donor_paired_tests.tsv", sep="\t", index=False)

consensus_rows = []
for (lineage, contrast), group in tests.groupby(["lineage", "contrast"], observed=True):
    consensus_rows.append(
        {
            "lineage": lineage,
            "contrast": contrast,
            "methods_available": len(group),
            "methods_positive_mean_delta": int((group.mean_paired_delta > 0).sum()),
            "methods_negative_mean_delta": int((group.mean_paired_delta < 0).sum()),
            "methods_with_at_least_4_of_5_donors_same_direction": int(
                (group[["positive_donors", "negative_donors"]].max(axis=1) >= 4).sum()
            ),
            "minimum_exact_signflip_p": group.exact_signflip_p.min(),
        }
    )

pd.DataFrame(consensus_rows).to_csv(ROOT / "trajectory_cross_method_consensus.tsv", sep="\t", index=False)
