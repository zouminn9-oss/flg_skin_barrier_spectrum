#!/usr/bin/env python3
"""Build compact robustness summaries and Supplementary Figure S2."""

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.stats import spearmanr


ROOT = Path(__file__).resolve().parents[1]
RES = ROOT / "results/advanced_single_cell"
FIGDIR = ROOT / "paper_rewriting_output/jid_innovations_submission/figures"


def read_flux(path: Path) -> pd.DataFrame:
    x = pd.read_csv(path, index_col=0)
    x.index.name = "cell"
    return x


def donor_flux(flux: pd.DataFrame) -> pd.DataFrame:
    meta = pd.read_csv(
        ROOT / "data/processed/advanced_single_cell_inputs/paired_day4_irritant_balanced/metadata.tsv",
        sep="\t",
        index_col=0,
    )
    common = flux.index.intersection(meta.index)
    z = flux.loc[common].join(meta.loc[common, ["Patient", "Lesion", "Basic_Celltype"]])
    return (
        z.groupby(["Patient", "Lesion", "Basic_Celltype"], observed=True)
        .median(numeric_only=True)
        .reset_index()
    )


def paired_effects(donor: pd.DataFrame) -> pd.DataFrame:
    long = donor.melt(
        id_vars=["Patient", "Lesion", "Basic_Celltype"],
        var_name="module",
        value_name="median_flux",
    )
    wide = long.pivot_table(
        index=["Patient", "Basic_Celltype", "module"],
        columns="Lesion",
        values="median_flux",
    ).dropna(subset=["Day4_Allergy", "Irritant"])
    wide["difference"] = wide["Day4_Allergy"] - wide["Irritant"]
    return wide.reset_index()


def main() -> None:
    FIGDIR.mkdir(parents=True, exist_ok=True)

    flux100 = read_flux(RES / "metabolism/scFEA/formal_imputed/scfea_flux.csv")
    flux50 = read_flux(RES / "metabolism/scFEA/sensitivity_epoch50/scfea_flux.csv")
    common_cells = flux100.index.intersection(flux50.index)
    common_modules = flux100.columns.intersection(flux50.columns)
    flat_rho = spearmanr(
        flux100.loc[common_cells, common_modules].to_numpy().ravel(),
        flux50.loc[common_cells, common_modules].to_numpy().ravel(),
    ).statistic
    donor100 = donor_flux(flux100)
    donor50 = donor_flux(flux50)
    eff100 = paired_effects(donor100)
    eff50 = paired_effects(donor50)
    em = eff100.merge(
        eff50,
        on=["Patient", "Basic_Celltype", "module"],
        suffixes=("_100", "_50"),
    )
    effect_rho = spearmanr(em["difference_100"], em["difference_50"]).statistic
    sens = pd.DataFrame(
        [
            ["cell_by_module_flux", len(common_cells) * len(common_modules), flat_rho],
            ["paired_donor_module_effect", len(em), effect_rho],
        ],
        columns=["comparison", "n_values", "spearman_rho_epoch50_vs_epoch100"],
    )
    sens.to_csv(RES / "metabolism/scFEA/scfea_epoch_sensitivity.tsv", sep="\t", index=False)

    traj = {}
    for lineage in ["APC", "KRT"]:
        m = pd.read_csv(RES / f"trajectory/{lineage}/trajectory_method_spearman.tsv", sep="\t", index_col=0)
        traj[lineage] = m.loc[["scTour", "Monocle2", "VECTOR"], ["scTour", "Monocle2", "VECTOR"]]

    cellchat = pd.read_csv(RES / "communication/CellChat/cellchat_aggregate_with_lodo_support.tsv", sep="\t")
    cpdb = pd.read_csv(RES / "communication/CellPhoneDB/cellphonedb_condition_comparison_q10.tsv", sep="\t")
    nn = pd.read_csv(RES / "communication/NicheNet/nichenet_aggregate_with_lodo_support.tsv", sep="\t")
    robust_cc = cellchat[cellchat["lodo_support_of_5"] >= 4]
    ligands = ["MIF", "LGALS9", "HBEGF", "CD99"]
    comm = pd.DataFrame(0.0, index=ligands, columns=["CellChat", "CellPhoneDB", "NicheNet"])
    for ligand in ligands:
        comm.loc[ligand, "CellChat"] = min(1, (robust_cc["ligand"] == ligand).sum() / 2)
        cpdb_hits = cpdb.astype(str).apply(lambda c: c.str.contains(ligand, case=False, regex=False)).any(axis=1)
        comm.loc[ligand, "CellPhoneDB"] = min(1, int(cpdb_hits.sum()))
        nsub = nn[nn["test_ligand"] == ligand]
        comm.loc[ligand, "NicheNet"] = 0 if nsub.empty else min(1, nsub["lodo_top20_support_of_5"].max() / 4)

    scm = pd.read_csv(RES / "metabolism/scMetabolism/scmetabolism_cross_method_summary.tsv", sep="\t")
    order = ["APC", "KRT", "LYMPH"]

    m108 = em[em["module"] == "M_108"].copy()
    m108["difference_x1e6"] = m108["difference_100"] * 1e6

    fig = plt.figure(figsize=(12.6, 9.0), constrained_layout=True)
    gs = fig.add_gridspec(2, 2)

    sub = gs[0, 0].subgridspec(1, 2, wspace=0.15)
    for i, lineage in enumerate(["APC", "KRT"]):
        ax = fig.add_subplot(sub[0, i])
        im = ax.imshow(traj[lineage], cmap="RdBu_r", vmin=-1, vmax=1)
        ax.set_xticks(range(3), traj[lineage].columns, rotation=45, ha="right")
        ax.set_yticks(range(3), traj[lineage].index if i == 0 else ["", "", ""])
        for r in range(3):
            for c in range(3):
                ax.text(c, r, f"{traj[lineage].iloc[r, c]:.2f}", ha="center", va="center", fontsize=8)
        ax.set_title(lineage, fontsize=10)
    fig.colorbar(im, ax=[fig.axes[0], fig.axes[1]], fraction=0.035, label="Cell-level Spearman ρ")
    fig.axes[0].text(-0.48, 1.20, "a", transform=fig.axes[0].transAxes, fontsize=15, fontweight="bold")
    fig.axes[0].text(0, 1.20, "Trajectory-method agreement", transform=fig.axes[0].transAxes, fontsize=11, fontweight="bold")

    ax = fig.add_subplot(gs[0, 1])
    im2 = ax.imshow(comm, cmap="Blues", vmin=0, vmax=1)
    ax.set_xticks(range(3), comm.columns, rotation=25, ha="right")
    ax.set_yticks(range(len(comm)), comm.index)
    for r in range(len(comm)):
        for c in range(3):
            ax.text(c, r, "supported" if comm.iloc[r, c] > 0 else "—", ha="center", va="center", fontsize=8)
    ax.set_title("b   Cross-framework communication candidates", loc="left", fontsize=11, fontweight="bold")

    ax = fig.add_subplot(gs[1, 0])
    x = np.arange(len(order))
    width = 0.34
    for j, sig in enumerate(["KEGG", "REACTOME"]):
        vals = [scm[(scm.Basic_Celltype == ct) & (scm.signature_type == sig)].spearman_rho.iloc[0] for ct in order]
        ax.bar(x + (j - 0.5) * width, vals, width, label=sig, color=["#4C78A8", "#F58518"][j])
    ax.set_xticks(x, order)
    ax.set_ylim(0, 0.8)
    ax.set_ylabel("AUCell–VISION effect Spearman ρ")
    ax.legend(frameon=False)
    ax.set_title("c   Metabolic-score agreement", loc="left", fontsize=11, fontweight="bold")

    ax = fig.add_subplot(gs[1, 1])
    colors = {"APC": "#00796B", "KRT": "#D95F02"}
    for j, ct in enumerate(["APC", "KRT"]):
        vals = m108[m108.Basic_Celltype == ct].sort_values("Patient")
        ax.scatter(np.full(len(vals), j), vals.difference_x1e6, s=42, color=colors[ct], zorder=3)
        ax.plot([j - 0.17, j + 0.17], [vals.difference_x1e6.median()] * 2, color="black", lw=2)
        for _, row in vals.iterrows():
            ax.text(j + 0.035, row.difference_x1e6, row.Patient, fontsize=7, va="center")
    ax.axhline(0, color="0.45", lw=0.8)
    ax.set_xticks([0, 1], ["APC", "KRT"])
    ax.set_ylabel("Day-4 allergy − irritant flux (×10⁻⁶)")
    ax.set_title("d   scFEA G6P → G1P module (M_108)", loc="left", fontsize=11, fontweight="bold")
    ax.text(0.02, 0.02, f"50 vs 100 epochs: donor-effect ρ = {effect_rho:.2f}", transform=ax.transAxes, fontsize=8)

    fig.suptitle("Orthogonal single-cell sensitivity analyses", fontsize=15, fontweight="bold")
    for stem in ["figure6", "figureS2"]:
        for ext in ["png", "pdf", "tif"]:
            fig.savefig(FIGDIR / f"{stem}.{ext}", dpi=400 if ext != "pdf" else 300, bbox_inches="tight")
    plt.close(fig)

    summary = pd.DataFrame(
        [
            ["Trajectory", "APC", "pairwise cell-level rho", f"{traj['APC'].to_numpy()[np.triu_indices(3, 1)].min():.3f} to {traj['APC'].to_numpy()[np.triu_indices(3, 1)].max():.3f}", "No donor contrast survived BH correction"],
            ["Trajectory", "KRT", "pairwise cell-level rho", f"{traj['KRT'].to_numpy()[np.triu_indices(3, 1)].min():.3f} to {traj['KRT'].to_numpy()[np.triu_indices(3, 1)].max():.3f}", "Day4-versus-irritant orientation was method-dependent"],
            ["Communication", "All", "CellChat robust LODO interactions", str(len(robust_cc)), "Supported in at least 4 of 5 donor omissions"],
            ["Communication", "All", "CellPhoneDB q<0.10 interaction-condition rows", str(len(cpdb)), "1,000 label permutations"],
            ["Metabolism", "All", "AUCell–VISION effect rho", f"{scm.spearman_rho.min():.3f} to {scm.spearman_rho.max():.3f}", "No pathway survived BH correction"],
            ["Metabolism", "All", "scFEA 50-versus-100-epoch donor-effect rho", f"{effect_rho:.3f}", "MAGIC-imputed exploratory flux; no module survived BH correction"],
        ],
        columns=["domain", "compartment", "robustness_quantity", "value", "interpretive_constraint"],
    )
    summary.to_csv(RES / "advanced_single_cell_summary.tsv", sep="\t", index=False)


if __name__ == "__main__":
    main()
