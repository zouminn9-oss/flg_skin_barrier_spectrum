#!/usr/bin/env python3
"""Create numbered 3x3 contact sheets for visual inspection of rendered DOCX pages."""

from pathlib import Path
from PIL import Image, ImageDraw

ROOT = Path("/Volumes/brilliant/flg_skin_barrier_spectrum/paper_rewriting_output/ijms_submission")
FOLDERS = [
    "rendered_endotype_final_main",
    "rendered_endotype_supp",
    "rendered_endotype_cover",
    "rendered_endotype_final_chinese",
]


def page_number(path: Path) -> int:
    return int(path.stem.split("-")[-1])


for folder_name in FOLDERS:
    folder = ROOT / folder_name
    pages = sorted(folder.glob("page-*.png"), key=page_number)
    for batch_index in range(0, len(pages), 9):
        batch = pages[batch_index:batch_index + 9]
        canvas = Image.new("RGB", (1500, 1980), "#d0d0d0")
        draw = ImageDraw.Draw(canvas)
        for slot, path in enumerate(batch):
            image = Image.open(path).convert("RGB")
            image.thumbnail((480, 620))
            x = 10 + (slot % 3) * 495 + (480 - image.width) // 2
            y = 28 + (slot // 3) * 650 + (620 - image.height) // 2
            canvas.paste(image, (x, y))
            draw.text((x, y - 20), f"page {page_number(path)}", fill="black")
        out = folder / f"contact-{batch_index // 9 + 1}.png"
        canvas.save(out, dpi=(150, 150))
        print(out)
