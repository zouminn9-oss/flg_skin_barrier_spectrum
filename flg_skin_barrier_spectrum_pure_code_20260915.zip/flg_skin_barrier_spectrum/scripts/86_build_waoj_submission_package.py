#!/usr/bin/env python3
"""Create a separate WAOJ package from the frozen September IJMS manuscript.

Does not modify the source manuscript or recompute biological results.
"""
from pathlib import Path
import re, json, hashlib, zipfile, shutil
from copy import deepcopy
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.text import WD_ALIGN_PARAGRAPH

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / 'paper_rewriting_output/ijms_submission/manuscript/ijms_manuscript.md'
DEST = ROOT / 'submission/WAOJ_Submission_20260913'
UP = DEST / '01_submission_files'
REV = DEST / '02_author_review'
SOURCE = DEST / '03_editable_sources'
for p in (UP, REV, SOURCE): p.mkdir(parents=True, exist_ok=True)
original = SRC.read_text()
TITLE = 'Cellular localization of a shared replication repair program in allergic and irritant skin inflammation'
SHORT = 'Replication repair in contact inflammation'

def section(name):
    m = re.search(r'^## '+re.escape(name)+r'\n(.*?)(?=^## |\Z)', original, re.M|re.S)
    assert m, name
    return m.group(1).strip()

intro = '''Allergic contact dermatitis (ACD) and irritant contact dermatitis (ICD) can produce similar erythema, pruritus and barrier disruption despite different initiating processes. ACD involves sensitization and antigen-specific immune responses, whereas ICD arises from direct injury and associated inflammation. Atopic dermatitis (AD) provides a related setting of chronic barrier dysfunction and immune activation, but shared transcriptional features do not make these conditions mechanistically interchangeable [1,2,3]. Identifying the cellular source of a shared response may help explain why whole-skin measurements obscure differences relevant to allergy research.

Cross-platform meta-analysis and tissue studies have identified recurrent AD signatures and substantial molecular heterogeneity [4,5,6]. Similarity network fusion can place such signatures in a cross-disease context [7,8]. Single-cell and spatial studies have resolved epithelial, stromal and immune states in inflammatory skin disease [9,10,11], while paired human challenge data show cell-specific transcriptional differences between allergic and irritant reactions [12]. Keratinocyte stress, antigen-presenting-cell (APC) activation and T-cell responses interact in contact inflammation, alongside overlapping epidermal, metabolic and proliferative programs [13,14,15,16,17,18,19]. Whether replication and repair pathways within this shared background show different compartment-level responses remains a testable question.

We used public transcriptomic datasets to identify a replication–repair program shared by AD and ACD and then examined its localization in paired allergic-versus-irritant challenge samples. A seven-disease network supplied the discovery context. A recurrent 16-gene subset was evaluated without refitting in an independent AD dataset, while the parent pathway program was tested separately in APCs and keratinocytes. These analyses address different questions: transfer of a tissue-level score and localization of a pathway response. Additional trajectory, communication, metabolic and regulatory models were used to prioritize hypotheses for future experiments, not to establish a diagnostic classifier or a causal mechanism.'''

results = section('2. Results')
captions = re.findall(r'^\*\*Figure \d\.\*\*.*$', results, re.M)
assert len(captions)==6
table_match = re.search(r'\*\*Table 1\.\*\*.*?\n\nAD, atopic dermatitis;.*?\n', results, re.S)
assert table_match
table = table_match.group(0).strip()
results = results.replace(table_match.group(0),'')
results = re.sub(r'^!\[\]\(.*\)\n?', '', results, flags=re.M)
results = re.sub(r'^\*\*Figure \d\.\*\*.*\n?', '', results, flags=re.M)
results = results.replace('Calibration across 396 network specifications establishes the AD–ACD edge', 'Specification calibration supports a conditional AD–ACD association')
results = results.replace('The compartment polarity is separable from proliferation', 'Compartment polarity persists after depletion of mitotic content')
results = results.replace('In the analysis branch carried forward for discovery,', 'The prespecified conservative REML criterion with modified Knapp–Hartung inference selected no pathway. Discovery therefore proceeded in the normal-theory REML sensitivity branch at q < 0.05. In that branch,')
results = results.replace('The edge therefore survives within-network multiplicity control, calibration of the specified grid and pathway resampling together.', 'These results support the edge conditional on the selected upstream analysis. Grid calibration addresses the enumerated fusion search, not the choice of meta-analytic estimator, pathway filters or view definitions.')
results = results.replace('All top 20 belonged to the stress/damage view.', 'All top 20 belonged to the stress/damage view. Because this view contributed to the selected representation and overlaps the all-positive view, its prominence is conditional on that representation.')
results = re.sub(r'The same network preserved interpretable structure elsewhere:.*?single high pairwise score\.\n\n', '', results, flags=re.S)
results = results.replace('All 16 had positive disease-level meta-effects in both AD and ACD (Figure 4c).', 'All 16 had positive disease-level meta-effects in both AD and ACD (Figure 4c), consistent with the direction-based selection rule rather than an independent validation of each gene.')
start = results.index('Biologically, the set spans five coupled operations')
end = results.index('### 2.5.',start)
results = results[:start]+results[end:]
results = results.replace('and adjustment assigned the shared coefficient to this tissue-renewal axis', 'and the LAD coefficient was not distinguishable from zero after adjustment')
results = results.replace("This result defines the score's whole-biopsy use: it captures coordinated replication-surveillance demand arising from lesional renewal, inflammatory turnover and tissue composition.", 'The external association is therefore compatible with a proliferation-linked tissue state; it does not establish an increment beyond proliferation or distinguish cell-state from cell-composition effects.')
results = results.replace('Cell-resolved analyses below then separate this portable tissue-activity readout from compartment-intrinsic deployment.', 'This dataset does not independently validate an ACD-versus-ICD compartment contrast. The following analysis tests the parent pathway program rather than assuming that the 16-gene score has equivalent cellular behavior.')
results = results.replace('(permutation P = 0.011, q = 0.044)', '(two-sided permutation P = 0.022, q = 0.044)')
results = results.replace('−0.941 (P = 0.001, q = 0.009)', '−0.941 (two-sided P = 0.002, q = 0.009)')
results = results.replace('Both directions were invariant to the composition of the program:', 'Direct core-gene scores were not significant (APC and keratinocyte q = 0.895); only 7 of 16 genes were measurable in APCs and 6 in keratinocytes. The parent pathway result is therefore not direct validation of the compact score. Both pathway directions survived every individual omission:')
results = results.replace('Allergic challenge therefore engages this stress-surveillance state in the antigen-presenting compartment, while irritant injury engages a stronger epithelial repair and replication response, which explains how the same class of pathways participates in both responses while separating them by cell type.', 'The pathway contrast is consistent with different epithelial and immune responses to the two challenges. The matched-pathway permutation assesses program enrichment conditional on donor-aware gene contrasts; it is not a permutation test over independent participants.')
start=results.index('Direct proliferation measurement pointed the same way:')
end=results.index('\n\n### 2.8.',start)
results=results[:start]+'''Of 20 canonical proliferation markers, none was measurable in the APC pseudobulk after expression filtering. In keratinocytes, seven measurable markers gave a score of −0.345 (P = 0.193). Lack of measurable APC markers prevents exclusion of proliferation as an explanation. Removing mitotic annotations demonstrates persistence of the pathway direction, not independence from S-phase activity or cellular turnover.'''+results[end:]
results=results.replace('Orthogonal models map the program to state, communication and metabolic hypotheses','Additional transcriptomic models prioritize state and signaling hypotheses')
results=results.replace('three unrelated trajectory algorithms', 'three trajectory algorithms')
results=results.replace('Metabolic scoring provided a second orthogonal map', 'Metabolic scoring provided an additional transcript-derived analysis')
results=results.replace('scFEA independently predicted', 'scFEA predicted')
results=results.replace('YY1 thereby provides the leading regulatory entry point.', 'This is a model-based prioritization, not an observed knockout effect. No transcription factor survived correction across all 306 tested regulons.')
results=results.replace('; This is a model-based', '. This is a model-based')
results=results.replace('A network edge is only as strong as the search that produced it, so we enumerated', 'We enumerated')
results=results.replace('Together, these layers convert the descriptive compartment polarity into a prioritized experimental panel;', 'These exploratory analyses nominate experimental candidates;')

discussion='''The main allergy-related finding is an opposite pathway response in APCs and keratinocytes within paired allergic and irritant challenge samples. The bulk-derived replication–repair program was higher under allergic challenge in APCs and higher under irritant challenge in keratinocytes. Separately, a fixed 16-gene subset generalized to an independent AD dataset as a proliferation-linked whole-biopsy signal. These observations suggest that a shared tissue program can have different cellular sources, but they do not establish that the compact gene score itself discriminates ACD from ICD.

The compartment result extends earlier work on keratinocyte stress, dendritic-cell activation and antigen-specific responses in contact inflammation [13,14,15,16,17,18,19]. Replication-stress and DNA-damage responses provide plausible links between tissue injury and immune activation [30,31,32]. An epithelial repair response after irritant exposure and an APC-associated response after allergic challenge are biologically compatible interpretations of the observed directions. However, RNA abundance does not measure DNA lesions, checkpoint activity or repair flux. The APC compartment also pools heterogeneous cell populations, so a shift within that compartment could reflect changing subtype composition as well as a change within individual cells.

External validation improves confidence in the transferability of the tissue-level score while constraining its meaning. The GSE328048 analysis used fixed genes and weights, and repeated-title aggregation, gene omission and abundance-matched random sets supported the lesional-AD association. Nevertheless, the score correlated strongly with proliferation and had no residual LAD association after proliferation adjustment. It should therefore be interpreted as a candidate measure of lesional replication and renewal, not a proliferation-independent marker of allergic inflammation. The public dataset does not expose a direct library-to-donor key; biopsy-level results and metadata-based sensitivity analyses cannot substitute for a verified participant-level design.

Several discovery-stage limitations further delimit inference. The conservative meta-analytic criterion selected no pathways, and the normal-theory sensitivity branch was used for subsequent discovery. The 396-specification calibration controls selection within that fusion grid while upstream feature definitions remain fixed. Overlap between pathway views and shared Reactome genes limits the independence of supporting annotations. Gene-direction recurrence partly follows from the selection rule, and the leave-one-cohort audit is an internal stability analysis with the pathway background held fixed. These results support an exploratory transcriptomic program rather than confirmatory evidence for a prespecified disease mechanism.

At cellular resolution, the decisive contrast rests on five paired donors. Pathway-matched permutations quantify enrichment conditional on their estimated gene effects; they do not increase the number of independent participants. Persistence after removing mitotic content is informative, but the absence of measurable proliferation markers in APCs leaves cell-cycle contributions unresolved. The 16-gene subset and parent pathway score require direct comparison in an independent ACD–ICD cohort before either is used as a compartment-resolved biomarker.

The downstream analyses identify possible experiments rather than additional mechanistic validation. MIF–CD74 and galectin-9 are biologically plausible communication candidates [33,34], but ligand–receptor compatibility does not demonstrate physical signaling. Trajectory and metabolic contrasts did not survive donor-level false-discovery correction, and transcript-derived fluxes are not metabolite measurements. YY1 prioritization depends on a fitted regulatory model, while no factor survived the full regulon screen. These limits should guide interpretation of the apparent agreement between methods applied to the same transcriptomes.

For allergy research, the next step is paired spatial or cell-resolved analysis of independently collected patch-test tissue, with verified donor identities and assessment of APC subtypes. Keratinocyte–APC models could test whether MIF/CD74, galectin-9 or YY1 perturbation changes the pathway response alongside proliferation and DNA-damage measurements. This would complement the distinct keratinocyte and dendritic-cell activation events recognized in skin-sensitization frameworks [35,36]. Clinical discrimination, sensitization assessment, treatment selection and response monitoring remain future applications requiring dedicated cohorts, prespecified thresholds and prospective validation.'''

methods=section('4. Materials and Methods')
advanced = re.search(r'### 4\.12\..*?(?=### 4\.13\.)',methods,re.S).group(0)
methods=methods.replace(advanced,'''### 4.12. Additional single cell analyses

Matched, stratified samples of 2,000 APCs or keratinocytes were analyzed with scTour, VECTOR and Monocle2 [21,22,23]. Communication analysis used 1,874 donor- and condition-balanced cells with CellChat, CellPhoneDB and NicheNet [24,25,26]. AUCell and VISION pathway scores and scFEA relative flux estimates were summarized at donor level [27,28]. Trajectory and metabolic contrasts used exact two-sided sign-flip tests and within-family false-discovery correction. Complete parameters, axis-orientation rules, the scFEA numerical patch and sensitivity fits are provided in Supplementary Methods.

''')
methods=methods.replace('Cell-cycle independence of the compartment result','Sensitivity to mitotic pathway content')
methods=methods.replace('using an independent permutation seed; permutation values for the full program therefore differ from the primary analysis in the third decimal.', 'using an independent seed. Figure 5e and Table S9 report directional P values; primary localization uses two-sided P values and BH correction.')
methods=methods.replace('the resulting enrichment P values were adjusted across the four compartments.', 'two-sided enrichment P values, defined as twice the smaller directional tail and capped at one, were BH-adjusted across four compartments.')
methods=methods.replace('The number of independent participants, not cells or replicates, defines every sample size.', 'Participant identities define the inferential unit wherever available. In GSE328048, the reported primary unit is the deposited biopsy because the public library-to-donor key is unavailable; clustering sensitivities are reported separately.')
methods=methods.replace('Single cells, technical replicates, repeated sites and repeated time points were never treated as independent participants.', 'Single cells and technical replicates were not treated as independent participants. Participant pairing was retained when available; the external dataset with unresolved donor identifiers was analyzed at biopsy level with clustering sensitivities.')
methods=methods.replace('All analysis scripts, thresholds, random seeds, source checksums and result paths are included in the reproducibility materials.', 'Supplementary Table S8 indexes analysis scripts, thresholds, random seeds, source checksums and result paths in the project reproducibility materials.')
for number, replacement in {
    11: '''### 4.11. Regulator and compound prioritization

APC gene statistics were projected onto 306 CollecTRI regulons with gene-label permutation and full-family false-discovery correction [29]. Five nominally prioritized, core-connected factors entered a signed-regulon ridge model. Virtual knockout removed a fitted contribution, with gene-bootstrap and maximum-of-five network-null sensitivity analyses. Sci-Plex and LINCS/CMap chemical signatures were screened as perturbation probes, not therapies [40,41]. Complete parameters and selection rules appear in Supplementary Methods and Table S7.

''',
    13: '''### 4.13. Statistical interpretation

Meta-analysis combined cohort effects rather than pooled expression matrices. Network P values used plus-one permutation correction, with BH correction across 21 edges and maximum-statistic calibration across the specified fusion grid. These tests are conditional on the upstream sensitivity branch, pathway filtering and view definitions. Cellular pathway enrichment uses size-matched pathway permutations conditional on contrasts from five paired donors; it is not a participant-level randomization test. GSE328048 uses deposited biopsies as the primary public unit, with metadata-based clustering sensitivities. Full inferential scopes and downstream evidence-family definitions are provided in Supplementary Methods [38,39].

''',
    14: '''### 4.14. Reproducibility

Supplementary Table S8 indexes the reproducibility materials. External-validation outputs include matrix QC, biopsy and clustered scores, permutations, gene omissions and proliferation-adjusted models. Supplementary Table S10 indexes additional single-cell results and the scFEA source patch. Missing genetic, functional or spatial evidence was not imputed; only transcriptomic and pathway data covered all seven disease nodes.

'''
}.items():
    match=re.search(rf'### 4\.{number}\..*?(?=### 4\.|\Z)',methods,re.S)
    assert match
    advanced+='\n\n'+match.group(0)
    methods=methods.replace(match.group(0),replacement)
conclusion='''A replication–repair pathway program shared by AD and ACD showed opposite APC and keratinocyte responses in five paired allergic and irritant challenges. An associated 16-gene score separately generalized to AD whole biopsies as a proliferation-linked tissue signal. Together, the analyses motivate independent tests of cellular localization in contact inflammation without establishing causal regulation, diagnostic performance for ACD versus ICD, or clinical utility.'''

abstract='''**Background:** Allergic and irritant contact reactions share visible inflammatory features, but antigen-driven immunity and direct epithelial injury may engage shared molecular programs in different cell compartments. We investigated the cellular localization of a replication–repair program identified across inflammatory skin diseases.

**Methods:** Public transcriptomic data were integrated across seven skin diseases. A normal-theory random-effects sensitivity branch was used after the conservative meta-analytic criterion selected no pathways. The AD–ACD relationship was evaluated across 396 similarity-network-fusion specifications with maximum-statistic calibration. A recurrent 16-gene subset was applied without refitting to independent atopic dermatitis (AD) biopsies. The parent pathway program was evaluated separately in donor-aware pseudobulk profiles from five paired allergic and irritant challenges. Additional transcriptomic models prioritized exploratory signaling and regulatory hypotheses.

**Results:** The selected AD–ACD edge ranked third among 21 pairs (conditional q = 0.001; grid-calibrated P = 0.010). In challenge samples, the program was higher under allergy in antigen-presenting cells (APCs; pathway-matched q = 0.044) and higher under irritation in keratinocytes (q = 0.009). Both directions persisted after removal of mitotic pathway content. In independent whole biopsies, the fixed score was higher in 54 lesional AD than 23 healthy samples (AUC = 0.827; 95% CI, 0.721–0.913). It correlated with proliferation (ρ = 0.915), with no residual AD association after adjustment (P = 0.904). Donor-level trajectory and metabolic comparisons did not survive false-discovery correction.

**Conclusions:** A shared replication–repair program showed contrasting cellular localization in allergic and irritant inflammation. External validation supports a proliferation-linked AD tissue signal, not independent replication of the APC–keratinocyte contrast. The findings provide a hypothesis for contact-inflammation research that requires independent cellular and functional validation before clinical application.'''
keywords='allergic contact dermatitis; irritant contact dermatitis; atopic dermatitis; antigen-presenting cells; transcriptomics'

captions[4]=captions[4].replace('The fixed program is deployed in opposite directions by APCs and keratinocytes, independently of proliferation.', 'The fixed pathway program has opposite APC and keratinocyte directions that persist after depletion of mitotic content.')
captions[4]=captions[4].replace('same permutation procedure under an independent seed, so full-program values differ from **a** in the third decimal.', 'directional permutation P values under an independent seed; panel **a** reports BH q values based on two-sided P values.')
captions[4]+=' Absence of measurable proliferation markers does not establish absence of proliferation.'
captions[5]=captions[5].replace('Orthogonal single-cell models','Additional single-cell models')
captions[3]=captions[3].replace('all 16 genes are positive in both diseases.', 'all 16 genes are positive in both diseases, consistent with their direction-based selection.')
refs={int(m.group(1)):m.group(2) for m in re.finditer(r'^(\d+)\. (.*)$',section('References'),re.M)}
assert len(refs)==41

def unnumber(t): return re.sub(r'^### \d+\.\d+\. ', '### ',t,flags=re.M)
body='\n\n'.join(['## Introduction',intro,'## Methods',unnumber(methods),'## Results',unnumber(results),'## Discussion',discussion,'## Conclusions',conclusion])
order=[]
for m in re.finditer(r'\[(\d+(?:,\s*\d+)*)\]',body):
    for x in map(int,m.group(1).replace(' ','').split(',')):
        if x not in order: order.append(x)
assert set(order)==set(refs), (set(refs)-set(order))
refmap={old:i+1 for i,old in enumerate(order)}
def renumber(t):
    return re.sub(r'\[(\d+(?:,\s*\d+)*)\]',lambda m:'['+','.join(str(refmap[int(x)]) for x in m.group(1).replace(' ','').split(','))+']',t)
body=renumber(body)
def vancouver(r):
    r=re.sub(r'\*+', '',r)
    if r.startswith('OECD.'):
        return r.replace('; OECD Guidelines', '. OECD Guidelines').replace('; OECD Publishing: Paris, France,', '. Paris: OECD Publishing;')
    m=re.match(r'(.*?)\. (.*?)\. ([^*]+?) (\d{4}), (\d+), (.*)\.$',r)
    assert m, r
    auth,title,journal,year,vol,pages=m.groups()
    authors=[]
    for a in auth.split('; '):
        if a=='et al': authors.append('et al'); continue
        if ', ' in a:
            surname,initial=a.split(', ',1); authors.append(surname+' '+initial.replace('.','').replace(' ',''))
        else: authors.append(a)
    return ', '.join(authors)+'. '+title+'. '+journal+' '+year+';'+vol+':'+pages+'.'
reference_text='\n\n'.join(f'{i+1}. {vancouver(refs[n])}' for i,n in enumerate(order))

declarations='''## Abbreviations

ACD, allergic contact dermatitis; AD, atopic dermatitis; APC, antigen-presenting cell; BH, Benjamini–Hochberg; GEO, Gene Expression Omnibus; HC, healthy control; HS, hidradenitis suppurativa; ICD, irritant contact dermatitis; LAD, lesional atopic dermatitis; NAD, nonlesional atopic dermatitis; REML, restricted maximum likelihood; SNF, similarity network fusion.

## Ethics approval and consent to participate

This secondary analysis used de-identified data from public repositories and involved no new recruitment, specimens or animal experiments. Source-study ethics and consent information is provided in the original publications and repository records. No new ethics approval number is claimed for this reanalysis.

## Consent for publication

Not applicable. No identifiable individual information is reported.

## Availability of data and materials

The public source accessions are listed in Table 1. Supplementary Tables S1–S11 report the supporting results and index the reproducibility materials. The project repository address and author-identifying declarations are supplied separately to the editors for review blinding.

## Funding and competing interests

This research received no external funding. The authors declare no competing interests.

## Declaration of generative AI and AI assisted technologies in manuscript preparation

During preparation of this manuscript, the authors used OpenAI ChatGPT and Codex to assist with language revision, manuscript restructuring and document formatting. The authors are responsible for reviewing and verifying the resulting text and for the scientific content of the submission.

## Supplementary material

Supplementary Information contains extended methods, Figures S1–S2 and Tables S1–S11. All downstream models are exploratory; the external validation concerns the AD tissue-level score rather than the allergic-versus-irritant compartment contrast.'''
manuscript=f'# {TITLE}\n\n## Abstract\n\n{abstract}\n\n**Keywords:** {keywords}\n\n{body}\n\n{declarations}\n\n## References\n\n{reference_text}\n\n## Table\n\n{table}\n\n## Figure legends\n\n'+ '\n\n'.join(captions)
manuscript=re.sub(r'\n{3,}','\n\n',manuscript)
(SOURCE/'waoj_manuscript.md').write_text(manuscript)
(SOURCE/'reference_number_mapping.json').write_text(json.dumps(refmap,indent=2))

def words(t): return len(re.findall(r"\b[\w]+(?:[’'−–-][\w]+)*\b", re.sub(r'\[[\d, ]+\]','',t)))
abstract_wc=words(re.sub(r'\*\*(Background|Methods|Results|Conclusions):\*\*','',abstract))
body_wc=words(re.sub(r'^#{2,3} .*$', '',body,flags=re.M))

def add_inline(p,text):
    tokens=re.split(r'(\*\*.*?\*\*|\*[^*]+?\*|\[\d+(?:,\d+)*\])',text)
    for tok in tokens:
        if not tok: continue
        r=p.add_run(tok.strip('*') if tok.startswith('*') else tok)
        if tok.startswith('**'): r.bold=True
        elif tok.startswith('*'): r.italic=True
        elif re.fullmatch(r'\[\d+(?:,\d+)*\]',tok): r.text=tok[1:-1]; r.font.superscript=True

def style_doc(d,double=True,header=True):
    for s in d.sections:
        s.page_width=Inches(8.5); s.page_height=Inches(11)
        s.top_margin=s.bottom_margin=Inches(.8)
        s.left_margin=s.right_margin=Inches(.9)
        if header:
            p=s.header.paragraphs[0];p.text=SHORT;p.style=d.styles['Header']
        p=s.footer.paragraphs[0];p.alignment=WD_ALIGN_PARAGRAPH.CENTER
        f=OxmlElement('w:fldSimple');f.set(qn('w:instr'),'PAGE');p._p.append(f)
    for name in ('Normal','Title','Heading 1','Heading 2','Heading 3','Header','Footer'):
        s=d.styles[name];s.font.name='Times New Roman';s.font.color.rgb=RGBColor(0,0,0)
        fonts=s.element.get_or_add_rPr().rFonts
        if fonts is not None:
            for a in list(fonts.attrib):
                if 'theme' in a.lower():del fonts.attrib[a]
        s.font.size=Pt(12 if name!='Title' else 16)
        s.paragraph_format.space_after=Pt(6)
        s.paragraph_format.line_spacing=2 if double and name=='Normal' else 1.1
        if name.startswith('Heading'):s.paragraph_format.keep_with_next=True
    for element in d.styles.element.iter():
        for child in list(element):
            if child.tag==qn('w:pBdr'):element.remove(child)
    d.core_properties.author='';d.core_properties.last_modified_by=''
    d.core_properties.title=TITLE

def make_doc(md,path,double=True):
    d=Document();style_doc(d,double)
    blocks=md.strip().split('\n\n')
    for b in blocks:
        b=b.strip()
        if not b:continue
        if b.startswith('|'):
            rows=[x for x in b.splitlines() if x.startswith('|') and not re.match(r'\|\s*[-:]+',x)]
            cells=[[x.strip() for x in r.strip('|').split('|')] for r in rows]
            t=d.add_table(rows=0,cols=len(cells[0]));t.autofit=False
            widths=[2.05,.65,1.35,2.55]
            for ri,row in enumerate(cells):
                for ci,(c,txt) in enumerate(zip(t.add_row().cells,row)):
                    c.width=Inches(widths[ci]);add_inline(c.paragraphs[0],txt)
                    for p in c.paragraphs:
                        p.paragraph_format.line_spacing=1.05
                        for r in p.runs:r.font.size=Pt(10)
                    tcPr=c._tc.get_or_add_tcPr();border=OxmlElement('w:tcBorders')
                    for edge in ('top','left','bottom','right'):
                        e=OxmlElement('w:'+edge);e.set(qn('w:val'),'single');e.set(qn('w:sz'),'4');e.set(qn('w:color'),'D9D9D9');border.append(e)
                    tcPr.append(border)
                    if ri==0:
                        sh=OxmlElement('w:shd');sh.set(qn('w:fill'),'E7E6E6');tcPr.append(sh)
                        for r in c.paragraphs[0].runs:r.bold=True
                if ri==0:
                    repeat=OxmlElement('w:tblHeader');t.rows[-1]._tr.get_or_add_trPr().append(repeat)
            continue
        if b.startswith('# '):d.add_paragraph(b[2:],style='Title');continue
        if b.startswith('## '):
            p=d.add_paragraph(b[3:],style='Heading 1')
            if b[3:] in ('References','Table','Figure legends'):p.paragraph_format.page_break_before=True
            continue
        if b.startswith('### '):d.add_paragraph(b[4:],style='Heading 2');continue
        p=d.add_paragraph();add_inline(p,b.replace('\n','\n'))
    d.save(path);return d

make_doc(manuscript,UP/'waoj_manuscript_blinded.docx')
authors=original.split('\n\n')[2:5]
titlepage=f'''# {TITLE}

Article type: Research article

Short title: {SHORT}

Yue-Min Zou¹, Si-Ran Bao¹, Yi-Ming Qi¹ and Jie Ma²

¹ Beijing University of Chinese Medicine, Beijing, China

² Xiyuan Hospital of China Academy of Chinese Medical Sciences, Beijing, China

Corresponding author: Jie Ma, Xiyuan Hospital of China Academy of Chinese Medical Sciences, No. 1 Xiyuan Caochang, Haidian District, Beijing 100091, P.R. China. Email: majiexyyy@126.com. Telephone: +86-10-62835103.

Author emails: Yue-Min Zou, ydkabb@163.com; Si-Ran Bao, 17835489728@163.com; Yi-Ming Qi, 20190125040@bucm.edu.cn; Jie Ma, majiexyyy@126.com.

Abstract: {abstract_wc} words. Main text: {body_wc} words, excluding abstract, section headings, declarations, references, table and figure legends. Six main figures, one main table, two supplementary figures and eleven supplementary table numbers. References: 41.

## Author contributions

{section('Author Contributions').replace('All authors have read and agreed to the published version of the manuscript.','')}

## Funding

This research received no external funding.

## Competing interests

The authors declare no competing interests.

## Acknowledgments

We acknowledge the investigators who generated and publicly deposited the datasets reanalyzed here.

## Project repository

https://github.com/zouminn9-oss/flg_skin_barrier_spectrum

## Declaration of generative AI and AI assisted technologies in manuscript preparation

OpenAI ChatGPT and Codex assisted with language revision, manuscript restructuring and document formatting. Final scientific verification and approval remain the responsibility of all authors.
'''
make_doc(titlepage,UP/'title_page.docx',False)
(SOURCE/'title_page.md').write_text(titlepage)
cover=f'''13 September 2026

Editors

World Allergy Organization Journal

Dear Editors,

We submit “{TITLE}” for consideration as a Research article in World Allergy Organization Journal.

The manuscript addresses a question relevant to contact allergy: whether a molecular program shared across inflammatory skin diseases differs in its cellular localization between allergic and irritant reactions. Using existing public datasets, we identified a replication–repair program linking atopic dermatitis and allergic contact dermatitis. In donor-aware analyses of five paired challenge participants, the parent pathway program was allergy-high in antigen-presenting cells and irritant-high in keratinocytes. These directions persisted after individual pathway omission and depletion of mitotic pathway content.

A separate, fixed 16-gene subset was evaluated without refitting in independent AD biopsies. Its lesional-versus-healthy AUC was 0.827, but it correlated strongly with proliferation and had no residual association after adjustment. We therefore distinguish external transfer of a tissue-level score from the small-sample cellular contrast; we do not claim an independently validated ACD–ICD classifier, a causal mechanism or a treatment-selection tool.

We believe the study will interest readers investigating allergic contact inflammation and epithelial–immune interactions. The cross-disease analysis supplies biological context, while the challenge data identify a compartment-specific hypothesis for independent spatial and functional testing. The manuscript reports the negative conservative meta-analysis, the conditional scope of the 396-specification calibration and the exploratory status of downstream signaling and regulatory models.

The work reanalyzes de-identified public data and includes no new human or animal experiments. Source accessions, supporting results and reproducibility information accompany the manuscript. The authors declare no competing interests and received no external funding. Assistance from OpenAI ChatGPT and Codex in manuscript preparation is disclosed in the manuscript.

Thank you for considering our work.

Sincerely,

Jie Ma, corresponding author

Xiyuan Hospital of China Academy of Chinese Medical Sciences

No. 1 Xiyuan Caochang, Haidian District, Beijing 100091, P.R. China

majiexyyy@126.com | +86-10-62835103
'''
make_doc(cover,UP/'cover_letter.docx',False)
(SOURCE/'cover_letter.md').write_text(cover)
highlights=[
'A shared replication repair program links atopic and allergic contact dermatitis.',
'Paired challenges show opposite APC and keratinocyte pathway responses.',
'A fixed 16 gene score generalizes to AD biopsies and tracks proliferation.',
'Independent cohorts must test the cellular contrast before clinical use.'
]
assert all(len(h)<=85 for h in highlights)
highlight_md='# Highlights\n\n'+'\n\n'.join('• '+h for h in highlights)
make_doc(highlight_md,UP/'highlights.docx',False)
(SOURCE/'highlights.md').write_text(highlight_md)

prior=ROOT/'submission/IJMS_Submission_20260911/01_upload_ready'
sup=Document(prior/'supplementary_information.docx')
from docx.enum.style import WD_STYLE_TYPE
if 'Heading 1' not in sup.styles:
    st=sup.styles.add_style('Heading 1',WD_STYLE_TYPE.PARAGRAPH)
    st.font.name='Times New Roman';st.font.size=Pt(13);st.font.bold=True
    st.paragraph_format.keep_with_next=True
for p in sup.paragraphs:
    if p.text.lower().startswith('antigen-presenting cells and keratinocytes deploy'):p.text=TITLE
    if 'selected transcriptomic branch used four pathway views' in p.text:
        p.text=p.text.replace('used four pathway views','used the all-positive and stress/damage pathway views, selected from four candidate views,')
    if 'Cell-cycle independence of the compartment result' in p.text:
        p.text=p.text.replace('Cell-cycle independence of the compartment result','Sensitivity to mitotic pathway content')
    if 'Supplementary methods'==p.text:
        p.text='Supplementary methods overview'
    if p.text.startswith('Compartment scores are mean signed z statistics'):
        p.text=p.text.replace('under an independent seed.', 'under an independent seed. Table S9 reports directional P values; Table S5 reports two-sided P values and their BH correction.')
    for r in p.runs:r.font.color.rgb=RGBColor(0,0,0)
for st in sup.styles:
    if st.type==WD_STYLE_TYPE.PARAGRAPH:
        st.font.color.rgb=RGBColor(0,0,0)
for ti,t in enumerate(sup.tables):
    t.autofit=False
    n=len(t.columns)
    widths=([.4,2.5,1.3,1.1,1.1,1.1,1.5] if ti==2 else [9.9/n]*n)
    if ti==7:widths=[3.0,6.9]
    for rowi,row in enumerate(t.rows):
        row._tr.get_or_add_trPr().append(OxmlElement('w:cantSplit'))
        for ci,c in enumerate(row.cells):
            c.width=Inches(widths[ci])
            for p in c.paragraphs:
                p.paragraph_format.line_spacing=1.05;p.paragraph_format.space_after=Pt(2)
                for r in p.runs:r.font.size=Pt(9);r.font.name='Times New Roman';r.font.color.rgb=RGBColor(0,0,0)
            tcPr=c._tc.get_or_add_tcPr();border=OxmlElement('w:tcBorders')
            for edge in ('top','left','bottom','right'):
                e=OxmlElement('w:'+edge);e.set(qn('w:val'),'single');e.set(qn('w:sz'),'4');e.set(qn('w:color'),'D9D9D9');border.append(e)
            tcPr.append(border)
            if rowi==0:
                sh=OxmlElement('w:shd');sh.set(qn('w:fill'),'E7E6E6');tcPr.append(sh)
                for p in c.paragraphs:
                    for r in p.runs:r.bold=True
        if rowi==0:
            repeat=OxmlElement('w:tblHeader');row._tr.get_or_add_trPr().append(repeat)
    if ti==4:t.cell(0,5).text='Two-sided P'
    if ti==7:
        for row in t.rows:
            if row.cells[0].text=='Main manuscript source':
                row.cells[1].text='submission/WAOJ_Submission_20260913/03_editable_sources/waoj_manuscript.md'
    for row in t.rows:
        for c in row.cells:
            for p in c.paragraphs:
                for r in p.runs:r.font.size=Pt(9);r.font.name='Times New Roman'
sup.add_page_break();sup.add_heading('Extended single cell methods',level=1)
for b in renumber(unnumber(advanced)).split('\n\n')[1:]:
    if b.startswith('### '):sup.add_heading(b[4:].strip(),level=1)
    elif b.strip():p=sup.add_paragraph();add_inline(p,b.strip())
sup.add_heading('Interpretation of compartment enrichment',level=1)
sup.add_paragraph('The parent pathway program and the recurrent 16-gene score are distinct inferential objects. Matched-pathway permutation P values assess enrichment conditional on donor-aware effects and do not increase the number of independent donors. Persistence after mitotic-content depletion does not establish proliferation independence. The full transcription-factor screen did not yield an FDR-significant regulator. Downstream computational perturbations are candidate-generating models, not observed biological interventions.')
sup.add_paragraph('References in these extended methods use the numbering of the main manuscript.')
# Preserve tested table and figure geometry; change only identifying headers and title.
for s in sup.sections:
    for p in s.header.paragraphs:p.text=SHORT
sup.core_properties.author='';sup.core_properties.last_modified_by='';sup.core_properties.title='Supplementary Information'
sup.save(UP/'supplementary_information.docx')
with zipfile.ZipFile(prior/'figures.zip') as z:
    for name in z.namelist():
        assert '/' not in name and name.endswith('.tif'),name
        (UP/name).write_bytes(z.read(name))

(REV/'ABSTRACT_FOR_PORTAL.txt').write_text(re.sub(r'\*\*','',abstract)+'\n\nKeywords: '+keywords+'\n')
(REV/'DECLARATIONS_FOR_AUTHOR_CONFIRMATION.md').write_text('''# 投稿前必须由作者确认

- 本稿未发表且当前未在其他期刊审理。存在 IJMS 投稿包不等于已投稿；若 IJMS 已在审，不得同时投 WAOJ。
- 全体作者已审阅并批准这个 WAOJ 新版本及作者顺序、贡献、署名、通讯信息。
- 无外部资助及无利益冲突的声明仍准确。
- 由作者或所在机构确认公共数据二次分析的伦理适用性；不得把自动生成的说明当作机构出具的伦理豁免。
- 核对生成式 AI 声明是否覆盖实际使用范围；如分析代码、图或其他研究步骤也使用过 AI，应如实补充。此包明确披露了本次写作、结构和排版辅助。
- 核对公开代码仓库是否可访问，并包含 9 月新增 GSE328048 分析及最新脚本与结果。本文没有验证远程仓库的完整内容，也没有推送或公开任何文件。
- 确认后，可在 cover letter 倒数第二段后加入：The manuscript has not been published previously, is not under consideration elsewhere, and all authors have approved this submission.
- 在投稿系统中确认实际文章类别、盲审模式、允许的 Word 扩展名、摘要限制、推荐审稿人、声明表及费用。没有签名、支付或在线提交被代为完成。
''')
(REV/'JOURNAL_REQUIREMENTS_AND_UPLOAD_ORDER.md').write_text(f'''# WAOJ 投稿规格和上传顺序

核查日期：2026-09-13。

官方指南：https://www.sciencedirect.com/journal/world-allergy-organization-journal/publish/guide-for-authors

期刊作者页面：https://www.worldallergyorganizationjournal.org/content/authorinfo

投稿系统：https://www.editorialmanager.com/waoj/default.aspx

官方范围包括过敏、哮喘、过敏反应和临床免疫学中的机制、转化和临床研究。近一年纯公共数据先例：https://pmc.ncbi.nlm.nih.gov/articles/PMC12491865/

访问限制：本次官方指南页面返回访问错误，浏览器备用读取也未成功。因此不能将下列历史规格宣称为已核实的 2026 现行硬性要求。公开转载的历史指南列出 Research 摘要 250–400 词、正文 4000–5000 词、3–5 个关键词、4–8 个图表、40–50 篇参考文献、12 磅双倍行距、页码、匿名主稿、单独标题页及独立图文件。本包按这些保守兼容规格准备，最终以投稿系统当日指南为准。参考转载：https://m.mcdurieux.com/displayj.aspx?jid=16630

当前统计：摘要 {abstract_wc} 词；正文 {body_wc} 词；5 个关键词；6 图加 1 表；41 篇参考文献。Word 主稿为可编辑 .docx，主图未嵌入，表格在参考文献之后，图注在文末；无手工行号。Highlights 是备用文件，不能据此认定期刊强制要求。

| 顺序 | 文件 | 上传角色 |
|---|---|---|
| 1 | cover_letter.docx | Cover letter，仅编辑可见 |
| 2 | title_page.docx | Title page，含全部作者身份信息 |
| 3 | waoj_manuscript_blinded.docx | Main manuscript，匿名正文 |
| 4 | figure1.tif 至 figure6.tif | 各自作为 Figure 上传 |
| 5 | supplementary_information.docx | Supplementary material，含 S1–S11 及 S1–S2 |
| 6 | figureS1.tif、figureS2.tif | 系统需要独立补图时上传 |
| 7 | highlights.docx | 系统提供或要求 Highlights 类别时上传 |

勿将整个 ZIP 作为主稿上传；ZIP 是本地交付容器。02_author_review 和 03_editable_sources 不上传审稿系统。若系统采取非匿名审稿，可使用独立 title page 配合主稿，不要自行丢弃作者页。公开代码链接目前保留在作者页，须按系统盲审规则设置匿名审稿访问方式。
''')
(REV/'SCIENTIFIC_CHANGE_LOG.md').write_text('''# 相对 9 月 12 日 IJMS 稿的修改

1. 标题、摘要、引言和讨论聚焦过敏与刺激性接触炎症；不再称已建立临床 endotype 或治疗选择工具。
2. 结构改为 Introduction–Methods–Results–Discussion–Conclusions；重新按首次出现顺序编号全部 41 篇参考文献，转换为简洁数字引用格式。
3. 明确区分 16 基因组织评分与 parent pathway program；不把 AD 整体组织验证写成 ACD–ICD 细胞差异验证。
4. 提前披露保守 meta-analysis 零通路、敏感性分支、396 网格校正的条件范围；保留原有数值，未重算或挑选新结果。
5. 将“independently of proliferation”改为去除有丝分裂成分后方向保留，并明确 APC 中标记不可测不能排除增殖。
6. 讨论中注明仅 5 名配对供者，随机通路富集检验不是供者置换检验；下游轨迹、代谢和调控为探索性分析。
7. 详细轨迹、通讯、代谢参数移入补充材料，保留正文方法概述和全部引用。
8. 补充材料原先将 selected branch 写成四个视图，改为从四个候选视图中选择 all-positive 与 stress/damage 两视图。
9. 图1–6和补图S1–S2原始 TIFF 按字节保留；不改变坐标、统计量或数据图形。图5文字图注同步收紧推断。
10. 保留原作者顺序和联系方式；新投稿排他性及全体作者批准不作未核实的代签声明。新增本次 AI 辅助写作披露。
11. 按 celltype_program_scores.tsv 将主定位分析的 P 值统一为双侧（APC 0.022；角质形成细胞 0.002），与原有 BH q 值 0.044/0.009 对应；图5e和表S9仍保留独立种子的方向性 P 值，并明确标注两者区别。
12. 补充原结果表中直接16基因细胞评分不显著（两细胞组 q = 0.895）、可测基因数仅7/16和6/16的信息，避免以通路富集替代紧凑基因评分的验证。

核验范围：本次属于转刊重构及关键数值交叉核对，不是全流水线重跑或对 41 篇文献逐句重新审计。作者最终科学审核仍必需。
''')
shutil.copy2(SRC,SOURCE/'source_ijms_manuscript_20260912.md')
shutil.copy2(Path(__file__),SOURCE/Path(__file__).name)
metrics={'abstract_words':abstract_wc,'main_text_words':body_wc,'references':len(refs),'main_figures':6,'main_tables':1,'source_sha256':hashlib.sha256(SRC.read_bytes()).hexdigest(),'reference_map':refmap}
(REV/'BUILD_METRICS.json').write_text(json.dumps(metrics,indent=2))
(DEST/'README.md').write_text('''# World Allergy Organization Journal 投稿包

基于 2026-09-12 最新 IJMS 稿制作的独立 WAOJ 版本。原 IJMS 文件未覆盖。

01_submission_files：英文 Word 主稿、作者页、投稿信、Highlights、补充材料与独立 TIFF 图。

02_author_review：中文上传说明、声明确认清单、科学修改记录、摘要粘贴文本及核验记录。

03_editable_sources：可编辑 Markdown、新旧参考编号对照、源稿快照及生成脚本。

本包尚未在线提交。请先阅读 02_author_review 中的两个投稿确认文件。官方指南本次访问受限，最新强制格式要求需在投稿系统再次确认。全体作者批准、排他投稿、伦理适用性、代码可访问性和 AI 使用范围须由作者核实。
''')
print(json.dumps(metrics,indent=2))
