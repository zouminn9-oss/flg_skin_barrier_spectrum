#!/usr/bin/env Rscript

suppressPackageStartupMessages(library(Matrix))

args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 3L) {
  stop("Usage: 88_gse328048_pseudobulk.R SERIES_MATRIX INPUT_DIR OUTPUT_DIR")
}
series_path <- args[[1L]]
input_dir <- args[[2L]]
output_dir <- args[[3L]]
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)

parse_series_row <- function(prefix) {
  hit <- grep(paste0("^", prefix, "\\t"), readLines(series_path, warn = FALSE), value = TRUE)
  if (length(hit) != 1L) stop("Expected one row for ", prefix, "; found ", length(hit))
  fields <- strsplit(hit, "\\t", fixed = FALSE)[[1L]][-1L]
  gsub('^"|"$', "", fields)
}

gsm <- parse_series_row("!Sample_geo_accession")
title <- parse_series_row("!Sample_title")
all_lines <- readLines(series_path, warn = FALSE)
disease_line <- grep('^!Sample_characteristics_ch1\\t.*"disease:', all_lines, value = TRUE)
if (length(disease_line) != 1L) stop("Disease annotation row is not unique")
disease <- strsplit(disease_line, "\\t")[[1L]][-1L]
disease <- sub('^"disease: ', "", disease)
disease <- sub('"$', "", disease)
group <- c("Control" = "HC", "Nonles AD" = "NAD", "Les AD" = "LAD")[disease]
if (anyNA(group)) stop("Unexpected disease annotation")

profiles <- vector("list", length(gsm))
qc <- data.frame(
  gsm = gsm, sample_title = title, group = unname(group),
  filtered_cells = NA_integer_, threshold_pass_cells = NA_integer_,
  total_umi = NA_real_, detected_genes = NA_integer_,
  stringsAsFactors = FALSE
)

for (i in seq_along(gsm)) {
  matrix_path <- Sys.glob(file.path(input_dir, paste0(gsm[[i]], "_*_filtered_matrix.mtx.gz")))
  feature_path <- Sys.glob(file.path(input_dir, paste0(gsm[[i]], "_*_filtered_features.tsv.gz")))
  if (length(matrix_path) != 1L || length(feature_path) != 1L) {
    stop("Missing or ambiguous matrix/features for ", gsm[[i]])
  }
  features <- read.delim(gzfile(feature_path), header = FALSE, sep = "\t", quote = "",
                         stringsAsFactors = FALSE, comment.char = "")
  if (ncol(features) < 2L) stop("Invalid feature table: ", feature_path)
  expression_feature <- if (ncol(features) >= 3L) features[[3L]] == "Gene Expression" else rep(TRUE, nrow(features))
  genes <- features[[2L]][expression_feature]
  m <- readMM(gzfile(matrix_path))
  if (nrow(m) != nrow(features)) stop("Feature/matrix row mismatch for ", gsm[[i]])
  m_expr <- m[expression_feature, , drop = FALSE]
  collapsed <- rowsum(as.numeric(rowSums(m_expr)), group = genes, reorder = FALSE)
  gene_counts <- collapsed[, 1L]
  names(gene_counts) <- rownames(collapsed)
  profiles[[i]] <- gene_counts
  cell_umi <- as.numeric(colSums(m_expr))
  mitochondrial <- startsWith(genes, "MT-")
  cell_mt <- if (any(mitochondrial)) as.numeric(colSums(m_expr[mitochondrial, , drop = FALSE])) else rep(0, ncol(m_expr))
  keep <- cell_umi >= 200 & ifelse(cell_umi > 0, 100 * cell_mt / cell_umi <= 25, FALSE)
  qc$filtered_cells[[i]] <- ncol(m_expr)
  qc$threshold_pass_cells[[i]] <- sum(keep)
  qc$total_umi[[i]] <- sum(gene_counts)
  qc$detected_genes[[i]] <- sum(gene_counts > 0)
  message(sprintf("[%03d/%03d] %s: %d cells, %d threshold-pass, %d genes",
                  i, length(gsm), gsm[[i]], ncol(m_expr), sum(keep), sum(gene_counts > 0)))
  rm(m, m_expr)
  invisible(gc(FALSE))
}

gene_universe <- sort(unique(unlist(lapply(profiles, names), use.names = FALSE)))
pseudobulk <- matrix(0, nrow = length(gene_universe), ncol = length(gsm),
                     dimnames = list(gene_universe, gsm))
for (i in seq_along(profiles)) pseudobulk[names(profiles[[i]]), i] <- profiles[[i]]

metadata <- data.frame(
  gsm = gsm,
  sample_title = title,
  disease_geo = disease,
  group = unname(group),
  donor_key_frozen = title,
  stringsAsFactors = FALSE
)

write.table(metadata, file.path(output_dir, "sample_metadata.tsv"), sep = "\t",
            quote = FALSE, row.names = FALSE)
write.table(qc, file.path(output_dir, "sample_qc.tsv"), sep = "\t",
            quote = FALSE, row.names = FALSE)
con <- gzfile(file.path(output_dir, "pseudobulk_counts.tsv.gz"), "wt")
write.table(cbind(gene = rownames(pseudobulk), as.data.frame(pseudobulk, check.names = FALSE)),
            con, sep = "\t", quote = FALSE, row.names = FALSE)
close(con)
writeLines(c(
  paste("samples", ncol(pseudobulk), sep = "\t"),
  paste("genes", nrow(pseudobulk), sep = "\t"),
  paste("cells", sum(qc$filtered_cells), sep = "\t"),
  paste("total_umi", format(sum(qc$total_umi), scientific = FALSE), sep = "\t")
), file.path(output_dir, "pseudobulk_manifest.tsv"))
