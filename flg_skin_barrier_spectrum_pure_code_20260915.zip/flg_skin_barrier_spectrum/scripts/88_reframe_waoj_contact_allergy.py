#!/usr/bin/env python3
"""Reframe the retained WAOJ package without changing analytical outputs."""
from pathlib import Path
import ast, re, json, hashlib, shutil, csv, zipfile, difflib
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.text import WD_ALIGN_PARAGRAPH

ROOT=Path(__file__).resolve().parents[1]
OLD=ROOT/'submission/WAOJ_Submission_20260913'
OUT=ROOT/'submission/WAOJ_Submission_20260914_AllergyFocus'
UP=OUT/'01_submission_files';EDIT=OUT/'03_editable_sources';REV=OUT/'02_author_review'
for d in [UP,EDIT,REV]:d.mkdir(parents=True,exist_ok=True)
source=OLD/'03_editable_sources/waoj_manuscript.md'
old=source.read_text()
OLDTITLE=old.splitlines()[0][2:]
TITLE='Opposite cellular replication repair responses in allergic and irritant contact inflammation'
SHORT='Replication repair in contact inflammation'
# Reuse only the reviewed formatting functions, never execute the prior builder.
builder=OLD/'03_editable_sources/86_build_waoj_submission_package.py'
tree=ast.parse(builder.read_text())
helpers=[x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name in ['words','add_inline','style_doc','make_doc']]
exec(compile(ast.Module(body=helpers,type_ignores=[]),str(builder),'exec'),globals())
def section(label):
    m=re.search(r'^## '+re.escape(label)+r'\n(.*?)(?=^## |\Z)',old,re.M|re.S)
    assert m,label
    return m.group(1).strip()
def subsections(text):return re.findall(r'^### .*?(?=^### |\Z)',text,re.M|re.S)
figmap={1:1,5:2,2:3,3:4,4:5,6:6}
def remapfig(t):
    return re.sub(r'(Figure )(\d)(?=[a-z.\s])',lambda m:m[1]+str(figmap[int(m[2])]),t)

intro='''Allergic contact dermatitis (ACD) and irritant contact dermatitis (ICD) can produce similar erythema, pruritus and barrier disruption despite different initiating processes. ACD involves sensitization and antigen-specific immune responses, whereas ICD begins with direct injury and associated inflammation [15,16,18]. This distinction does not divide contact inflammation into exclusively immune and exclusively epithelial disease: keratinocytes and immune cells participate in both responses. The question is which cellular responses differ when allergic and irritant challenges are compared directly.

Tissue transcriptomics has identified molecular differences between ACD and ICD, and paired human challenge studies have resolved cell-specific signatures [17,18,12]. These studies establish the context for asking a narrower question: whether a molecular program shared by inflammatory skin diseases shows different allergic-versus-irritant responses in epithelial and antigen-presenting compartments. We examine replication and repair pathways because their tissue-level enrichment could reflect renewal, injury responses or immune-cell activity. A shared pathway signal alone cannot identify which of these cellular processes accounts for a challenge difference.

Atopic dermatitis (AD) provides a related discovery setting of barrier dysfunction and immune activation, without being a substitute for contact allergy [1,2,3]. AD tissue studies and meta-analysis have identified recurrent signatures and substantial heterogeneity [4,5,6]. Similarity network fusion can organize these findings across diseases [7,8], while single-cell and spatial studies reveal cellular states hidden within tissue averages [9,10,11]. Interactions among epidermal stress, APC activation and T-cell responses further motivate separating the cellular sources of a shared program [13,14,15,16,17,18,19].

We identified a replication–repair pathway program from AD and ACD within a seven-disease discovery network, then tested its fixed membership in paired allergic and irritant challenge samples. The central comparison concerns opposite challenge-associated directions in APCs and keratinocytes, with pathway-omission and mitotic-content sensitivity analyses. A recurrent 16-gene subset was evaluated separately in independent AD biopsies to assess tissue-level transfer. This external analysis does not validate the contact-challenge contrast. Additional transcriptomic models were used to nominate follow-up experiments; the study does not establish a diagnostic classifier or demonstrate antigen-specific regulation of the program.'''

intro=intro.replace('epithelial and antigen-presenting compartments.', 'epithelial and antigen-presenting cell (APC) compartments.')

abstract='''**Background:** Allergic contact dermatitis (ACD) and irritant contact dermatitis (ICD) can produce similar skin inflammation, but shared tissue signatures may conceal different epithelial and immune responses. We asked whether a replication–repair pathway program shows contrasting cellular responses to allergic and irritant challenges.

**Methods:** A pathway program identified from atopic dermatitis (AD) and allergic contact dermatitis within a seven-disease transcriptomic network was tested without changing its membership in donor-aware pseudobulk profiles from five paired allergic and irritant challenges. Pathway-matched permutations assessed compartment enrichment, with pathway-omission and mitotic-content sensitivity analyses. Network discovery used a normal-theory sensitivity branch after the conservative meta-analytic criterion selected no pathways; calibration was conditional on the specified fusion search. A fixed 16-gene subset was evaluated separately in independent AD biopsies.

**Results:** The parent program was higher under allergic challenge in antigen-presenting cells (APCs; 17 of 19 measurable pathways allergy-high; q = 0.044) and higher under irritant challenge in keratinocytes (14 of 16 pathways irritant-high; q = 0.009). The all-cell contrast was not significant (q = 0.384). Both compartment directions persisted after individual pathway omission and depletion of mitotic content. Direct cellular scores for the compact 16-gene subset were not significant. In independent whole biopsies, that subset separated lesional AD from healthy samples (AUC = 0.827), but the AD association was absent after proliferation adjustment (P = 0.904). Donor-level trajectory and metabolic analyses did not survive false-discovery correction.

**Conclusions:** Allergic and irritant contact inflammation showed opposite compartment-level responses of a shared replication–repair program. The findings motivate independent tests of epithelial–immune differences in contact inflammation; they do not establish an allergy-specific mechanism or clinically validated discrimination between ACD and ICD.'''
keywords='allergic contact dermatitis; irritant contact dermatitis; antigen-presenting cells; keratinocytes; transcriptomics'

method_parts=subsections(section('Methods'))
assert len(method_parts)==14
# Study design and processing precede the central paired comparison, then discovery details.
method_parts[0]=method_parts[0].replace('Discovery-network nodes were AD, ACD, ICD, psoriasis, acne, rosacea and HS.', 'The central contact-inflammation comparison used paired allergic and irritant challenge samples. The pathway program was derived separately from a discovery network containing AD, ACD, ICD, psoriasis, acne, rosacea and HS.')
method_parts[0]=method_parts[0].replace('rosacea and HS.', 'rosacea and hidradenitis suppurativa (HS).',1)
methods='\n\n'.join(method_parts[i].strip() for i in [0,1,8,9,2,3,4,5,6,7,10,11,12,13])
methods=methods.replace('Figure 5e and Table S9 report directional P values', 'The mitotic-content sensitivity analysis in Table S9 reports directional P values')

r=subsections(section('Results'))
assert len(r)==9
discovery='''### A shared replication repair program defines the object tested in contact challenges

We assembled pathway effects from 13 bulk contrasts across seven inflammatory skin diseases, estimating cohort effects separately and preserving available pairing (Figure 1a; Table 1). The prespecified conservative REML criterion with modified Knapp–Hartung inference selected no pathway. In the normal-theory REML sensitivity branch, 613 pathways were selected in AD and 894 in ACD; 429 had concordant effects and were selected in both diseases (Figure 1b,c; Supplementary Table S1). Cross-disease similarities supplied discovery context rather than evidence that AD and ACD have interchangeable mechanisms (Figure 1d).

The selected AD–ACD relationship was supported by pathways involved in DNA-damage recognition, replication, repair synthesis and checkpoint control. The 20 pathways with the largest deletion influence formed the fixed program tested in contact-challenge samples. Program membership was not selected from the allergic-versus-irritant cellular effects. Its network calibration and pathway robustness are reported below, after the central paired comparison, to distinguish discovery provenance from cellular localization.'''
paired=r[5].replace('### Antigen-presenting cells and keratinocytes deploy the program in opposite directions','### Allergic and irritant challenges produce opposite APC and keratinocyte responses')
paired=paired.replace('We then tested the bulk-derived program', 'We tested the bulk-derived program')
paired=paired.replace('— the whole-skin average that the compartment analysis resolves.', '. The pooled all-cell result was not significant despite the opposing compartment directions; this is compatible with loss of compartment-specific information on aggregation, but does not demonstrate statistical cancellation.')
paired=paired.replace(') .', ').')
mitosis=r[6]
network='''### Network calibration and pathway sensitivity define the discovery scope

The selected AD–ACD relationship ranked third among 21 disease pairs, with fused similarity 0.259 and conditional edge q = 0.001 (Figure 2a,c). The search enumerated 396 combinations of pathway views and fusion parameters; each of 500 grid-level permutations repeated the complete search and retained its maximum AD–ACD similarity. The resulting grid-calibrated P value was 0.010 (Figure 2b). Across 1,000 pathway bootstraps, the 95% similarity interval was 0.216–0.304 and AD–ACD co-clustering was 1.000 (Figure 2d; Supplementary Table S2). These tests address the enumerated fusion search conditional on the upstream sensitivity branch, not selection of meta-analytic estimators or feature definitions.

Pathway deletion identified convergent repair and replication annotations, including nucleotide-excision repair synthesis, damage bypass, ATM-associated signaling and DNA strand elongation (Figure 3a,b; Supplementary Table S3). All top 20 drivers belonged to the stress/damage view, which contributed to the selected representation and overlapped the all-positive view. Among the highest 10% of influence values, stress/damage pathways were enriched (odds ratio 17.91; one-sided Fisher P = 3.9 × 10⁻³⁷), as were pathways selected in both AD and ACD (odds ratio 1.63; P = 0.005; Figure 3c). The prominence of this theme is conditional on the representation used for discovery.

Removing view overlap changed similarity from 0.259 to 0.247 while retaining rank 3 of 21. The stress/damage view alone also retained rank 3; the all-positive view alone gave rank 6 (Figure 3e). Across 1,000 random deletions of 10% of pathways, median similarity was 0.258 (95% interval, 0.245–0.276) and rank remained 3 in every run (Figure 3d). Shared genes and nested Reactome annotations make these findings correlated descriptions of one program rather than independent replications.'''
core=r[3].replace('### A recurrent 16-gene core provides a transferable readout of the program','### A recurrent gene subset provides a separate tissue readout')
external=r[4].replace('The following analysis tests the parent pathway program rather than assuming that the 16-gene score has equivalent cellular behavior.', 'The preceding cellular comparison concerns the parent pathway program; its results cannot be transferred to the compact score.')
results='\n\n'.join(x.strip() for x in [discovery,paired,mitosis,network,core,external,r[7],r[8]])
discussion=section('Discussion').split('\n\n')
discussion[0]='''The central finding is a difference in how a shared replication–repair program is expressed across cellular compartments during allergic and irritant contact inflammation. In paired challenge samples, the program was higher under allergy in APCs and higher under irritation in keratinocytes. The all-cell analysis did not show significant enrichment. The compartment results therefore identify information that is not apparent in the pooled analysis, without proving that the opposing signals quantitatively cancel. A separate 16-gene AD tissue score addresses transfer across biopsies, not discrimination between the two contact reactions.'''
discussion[1]='''Earlier tissue and single-cell studies have already shown that allergic and irritant contact reactions have different molecular signatures [12,17,18]. Our analysis asks specifically how a bulk-derived shared replication–repair program behaves within the epithelial and antigen-presenting compartments. The observed directions are compatible with a stronger epithelial repair-associated response to irritant exposure and a stronger APC-associated response to allergic challenge. This interpretation does not imply that keratinocytes are uninvolved in allergy or that irritant inflammation lacks immune participation [14,15,16]. Nor does the APC result demonstrate antigen-specific recognition, presentation capacity or T-cell activation: these functions were not measured by the pathway score. RNA abundance also does not quantify DNA lesions, checkpoint activity or repair flux [35,36,37].'''
discussion.insert(2,'''The contrast is relative to the other challenge, not a claim that either condition has no activity in the opposite compartment. APCs pool heterogeneous populations, so subtype composition and within-cell responses remain alternative explanations. Because the two compartments were tested separately against matched pathway backgrounds, opposite score directions and their q values are not themselves a formal condition-by-compartment interaction test. Establishing that interaction, resolving APC subtypes and verifying challenge-associated protein or damage responses would strengthen the proposed distinction between the two forms of contact inflammation.''')
discussion='\n\n'.join(discussion)
conclusion='''A shared replication–repair pathway program showed an allergy-high response in APCs and an irritant-high response in keratinocytes in five paired contact challenges. The finding supports investigation of cellular responses that differ between allergic contact inflammation and irritant injury. Independent paired cohorts and functional measurements are needed to establish the underlying biology. The associated AD tissue score is proliferation-linked and does not validate clinical discrimination between ACD and ICD.'''

body='\n\n'.join(['## Introduction',intro,'## Methods',methods,'## Results',results,'## Discussion',discussion,'## Conclusions',conclusion])
body=remapfig(body)
refs={int(n):t for n,t in re.findall(r'^(\d+)\. (.*)$',section('References'),re.M)}
order=[]
for group in re.findall(r'\[([\d, ]+)\]',body):
    for n in map(int,group.replace(' ','').split(',')):
        if n not in order:order.append(n)
assert set(order)==set(refs)
refmap={old:i+1 for i,old in enumerate(order)}
def renum(text):return re.sub(r'\[([\d, ]+)\]',lambda m:'['+','.join(map(str,sorted(refmap[int(n)] for n in m[1].replace(' ','').split(','))))+']',text)
body=renum(body)
reftext='\n\n'.join(f'{i+1}. {refs[n]}' for i,n in enumerate(order))
caps=re.findall(r'^\*\*Figure \d\.\*\*.*$',section('Figure legends'),re.M)
caps='\n\n'.join(remapfig(caps[n-1]) for n in [1,5,2,3,4,6])
declarations=old.split('## Abbreviations\n',1)[1].split('## References\n',1)[0].strip()
table=section('Table')
# Move the central challenge cohort to the first table row; other rows retain content.
tablelines=table.splitlines(); data=[l for l in tablelines if l.startswith('| GSE267929')]
assert len(data)==1
tablelines.remove(data[0]);idx=next(i for i,l in enumerate(tablelines) if l.startswith('| ---'))
tablelines.insert(idx+1,data[0]);table='\n'.join(tablelines)
manuscript=f'# {TITLE}\n\n## Abstract\n\n{abstract}\n\n**Keywords:** {keywords}\n\n{body}\n\n## Abbreviations\n\n{declarations}\n\n## References\n\n{reftext}\n\n## Table\n\n{table}\n\n## Figure legends\n\n{caps}\n'
aw=words(re.sub(r'\*\*(Background|Methods|Results|Conclusions):\*\*','',abstract))
bw=words(re.sub(r'^#{2,3} .*$', '',body,flags=re.M))
make_doc(manuscript,UP/'waoj_manuscript_blinded.docx')
(EDIT/'waoj_manuscript.md').write_text(manuscript)

tp=(OLD/'03_editable_sources/title_page.md').read_text().replace(OLDTITLE,TITLE)
tp=re.sub(r'Abstract: \d+ words\. Main text: \d+ words',f'Abstract: {aw} words. Main text: {bw} words',tp)
make_doc(tp,UP/'title_page.docx',False);(EDIT/'title_page.md').write_text(tp)
cover=(OLD/'03_editable_sources/cover_letter.md').read_text().replace(OLDTITLE,TITLE).replace('13 September 2026','14 September 2026')
start=cover.index('The manuscript addresses');end=cover.index('\n\nThe work reanalyzes',start)
cover=cover[:start]+'''The manuscript addresses the distinction between allergic contact inflammation and irritant injury. Similar tissue-level responses need not imply similar cellular responses. In donor-aware analyses of five paired challenge participants, a fixed replication–repair pathway program was allergy-high in antigen-presenting cells and irritant-high in keratinocytes, while the pooled all-cell analysis was not significant. Both compartment directions persisted after individual pathway omission and depletion of mitotic content.

The contribution is a pathway-level examination of the epithelial–immune contrast, building on prior molecular studies of allergic and irritant contact dermatitis. A cross-disease network supplied the program independently of the cellular comparison. We report the negative conservative meta-analysis and the conditional scope of the network search calibration. The compartment findings remain small-sample, transcript-derived associations; they do not demonstrate antigen-specific function, proliferation independence or a formal condition-by-compartment interaction.

A separate fixed 16-gene subset generalized to independent AD biopsies, but its association was absent after proliferation adjustment. We therefore do not present that tissue analysis as validation of an ACD–ICD classifier. The manuscript prioritizes the direct contact-challenge comparison and the experiments needed to test its biological interpretation, making the work relevant to readers studying contact allergy and epithelial–immune responses to chemical exposure.'''+cover[end:]
make_doc(cover,UP/'cover_letter.docx',False);(EDIT/'cover_letter.md').write_text(cover)
highlights=[
    'Allergic and irritant challenges show opposite cellular pathway responses.',
    'Replication repair is allergy-high in APCs and irritant-high in keratinocytes.',
    'Compartment directions persist after depletion of mitotic pathway content.',
    'Independent cellular validation is needed before clinical discrimination.'
]
assert all(len(x)<=85 for x in highlights)
hi='# Highlights\n\n'+'\n\n'.join('• '+x for x in highlights)
make_doc(hi,UP/'highlights.docx',False);(EDIT/'highlights.md').write_text(hi)

sup=Document(OLD/'01_submission_files/supplementary_information.docx')
for p in sup.paragraphs:
    if p.text==OLDTITLE:p.text=TITLE
    # Extended methods contain superscript references, not superscript measurements.
    for run in p.runs:
        if run.font.superscript and re.fullmatch(r'\d+(?:,\d+)*',run.text):
            run.text=','.join(map(str,sorted(refmap[int(n)] for n in run.text.split(','))))
        mapped=remapfig(run.text)
        if mapped!=run.text:run.text=mapped
for t in sup.tables:
    for row in t.rows:
        for c in row.cells:
            for p in c.paragraphs:
                for run in p.runs:
                    run.text=run.text.replace('WAOJ_Submission_20260913','WAOJ_Submission_20260914_AllergyFocus')
sup.save(UP/'supplementary_information.docx')
# Renumber filenames only: every image remains byte-identical to its source.
for oldnum,newnum in figmap.items():shutil.copy2(OLD/f'01_submission_files/figure{oldnum}.tif',UP/f'figure{newnum}.tif')
for n in [1,2]:shutil.copy2(OLD/f'01_submission_files/figureS{n}.tif',UP/f'figureS{n}.tif')

(REV/'ABSTRACT_FOR_PORTAL.txt').write_text(abstract.replace('**','')+'\n\nKeywords: '+keywords+'\n')
guide=(OLD/'02_author_review/JOURNAL_REQUIREMENTS_AND_UPLOAD_ORDER.md').read_text()
guide=guide.replace('核查日期：2026-09-13。','沿用2026-09-13指南核查记录；2026-09-14更新稿件，未重新认证官方现行格式。')
guide=re.sub(r'摘要 \d+ 词；正文 \d+ 词',f'摘要 {aw} 词；正文 {bw} 词',guide)
guide+='\n\n本版文件已重新编号：旧图5为新图2；旧图2/3/4为新图3/4/5。上传时仅使用本文件夹，勿与9月13日旧版混用。\n'
(REV/'JOURNAL_REQUIREMENTS_AND_UPLOAD_ORDER.md').write_text(guide)
decl=(OLD/'02_author_review/DECLARATIONS_FOR_AUTHOR_CONFIRMATION.md').read_text()
decl=decl.replace('存在 IJMS 投稿包不等于已投稿；若 IJMS 已在审，不得同时投 WAOJ。','作者已告知 IJMS 拒稿；提交前仍应确认该决定为最终结案且没有其他期刊在审。未审阅拒稿信或审稿意见，不能声称已针对其完成修改。')
(REV/'DECLARATIONS_FOR_AUTHOR_CONFIRMATION.md').write_text(decl)
(REV/'SCIENTIFIC_CHANGE_LOG.md').write_text('''# 2026年9月14日变态反应主线修订

目标：将过敏性接触反应与刺激损伤的细胞响应区别置于全文中心。未新增实验、重算分析或改动图像数据。

- 标题、结构化摘要、引言和讨论突出直接过敏–刺激比较。
- 原结果第六节提前为第二节；核心细胞图从图5调整为图2。
- 先用简短发现概述定义固定通路程序，再呈现细胞比较；网络校准与通路敏感性合并压缩，位于核心比较之后。
- 方法中配对细胞比较及有丝分裂敏感性提前；研究设计与数据表先说明核心挑战数据的角色。
- 16基因AD外部验证保留但与ACD–ICD细胞比较明确分开，不作为过敏与刺激的诊断验证。
- 明确既往研究已报道ACD–ICD分子差异；本稿新增视角限定为共享复制修复程序的细胞响应。
- 不将刺激性炎症描述为没有免疫参与，不将APC富集解释为直接证明抗原特异性机制。
- 新增说明：各区室方向与显著性不等于正式的条件×区室交互作用检验；未显著全细胞信号不证明统计抵消。
- 原文41条参考文献按新的首次出现顺序重排；补充方法引用同步映射。
- 同步作者页、投稿信、Highlights、图名和上传说明；作者信息、资金声明等保留待作者确认。

原始结果及9月13日投稿包均保留。本次不是IJMS审稿意见逐条回应，因为尚未收到拒稿信或评审意见。
''')
(REV/'FOCUS_AND_EVIDENCE_AUDIT.md').write_text('''# 主线与证据范围核查

## 可支持的核心比较

| 主张 | 项目来源 | 结果 |
|---|---|---|
| APC程序相对过敏更高 | celltype_program_scores.tsv | 17/19；双侧P 0.02179782；q 0.04359564 |
| 角质形成细胞程序相对刺激更高 | 同上 | 14/16；双侧P 0.00219978；q 0.00879912 |
| 全细胞程序未显著 | 同上 | q 0.383695 |
| 直接核心基因评分未显著 | 同上 | APC与KRT q 0.894711；可测7/16与6/16 |
| AD组织评分与临床鉴别不是同一问题 | primary_LAD_vs_HC_biopsy.tsv；title_cluster_proliferation_adjusted.tsv | AUC 0.826892；调整P 0.904389 |

单细胞来源目录：results/exploratory_snf/selected_positive_reml_z_q05/optimized_AD_ACD_branch/mechanism/single_cell_localization/

外部验证目录：results/external_validation/GSE328048/analysis/

## 保留的限制

五名配对供者；随机通路检验并非供者置换。AD验证不复制ACD–ICD区室差异。未做新的条件×区室交互检验；未直接测定抗原呈递、特异性T细胞、DNA损伤或代谢通量。阴性的保守meta分析及下游FDR结果保留。

## 文献和范围

修订时核对既往直接比较研究的公开书目信息，未增加文献或声称首次发现ACD与ICD分子差异：[Frisoli等](https://pubmed.ncbi.nlm.nih.gov/39341550/)；[Lefevre等](https://pubmed.ncbi.nlm.nih.gov/34174113/)。原41条文献按编号映射保留，本次未逐篇重新审计全文。

本记录是本次主线修改的定向核查，不是完整流水线复现。作者最终科学审核及官方现行投稿要求仍须另行确认。
''')
(REV/'FIGURE_NUMBER_MAPPING.tsv').write_text('previous\tcurrent\tcontent\n1\t1\tDiscovery atlas\n5\t2\tAllergic versus irritant compartment responses\n2\t3\tNetwork calibration\n3\t4\tPathway sensitivity\n4\t5\tGene core\n6\t6\tExploratory models\n')
(EDIT/'reference_number_mapping_from_20260913.json').write_text(json.dumps(refmap,indent=2))
(EDIT/'source_waoj_manuscript_20260913.md').write_text(old)
(EDIT/'manuscript_changes.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True),manuscript.splitlines(True),fromfile='WAOJ_20260913',tofile='WAOJ_20260914_AllergyFocus')))
shutil.copy2(builder,EDIT/'86_formatting_helper_source.py')
shutil.copy2(Path(__file__),EDIT/Path(__file__).name)
metrics={'abstract_words':aw,'main_text_words':bw,'references':41,'main_figures':6,'supplementary_figures':2,'main_tables':1,'reference_map_from_20260913':refmap,'figure_map_from_20260913':figmap,'previous_manuscript_sha256':hashlib.sha256(source.read_bytes()).hexdigest()}
(REV/'BUILD_METRICS.json').write_text(json.dumps(metrics,indent=2))
(OUT/'README.md').write_text('''# WAOJ 过敏与刺激损伤主线版

版本：2026-09-14。基于9月13日WAOJ稿独立制作，旧稿与IJMS稿均未覆盖。

01_submission_files 包含5份Word和8张独立TIFF。02_author_review包含上传说明、声明确认、修改记录、证据核查及图号映射。03_editable_sources包含新旧Markdown、差异文件和生成脚本，仅供本地编辑，不上传审稿系统。

使用本版全部文件，勿混用旧图号。ZIP仅为交付容器，请按上传说明分别选择文件。

作者告知IJMS已拒稿；未获得拒稿信，不代表已回应其审稿意见。本包尚未在线提交，未支付或代签。官方指南沿用9月13日访问受限记录，投稿前需核实当日强制要求及全部作者声明。
''')
print(json.dumps(metrics,indent=2))
