#!/usr/bin/env python3
"""Bounded submission checks and ZIP delivery; no biological pipeline rerun."""
from pathlib import Path
import csv, hashlib, json, re, shutil, zipfile
from docx import Document
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
PACK = ROOT / 'submission/WAOJ_Submission_20260913'
UP = PACK / '01_submission_files'
REV = PACK / '02_author_review'
EDIT = PACK / '03_editable_sources'
OLD = ROOT / 'submission/IJMS_Submission_20260911/01_upload_ready'
checks = []
def check(label, passed):
    assert passed, label
    checks.append(label)
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def rows(path):
    with path.open() as f: return list(csv.DictReader(f, delimiter='\t'))
def bh(vals):
    order = sorted(range(len(vals)), key=lambda i: vals[i])
    out = [0.0]*len(vals); v=1.0
    for j in range(len(vals)-1,-1,-1):
        i=order[j];v=min(v, vals[i]*len(vals)/(j+1));out[i]=v
    return out

metrics=json.loads((REV/'BUILD_METRICS.json').read_text())
src=ROOT/'paper_rewriting_output/ijms_submission/manuscript/ijms_manuscript.md'
check('原 IJMS 源稿 SHA-256 保持不变', sha(src)==metrics['source_sha256']=='d7c5ff8506fb8c29691bf726d0ddffba63f06c8c72f3ef4481d9f37eb01bb45a')
check('源稿快照与原文件相同',sha(src)==sha(EDIT/'source_ijms_manuscript_20260912.md'))
md=(EDIT/'waoj_manuscript.md').read_text()
body=md.split('## Introduction\n')[1].split('## Ethics')[0]
seen=[]
for cite in re.findall(r'\[([\d, ]+)\]',body):
    for n in map(int,cite.replace(' ','').split(',')):
        if n not in seen:seen.append(n)
check('正文引用按首次出现编号 1–41，无遗漏',seen==list(range(1,42)))
check('参考文献条目编号 1–41', list(map(int,re.findall(r'^(\d+)\. ',md.split('## References\n')[1],re.M)))==list(range(1,42)))
check('6 幅主图图注及 1 个主表',len(re.findall(r'^\*\*Figure \d\.\*\*',md,re.M))==6 and len(Document(UP/'waoj_manuscript_blinded.docx').tables)==1)
check('摘要/正文采用历史兼容范围；非现行官方限制认证',250<=metrics['abstract_words']<=400 and 4000<=metrics['main_text_words']<=5000)
for p in UP.glob('*.docx'):
    if p.name.startswith('.'): continue
    with zipfile.ZipFile(p) as z:
        check(p.name+'：DOCX 容器完整',z.testzip() is None)
        allxml='\n'.join(z.read(n).decode('utf-8') for n in z.namelist() if n.endswith('.xml'))
        check(p.name+'：无旧期刊抬头',not any(x in allxml for x in ['IJMS','International Journal of Molecular Sciences']))
        if p.name in ['waoj_manuscript_blinded.docx','supplementary_information.docx']:
            check(p.name+'：未检出作者姓名或邮箱',not any(x in allxml for x in ['Yue-Min Zou','Si-Ran Bao','Yi-Ming Qi','Jie Ma','majiexyyy@126.com']))
            check(p.name+'：无修订标记或实际批注内容',not re.search(r'<w:(ins|del|comment)\b',allxml))

old=Document(OLD/'supplementary_information.docx');new=Document(UP/'supplementary_information.docx')
check('补充材料保留全部 16 个表格对象（S1–S11及续表）',len(old.tables)==len(new.tables)==16)
changed=[]
for ti,(a,b) in enumerate(zip(old.tables,new.tables)):
    check(f'补充表格对象 {ti+1} 行列数保留',len(a.rows)==len(b.rows) and len(a.columns)==len(b.columns))
    for ri,(ar,br) in enumerate(zip(a.rows,b.rows)):
        for ci,(ac,bc) in enumerate(zip(ar.cells,br.cells)):
            if ac.text!=bc.text:changed.append((ti,ri,ci,ac.text,bc.text))
check('补充表格仅变更 S5 的 P 列标签及 S8 主稿路径，数值单元格不变',len(changed)==2 and all((x[0]==4 and x[1:3]==(0,5)) or (x[0]==7 and x[2]==1 and x[4].endswith('waoj_manuscript.md')) for x in changed))
check('补充材料保留 2 个嵌入式补图',len(new.inline_shapes)==len(old.inline_shapes)==2)

figlines=['file\twidth_px\theight_px\tdpi_x\tdpi_y\tsha256\tsource_bytes_identical']
with zipfile.ZipFile(OLD/'figures.zip') as z:
    check('8 个独立 TIFF 图文件齐全',set(z.namelist())=={p.name for p in UP.glob('*.tif') if not p.name.startswith('.')} and len(z.namelist())==8)
    for p in sorted(p for p in UP.glob('*.tif') if not p.name.startswith('.')):
        check(p.name+'：与原图逐字节相同',p.read_bytes()==z.read(p.name))
        with Image.open(p) as im:
            dpi=im.info.get('dpi',(0,0))
            check(p.name+'：图像可读且标记分辨率至少 300 dpi',min(dpi)>=300)
            figlines.append(f'{p.name}\t{im.width}\t{im.height}\t{dpi[0]}\t{dpi[1]}\t{sha(p)}\ttrue')
(REV/'FIGURE_MANIFEST.tsv').write_text('\n'.join(figlines)+'\n')

local=ROOT/'results/exploratory_snf/selected_positive_reml_z_q05/optimized_AD_ACD_branch/mechanism/single_cell_localization/celltype_program_scores.tsv'
cell=rows(local)
for prefix,qkey in [('driver_pathway','driver_pathway_q_BH_4celltypes'),('core_gene','core_gene_q_BH_4celltypes')]:
    ps=[float(r[prefix+'_empirical_p_two_sided']) for r in cell]
    check(prefix+'：双侧 P 等于较小尾部两倍（上限1）',all(abs(ps[i]-min(1,2*min(float(r[prefix+'_empirical_p_up']),float(r[prefix+'_empirical_p_down']))))<1e-12 for i,r in enumerate(cell)))
    check(prefix+'：四细胞组 BH 重算一致',all(abs(x-float(r[qkey]))<1e-12 for x,r in zip(bh(ps),cell)))
check('正文主定位 P/q 及核心评分阴性结果已明确',all(x in md for x in ['two-sided permutation P = 0.022, q = 0.044','two-sided P = 0.002, q = 0.009','q = 0.895','only 7 of 16 genes']))
ex=ROOT/'results/external_validation/GSE328048/analysis'
r=rows(ex/'primary_LAD_vs_HC_biopsy.tsv')[0]
check('外部验证样本量及 AUC/CI 与结果表一致',r['n_x']=='54' and r['n_y']=='23' and tuple(round(float(r[k]),3) for k in ['auc','auc_ci_low','auc_ci_high'])==(.827,.721,.913))
adj=rows(ex/'title_cluster_proliferation_adjusted.tsv')[0]
check('增殖调整后 LAD P = 0.904 与结果表一致',adj['term']=='LAD' and round(float(adj['p_two_sided']),3)==.904 and 'P = 0.904' in md)

report=f'''# 投稿包有限范围核查记录

日期：2026-09-13。摘要 {metrics['abstract_words']} 词；正文 {metrics['main_text_words']} 词；41 篇文献。

本次核查是转刊重构、文件完整性及关键结果交叉核对，不是全分析重跑或逐篇文献真实性重新审计。通过下列检查不等于作者已批准或编辑部已确认格式。

## 通过的程序检查

'''+ '\n'.join('- '+c for c in checks)+'''

## 逐页排版复核

主稿30页、作者页2页、投稿信1页、Highlights 1页、补充材料16页已渲染检查。末轮仅主稿第9/11/17/29页和补充材料第2–8页变化，均重新查看；其他页与已审阅渲染图逐像素相同。未见文本遮挡或裁切；补充表头跨页重复，表格行不拆页。保留原有图形，不在本次重绘图像。

## 数据来源

- 单细胞定位：results/exploratory_snf/selected_positive_reml_z_q05/optimized_AD_ACD_branch/mechanism/single_cell_localization/celltype_program_scores.tsv
- 外部验证：results/external_validation/GSE328048/analysis/primary_LAD_vs_HC_biopsy.tsv
- 增殖调整：results/external_validation/GSE328048/analysis/title_cluster_proliferation_adjusted.tsv
- 图像及补充数值：submission/IJMS_Submission_20260911/01_upload_ready/

## 尚需人工确认

官方现行指南本次访问受限；格式数字采用历史兼容范围而非2026官方认证。需在实际投稿系统核实文章类型、强制字段、文件格式和声明。全体作者批准、排他投稿、伦理适用性、作者信息、资金/利益冲突、AI使用范围、远程代码完整性仍由作者核实。没有在线提交、付款、签名、推送代码或更改原 IJMS 文件。
'''
(REV/'VERIFICATION_REPORT.md').write_text(report)
shutil.copy2(Path(__file__),EDIT/Path(__file__).name)
manifest=REV/'FILE_MANIFEST.tsv'
files=sorted(p for p in PACK.rglob('*') if p.is_file() and not p.name.startswith('.') and p!=manifest)
manifest.write_text('path\tbytes\tsha256\n'+'\n'.join(f'{p.relative_to(PACK)}\t{p.stat().st_size}\t{sha(p)}' for p in files)+'\n')
archive=PACK.with_suffix('.zip')
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in files+[manifest]:z.write(p,Path(PACK.name)/p.relative_to(PACK))
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
print(json.dumps({'checks_passed':len(checks),'zip':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive)},indent=2))
