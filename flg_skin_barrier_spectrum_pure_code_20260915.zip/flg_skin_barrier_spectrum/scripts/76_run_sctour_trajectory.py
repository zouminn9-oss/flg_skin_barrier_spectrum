#!/usr/bin/env python3
"""Run scTour with seed replication on the prepared APC/KRT state-continuum bundles."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import anndata as ad
import numpy as np
import pandas as pd
import scanpy as sc
import scipy.io
import scipy.sparse as sp
from scipy.stats import spearmanr
import sctour as sct


CONDITION_ORDER = ["Nonlesional", "Irritant", "Day2_Allergy", "Day4_Allergy"]


def stratified_sample(meta: pd.DataFrame, maximum: int, seed: int) -> np.ndarray:
    if len(meta) <= maximum:
        return np.arange(len(meta))
    rng = np.random.default_rng(seed)
    keys = meta["Patient"].astype(str) + "|" + meta["Lesion"].astype(str)
    groups = {k: np.flatnonzero(keys.values == k) for k in sorted(keys.unique())}
    quota = max(1, maximum // len(groups))
    picked = []
    remainder = []
    for idx in groups.values():
        take = min(quota, len(idx))
        chosen = rng.choice(idx, take, replace=False)
        picked.extend(chosen.tolist())
        remainder.extend(np.setdiff1d(idx, chosen, assume_unique=False).tolist())
    if len(picked) < maximum:
        picked.extend(rng.choice(remainder, maximum - len(picked), replace=False).tolist())
    return np.sort(np.asarray(picked[:maximum], dtype=int))


def load_bundle(bundle: Path, maximum: int, seed: int) -> ad.AnnData:
    counts = scipy.io.mmread(bundle / "counts_genes_by_cells.mtx").tocsr().T
    genes = pd.read_csv(bundle / "genes.tsv", sep="\t")["gene_symbol"].astype(str).values
    barcodes = pd.read_csv(bundle / "barcodes.tsv", sep="\t").iloc[:, 0].astype(str).values
    meta = pd.read_csv(bundle / "metadata.tsv", sep="\t", index_col=0).loc[barcodes]
    keep = stratified_sample(meta, maximum, seed)
    adata = ad.AnnData(X=counts[keep, :], obs=meta.iloc[keep].copy())
    adata.obs_names = barcodes[keep]
    adata.var_names = genes
    adata.var_names_make_unique()
    sc.pp.calculate_qc_metrics(adata, inplace=True, percent_top=None, log1p=False)
    # Select informative genes on a normalized copy while preserving integer counts for NB training.
    hvg = adata.copy()
    sc.pp.normalize_total(hvg, target_sum=1e4)
    sc.pp.log1p(hvg)
    sc.pp.highly_variable_genes(hvg, flavor="seurat", n_top_genes=min(1000, hvg.n_vars))
    chosen = hvg.var_names[hvg.var["highly_variable"]]
    adata = adata[:, chosen].copy()
    # scTour 1.0 expects either a dense array or legacy sparse matrices exposing `.A`.
    # Dense 2,000 x 1,000 float32 input is small and avoids SciPy 1.15 API drift.
    adata.X = np.asarray(adata.X.toarray() if sp.issparse(adata.X) else adata.X, dtype=np.float32)
    return adata


def orient_time(t: np.ndarray, meta: pd.DataFrame) -> tuple[np.ndarray, bool]:
    lesion = meta["Lesion"].astype(str).values
    if np.any(lesion == "Nonlesional") and np.any(lesion == "Day4_Allergy"):
        flip = np.nanmedian(t[lesion == "Nonlesional"]) > np.nanmedian(t[lesion == "Day4_Allergy"])
    else:
        flip = False
    return (1.0 - t if flip else t), bool(flip)


def run_lineage(bundle: Path, out_dir: Path, maximum: int, epochs: int, seeds: list[int]) -> None:
    out_dir.mkdir(parents=True, exist_ok=True)
    adata = load_bundle(bundle, maximum, seeds[0])
    times = []
    latents = []
    run_info = []
    for seed in seeds:
        trainer = sct.train.Trainer(
            adata,
            n_latent=5,
            n_ode_hidden=25,
            n_vae_hidden=128,
            loss_mode="nb",
            nepoch=epochs,
            batch_size=min(512, adata.n_obs),
            random_state=seed,
            use_gpu=False,
        )
        trainer.train()
        t, flipped = orient_time(trainer.get_time(), adata.obs)
        z, _, _ = trainer.get_latentsp()
        times.append(t)
        latents.append(z)
        run_info.append({"seed": seed, "orientation_flipped": flipped})

    time_mat = np.column_stack(times)
    rank_mat = np.column_stack([pd.Series(x).rank(pct=True).values for x in times])
    consensus = np.median(rank_mat, axis=1)
    out = adata.obs.copy()
    for j, seed in enumerate(seeds):
        out[f"scTour_seed_{seed}"] = times[j]
    out["scTour_consensus_rank"] = consensus
    out.to_csv(out_dir / "sctour_cell_pseudotime.tsv", sep="\t", index_label="barcode")

    corr = pd.DataFrame(index=seeds, columns=seeds, dtype=float)
    for i in range(len(seeds)):
        for j in range(len(seeds)):
            corr.iloc[i, j] = spearmanr(times[i], times[j]).statistic
    corr.to_csv(out_dir / "sctour_seed_spearman.tsv", sep="\t", index_label="seed")

    donor_condition = (
        out.groupby(["Patient", "Lesion"], observed=True)["scTour_consensus_rank"]
        .agg(["median", "mean", "count"])
        .reset_index()
    )
    donor_condition.to_csv(out_dir / "sctour_donor_condition_summary.tsv", sep="\t", index=False)
    condition = (
        out.groupby("Lesion", observed=True)["scTour_consensus_rank"]
        .agg(["median", "mean", "count"])
        .reindex(CONDITION_ORDER)
        .reset_index()
    )
    condition.to_csv(out_dir / "sctour_condition_summary.tsv", sep="\t", index=False)

    np.save(out_dir / "sctour_consensus_latent.npy", np.median(np.stack(latents), axis=0))
    meta = {
        "method": "scTour",
        "sctour_version": getattr(sct, "__version__", "unknown"),
        "cells": int(adata.n_obs),
        "genes": int(adata.n_vars),
        "epochs_per_seed": epochs,
        "seeds": seeds,
        "run_info": run_info,
        "minimum_pairwise_seed_spearman": float(np.nanmin(corr.values[np.triu_indices(len(seeds), 1)])),
        "orientation_rule": "flip only when the Nonlesional median exceeds the Day4_Allergy median",
    }
    (out_dir / "sctour_run_metadata.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input-root", type=Path, default=Path("data/processed/advanced_single_cell_inputs"))
    parser.add_argument("--output-root", type=Path, default=Path("results/advanced_single_cell/trajectory"))
    parser.add_argument("--max-cells", type=int, default=2000)
    parser.add_argument("--epochs", type=int, default=100)
    args = parser.parse_args()
    seeds = [20260910, 20260911, 20260912]
    for lineage in ("APC", "KRT"):
        run_lineage(
            args.input_root / f"state_continuum_{lineage}",
            args.output_root / lineage / "scTour",
            args.max_cells,
            args.epochs,
            seeds,
        )


if __name__ == "__main__":
    main()
