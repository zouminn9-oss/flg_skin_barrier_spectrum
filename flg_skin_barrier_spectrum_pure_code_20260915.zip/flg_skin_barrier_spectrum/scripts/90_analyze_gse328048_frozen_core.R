#!/usr/bin/env Rscript

args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 3L) {
  stop("Usage: 90_analyze_gse328048_frozen_core.R PSEUDOBULK_COUNTS MAPPING_TSV OUTPUT_DIR")
}
counts_path <- args[[1L]]
mapping_path <- args[[2L]]
output_dir <- args[[3L]]
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)

set.seed(20260911)
B <- 10000L
core <- c("RPA1", "RPA3", "PCNA", "UBA52", "UBB", "POLD1", "POLD3", "POLD4",
          "POLE2", "BRCA1", "ATR", "ATRIP", "BLM", "EXO1", "RAD51", "CDK2")
proliferation <- c("MKI67", "TOP2A", "CCNB1", "CCNB2", "CDK1", "AURKA", "AURKB", "PLK1",
                   "UBE2C", "CENPF", "NUSAP1", "TPX2", "KIF11", "KIF23", "ASPM", "PTTG1")

raw <- read.delim(gzfile(counts_path), check.names = FALSE, stringsAsFactors = FALSE)
genes <- raw[[1L]]
counts <- as.matrix(raw[-1L])
storage.mode(counts) <- "double"
rownames(counts) <- genes
rm(raw)
mapping <- read.delim(mapping_path, check.names = FALSE, stringsAsFactors = FALSE)
mapping <- mapping[match(colnames(counts), mapping$gsm), ]
if (anyNA(mapping$gsm)) stop("Pseudobulk columns do not match mapping")
if (length(intersect(core, genes)) < 14L) stop("Frozen score is not evaluable: fewer than 14 core genes mapped")
if (!all(core %in% genes)) stop("Expected all 16 frozen genes in GSE328048")
if (!all(proliferation %in% genes)) stop("One or more fixed proliferation genes are absent")

rank_matrix <- apply(counts, 2L, rank, ties.method = "average")
rownames(rank_matrix) <- genes
G <- nrow(rank_matrix)
rank_score <- function(gene_set) {
  k <- length(gene_set)
  2 * (colMeans(rank_matrix[gene_set, , drop = FALSE]) - (k + 1) / 2) / (G - k) - 1
}
core_score <- rank_score(core)
prolif_score <- rank_score(proliferation)

library_size <- colSums(counts)
logcpm_core <- log2(sweep(counts[core, , drop = FALSE], 2L, library_size / 1e6, "/") + 1)
hc_columns <- mapping$group == "HC"
hc_mean <- rowMeans(logcpm_core[, hc_columns, drop = FALSE])
hc_sd <- apply(logcpm_core[, hc_columns, drop = FALSE], 1L, sd)
hc_sd[!is.finite(hc_sd) | hc_sd == 0] <- NA_real_
z_score <- colMeans(sweep(sweep(logcpm_core, 1L, hc_mean, "-"), 1L, hc_sd, "/"), na.rm = TRUE)

biopsy <- data.frame(
  gsm = mapping$gsm,
  sample_title = mapping$sample_title,
  clinical_sample_id = mapping$clinical_sample_id,
  patient_id = mapping$patient_id,
  group = mapping$group,
  core_rank_score = as.numeric(core_score),
  proliferation_rank_score = as.numeric(prolif_score),
  core_logcpm_hc_z_score = as.numeric(z_score),
  filtered_cells = mapping$filtered_cells,
  published_qc_cells = mapping$published_qc_cells,
  assignment_cost = mapping$assignment_cost,
  stringsAsFactors = FALSE
)
biopsy$title_cluster <- sub("-[0-9]+$", "", biopsy$sample_title)
donor <- aggregate(cbind(core_rank_score, proliferation_rank_score, core_logcpm_hc_z_score) ~
                     patient_id + group, biopsy, mean)
title_cluster <- aggregate(cbind(core_rank_score, proliferation_rank_score, core_logcpm_hc_z_score) ~
                             title_cluster + group, biopsy, mean)

auc_value <- function(x, y) mean(outer(x, y, function(a, b) (a > b) + 0.5 * (a == b)))
unpaired_stats <- function(x, y, label, do_boot = TRUE) {
  auc <- auc_value(x, y)
  out <- data.frame(
    contrast = label,
    n_x = length(x), n_y = length(y),
    median_x = median(x), median_y = median(y),
    median_difference = median(x) - median(y),
    hodges_lehmann_shift = median(as.vector(outer(x, y, "-"))),
    mean_difference = mean(x) - mean(y),
    auc = auc, cliffs_delta = 2 * auc - 1,
    mann_whitney_p_one_sided = wilcox.test(x, y, alternative = "greater", exact = FALSE)$p.value,
    mann_whitney_p_two_sided = wilcox.test(x, y, alternative = "two.sided", exact = FALSE)$p.value,
    permutation_p_mean_difference = NA_real_,
    median_difference_ci_low = NA_real_, median_difference_ci_high = NA_real_,
    auc_ci_low = NA_real_, auc_ci_high = NA_real_,
    stringsAsFactors = FALSE
  )
  combined <- c(x, y)
  nx <- length(x)
  observed <- mean(x) - mean(y)
  permuted <- replicate(B, {
    idx <- sample.int(length(combined), nx, replace = FALSE)
    mean(combined[idx]) - mean(combined[-idx])
  })
  out$permutation_p_mean_difference <- (1 + sum(permuted >= observed)) / (B + 1)
  if (do_boot) {
    boots <- replicate(B, {
      xb <- sample(x, replace = TRUE)
      yb <- sample(y, replace = TRUE)
      c(median(xb) - median(yb), auc_value(xb, yb))
    })
    out$median_difference_ci_low <- quantile(boots[1L, ], 0.025, names = FALSE)
    out$median_difference_ci_high <- quantile(boots[1L, ], 0.975, names = FALSE)
    out$auc_ci_low <- quantile(boots[2L, ], 0.025, names = FALSE)
    out$auc_ci_high <- quantile(boots[2L, ], 0.975, names = FALSE)
  }
  out
}

lad <- donor$core_rank_score[donor$group == "LAD"]
nad <- donor$core_rank_score[donor$group == "NAD"]
hc <- donor$core_rank_score[donor$group == "HC"]
primary <- unpaired_stats(lad, hc, "LAD_vs_HC")
nad_hc <- unpaired_stats(nad, hc, "NAD_vs_HC")
biopsy_primary <- unpaired_stats(biopsy$core_rank_score[biopsy$group == "LAD"],
                                 biopsy$core_rank_score[biopsy$group == "HC"],
                                 "LAD_vs_HC_biopsy")
title_primary <- unpaired_stats(title_cluster$core_rank_score[title_cluster$group == "LAD"],
                                title_cluster$core_rank_score[title_cluster$group == "HC"],
                                "LAD_vs_HC_title_cluster")

paired <- merge(donor[donor$group == "LAD", c("patient_id", "core_rank_score")],
                donor[donor$group == "NAD", c("patient_id", "core_rank_score")],
                by = "patient_id", suffixes = c("_LAD", "_NAD"))
paired$difference <- paired$core_rank_score_LAD - paired$core_rank_score_NAD
paired_wilcox <- wilcox.test(paired$core_rank_score_LAD, paired$core_rank_score_NAD,
                             paired = TRUE, alternative = "greater", exact = FALSE)$p.value
observed_paired_mean <- mean(paired$difference)
signflip <- replicate(B, mean(paired$difference * sample(c(-1, 1), nrow(paired), replace = TRUE)))
paired_signflip_p <- (1 + sum(signflip >= observed_paired_mean)) / (B + 1)
secondary_bh <- p.adjust(c(paired_wilcox, nad_hc$mann_whitney_p_one_sided), method = "BH")

primary$primary_supported <- primary$mean_difference > 0 &
  primary$mann_whitney_p_one_sided < 0.05 & primary$permutation_p_mean_difference < 0.05
nad_hc$secondary_directional_bh <- secondary_bh[[2L]]
paired_summary <- data.frame(
  contrast = "paired_LAD_vs_NAD", n_pairs = nrow(paired),
  median_difference = median(paired$difference), mean_difference = mean(paired$difference),
  wilcoxon_p_one_sided = paired_wilcox, signflip_p_mean_difference = paired_signflip_p,
  secondary_directional_bh = secondary_bh[[1L]], stringsAsFactors = FALSE
)
title_paired <- merge(title_cluster[title_cluster$group == "LAD", c("title_cluster", "core_rank_score")],
                      title_cluster[title_cluster$group == "NAD", c("title_cluster", "core_rank_score")],
                      by = "title_cluster", suffixes = c("_LAD", "_NAD"))
title_paired$difference <- title_paired$core_rank_score_LAD - title_paired$core_rank_score_NAD
title_paired_summary <- data.frame(
  contrast = "title_cluster_paired_LAD_vs_NAD", n_pairs = nrow(title_paired),
  median_difference = median(title_paired$difference), mean_difference = mean(title_paired$difference),
  wilcoxon_p_one_sided = wilcox.test(title_paired$core_rank_score_LAD, title_paired$core_rank_score_NAD,
                                     paired = TRUE, alternative = "greater", exact = FALSE)$p.value,
  stringsAsFactors = FALSE
)

# Leave-one-gene-out sensitivity.
loo <- do.call(rbind, lapply(core, function(omitted) {
  score <- rank_score(setdiff(core, omitted))
  tmp <- aggregate(score ~ title_cluster + group,
                   data.frame(score = score, title_cluster = biopsy$title_cluster, group = biopsy$group), mean)
  x <- tmp$score[tmp$group == "LAD"]
  y <- tmp$score[tmp$group == "HC"]
  a <- auc_value(x, y)
  data.frame(omitted_gene = omitted, mean_difference = mean(x) - mean(y), auc = a,
             cliffs_delta = 2 * a - 1,
             p_one_sided = wilcox.test(x, y, alternative = "greater", exact = FALSE)$p.value,
             direction_positive = mean(x) > mean(y), nominally_significant = mean(x) > mean(y) &
               wilcox.test(x, y, alternative = "greater", exact = FALSE)$p.value < 0.05)
}))

# HC-standardized logCPM sensitivity.
z_lad <- donor$core_logcpm_hc_z_score[donor$group == "LAD"]
z_hc <- donor$core_logcpm_hc_z_score[donor$group == "HC"]
z_sensitivity <- unpaired_stats(z_lad, z_hc, "LAD_vs_HC_logCPM_HC_z", do_boot = FALSE)

# Proliferation-adjusted donor-level linear model.
model_data <- donor[donor$group %in% c("LAD", "HC"), ]
model_data$LAD <- as.integer(model_data$group == "LAD")
fit <- lm(core_rank_score ~ LAD + proliferation_rank_score, data = model_data)
fit_summary <- summary(fit)$coefficients
fit_ci <- confint(fit)
proliferation_adjusted <- data.frame(
  term = "LAD", coefficient = coef(fit)[["LAD"]], standard_error = fit_summary["LAD", "Std. Error"],
  p_two_sided = fit_summary["LAD", "Pr(>|t|)"], ci_low = fit_ci["LAD", 1L], ci_high = fit_ci["LAD", 2L]
)
title_model_data <- title_cluster[title_cluster$group %in% c("LAD", "HC"), ]
title_model_data$LAD <- as.integer(title_model_data$group == "LAD")
title_fit <- lm(core_rank_score ~ LAD + proliferation_rank_score, data = title_model_data)
title_fit_summary <- summary(title_fit)$coefficients
title_fit_ci <- confint(title_fit)
title_proliferation_adjusted <- data.frame(
  term = "LAD", coefficient = coef(title_fit)[["LAD"]],
  standard_error = title_fit_summary["LAD", "Std. Error"],
  p_two_sided = title_fit_summary["LAD", "Pr(>|t|)"],
  ci_low = title_fit_ci["LAD", 1L], ci_high = title_fit_ci["LAD", 2L]
)

# Abundance-matched random-set specificity.
mean_abundance <- rowMeans(counts)
abundance_bin <- pmin(10L, ceiling(rank(mean_abundance, ties.method = "first") * 10 / length(mean_abundance)))
names(abundance_bin) <- genes
core_bins <- abundance_bin[core]
set.seed(20260911)
random_differences <- numeric(B)
random_differences_biopsy <- numeric(B)
random_differences_title <- numeric(B)
for (b in seq_len(B)) {
  sampled <- unlist(lapply(sort(unique(core_bins)), function(bin) {
    sample(genes[abundance_bin == bin], sum(core_bins == bin), replace = FALSE)
  }), use.names = FALSE)
  score <- rank_score(sampled)
  tmp <- aggregate(score ~ patient_id + group,
                   data.frame(score = score, patient_id = biopsy$patient_id, group = biopsy$group), mean)
  random_differences[[b]] <- mean(tmp$score[tmp$group == "LAD"]) - mean(tmp$score[tmp$group == "HC"])
  random_differences_biopsy[[b]] <- mean(score[biopsy$group == "LAD"]) - mean(score[biopsy$group == "HC"])
  title_tmp <- aggregate(score ~ title_cluster + group,
                         data.frame(score = score, title_cluster = biopsy$title_cluster, group = biopsy$group), mean)
  random_differences_title[[b]] <- mean(title_tmp$score[title_tmp$group == "LAD"]) -
    mean(title_tmp$score[title_tmp$group == "HC"])
}
specificity_p <- (1 + sum(random_differences >= primary$mean_difference)) / (B + 1)
specificity_p_biopsy <- (1 + sum(random_differences_biopsy >= biopsy_primary$mean_difference)) / (B + 1)
specificity_p_title <- (1 + sum(random_differences_title >= title_primary$mean_difference)) / (B + 1)

# Biopsy-level sensitivity with donor-cluster bootstrap.
biopsy_lad <- biopsy[biopsy$group == "LAD", ]
biopsy_hc <- biopsy[biopsy$group == "HC", ]
cluster_boot <- replicate(B, {
  lad_ids <- sample(unique(biopsy_lad$patient_id), replace = TRUE)
  hc_ids <- sample(unique(biopsy_hc$patient_id), replace = TRUE)
  lx <- unlist(lapply(lad_ids, function(id) biopsy_lad$core_rank_score[biopsy_lad$patient_id == id]))
  hx <- unlist(lapply(hc_ids, function(id) biopsy_hc$core_rank_score[biopsy_hc$patient_id == id]))
  mean(lx) - mean(hx)
})
biopsy_sensitivity <- data.frame(
  n_LAD_biopsies = nrow(biopsy_lad), n_HC_biopsies = nrow(biopsy_hc),
  mean_difference = mean(biopsy_lad$core_rank_score) - mean(biopsy_hc$core_rank_score),
  cluster_boot_ci_low = quantile(cluster_boot, 0.025, names = FALSE),
  cluster_boot_ci_high = quantile(cluster_boot, 0.975, names = FALSE)
)

# Gene-level direction on logCPM for interpretability only.
gene_effects <- do.call(rbind, lapply(core, function(gene) {
  values <- logcpm_core[gene, ]
  x <- values[biopsy$group == "LAD"]
  y <- values[biopsy$group == "HC"]
  data.frame(gene = gene, mean_log2cpm_LAD = mean(x), mean_log2cpm_HC = mean(y),
             mean_difference = mean(x) - mean(y),
             p_one_sided = wilcox.test(x, y, alternative = "greater", exact = FALSE)$p.value)
}))
gene_effects$p_bh <- p.adjust(gene_effects$p_one_sided, method = "BH")

write.table(biopsy, file.path(output_dir, "frozen_core_scores_biopsy.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
write.table(donor, file.path(output_dir, "frozen_core_scores_donor.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
write.table(title_cluster, file.path(output_dir, "frozen_core_scores_title_cluster.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
write.table(primary, file.path(output_dir, "primary_LAD_vs_HC.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
write.table(biopsy_primary, file.path(output_dir, "primary_LAD_vs_HC_biopsy.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
write.table(title_primary, file.path(output_dir, "primary_LAD_vs_HC_title_cluster.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
write.table(nad_hc, file.path(output_dir, "secondary_NAD_vs_HC.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
write.table(paired, file.path(output_dir, "paired_scores.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
write.table(paired_summary, file.path(output_dir, "secondary_paired_LAD_vs_NAD.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
write.table(title_paired, file.path(output_dir, "title_cluster_paired_scores.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
write.table(title_paired_summary, file.path(output_dir, "title_cluster_paired_summary.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
write.table(loo, file.path(output_dir, "leave_one_gene_out.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
write.table(z_sensitivity, file.path(output_dir, "logcpm_hc_z_sensitivity.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
write.table(proliferation_adjusted, file.path(output_dir, "proliferation_adjusted.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
write.table(title_proliferation_adjusted, file.path(output_dir, "title_cluster_proliferation_adjusted.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
write.table(data.frame(random_mean_difference_qc_mapped = random_differences,
                       random_mean_difference_biopsy = random_differences_biopsy,
                       random_mean_difference_title_cluster = random_differences_title),
            file.path(output_dir, "matched_random_set_null.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
write.table(data.frame(analysis = c("qc_mapped_donor", "biopsy", "title_cluster"),
                       observed_mean_difference = c(primary$mean_difference, biopsy_primary$mean_difference, title_primary$mean_difference),
                       empirical_p = c(specificity_p, specificity_p_biopsy, specificity_p_title)),
            file.path(output_dir, "matched_random_set_summary.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
write.table(biopsy_sensitivity, file.path(output_dir, "biopsy_cluster_bootstrap.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
write.table(gene_effects, file.path(output_dir, "core_gene_logcpm_effects.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)

png(file.path(output_dir, "GSE328048_frozen_16gene_validation.png"), width = 2400, height = 1800, res = 300)
par(mfrow = c(2, 2), mar = c(4.2, 4.5, 2.2, 1.2), las = 1)
boxplot(core_rank_score ~ group, title_cluster, order = c("HC", "NAD", "LAD"), col = c("#4DAF4A", "#377EB8", "#E41A1C"),
        ylab = "Frozen 16-gene rank score", xlab = "", main = "A  Public title-cluster analysis")
stripchart(core_rank_score ~ group, title_cluster, at = 1:3, vertical = TRUE, method = "jitter", add = TRUE, pch = 21, bg = "white")
plot(c(1, 2), range(c(title_paired$core_rank_score_NAD, title_paired$core_rank_score_LAD)), type = "n", xaxt = "n",
     xlab = "", ylab = "Frozen 16-gene rank score", main = "B  Title-cluster pairing")
axis(1, at = 1:2, labels = c("NAD", "LAD"))
apply(title_paired, 1L, function(z) lines(c(1, 2), as.numeric(z[c("core_rank_score_NAD", "core_rank_score_LAD")]), col = "#99999980"))
points(rep(1, nrow(title_paired)), title_paired$core_rank_score_NAD, pch = 21, bg = "#377EB8")
points(rep(2, nrow(title_paired)), title_paired$core_rank_score_LAD, pch = 21, bg = "#E41A1C")
dotchart(loo$cliffs_delta, labels = loo$omitted_gene, pch = 19, color = ifelse(loo$nominally_significant, "#2166AC", "#999999"),
         xlab = "Cliff's delta (LAD vs HC)", main = "C  Leave-one-gene-out")
abline(v = 0, lty = 2)
hist(random_differences_title, breaks = 50, col = "#D9D9D9", border = "white", xlab = "LAD-HC mean score difference",
     main = "D  Abundance-matched random sets")
abline(v = title_primary$mean_difference, col = "#B2182B", lwd = 3)
legend("topright", legend = sprintf("Frozen core; empirical P = %.4g", specificity_p_title), col = "#B2182B", lwd = 3, bty = "n")
dev.off()

report <- c(
  "# GSE328048 frozen 16-gene external validation",
  "",
  sprintf("QC-count-mapped donor sensitivity, LAD versus HC: n=%d versus %d; mean difference %.6f; median difference %.6f; AUC %.3f (95%% CI %.3f–%.3f); Cliff's delta %.3f; one-sided Mann–Whitney P=%.4g; 10,000-label permutation P=%.4g. Primary support: %s.",
          primary$n_x, primary$n_y, primary$mean_difference, primary$median_difference, primary$auc,
          primary$auc_ci_low, primary$auc_ci_high, primary$cliffs_delta,
          primary$mann_whitney_p_one_sided, primary$permutation_p_mean_difference,
          ifelse(primary$primary_supported, "YES", "NO")),
  "",
  sprintf("Public-metadata analyses: biopsy-level LAD versus HC n=%d versus %d, AUC %.3f, one-sided Mann–Whitney P=%.4g, permutation P=%.4g; title-cluster LAD versus HC n=%d versus %d, AUC %.3f, one-sided Mann–Whitney P=%.4g, permutation P=%.4g.",
          biopsy_primary$n_x, biopsy_primary$n_y, biopsy_primary$auc, biopsy_primary$mann_whitney_p_one_sided,
          biopsy_primary$permutation_p_mean_difference, title_primary$n_x, title_primary$n_y, title_primary$auc,
          title_primary$mann_whitney_p_one_sided, title_primary$permutation_p_mean_difference),
  "",
  sprintf("QC-count-mapped paired LAD versus NAD: %d donors; median paired difference %.6f; one-sided Wilcoxon P=%.4g; sign-flip P=%.4g; BH-adjusted directional P=%.4g. Public title-cluster pairing: %d clusters; median difference %.6f; one-sided Wilcoxon P=%.4g.",
          paired_summary$n_pairs, paired_summary$median_difference, paired_summary$wilcoxon_p_one_sided,
          paired_summary$signflip_p_mean_difference, paired_summary$secondary_directional_bh,
          title_paired_summary$n_pairs, title_paired_summary$median_difference,
          title_paired_summary$wilcoxon_p_one_sided),
  "",
  sprintf("NAD versus HC: n=%d versus %d; AUC %.3f; one-sided Mann–Whitney P=%.4g; BH-adjusted directional P=%.4g.",
          nad_hc$n_x, nad_hc$n_y, nad_hc$auc, nad_hc$mann_whitney_p_one_sided, nad_hc$secondary_directional_bh),
  "",
  sprintf("Robustness: %d/16 leave-one-gene-out scores retained a positive nominally significant primary contrast; abundance-matched random-set empirical P values were %.4g (QC-mapped), %.4g (biopsy), and %.4g (title-cluster); title-cluster proliferation-adjusted LAD coefficient %.6f (95%% CI %.6f–%.6f, two-sided P=%.4g).",
          sum(loo$nominally_significant), specificity_p, specificity_p_biopsy,
          specificity_p_title, title_proliferation_adjusted$coefficient,
          title_proliferation_adjusted$ci_low, title_proliferation_adjusted$ci_high,
          title_proliferation_adjusted$p_two_sided),
  "",
  "The GEO record does not expose a direct library-to-donor key. QC-cell-count donor mapping is therefore sensitivity-only; biopsy and title-cluster results are retained separately. Interpretation is limited to external transcriptomic generalization. Whole-biopsy pseudobulk may reflect both cell-state and cell-composition changes; it does not establish causality, diagnostic accuracy, or clinical utility."
)
writeLines(report, file.path(output_dir, "VALIDATION_REPORT.md"))
cat(paste(report, collapse = "\n"), "\n")
