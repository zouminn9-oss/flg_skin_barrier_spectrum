#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(Matrix)
  library(nichenetr)
})

set.seed(20260910)
bundle <- "data/processed/advanced_single_cell_inputs/paired_day4_irritant_balanced"
model_dir <- "external_tools/NicheNet_data"
out_root <- "results/advanced_single_cell/communication/NicheNet"
dir.create(out_root, recursive = TRUE, showWarnings = FALSE)

counts <- readMM(file.path(bundle, "counts_genes_by_cells.mtx"))
genes <- read.delim(file.path(bundle, "genes.tsv"), check.names = FALSE)[[1]]
cells <- read.delim(file.path(bundle, "barcodes.tsv"), check.names = FALSE)[[1]]
meta <- read.delim(file.path(bundle, "metadata.tsv"), row.names = 1, check.names = FALSE)
rownames(counts) <- make.unique(as.character(genes))
colnames(counts) <- as.character(cells)
meta <- meta[cells, , drop = FALSE]
counts <- as(counts, "CsparseMatrix")

lr_network <- readRDS(file.path(model_dir, "lr_network_human_21122021.rds"))
ligand_target_matrix <- readRDS(file.path(model_dir, "ligand_target_matrix_nsga2r_final.rds"))
lr_network <- unique(lr_network[c("from", "to")])
names(lr_network) <- c("ligand", "receptor")

exact_signflip_p <- function(delta) {
  n <- length(delta)
  grid <- as.matrix(expand.grid(rep(list(c(-1, 1)), n)))
  observed <- abs(mean(delta))
  mean(abs(grid %*% delta / n) >= observed - 1e-12)
}

receiver_pseudobulk <- function(excluded_donor = NA_character_) {
  donors <- sort(setdiff(unique(meta$Patient), excluded_donor))
  samples <- expand.grid(Patient = donors, Lesion = c("Irritant", "Day4_Allergy"), stringsAsFactors = FALSE)
  pb <- sapply(seq_len(nrow(samples)), function(i) {
    ix <- meta$Patient == samples$Patient[i] & meta$Lesion == samples$Lesion[i] & meta$Basic_Celltype == "KRT"
    Matrix::rowSums(counts[, ix, drop = FALSE])
  })
  colnames(pb) <- paste(samples$Patient, samples$Lesion, sep = "|")
  logcpm <- log2(t(t(pb) / pmax(colSums(pb), 1)) * 1e6 + 1)
  day4 <- logcpm[, paste(donors, "Day4_Allergy", sep = "|"), drop = FALSE]
  irritant <- logcpm[, paste(donors, "Irritant", sep = "|"), drop = FALSE]
  delta <- day4 - irritant
  mean_delta <- rowMeans(delta)
  sd_delta <- apply(delta, 1, sd)
  rank_stat <- mean_delta / (sd_delta / sqrt(length(donors)) + 0.1)
  p <- apply(delta, 1, exact_signflip_p)
  data.frame(
    gene = rownames(counts),
    mean_log2cpm_delta_Day4_vs_Irritant = mean_delta,
    paired_rank_statistic = rank_stat,
    exact_signflip_p = p,
    q_BH = p.adjust(p, method = "BH"),
    positive_donors = rowSums(delta > 0),
    negative_donors = rowSums(delta < 0),
    stringsAsFactors = FALSE
  )
}

expressed_genes <- function(celltype, condition, excluded_donor = NA_character_, threshold = 0.05) {
  ix <- meta$Basic_Celltype == celltype & meta$Lesion == condition
  if (!is.na(excluded_donor)) ix <- ix & meta$Patient != excluded_donor
  rownames(counts)[Matrix::rowMeans(counts[, ix, drop = FALSE] > 0) >= threshold]
}

run_direction <- function(direction, excluded_donor = NA_character_) {
  de <- receiver_pseudobulk(excluded_donor)
  condition <- if (direction == "Day4_up") "Day4_Allergy" else "Irritant"
  sign_mult <- if (direction == "Day4_up") 1 else -1
  de$directional_statistic <- sign_mult * de$paired_rank_statistic
  de$directional_effect <- sign_mult * de$mean_log2cpm_delta_Day4_vs_Irritant
  background <- Reduce(intersect, list(
    rownames(ligand_target_matrix),
    union(expressed_genes("KRT", "Irritant", excluded_donor), expressed_genes("KRT", "Day4_Allergy", excluded_donor))
  ))
  candidates <- de$gene[de$gene %in% background & is.finite(de$directional_statistic) & de$directional_effect > 0]
  candidates <- candidates[order(de$directional_statistic[match(candidates, de$gene)], decreasing = TRUE)]
  geneset <- head(candidates, 200L)
  sender_genes <- union(
    expressed_genes("APC", condition, excluded_donor),
    expressed_genes("LYMPH", condition, excluded_donor)
  )
  receptor_genes <- expressed_genes("KRT", condition, excluded_donor)
  lr <- lr_network[lr_network$ligand %in% sender_genes & lr_network$receptor %in% receptor_genes, , drop = FALSE]
  potential_ligands <- intersect(unique(lr$ligand), colnames(ligand_target_matrix))
  if (length(geneset) < 30L || length(potential_ligands) < 3L) {
    stop("Insufficient NicheNet inputs after expression filtering: targets=", length(geneset),
         ", ligands=", length(potential_ligands), ", direction=", direction,
         ", excluded_donor=", excluded_donor)
  }
  activity <- predict_ligand_activities(
    geneset = geneset,
    background_expressed_genes = background,
    ligand_target_matrix = ligand_target_matrix,
    potential_ligands = potential_ligands
  )
  activity <- activity[order(activity$pearson, decreasing = TRUE), , drop = FALSE]
  activity$rank <- seq_len(nrow(activity))
  activity$direction <- direction
  activity$condition <- condition
  activity$excluded_donor <- ifelse(is.na(excluded_donor), "none", excluded_donor)
  activity$n_target_genes <- length(geneset)
  activity$n_background_genes <- length(background)
  activity$n_candidate_ligands <- length(potential_ligands)
  list(activity = activity, de = de, geneset = geneset, lr = lr)
}

aggregate_results <- list()
lodo_rows <- list()
for (direction in c("Day4_up", "Irritant_up")) {
  message("NicheNet aggregate: ", direction)
  full <- run_direction(direction)
  aggregate_results[[direction]] <- full
  write.table(full$activity, file.path(out_root, paste0("nichenet_", direction, "_ligand_activity.tsv")), sep = "\t", quote = FALSE, row.names = FALSE)
  write.table(full$de, file.path(out_root, paste0("nichenet_", direction, "_receiver_pseudobulk_statistics.tsv")), sep = "\t", quote = FALSE, row.names = FALSE)
  writeLines(full$geneset, file.path(out_root, paste0("nichenet_", direction, "_top200_receiver_targets.txt")))
  top_ligands <- head(full$activity$test_ligand, 20L)
  links <- do.call(rbind, lapply(top_ligands, function(ligand) {
    z <- get_weighted_ligand_target_links(ligand, full$geneset, ligand_target_matrix, n = 100)
    z$ligand <- ligand
    z
  }))
  links$direction <- direction
  write.table(links, file.path(out_root, paste0("nichenet_", direction, "_top_ligand_target_links.tsv")), sep = "\t", quote = FALSE, row.names = FALSE)
  for (donor in sort(unique(meta$Patient))) {
    message("NicheNet LODO: ", direction, ", excluding ", donor)
    z <- run_direction(direction, excluded_donor = donor)$activity
    z$held_out <- donor
    lodo_rows[[paste(direction, donor, sep = "|")]] <- z
  }
}

lodo <- do.call(rbind, lodo_rows)
rownames(lodo) <- NULL
write.table(lodo, file.path(out_root, "nichenet_lodo_ligand_activity.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)

aggregate_activity <- do.call(rbind, lapply(aggregate_results, `[[`, "activity"))
support <- aggregate(rank ~ direction + test_ligand, lodo[lodo$rank <= 20, , drop = FALSE], function(x) length(x))
names(support)[3] <- "lodo_top20_support_of_5"
median_rank <- aggregate(rank ~ direction + test_ligand, lodo, median)
names(median_rank)[3] <- "lodo_median_rank"
aggregate_activity <- merge(aggregate_activity, support, by = c("direction", "test_ligand"), all.x = TRUE)
aggregate_activity <- merge(aggregate_activity, median_rank, by = c("direction", "test_ligand"), all.x = TRUE)
aggregate_activity$lodo_top20_support_of_5[is.na(aggregate_activity$lodo_top20_support_of_5)] <- 0L
write.table(aggregate_activity, file.path(out_root, "nichenet_aggregate_with_lodo_support.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)

writeLines(c(
  paste0("nichenetr_version\t", packageVersion("nichenetr")),
  "model\tNicheNet-v2 human ligand-receptor network and NSGA-II ligand-target matrix",
  "model_record\tZenodo 7074291",
  "ligand_target_matrix_md5\tb09606b04b2d4490418d9028c0e58b9f",
  "lr_network_md5\t2a155f81e9ffffd5d5e709fe66bcc465",
  "receiver\tKRT",
  "senders\tAPC,LYMPH",
  "expression_fraction_threshold\t0.05",
  "target_definition\ttop 200 direction-specific genes by paired-donor pseudobulk rank statistic",
  "inference\texact two-sided sign-flip test over paired donor log2-CPM deltas",
  "lodo_replicates\t5 per direction"
), file.path(out_root, "nichenet_run_metadata.tsv"))
