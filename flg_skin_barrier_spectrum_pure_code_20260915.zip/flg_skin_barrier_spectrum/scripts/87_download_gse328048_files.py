#!/usr/bin/env python3
"""Download GSE328048 feature tables and sparse matrices with resumable workers."""

from __future__ import annotations

import argparse
import csv
import os
import subprocess
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path


def supplementary_urls(series_matrix: Path) -> list[str]:
    urls: list[str] = []
    with series_matrix.open(newline="") as handle:
        for row in csv.reader(handle, delimiter="\t"):
            if not row or row[0] not in {
                "!Sample_supplementary_file_2",
                "!Sample_supplementary_file_3",
            }:
                continue
            urls.extend(value.replace("ftp://", "https://", 1) for value in row[1:])
    if len(urls) != 232:
        raise RuntimeError(f"Expected 232 URLs (116 features + 116 matrices), found {len(urls)}")
    return urls


def download(url: str, output_dir: Path) -> tuple[str, int]:
    destination = output_dir / url.rsplit("/", 1)[-1]
    env = os.environ.copy()
    env.setdefault("https_proxy", "http://127.0.0.1:7890")
    env.setdefault("http_proxy", "http://127.0.0.1:7890")
    command = [
        "curl", "--location", "--fail", "--silent", "--show-error",
        "--retry", "8", "--retry-delay", "2", "--retry-all-errors",
        "--continue-at", "-", "--output", str(destination), url,
    ]
    subprocess.run(command, check=True, env=env)
    return destination.name, destination.stat().st_size


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--series-matrix", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=16)
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    urls = supplementary_urls(args.series_matrix)
    total = len(urls)
    completed = 0
    total_bytes = 0
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        futures = {pool.submit(download, url, args.output_dir): url for url in urls}
        for future in as_completed(futures):
            name, size = future.result()
            completed += 1
            total_bytes += size
            print(f"[{completed:03d}/{total}] {name} ({size / 1024**2:.1f} MiB)", flush=True)
    print(f"Downloaded {total} files; aggregate size {total_bytes / 1024**3:.2f} GiB")


if __name__ == "__main__":
    main()
