#!/usr/bin/env Rscript

# Fine-state program localization and paired differential-abundance analysis
# for the five common GSE267929 allergy/irritant donors.

suppressPackageStartupMessages({
  library(Matrix)
  library(edgeR)
  library(limma)
})

root <- normalizePath(getwd())
raw <- file.path(root, "data", "raw")
sc_raw <- file.path(raw, "expression", "geo", "GSE267929")
meta_path <- file.path(raw, "geo", "GSE267929", "GSE267929_meta.data.tsv.gz")
mech <- file.path(
  root, "results", "exploratory_snf", "selected_positive_reml_z_q05",
  "optimized_AD_ACD_branch", "mechanism"
)
out <- file.path(mech, "single_cell_subtype_robustness")
dir.create(out, recursive = TRUE, showWarnings = FALSE)

donors <- c("P1", "P2", "P3", "P4", "P8")
conditions <- c("Irritant", "Day4_Allergy")
min_cells <- 10L
min_paired_donors <- 3L

read_gmt <- function(path) {
  x <- strsplit(readLines(path, warn = FALSE), "\t", fixed = TRUE)
  sets <- lapply(x, function(z) unique(z[-c(1, 2)]))
  names(sets) <- vapply(x, `[[`, character(1), 1)
  sets
}

counts <- readMM(gzfile(file.path(sc_raw, "GSE267929_matrix.mtx.gz")))
genes <- read.delim(gzfile(file.path(sc_raw, "GSE267929_genes.tsv.gz")), header = FALSE)
barcodes <- readLines(gzfile(file.path(sc_raw, "GSE267929_barcodes.tsv.gz")))
meta <- read.table(
  gzfile(meta_path), header = TRUE, row.names = 1, check.names = FALSE,
  stringsAsFactors = FALSE
)
stopifnot(nrow(counts) == nrow(genes), ncol(counts) == length(barcodes))
stopifnot(identical(barcodes, rownames(meta)))
rownames(counts) <- genes[[2]]
colnames(counts) <- barcodes

reactome <- read_gmt(file.path(raw, "pathways", "reactome_v97", "ReactomePathways.gmt"))
drivers <- read.delim(file.path(mech, "top_AD_ACD_pathway_drivers.tsv"), check.names = FALSE)
driver_pathways <- head(drivers$pathway, 20L)

fit_program <- function(pb, smeta, flip = NULL) {
  dat <- smeta
  current_donors <- sort(unique(dat$participant))
  if (is.null(flip)) flip <- setNames(rep(FALSE, length(current_donors)), current_donors)
  swap <- unname(flip[dat$participant])
  dat$analysis_condition <- dat$condition
  dat$analysis_condition[swap & dat$condition == "Day4_Allergy"] <- "Irritant"
  dat$analysis_condition[swap & dat$condition == "Irritant"] <- "Day4_Allergy"
  dat$participant <- factor(dat$participant)
  dat$analysis_condition <- factor(dat$analysis_condition, levels = conditions)
  design <- model.matrix(~ participant + analysis_condition, dat)

  y <- DGEList(counts = pb)
  keep <- filterByExpr(y, design = design, min.count = 5)
  y <- normLibSizes(y[keep, , keep.lib.sizes = FALSE])
  y <- estimateDisp(y, design, robust = TRUE)
  fit <- glmQLFit(y, design, robust = TRUE)
  qlf <- glmQLFTest(fit, coef = "analysis_conditionDay4_Allergy")
  tt <- topTags(qlf, n = Inf, sort.by = "none")$table
  stat <- sign(tt$logFC) * sqrt(pmax(tt$F, 0))
  names(stat) <- rownames(tt)
  stat <- stat[is.finite(stat)]

  idx <- lapply(reactome, function(z) which(names(stat) %in% z))
  sizes <- vapply(idx, length, integer(1))
  idx <- idx[sizes >= 10L & sizes <= 500L]
  cam <- cameraPR(stat, index = idx, use.ranks = TRUE, inter.gene.cor = 0.01, sort = FALSE)
  cam$pathway <- rownames(cam)
  selected <- cam[cam$pathway %in% driver_pathways, , drop = FALSE]
  z <- ifelse(selected$Direction == "Up", 1, -1) *
    qnorm(pmax(selected$PValue / 2, 1e-300), lower.tail = FALSE)
  list(
    score = mean(z), measured = nrow(selected), up = sum(selected$Direction == "Up"),
    tested_genes = nrow(tt)
  )
}

aggregate_subtype <- function(subtype) {
  use <- meta$Detailed_Celltype == subtype & meta$Patient %in% donors & meta$Lesion %in% conditions
  m <- meta[use, , drop = FALSE]
  cell_table <- table(
    factor(m$Patient, levels = donors), factor(m$Lesion, levels = conditions)
  )
  eligible <- donors[apply(cell_table >= min_cells, 1, all)]
  if (length(eligible) < min_paired_donors) return(NULL)
  m <- m[m$Patient %in% eligible, , drop = FALSE]
  grouping <- interaction(m$Patient, m$Lesion, drop = TRUE, sep = "__")
  z <- sparse.model.matrix(~ 0 + grouping)
  colnames(z) <- sub("^grouping", "", colnames(z))
  pb <- counts[, rownames(m), drop = FALSE] %*% z
  parts <- do.call(rbind, strsplit(colnames(pb), "__", fixed = TRUE))
  smeta <- data.frame(
    sample = colnames(pb), participant = parts[, 1], condition = parts[, 2],
    cells = as.integer(table(grouping)[colnames(pb)]), stringsAsFactors = FALSE
  )
  ord <- order(match(smeta$participant, eligible), match(smeta$condition, conditions))
  list(counts = pb[, ord, drop = FALSE], meta = smeta[ord, , drop = FALSE], donors = eligible)
}

subtype_parent <- unique(meta[, c("Detailed_Celltype", "Basic_Celltype")])
subtype_parent <- subtype_parent[
  subtype_parent$Basic_Celltype %in% c("APC", "KRT") & !is.na(subtype_parent$Detailed_Celltype),
  , drop = FALSE
]

subtype_rows <- list()
subtype_perm_rows <- list()
subtype_loo_rows <- list()

for (i in seq_len(nrow(subtype_parent))) {
  subtype <- subtype_parent$Detailed_Celltype[i]
  parent <- subtype_parent$Basic_Celltype[i]
  obj <- aggregate_subtype(subtype)
  if (is.null(obj)) next
  observed <- fit_program(obj$counts, obj$meta)
  n <- length(obj$donors)
  grid <- expand.grid(rep(list(c(FALSE, TRUE)), n), KEEP.OUT.ATTRS = FALSE)
  names(grid) <- obj$donors
  null <- numeric(nrow(grid))
  for (j in seq_len(nrow(grid))) {
    flip <- setNames(as.logical(grid[j, ]), obj$donors)
    null[j] <- fit_program(obj$counts, obj$meta, flip)$score
    subtype_perm_rows[[length(subtype_perm_rows) + 1L]] <- data.frame(
      parent = parent, subtype = subtype, permutation_id = j - 1L,
      flipped_donors = paste(obj$donors[flip], collapse = ";"),
      score = null[j], stringsAsFactors = FALSE
    )
  }
  direction <- if (parent == "APC") "positive" else "negative"
  p_dir <- if (direction == "positive") {
    mean(null >= observed$score - 1e-12)
  } else {
    mean(null <= observed$score + 1e-12)
  }
  p_two <- mean(abs(null) >= abs(observed$score) - 1e-12)

  loo_scores <- numeric()
  if (n >= 4L) {
    for (omitted in obj$donors) {
      keep <- obj$meta$participant != omitted
      ans <- fit_program(obj$counts[, keep, drop = FALSE], obj$meta[keep, , drop = FALSE])
      loo_scores <- c(loo_scores, ans$score)
      subtype_loo_rows[[length(subtype_loo_rows) + 1L]] <- data.frame(
        parent = parent, subtype = subtype, omitted_donor = omitted,
        retained_donors = n - 1L, score = ans$score,
        same_parental_direction = if (parent == "APC") ans$score > 0 else ans$score < 0,
        stringsAsFactors = FALSE
      )
    }
  }
  subtype_rows[[length(subtype_rows) + 1L]] <- data.frame(
    parent = parent, subtype = subtype, n_paired_donors = n,
    donors = paste(obj$donors, collapse = ";"), observed_score = observed$score,
    expected_parental_direction = direction, exact_p_directional = p_dir,
    exact_p_two_sided = p_two, exact_permutations = nrow(grid),
    measured_pathways = observed$measured, pathways_up = observed$up,
    tested_genes = observed$tested_genes,
    loo_runs = length(loo_scores),
    loo_parental_direction_preserved = if (length(loo_scores)) {
      sum(if (parent == "APC") loo_scores > 0 else loo_scores < 0)
    } else NA_integer_,
    loo_min = if (length(loo_scores)) min(loo_scores) else NA_real_,
    loo_max = if (length(loo_scores)) max(loo_scores) else NA_real_,
    stringsAsFactors = FALSE
  )
}

subtypes <- do.call(rbind, subtype_rows)
subtypes$q_directional_BH_all_subtypes <- p.adjust(subtypes$exact_p_directional, "BH")
subtypes$q_two_sided_BH_all_subtypes <- p.adjust(subtypes$exact_p_two_sided, "BH")
subtypes <- subtypes[order(subtypes$parent, subtypes$exact_p_directional), ]
write.table(subtypes, file.path(out, "subtype_program_summary.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
write.table(do.call(rbind, subtype_perm_rows), file.path(out, "subtype_label_swap_null.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
if (length(subtype_loo_rows)) {
  write.table(do.call(rbind, subtype_loo_rows), file.path(out, "subtype_leave_one_donor_out.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
}

# Paired differential abundance.  Basic populations use their fraction of all
# cells; detailed APC/KRT states use their fraction of the corresponding parent.
exact_abundance <- function(difference) {
  n <- length(difference)
  grid <- expand.grid(rep(list(c(-1, 1)), n), KEEP.OUT.ATTRS = FALSE)
  null <- apply(grid, 1, function(s) mean(as.numeric(s) * difference))
  observed <- mean(difference)
  data.frame(
    mean_logit_difference = observed,
    exact_p_two_sided = mean(abs(null) >= abs(observed) - 1e-12),
    exact_permutations = length(null),
    loo_min = min(vapply(seq_along(difference), function(i) mean(difference[-i]), numeric(1))),
    loo_max = max(vapply(seq_along(difference), function(i) mean(difference[-i]), numeric(1))),
    loo_same_direction = sum(vapply(
      seq_along(difference), function(i) sign(mean(difference[-i])) == sign(observed), logical(1)
    ))
  )
}

m5 <- meta[meta$Patient %in% donors & meta$Lesion %in% conditions, , drop = FALSE]
abundance_rows <- list()

for (celltype in sort(unique(m5$Basic_Celltype))) {
  diff <- numeric(length(donors))
  for (i in seq_along(donors)) {
    d <- donors[i]
    vals <- numeric(2)
    for (j in seq_along(conditions)) {
      z <- m5$Patient == d & m5$Lesion == conditions[j]
      count <- sum(z & m5$Basic_Celltype == celltype)
      total <- sum(z)
      vals[j] <- qlogis((count + 0.5) / (total + 1))
    }
    diff[i] <- vals[2] - vals[1]
  }
  test <- exact_abundance(diff)
  abundance_rows[[length(abundance_rows) + 1L]] <- data.frame(
    level = "basic_fraction_of_all_cells", parent = "all_cells", feature = celltype,
    n_donors = length(donors), test, stringsAsFactors = FALSE
  )
}

for (i in seq_len(nrow(subtype_parent))) {
  subtype <- subtype_parent$Detailed_Celltype[i]
  parent <- subtype_parent$Basic_Celltype[i]
  diff <- numeric(length(donors))
  for (j in seq_along(donors)) {
    d <- donors[j]
    vals <- numeric(2)
    for (k in seq_along(conditions)) {
      z <- m5$Patient == d & m5$Lesion == conditions[k] & m5$Basic_Celltype == parent
      count <- sum(z & m5$Detailed_Celltype == subtype)
      total <- sum(z)
      vals[k] <- qlogis((count + 0.5) / (total + 1))
    }
    diff[j] <- vals[2] - vals[1]
  }
  test <- exact_abundance(diff)
  abundance_rows[[length(abundance_rows) + 1L]] <- data.frame(
    level = "detailed_fraction_of_parent", parent = parent, feature = subtype,
    n_donors = length(donors), test, stringsAsFactors = FALSE
  )
}

abundance <- do.call(rbind, abundance_rows)
abundance$q_BH_within_level <- ave(
  abundance$exact_p_two_sided, abundance$level,
  FUN = function(p) p.adjust(p, "BH")
)
abundance$direction <- ifelse(
  abundance$mean_logit_difference > 0, "higher_fraction_in_allergy", "higher_fraction_in_irritant"
)
abundance <- abundance[order(abundance$level, abundance$exact_p_two_sided), ]
write.table(abundance, file.path(out, "paired_differential_abundance.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)

writeLines(c(
  paste0("common_donors\t", paste(donors, collapse = ";")),
  paste0("conditions\t", paste(conditions, collapse = ";")),
  paste0("minimum_cells_per_subtype_donor_condition\t", min_cells),
  paste0("minimum_paired_donors_for_subtype_program\t", min_paired_donors),
  "subtype_null\texhaustive within-donor label swaps",
  "abundance_null\texhaustive paired sign flips of donor logit differences",
  "multiplicity\tBH within subtype-program family and abundance-resolution family"
), file.path(out, "RUN_PARAMETERS.tsv"))

print(subtypes)
cat("\nPaired abundance results:\n")
print(abundance)
