#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(Matrix)
  library(Seurat)
  library(CellChat)
  library(future)
})

set.seed(20260910)
future::plan("sequential")
bundle <- "data/processed/advanced_single_cell_inputs/paired_day4_irritant_balanced"
out_root <- "results/advanced_single_cell/communication/CellChat"
dir.create(out_root, recursive = TRUE, showWarnings = FALSE)

counts <- readMM(file.path(bundle, "counts_genes_by_cells.mtx"))
genes <- read.delim(file.path(bundle, "genes.tsv"), check.names = FALSE)[[1]]
cells <- read.delim(file.path(bundle, "barcodes.tsv"), check.names = FALSE)[[1]]
meta <- read.delim(file.path(bundle, "metadata.tsv"), row.names = 1, check.names = FALSE)
rownames(counts) <- make.unique(as.character(genes))
colnames(counts) <- as.character(cells)
meta <- meta[cells, , drop = FALSE]
counts <- as(counts, "CsparseMatrix")

seu <- CreateSeuratObject(counts = counts, min.cells = 0, min.features = 0, meta.data = meta)
seu <- NormalizeData(seu, verbose = FALSE)
norm <- LayerData(seu, assay = "RNA", layer = "data")

run_cellchat <- function(condition, excluded_donor = NA_character_, nboot = 100L, save_object = TRUE) {
  keep <- meta$Lesion == condition
  if (!is.na(excluded_donor)) keep <- keep & meta$Patient != excluded_donor
  md <- meta[keep, , drop = FALSE]
  md$samples <- md$Patient
  mat <- norm[, rownames(md), drop = FALSE]
  cc <- createCellChat(object = mat, meta = md, group.by = "Basic_Celltype")
  cc@DB <- CellChatDB.human
  cc <- subsetData(cc)
  cc <- identifyOverExpressedGenes(cc, do.fast = FALSE)
  cc <- identifyOverExpressedInteractions(cc)
  cc <- computeCommunProb(cc, type = "triMean", raw.use = TRUE, population.size = FALSE,
                          nboot = nboot, seed.use = 20260910)
  cc <- filterCommunication(cc, min.cells = 5)
  cc <- computeCommunProbPathway(cc)
  cc <- aggregateNet(cc)
  tab <- subsetCommunication(cc, thresh = 1)
  if (!nrow(tab)) return(list(table = tab, object = cc))
  tab$qvalue_global <- p.adjust(tab$pval, method = "BH")
  tab$condition <- condition
  tab$excluded_donor <- ifelse(is.na(excluded_donor), "none", excluded_donor)
  tab$key <- paste(tab$source, tab$target, tab$ligand, tab$receptor, sep = "|")
  if (save_object) {
    d <- file.path(out_root, condition)
    dir.create(d, recursive = TRUE, showWarnings = FALSE)
    saveRDS(cc, file.path(d, "cellchat_object.rds"))
  }
  list(table = tab, object = cc)
}

aggregate_results <- list()
lodo_results <- list()
for (condition in c("Irritant", "Day4_Allergy")) {
  message("CellChat aggregate: ", condition)
  full <- run_cellchat(condition, nboot = 100L, save_object = TRUE)
  aggregate_results[[condition]] <- full$table
  d <- file.path(out_root, condition)
  write.table(full$table, file.path(d, "cellchat_all_interactions.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
  sig <- full$table[full$table$pval < 0.05 & full$table$prob > 0, , drop = FALSE]
  write.table(sig, file.path(d, "cellchat_interactions_p05.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
  for (donor in sort(unique(meta$Patient))) {
    message("CellChat leave-one-donor-out: ", condition, ", excluding ", donor)
    lr <- run_cellchat(condition, excluded_donor = donor, nboot = 30L, save_object = FALSE)$table
    if (nrow(lr)) {
      lr$held_out <- donor
      lodo_results[[paste(condition, donor, sep = "|")]] <- lr
    }
  }
}

lodo <- do.call(rbind, lodo_results)
write.table(lodo, file.path(out_root, "cellchat_lodo_all_interactions.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
support <- aggregate(
  held_out ~ condition + key,
  lodo[lodo$pval < 0.05 & lodo$prob > 0, , drop = FALSE],
  function(x) length(unique(x))
)
names(support)[names(support) == "held_out"] <- "lodo_support_of_5"
full <- do.call(rbind, aggregate_results)
full <- merge(full, support, by = c("condition", "key"), all.x = TRUE)
full$lodo_support_of_5[is.na(full$lodo_support_of_5)] <- 0L
write.table(full, file.path(out_root, "cellchat_aggregate_with_lodo_support.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)

keep_cols <- c("key", "source", "target", "ligand", "receptor", "interaction_name_2", "pathway_name", "prob", "pval", "qvalue_global", "lodo_support_of_5")
a <- aggregate_results[["Irritant"]]
b <- aggregate_results[["Day4_Allergy"]]
a <- merge(a, support[support$condition == "Irritant", c("key", "lodo_support_of_5")], by = "key", all.x = TRUE)
b <- merge(b, support[support$condition == "Day4_Allergy", c("key", "lodo_support_of_5")], by = "key", all.x = TRUE)
a$lodo_support_of_5[is.na(a$lodo_support_of_5)] <- 0L
b$lodo_support_of_5[is.na(b$lodo_support_of_5)] <- 0L
a <- a[intersect(keep_cols, names(a))]
b <- b[intersect(keep_cols, names(b))]
names(a)[names(a) %in% c("prob", "pval", "qvalue_global", "lodo_support_of_5")] <- paste0(names(a)[names(a) %in% c("prob", "pval", "qvalue_global", "lodo_support_of_5")], "_Irritant")
names(b)[names(b) %in% c("prob", "pval", "qvalue_global", "lodo_support_of_5")] <- paste0(names(b)[names(b) %in% c("prob", "pval", "qvalue_global", "lodo_support_of_5")], "_Day4_Allergy")
comp <- merge(a, b, by = intersect(c("key", "source", "target", "ligand", "receptor", "interaction_name_2", "pathway_name"), intersect(names(a), names(b))), all = TRUE)
comp$log2_probability_ratio_Day4_vs_Irritant <- log2((comp$prob_Day4_Allergy + 1e-12) / (comp$prob_Irritant + 1e-12))
write.table(comp, file.path(out_root, "cellchat_condition_comparison.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)

writeLines(c(
  paste0("CellChat_version\t", packageVersion("CellChat")),
  "database\tCellChatDB.human bundled with installed package",
  "aggregate_bootstraps\t100",
  "lodo_bootstraps\t30",
  "lodo_replicates_per_condition\t5",
  "minimum_cells_per_group\t5",
  "expression_summary\ttriMean",
  "population_size_weighting\tFALSE",
  "seed\t20260910"
), file.path(out_root, "cellchat_run_metadata.tsv"))
