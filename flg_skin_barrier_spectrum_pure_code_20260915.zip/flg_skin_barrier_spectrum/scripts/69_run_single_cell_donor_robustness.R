#!/usr/bin/env Rscript

# Donor-level robustness for the fixed AD-ACD driver program in GSE267929.
#
# This analysis addresses a limitation of the primary size-matched pathway null:
# that null is conditional on one donor-aware contrast and does not propagate the
# uncertainty associated with the five paired donors.  Here we keep the pathway
# program fixed, exhaust all 2^5 within-donor label swaps, and repeat the model
# after deleting each donor in turn.  The inferential unit is always the donor.

suppressPackageStartupMessages({
  library(Matrix)
  library(edgeR)
  library(limma)
})

root <- normalizePath(getwd())
raw_dir <- file.path(root, "data", "raw")
sc_dir <- file.path(raw_dir, "expression", "geo", "GSE267929")
meta_file <- file.path(raw_dir, "geo", "GSE267929", "GSE267929_meta.data.tsv.gz")
mech_dir <- file.path(
  root, "results", "exploratory_snf", "selected_positive_reml_z_q05",
  "optimized_AD_ACD_branch", "mechanism"
)
out_dir <- file.path(mech_dir, "single_cell_donor_robustness")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

common_donors <- c("P1", "P2", "P3", "P4", "P8")
compartments <- c("APC", "KRT")
min_cells <- 10L

read_gmt <- function(path) {
  x <- strsplit(readLines(path, warn = FALSE), "\t", fixed = TRUE)
  sets <- lapply(x, function(z) unique(z[-c(1, 2)]))
  names(sets) <- vapply(x, `[[`, character(1), 1)
  sets
}

counts <- readMM(gzfile(file.path(sc_dir, "GSE267929_matrix.mtx.gz")))
genes <- read.delim(
  gzfile(file.path(sc_dir, "GSE267929_genes.tsv.gz")),
  header = FALSE, stringsAsFactors = FALSE
)
barcodes <- readLines(gzfile(file.path(sc_dir, "GSE267929_barcodes.tsv.gz")))
meta <- read.table(
  gzfile(meta_file), header = TRUE, row.names = 1, check.names = FALSE,
  stringsAsFactors = FALSE
)
stopifnot(nrow(counts) == nrow(genes), ncol(counts) == length(barcodes))
stopifnot(identical(barcodes, rownames(meta)))
rownames(counts) <- genes[[2]]
colnames(counts) <- barcodes

reactome <- read_gmt(file.path(raw_dir, "pathways", "reactome_v97", "ReactomePathways.gmt"))
drivers <- read.delim(file.path(mech_dir, "top_AD_ACD_pathway_drivers.tsv"), check.names = FALSE)
driver_pathways <- head(drivers$pathway, 20L)

aggregate_compartment <- function(compartment) {
  keep <- meta$Basic_Celltype == compartment &
    meta$Patient %in% common_donors &
    meta$Lesion %in% c("Day4_Allergy", "Irritant")
  m <- meta[keep, , drop = FALSE]
  grouping <- interaction(m$Patient, m$Lesion, drop = TRUE, sep = "__")
  z <- sparse.model.matrix(~ 0 + grouping)
  colnames(z) <- sub("^grouping", "", colnames(z))
  pb <- counts[, keep, drop = FALSE] %*% z
  smeta <- do.call(rbind, strsplit(colnames(pb), "__", fixed = TRUE))
  smeta <- data.frame(
    sample = colnames(pb), participant = smeta[, 1], condition = smeta[, 2],
    cells = as.integer(table(grouping)[colnames(pb)]), stringsAsFactors = FALSE
  )
  eligible <- with(smeta, participant[cells >= min_cells])
  eligible <- names(which(table(eligible) == 2L))
  if (!setequal(eligible, common_donors)) {
    stop(compartment, ": expected common five donors, observed ", paste(eligible, collapse = ","))
  }
  use <- smeta$participant %in% common_donors
  list(counts = pb[, smeta$sample[use], drop = FALSE], meta = smeta[use, , drop = FALSE])
}

fit_program <- function(pb, smeta, flip = NULL) {
  dat <- smeta
  if (is.null(flip)) flip <- setNames(rep(FALSE, length(unique(dat$participant))), unique(dat$participant))
  swap <- unname(flip[dat$participant])
  dat$analysis_condition <- dat$condition
  dat$analysis_condition[swap & dat$condition == "Day4_Allergy"] <- "Irritant"
  dat$analysis_condition[swap & dat$condition == "Irritant"] <- "Day4_Allergy"
  dat$participant <- factor(dat$participant)
  dat$analysis_condition <- factor(dat$analysis_condition, levels = c("Irritant", "Day4_Allergy"))
  design <- model.matrix(~ participant + analysis_condition, data = dat)

  y <- DGEList(counts = pb)
  keep <- filterByExpr(y, design = design, min.count = 5)
  y <- calcNormFactors(y[keep, , keep.lib.sizes = FALSE])
  y <- estimateDisp(y, design, robust = TRUE)
  fit <- glmQLFit(y, design, robust = TRUE)
  qlf <- glmQLFTest(fit, coef = "analysis_conditionDay4_Allergy")
  tt <- topTags(qlf, n = Inf, sort.by = "none")$table
  # Rare permuted fits can return a minute negative quasi-likelihood F value
  # from floating-point roundoff.  Truncate those values at zero and exclude
  # any genuinely non-finite statistic before pathway testing.
  stat <- sign(tt$logFC) * sqrt(pmax(tt$F, 0))
  names(stat) <- rownames(tt)
  stat <- stat[is.finite(stat)]

  idx <- lapply(reactome, function(z) which(names(stat) %in% z))
  sizes <- vapply(idx, length, integer(1))
  idx <- idx[sizes >= 10L & sizes <= 500L]
  cam <- cameraPR(stat, index = idx, use.ranks = TRUE, inter.gene.cor = 0.01, sort = FALSE)
  cam$pathway <- rownames(cam)
  selected <- cam[cam$pathway %in% driver_pathways, , drop = FALSE]
  signed_z <- ifelse(selected$Direction == "Up", 1, -1) *
    qnorm(pmax(selected$PValue / 2, 1e-300), lower.tail = FALSE)
  list(
    score = mean(signed_z), measured_pathways = nrow(selected),
    pathways_up = sum(selected$Direction == "Up"), tested_genes = nrow(tt)
  )
}

make_flip_grid <- function(donors) {
  grid <- expand.grid(rep(list(c(FALSE, TRUE)), length(donors)), KEEP.OUT.ATTRS = FALSE)
  names(grid) <- donors
  grid
}

permutation_rows <- list()
loo_rows <- list()
summary_rows <- list()

for (compartment in compartments) {
  obj <- aggregate_compartment(compartment)
  smeta <- obj$meta
  pb <- obj$counts
  observed <- fit_program(pb, smeta)
  grid <- make_flip_grid(common_donors)

  perm_scores <- numeric(nrow(grid))
  for (i in seq_len(nrow(grid))) {
    flip <- setNames(as.logical(grid[i, ]), common_donors)
    perm_scores[i] <- fit_program(pb, smeta, flip)$score
    permutation_rows[[length(permutation_rows) + 1L]] <- data.frame(
      compartment = compartment,
      permutation_id = i - 1L,
      flipped_donors = paste(common_donors[flip], collapse = ";"),
      n_flipped = sum(flip),
      driver_program_score = perm_scores[i],
      stringsAsFactors = FALSE
    )
  }

  expected_direction <- if (compartment == "APC") "positive" else "negative"
  exact_p <- if (expected_direction == "positive") {
    mean(perm_scores >= observed$score - 1e-12)
  } else {
    mean(perm_scores <= observed$score + 1e-12)
  }

  loo_scores <- numeric(length(common_donors))
  for (i in seq_along(common_donors)) {
    omitted <- common_donors[i]
    keep <- smeta$participant != omitted
    fit_loo <- fit_program(pb[, keep, drop = FALSE], smeta[keep, , drop = FALSE])
    loo_scores[i] <- fit_loo$score
    loo_rows[[length(loo_rows) + 1L]] <- data.frame(
      compartment = compartment, omitted_donor = omitted,
      retained_donors = length(common_donors) - 1L,
      driver_program_score = fit_loo$score,
      measured_pathways = fit_loo$measured_pathways,
      same_direction_as_observed = sign(fit_loo$score) == sign(observed$score),
      stringsAsFactors = FALSE
    )
  }

  summary_rows[[length(summary_rows) + 1L]] <- data.frame(
    compartment = compartment,
    contrast = "Day4_Allergy_minus_Irritant",
    donors = paste(common_donors, collapse = ";"),
    n_donors = length(common_donors),
    observed_score = observed$score,
    expected_direction = expected_direction,
    exact_label_swap_p_one_sided = exact_p,
    exact_permutations = nrow(grid),
    leave_one_donor_out_min = min(loo_scores),
    leave_one_donor_out_max = max(loo_scores),
    leave_one_donor_out_same_direction = sum(sign(loo_scores) == sign(observed$score)),
    leave_one_donor_out_runs = length(loo_scores),
    measured_pathways = observed$measured_pathways,
    pathways_up = observed$pathways_up,
    tested_genes = observed$tested_genes,
    stringsAsFactors = FALSE
  )
}

permutations <- do.call(rbind, permutation_rows)
loo <- do.call(rbind, loo_rows)
summary <- do.call(rbind, summary_rows)
summary$exact_label_swap_q_BH_2compartments <- p.adjust(
  summary$exact_label_swap_p_one_sided, method = "BH"
)

write.table(
  permutations, file.path(out_dir, "paired_label_swap_null.tsv"),
  sep = "\t", quote = FALSE, row.names = FALSE
)
write.table(
  loo, file.path(out_dir, "leave_one_donor_out.tsv"),
  sep = "\t", quote = FALSE, row.names = FALSE
)
write.table(
  summary, file.path(out_dir, "donor_robustness_summary.tsv"),
  sep = "\t", quote = FALSE, row.names = FALSE
)

parameters <- c(
  "analysis\tpaired donor label-swap and leave-one-donor-out robustness",
  paste0("compartments\t", paste(compartments, collapse = ";")),
  paste0("fixed_donors\t", paste(common_donors, collapse = ";")),
  paste0("minimum_cells_per_donor_condition\t", min_cells),
  paste0("driver_pathways\t", length(driver_pathways)),
  "label_swap_null\texhaustive 2^5 within-donor swaps",
  "p_value\texact directional tail proportion; observed labeling included",
  "multiplicity\tBH across APC and KRT",
  "cameraPR_inter_gene_cor\t0.01"
)
writeLines(parameters, file.path(out_dir, "RUN_PARAMETERS.tsv"))

print(summary)
