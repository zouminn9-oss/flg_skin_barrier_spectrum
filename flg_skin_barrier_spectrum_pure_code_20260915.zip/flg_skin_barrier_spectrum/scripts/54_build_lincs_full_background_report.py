#!/usr/bin/env python3
"""Build the executed audit notebook and bounded MCP report payload."""

from datetime import datetime, timezone
from pathlib import Path
import json
import math
import sys

ROOT = Path(__file__).resolve().parents[1]
LOCAL_PACKAGES = ROOT / "environment/python_packages"
if LOCAL_PACKAGES.exists():
    sys.path.insert(0, str(LOCAL_PACKAGES))

import nbformat
from nbclient import NotebookClient
import numpy as np
import pandas as pd


MECH = ROOT / "results/exploratory_snf/selected_positive_reml_z_q05/optimized_AD_ACD_branch/mechanism"
OUT = MECH / "lincs_full_background_calibration"
NOTEBOOK = ROOT / "notebooks/lincs_full_background_calibration.executed.ipynb"
ARTIFACT = OUT / "report_artifact.json"
RANKING_PATH = OUT / "full_background_compound_ranking.tsv"
RECON_PATH = OUT / "targeted_full_score_reconciliation_summary.tsv"
SOURCE_QC_PATH = OUT / "SOURCE_AND_SCHEMA_QC.json"
DISPOSITION_PATH = OUT / "JNJ7706621_FULL_BACKGROUND_DISPOSITION.json"


ranking = pd.read_csv(RANKING_PATH, sep="\t")
recon = pd.read_csv(RECON_PATH, sep="\t")
source_qc = json.loads(SOURCE_QC_PATH.read_text())
disposition = json.loads(DISPOSITION_PATH.read_text())
run = json.loads((OUT / "RUN_PARAMETERS.json").read_text())
validation = json.loads((OUT / "VALIDATION_SUMMARY.json").read_text())
generated_at = datetime.now(timezone.utc).isoformat()

jnj = ranking.loc[ranking["pert_name"].eq("JNJ-7706621")].iloc[0]
top = ranking.nsmallest(20, "all_compound_rank").copy()
if not top["pert_name"].eq("JNJ-7706621").any():
    top = pd.concat([top, ranking.loc[ranking["pert_name"].eq("JNJ-7706621")]], ignore_index=True)
top = top.sort_values("median_apc_composite_reversal", ascending=True)
top["row_type"] = np.where(top["pert_name"].eq("JNJ-7706621"), "JNJ-7706621", "top background")

table = ranking.nsmallest(25, "all_compound_rank").copy()
if not table["pert_name"].eq("JNJ-7706621").any():
    table = pd.concat([table, ranking.loc[ranking["pert_name"].eq("JNJ-7706621")]], ignore_index=True)
table = table.sort_values("all_compound_rank")
table["row_type"] = np.where(table["pert_name"].eq("JNJ-7706621"), "candidate", "top background")


def clean_records(frame, columns):
    records = []
    for row in frame[columns].to_dict(orient="records"):
        clean = {}
        for key, value in row.items():
            if pd.isna(value):
                clean[key] = None
            elif isinstance(value, (np.integer,)):
                clean[key] = int(value)
            elif isinstance(value, (np.floating,)):
                clean[key] = float(value)
            elif isinstance(value, (np.bool_,)):
                clean[key] = bool(value)
            else:
                clean[key] = value
        records.append(clean)
    return records


candidate_summary = [{
    "disposition": disposition["full_background_label"],
    "all_rank": int(jnj["all_compound_rank"]),
    "all_compounds": int(len(ranking)),
    "all_tail_fraction": float(jnj["all_compound_competitive_upper_tail_fraction"]),
    "eligible_rank": int(jnj["stable_eligible_rank"]),
    "eligible_compounds": int(run["stable_eligible_compounds"]),
    "eligible_tail_fraction": float(jnj["stable_eligible_competitive_upper_tail_fraction"]),
    "median_composite": float(jnj["median_apc_composite_reversal"]),
    "targeted_q": float(disposition["frozen_targeted_BH_q"]),
    "source_reconciliation": disposition["source_reconciliation"],
}]

chart_columns = [
    "pert_name", "median_apc_composite_reversal", "all_compound_rank",
    "all_compound_competitive_upper_tail_fraction", "n_conditions", "n_cell_lines",
    "multi_condition_stable", "external_direction_supported", "toxicity_dominated", "row_type",
]
table_columns = chart_columns
chart_rows = clean_records(top, chart_columns)
table_rows = clean_records(table, table_columns)

label = disposition["full_background_label"]
if label == "full_background_competitive":
    outcome_sentence = "JNJ-7706621 meets the frozen descriptive full-background competitive rule."
elif label == "positive_not_top5":
    outcome_sentence = "JNJ-7706621 remains directionally robust but falls outside at least one frozen top-5% background boundary."
else:
    outcome_sentence = "JNJ-7706621 does not meet the frozen full-background support rule."

rank_sentence = (
    f"It ranks {int(jnj['all_compound_rank']):,} of {len(ranking):,} compounds "
    f"(competitive upper-tail fraction {jnj['all_compound_competitive_upper_tail_fraction']:.2%}) "
    f"and {int(jnj['stable_eligible_rank']):,} of {run['stable_eligible_compounds']:,} sample-size-eligible compounds "
    f"({jnj['stable_eligible_competitive_upper_tail_fraction']:.2%})."
)
source_sentence = (
    f"The current full matrix reconciles to the 2,787 targeted conditions as "
    f"`{disposition['source_reconciliation']}`; the matrix itself is a 2023-revised object under the 2021 path."
)
top_row = ranking.iloc[0]

ranking_source = {
    "id": "ranking_source",
    "label": "Complete LINCS compound ranking",
    "path": str(RANKING_PATH),
    "query": {
        "engine": "Python/pandas",
        "language": "python",
        "sql": f"SELECT * FROM read_csv_auto('{RANKING_PATH}', delim='\\t', header=true)",
        "code": "PYTHONPATH=environment/python_packages python3 scripts/52_score_lincs_full_background.py",
        "description": "Stream the frozen four reversal scores across all GCTX chemical conditions, then median-aggregate by provider pert_name.",
        "executed_at": run["completed_at_utc"],
        "tables_used": [str(RANKING_PATH), str(OUT / "condition_score_parts")],
        "filters": [
            "No cell-line, dose, time, batch, compound, or observed-score condition filtering",
            "Stable-eligible background requires at least two conditions and two cell lines",
        ],
        "metric_definitions": [
            "Median composite is the equal-weight mean of the frozen genome-rank, genome-weighted, program-rank, and program-weighted reversal scores, then median-aggregated within pert_name.",
            "Competitive upper-tail fraction = (1 + number of compounds with composite at least as large) / (1 + number of background compounds); it is not a null P value or FDR.",
            "Multi-condition stability requires at least two conditions, at least two cell lines, positive fraction >=2/3, positive minimum leave-one-condition median, and positive minimum leave-one-cell-line median.",
        ],
    },
}
source_qc_source = {
    "id": "source_qc",
    "label": "LINCS source and schema QC",
    "path": str(SOURCE_QC_PATH),
    "query": {
        "engine": "Python/h5py",
        "language": "python",
        "sql": f"SELECT * FROM read_json_auto('{SOURCE_QC_PATH}')",
        "code": "PYTHONPATH=environment/python_packages python3 scripts/51_inspect_lincs_full_background.py",
        "description": "Verify exact bytes and SHA-256, inventory HDF5 schema, reconcile all GCTX sig_id values to Broad siginfo_beta, and audit the newer ranker metadata as a secondary source.",
        "executed_at": source_qc["inspected_at_utc"],
        "tables_used": [str(SOURCE_QC_PATH), str(RECON_PATH)],
        "metric_definitions": [
            "Compatible means all five targeted primary/composite scores agree within 1e-6 with identical signs.",
            "Near-compatible means every score correlation is >=0.999 and sign agreement is >=99.9%.",
        ],
    },
}
sources = [ranking_source, source_qc_source]

manifest = {
    "version": 1,
    "surface": "report",
    "title": "JNJ-7706621 full-background LINCS calibration",
    "description": "Post-hoc computational calibration of the carried-forward nominal candidate against the complete current LINCS chemical-perturbation matrix.",
    "generatedAt": generated_at,
    "sources": sources,
    "blocks": [
        {"id": "title", "type": "markdown", "body": "# JNJ-7706621 full-background LINCS calibration", "layout": "full"},
        {"id": "executive_summary", "type": "markdown", "body": (
            "## Executive Summary\n\n"
            f"{outcome_sentence} {rank_sentence} {source_sentence} "
            "This is a competitive descriptive calibration, not a library-wide null P value, FDR, formal replication, clinical-efficacy result, safety result, or CDK2-specificity result."
        ), "layout": "full"},
        {"id": "headline_metrics", "type": "metric-strip", "cardIds": [
            "disposition_card", "all_rank_card", "eligible_rank_card", "source_card"
        ], "layout": "full"},
        {"id": "key_findings", "type": "markdown", "body": (
            "## Key Findings\n\n"
            f"JNJ's full-matrix median composite is {jnj['median_apc_composite_reversal']:.5f}. "
            f"The highest observed compound is `{top_row['pert_name']}` at {top_row['median_apc_composite_reversal']:.5f}. "
            f"JNJ retains {int(jnj['n_conditions'])} conditions across {int(jnj['n_cell_lines'])} cell lines; "
            f"multi-condition stability is `{str(bool(jnj['multi_condition_stable'])).lower()}`, external direction support is "
            f"`{str(bool(jnj['external_direction_supported'])).lower()}`, and toxicity dominance is `{str(bool(jnj['toxicity_dominated'])).lower()}`."
        ), "layout": "full"},
        {"id": "ranking_chart_block", "type": "chart", "chartId": "ranking_chart", "layout": "full"},
        {"id": "ranking_table_intro", "type": "markdown", "body": (
            "## Ranked Evidence Table\n\nThe table retains the top 25 compounds and JNJ for exact lookup. "
            "The complete 33,609-compound table remains in the source file."
        ), "layout": "full"},
        {"id": "ranking_table_block", "type": "table", "tableId": "ranking_table", "layout": "full"},
        {"id": "scope_method", "type": "markdown", "body": (
            "## Scope, Data, and Methodology\n\n"
            f"The analysis scored {run['conditions']:,} conditions from {run['compounds']:,} provider compound names. "
            f"The primary overlap contains {run['common_complete_APC_genes']:,} APC genes and "
            f"{run['common_complete_program_genes']:,} locked-program genes. Four frozen reversal scores were computed "
            "without selecting cell line, dose, time, compound, or favorable result, then median-aggregated by provider `pert_name`. "
            "Both the all-compound and at-least-two-condition/two-cell-line backgrounds are reported."
        ), "layout": "full"},
        {"id": "limitations", "type": "markdown", "body": (
            "## Limitations and Robustness\n\n"
            "The currently served 36.08-GB matrix is 518,888,264 bytes larger than the previously documented release and was modified in 2023; "
            "the authoritative Broad siginfo_beta metadata covers every matrix column, while the newer 2026 ranker metadata omits 102 dose-missing records. Competitive tail fractions describe rank and are not null-hypothesis P values. "
            f"The frozen targeted JNJ q remains {disposition['frozen_targeted_BH_q']:.4f}; no library-wide FDR was computed. "
            "The analysis remains post hoc, context-heterogeneous, and transcriptomic. It cannot establish skin efficacy, safety, target causality, or CDK2 specificity."
        ), "layout": "full"},
        {"id": "next_steps", "type": "markdown", "body": (
            "## Recommended Next Steps\n\n"
            "Do not relax thresholds further. For data-only follow-up, obtain a checksum-pinned original 2021 matrix or an independent perturbation resource "
            "with primary keratinocyte/skin contexts and repeat the frozen score panel. Preserve JNJ as a post-hoc nominal candidate and retain all negative backgrounds."
        ), "layout": "full"},
        {"id": "further_questions", "type": "markdown", "body": (
            "## Further Questions\n\n"
            "Can the originally documented 2021 object be recovered with a verifiable checksum? Is the rank stable in primary keratinocytes rather than predominantly cancer lines? "
            "Do non-cell-cycle mechanisms remain after stronger toxicity and proliferation controls?"
        ), "layout": "full"},
    ],
    "cards": [
        {"id": "disposition_card", "dataset": "candidate_summary", "sourceId": "ranking_source",
         "description": "Frozen descriptive outcome; not formal replication.",
         "metrics": [{"label": "Disposition", "field": "disposition"}]},
        {"id": "all_rank_card", "dataset": "candidate_summary", "sourceId": "ranking_source",
         "description": "Rank among every provider compound name, including singletons.",
         "metrics": [{"label": "All-background rank", "field": "all_rank", "format": "number"},
                     {"label": "Upper tail", "field": "all_tail_fraction", "format": "percent"}]},
        {"id": "eligible_rank_card", "dataset": "candidate_summary", "sourceId": "ranking_source",
         "description": "Rank among compounds with at least two conditions and two cell lines.",
         "metrics": [{"label": "Eligible rank", "field": "eligible_rank", "format": "number"},
                     {"label": "Upper tail", "field": "eligible_tail_fraction", "format": "percent"}]},
        {"id": "source_card", "dataset": "candidate_summary", "sourceId": "source_qc",
         "description": "Numerical agreement between current full-matrix and frozen targeted scores.",
         "metrics": [{"label": "Source reconciliation", "field": "source_reconciliation"}]},
    ],
    "charts": [{
        "id": "ranking_chart",
        "title": "Top compound composite reversal scores and JNJ-7706621",
        "subtitle": rank_sentence,
        "type": "bar",
        "options": {"orientation": "horizontal", "grouping": "grouped"},
        "intent": "comparison",
        "question": "Where does JNJ-7706621 sit relative to the highest full-background compound composites?",
        "rationale": "Sorted horizontal bars support long compound labels and show the focal candidate against the top background on one signed scale.",
        "comparisonContext": {"grain": "provider pert_name", "unit": "equal-weight reversal correlation composite", "normalization": "median over all available conditions"},
        "dataset": "ranking_chart",
        "sourceId": "ranking_source",
        "encodings": {
            "x": {"field": "pert_name", "type": "nominal", "label": "Compound"},
            "y": {"field": "median_apc_composite_reversal", "type": "quantitative", "label": "Median composite reversal", "format": "number"},
            "color": {"field": "row_type", "type": "nominal", "label": "Row type"},
            "tooltip": [
                {"field": "all_compound_rank", "type": "quantitative", "label": "All-background rank"},
                {"field": "n_conditions", "type": "quantitative", "label": "Conditions"},
                {"field": "n_cell_lines", "type": "quantitative", "label": "Cell lines"}
            ]
        },
        "combinationRationale": "Color distinguishes the carried-forward focal candidate from context bars; compound labels and rank tooltips provide non-color identification.",
        "maxRows": 21,
        "layout": "full"
    }],
    "tables": [{
        "id": "ranking_table", "title": "Top full-background compounds plus JNJ-7706621",
        "subtitle": "Exact compound aggregates; competitive fractions are descriptive ranks, not P values.",
        "dataset": "ranking_table", "sourceId": "ranking_source", "layout": "full", "density": "dense",
        "defaultSort": {"field": "all_compound_rank", "direction": "asc"},
        "columns": [
            {"field": "all_compound_rank", "label": "Rank", "type": "number"},
            {"field": "pert_name", "label": "Compound", "type": "text"},
            {"field": "median_apc_composite_reversal", "label": "Median composite", "type": "number"},
            {"field": "all_compound_competitive_upper_tail_fraction", "label": "Upper tail", "format": "percent"},
            {"field": "n_conditions", "label": "Conditions", "type": "number"},
            {"field": "n_cell_lines", "label": "Cell lines", "type": "number"},
            {"field": "multi_condition_stable", "label": "Stable", "type": "text"},
            {"field": "external_direction_supported", "label": "External +", "type": "text"},
            {"field": "toxicity_dominated", "label": "Toxicity dominated", "type": "text"}
        ]
    }]
}

snapshot = {
    "version": 1, "generatedAt": generated_at, "status": "ready",
    "datasets": {
        "candidate_summary": candidate_summary,
        "ranking_chart": chart_rows,
        "ranking_table": table_rows,
    },
}
artifact = {"surface": "report", "manifest": manifest, "snapshot": snapshot, "sources": sources}
ARTIFACT.write_text(json.dumps(artifact, indent=2, allow_nan=False) + "\n")

# Companion notebook: compact, executable, and limited to the evidence used in the report.
nb = nbformat.v4.new_notebook(cells=[
    nbformat.v4.new_markdown_cell(
        "# JNJ-7706621 full-background LINCS calibration\n\n"
        "Reproducible audit of source quality, complete compound ranking, targeted/full reconciliation, and the frozen candidate disposition."
    ),
    nbformat.v4.new_code_cell(
        "from pathlib import Path\nimport json, sys\nimport numpy as np\nimport pandas as pd\n"
        "ROOT = Path('/Volumes/brilliant/flg_skin_barrier_spectrum')\n"
        "OUT = ROOT / 'results/exploratory_snf/selected_positive_reml_z_q05/optimized_AD_ACD_branch/mechanism/lincs_full_background_calibration'\n"
        "ranking = pd.read_csv(OUT / 'full_background_compound_ranking.tsv', sep='\\t')\n"
        "source_qc = json.loads((OUT / 'SOURCE_AND_SCHEMA_QC.json').read_text())\n"
        "disposition = json.loads((OUT / 'JNJ7706621_FULL_BACKGROUND_DISPOSITION.json').read_text())\n"
        "run = json.loads((OUT / 'RUN_PARAMETERS.json').read_text())\n"
        "len(ranking), run['conditions'], run['compounds']"
    ),
    nbformat.v4.new_code_cell(
        "pd.DataFrame([{\n"
        " 'matrix_bytes': source_qc['local_bytes'],\n"
        " 'matrix_sha256': source_qc['local_sha256'],\n"
        " 'matrix_last_modified': source_qc['remote_last_modified'],\n"
        " 'metadata_records': source_qc['broad_siginfo']['gctx_records'],\n"
        " 'source_reconciliation': run['targeted_source_reconciliation'],\n"
        " 'version_status': source_qc['version_drift']['status'],\n"
        "}])"
    ),
    nbformat.v4.new_code_cell(
        "jnj = ranking.loc[ranking.pert_name.eq('JNJ-7706621')]\n"
        "jnj[['pert_name','n_conditions','n_cell_lines','median_apc_composite_reversal',\n"
        "     'all_compound_rank','all_compound_competitive_upper_tail_fraction',\n"
        "     'stable_eligible_rank','stable_eligible_competitive_upper_tail_fraction',\n"
        "     'multi_condition_stable','external_direction_supported','toxicity_dominated']]"
    ),
    nbformat.v4.new_code_cell(
        "ranking.nsmallest(20, 'all_compound_rank')[[\n"
        " 'all_compound_rank','pert_name','median_apc_composite_reversal','n_conditions','n_cell_lines',\n"
        " 'multi_condition_stable','external_direction_supported','toxicity_dominated'\n"
        "]]"
    ),
    nbformat.v4.new_code_cell(
        "assert len(ranking) == 33609\n"
        "assert int(jnj.n_conditions.iloc[0]) == 297\n"
        "assert not disposition['library_wide_fdr_computed']\n"
        "assert not disposition['formal_replication']\n"
        "disposition"
    ),
])
nb.metadata.kernelspec = {"display_name": "Python 3", "language": "python", "name": "python3"}
nb.metadata.language_info = {"name": "python", "version": "3"}
client = NotebookClient(nb, timeout=180, kernel_name="python3")
client.execute(cwd=str(ROOT))
nbformat.write(nb, NOTEBOOK)

print(json.dumps({
    "artifact": str(ARTIFACT), "notebook": str(NOTEBOOK),
    "artifact_datasets": {key: len(value) for key, value in snapshot["datasets"].items()},
    "validation_checks": validation["checks_passed"],
}, indent=2))
