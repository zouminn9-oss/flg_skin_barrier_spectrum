#!/usr/bin/env python3
"""Append the prespecified GSE328048 validation to the IJMS supplement."""

from __future__ import annotations

import csv
from pathlib import Path

from docx import Document
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt


ROOT = Path("/Volumes/brilliant/flg_skin_barrier_spectrum")
DOCX = ROOT / "paper_rewriting_output/ijms_submission/supplementary_information.docx"
ANALYSIS = ROOT / "results/external_validation/GSE328048/analysis"
FIGURE = ANALYSIS / "GSE328048_frozen_16gene_validation.png"


def read_one(name: str) -> dict[str, str]:
    with (ANALYSIS / name).open(newline="", encoding="utf-8") as handle:
        return next(csv.DictReader(handle, delimiter="\t"))


def add_cell_text(cell, text: str, bold: bool = False, size: float = 7.5) -> None:
    cell.text = ""
    paragraph = cell.paragraphs[0]
    paragraph.paragraph_format.space_after = Pt(0)
    run = paragraph.add_run(text)
    run.bold = bold
    run.font.size = Pt(size)
    cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.TOP


def shade(cell, fill: str) -> None:
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:fill"), fill)
    tc_pr.append(shd)


def add_table(doc: Document, headers: list[str], rows: list[list[str]], widths: list[float] | None = None):
    table = doc.add_table(rows=1, cols=len(headers))
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table_style = next((style for style in doc.styles if style.name == "Table Grid"), None)
    if table_style is not None:
        table.style = table_style
    for index, header in enumerate(headers):
        add_cell_text(table.rows[0].cells[index], header, bold=True, size=7.2)
        shade(table.rows[0].cells[index], "D9EAF7")
    for values in rows:
        cells = table.add_row().cells
        for index, value in enumerate(values):
            add_cell_text(cells[index], value, size=7.2)
    if widths:
        for row in table.rows:
            for index, width in enumerate(widths):
                row.cells[index].width = Inches(width)
    return table


def f(row: dict[str, str], key: str, digits: int = 3) -> str:
    return f"{float(row[key]):.{digits}f}"


def main() -> None:
    doc = Document(DOCX)
    existing = "\n".join(paragraph.text for paragraph in doc.paragraphs)
    if "Supplementary Figure S2." in existing or "Table S11." in existing:
        raise SystemExit("Figure S2 or Table S11 already exists; refusing to append a duplicate")

    biopsy = read_one("primary_LAD_vs_HC_biopsy.tsv")
    title = read_one("primary_LAD_vs_HC_title_cluster.tsv")
    donor = read_one("primary_LAD_vs_HC.tsv")
    title_pair = read_one("title_cluster_paired_summary.tsv")
    matched = list(csv.DictReader((ANALYSIS / "matched_random_set_summary.tsv").open(encoding="utf-8"), delimiter="\t"))
    matched_by = {row["analysis"]: row for row in matched}
    adjusted = read_one("title_cluster_proliferation_adjusted.tsv")
    with (ANALYSIS / "leave_one_gene_out.tsv").open(encoding="utf-8") as handle:
        loo = list(csv.DictReader(handle, delimiter="\t"))
    with (ANALYSIS / "core_gene_logcpm_effects.tsv").open(encoding="utf-8") as handle:
        genes = list(csv.DictReader(handle, delimiter="\t"))

    heading_2 = next(style for style in doc.styles if style.name == "Heading 2")
    body_text = next((style for style in doc.styles if style.name == "Body Text"), None)
    doc.add_page_break()
    heading = doc.add_paragraph("Supplementary Figure S2. External validation of the prespecified 16-gene score in GSE328048")
    heading.style = heading_2
    paragraph = doc.add_paragraph()
    paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
    paragraph.add_run().add_picture(str(FIGURE), width=Inches(6.45))
    caption = doc.add_paragraph(
        "(a) Prespecified rank-score distributions after aggregating repeated public sample-title prefixes. "
        "(b) Public title-cluster pairs for nonlesional (NAD) and lesional AD (LAD). "
        "(c) Cliff's delta for LAD versus healthy control (HC) after omitting each core gene; every point remained positive and nominally significant. "
        "(d) Null distribution from 10,000 expression-abundance-matched random 16-gene sets; the red line is the prespecified-core title-cluster difference (empirical P = 0.0065). "
        "The plotted analyses use only public GEO sample titles and do not depend on inferred donor mapping."
    )
    if body_text is not None:
        caption.style = body_text
    caption.paragraph_format.space_after = Pt(8)

    heading = doc.add_paragraph("Table S11. GSE328048 prespecified-score external validation and sensitivity analyses")
    heading.style = heading_2
    doc.add_paragraph(
        "The 16 genes, equal positive weights, rank-score equation, primary contrast and randomization plan were specified independently of GSE328048 and applied without refitting. "
        "All-cell pseudobulk profiles were reconstructed from 116 deposited matrices (54 LAD, 39 NAD and 23 HC). "
        "The public record does not expose a direct library-to-donor key; therefore biopsy-level inference is primary, title-prefix aggregation is a public-metadata sensitivity, and QC-cell-count mapping is non-authoritative sensitivity only."
    )

    summary_rows = [
        ["Primary biopsy", f"{biopsy['n_x']} LAD; {biopsy['n_y']} HC",
         f"Median Δ {f(biopsy, 'median_difference', 4)}; Cliff's δ {f(biopsy, 'cliffs_delta')}",
         f"{f(biopsy, 'auc')} ({f(biopsy, 'auc_ci_low')}–{f(biopsy, 'auc_ci_high')})",
         f"MW {float(biopsy['mann_whitney_p_one_sided']):.3g}; perm. {float(biopsy['permutation_p_mean_difference']):.3g}",
         "Prespecified primary rule supported"],
        ["Public title cluster", f"{title['n_x']} LAD; {title['n_y']} HC",
         f"Mean Δ {f(title, 'mean_difference', 4)}; Cliff's δ {f(title, 'cliffs_delta')}",
         f"{f(title, 'auc')} ({f(title, 'auc_ci_low')}–{f(title, 'auc_ci_high')})",
         f"MW {float(title['mann_whitney_p_one_sided']):.3g}; perm. {float(title['permutation_p_mean_difference']):.3g}",
         "Public-metadata sensitivity"],
        ["Title-cluster paired LAD–NAD", f"{title_pair['n_pairs']} pairs",
         f"Median paired Δ {f(title_pair, 'median_difference', 4)}", "—",
         f"Wilcoxon {float(title_pair['wilcoxon_p_one_sided']):.3g}", "Secondary contrast"],
        ["Abundance-matched null", "10,000 sets", f"Observed title-cluster mean Δ {f(title, 'mean_difference', 4)}", "—",
         f"Empirical {float(matched_by['title_cluster']['empirical_p']):.4f}", "Specificity beyond matched random genes"],
        ["Leave-one-gene-out", "16 scores", "16/16 positive",
         f"AUC {min(float(row['auc']) for row in loo):.3f}–{max(float(row['auc']) for row in loo):.3f}",
         "16/16 nominal P < 0.05", "No single gene drives the contrast"],
        ["Fixed proliferation adjustment", "45 LAD; 23 HC clusters",
         f"LAD β {f(adjusted, 'coefficient', 5)} ({f(adjusted, 'ci_low', 5)}–{f(adjusted, 'ci_high', 5)})", "—",
         f"Two-sided {float(adjusted['p_two_sided']):.3f}", "Whole-biopsy association not proliferation-independent"],
        ["QC-count-mapped donor sensitivity", f"{donor['n_x']} LAD; {donor['n_y']} HC",
         f"Mean Δ {f(donor, 'mean_difference', 4)}; Cliff's δ {f(donor, 'cliffs_delta')}",
         f"{f(donor, 'auc')} ({f(donor, 'auc_ci_low')}–{f(donor, 'auc_ci_high')})",
         f"MW {float(donor['mann_whitney_p_one_sided']):.3g}", "Non-authoritative mapping sensitivity"],
    ]
    add_table(doc, ["Analysis", "Units", "Effect", "AUC (95% CI)", "Directional P", "Interpretation"],
              summary_rows, [1.05, 0.75, 1.40, 1.05, 0.95, 1.55])

    doc.add_paragraph("Table S11 continued. Gene-level log2 counts-per-million effects (interpretive; the inferential object is the prespecified set).")
    gene_rows = []
    for row in genes:
        gene_rows.append([
            row["gene"], f(row, "mean_log2cpm_LAD"), f(row, "mean_log2cpm_HC"),
            f(row, "mean_difference"), f"{float(row['p_one_sided']):.3g}", f"{float(row['p_bh']):.3g}",
        ])
    add_table(doc, ["Gene", "LAD mean", "HC mean", "Difference", "One-sided P", "BH q"],
              gene_rows, [0.8, 0.9, 0.9, 0.9, 0.95, 0.8])
    doc.add_paragraph(
        "Interpretation boundary: the prespecified score externally generalizes as a whole-biopsy AD state, but its proliferation-adjusted coefficient is null. "
        "Whole-biopsy composition and proliferation can contribute to the association; these analyses do not establish diagnostic utility, causality or a cell-intrinsic mechanism."
    )

    doc.save(DOCX)
    print(f"Updated {DOCX}")
    print(f"LOO positive and nominally significant: {sum(row['nominally_significant'] == 'TRUE' for row in loo)}/16")


if __name__ == "__main__":
    main()
