#!/usr/bin/env python3
"""Correct the LOO AUC range in the already-appended Table S11."""

from pathlib import Path
from docx import Document

path = Path("/Volumes/brilliant/flg_skin_barrier_spectrum/paper_rewriting_output/ijms_submission/supplementary_information.docx")
doc = Document(path)
changed = 0
for table in doc.tables:
    for row in table.rows:
        if row.cells and row.cells[0].text.strip() == "Leave-one-gene-out":
            row.cells[3].text = "AUC 0.812–0.860"
            changed += 1
if changed != 1:
    raise SystemExit(f"Expected one leave-one-gene-out row, found {changed}")
doc.save(path)
print(path)
