#!/usr/bin/env python3
"""Build a clean, checksum-verified IJMS submission package."""

from __future__ import annotations

import hashlib
import re
import shutil
import sys
import tempfile
import zipfile
from datetime import date
from pathlib import Path

from docx import Document
from PIL import Image


ROOT = Path("/Volumes/brilliant/flg_skin_barrier_spectrum")
SOURCE = ROOT / "paper_rewriting_output/ijms_submission/upload_ready"
DEST = ROOT / "submission/IJMS_Submission_20260911"
ARCHIVE = ROOT / "submission/IJMS_Submission_20260911.zip"
UPLOAD = DEST / "01_upload_ready"
REFERENCE = DEST / "02_review_reference"

MANUSCRIPT = "ijms_manuscript.docx"
COVER = "cover_letter.docx"
SUPPLEMENT = "supplementary_information.docx"
FIGURE_NAMES = [
    "figure1.tif",
    "figure2.tif",
    "figure3.tif",
    "figure4.tif",
    "figure5.tif",
    "figure6.tif",
    "figureS1.tif",
    "figureS2.tif",
]
PLACEHOLDERS = [
    "FULL POSTAL ADDRESS AND POSTAL CODE REQUIRED",
    "ORCiD REQUIRED FOR ALL FOUR AUTHORS",
    "TELEPHONE REQUIRED",
]


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def docx_text(path: Path) -> str:
    doc = Document(path)
    parts = [p.text for p in doc.paragraphs]
    for table in doc.tables:
        for row in table.rows:
            parts.extend(cell.text for cell in row.cells)
    return "\n".join(parts)


def write_text(path: Path, text: str) -> None:
    path.write_text(text.rstrip() + "\n", encoding="utf-8")


def require(condition: bool, message: str) -> None:
    if not condition:
        raise RuntimeError(message)


def zip_tree(source: Path, destination: Path) -> None:
    with zipfile.ZipFile(destination, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for path in sorted(source.rglob("*")):
            if not path.is_file() or path.name.startswith("._") or path.name == ".DS_Store":
                continue
            zf.write(path, path.relative_to(source.parent).as_posix())


def main() -> None:
    require(not DEST.exists(), f"Refusing to overwrite existing package: {DEST}")
    require(not ARCHIVE.exists(), f"Refusing to overwrite existing archive: {ARCHIVE}")

    for name in (MANUSCRIPT, COVER, SUPPLEMENT):
        require((SOURCE / name).is_file(), f"Missing source file: {name}")
    for name in FIGURE_NAMES:
        require((SOURCE / "figures" / name).is_file(), f"Missing source figure: {name}")

    UPLOAD.mkdir(parents=True)
    REFERENCE.mkdir(parents=True)

    for name in (MANUSCRIPT, COVER, SUPPLEMENT):
        shutil.copy2(SOURCE / name, UPLOAD / name)

    figure_rows: list[tuple[str, int, int, float, int, str]] = []
    with tempfile.TemporaryDirectory(prefix="ijms_figures_") as tmp:
        tmpdir = Path(tmp)
        for name in FIGURE_NAMES:
            src = SOURCE / "figures" / name
            dst = tmpdir / name
            with Image.open(src) as im:
                dpi = im.info.get("dpi", (0.0, 0.0))
                dpi_x = float(dpi[0]) if dpi else 0.0
                width, height = im.size
                # Lossless LZW keeps pixels and resolution metadata while avoiding a
                # 71 MB uncompressed Figure 6 in the upload bundle.
                im.save(dst, format="TIFF", compression="tiff_lzw", dpi=dpi)
            with Image.open(dst) as check:
                require(check.size == (width, height), f"Dimensions changed for {name}")
                saved_dpi = check.info.get("dpi", (0.0, 0.0))
                require(min(saved_dpi) >= 299.0, f"Resolution below 300 dpi for {name}: {saved_dpi}")
            figure_rows.append((name, width, height, dpi_x, dst.stat().st_size, sha256(dst)))

        figures_zip = UPLOAD / "figures.zip"
        with zipfile.ZipFile(figures_zip, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
            for name in FIGURE_NAMES:
                zf.write(tmpdir / name, name)
        with zipfile.ZipFile(figures_zip) as zf:
            require(zf.testzip() is None, "Corrupt figures.zip")
            require(sorted(zf.namelist()) == sorted(FIGURE_NAMES), "Unexpected files in figures.zip")

    main_text = docx_text(UPLOAD / MANUSCRIPT)
    cover_text = docx_text(UPLOAD / COVER)
    supplement_text = docx_text(UPLOAD / SUPPLEMENT)

    for number in range(1, 7):
        require(f"Figure {number}." in main_text, f"Figure {number} caption missing from manuscript")
    require("Figure S1" in supplement_text, "Figure S1 missing from supplement")
    require("Figure S2" in supplement_text, "Figure S2 missing from supplement")
    for number in range(1, 12):
        require(f"Table S{number}" in supplement_text, f"Table S{number} missing from supplement")
    cover_date = re.search(r"\b(\d{1,2} [A-Z][a-z]+ 20\d{2})\b", cover_text)
    require(bool(cover_date), "Cover-letter date was not finalized")
    cover_date = cover_date.group(1)
    require("Section 4.13" in cover_text, "Cover letter does not cite Section 4.13")
    require("Section 4.12" not in cover_text, "Stale Section 4.12 remains in cover letter")
    require("[DATE]" not in cover_text, "Cover-letter date placeholder remains")
    for placeholder in PLACEHOLDERS:
        require(placeholder not in main_text and placeholder not in cover_text,
                f"Author-supplied field is still a placeholder: {placeholder}")
    # generic sweep: any remaining [ALL-CAPS ...] bracket is an unfilled field
    for label, text in (("manuscript", main_text), ("cover letter", cover_text)):
        stray = re.findall(r"\[[A-Z][A-Z ,\-]{6,}[^\]]*\]", text)
        require(not stray, f"Unfilled bracketed field in {label}: {stray}")

    upload_files = [UPLOAD / MANUSCRIPT, UPLOAD / COVER, UPLOAD / SUPPLEMENT, UPLOAD / "figures.zip"]
    upload_size = sum(path.stat().st_size for path in upload_files)
    require(upload_size < 120 * 1024 * 1024, "Upload set exceeds the IJMS 120 MB total limit")

    checklist = f"""
# IJMS submission checklist

Generated: {date.today().isoformat()}

## Passed checks

- [x] Manuscript structural verification: 23/23 checks passed.
- [x] Institutional Review Board Statement finalized as a public-data secondary-analysis waiver; no approval number is claimed.
- [x] Abstract length: 192 words (IJMS limit: 200 words).
- [x] References are numbered consecutively and cited in first-appearance order (41 references).
- [x] Reference list is formatted in MDPI style (authors separated by semicolons, abbreviated italic journal, bold year, italic volume) by `mdpi_reference_style.py`.
- [x] Figures 1–6 are embedded after first citation in the manuscript.
- [x] Separate figure archive contains Figures 1–6 and Figures S1–S2 only.
- [x] All separate figures retain at least 300 dpi and are at least 1000 px wide.
- [x] Supplement contains Figures S1–S2 and Tables S1–S11.
- [x] Cover-letter date is {cover_date}, and the methods cross-reference points to Section 4.13.
- [x] Upload-ready files total {upload_size / 1024 / 1024:.2f} MB, below the current IJMS 120 MB aggregate limit.
- [x] SHA-256 hashes and ZIP integrity were verified during package generation.
- [x] Corresponding-author telephone and full postal address are filled in the manuscript and cover letter; no bracketed placeholder remains in either file.
- [x] The ORCiD line was removed from the manuscript at the authors' request; ORCiD is supplied in the SuSy portal instead.

## Required before portal submission

- [ ] Obtain final approval of the exact submission files from all authors.
- [ ] Enter and cross-check title, abstract, keywords, authors, affiliations, funding, conflicts, and data availability in SuSy.
- [ ] Add suggested/opposed reviewers if requested by the portal.
- [ ] Re-run the structural verifier and regenerate this package after replacing placeholders.

## Upload order

1. `ijms_manuscript.docx` — main manuscript; figures are already embedded.
2. `cover_letter.docx` — required cover letter.
3. `supplementary_information.docx` — supplementary material.
4. `figures.zip` — optional separate high-resolution source figures.
"""
    write_text(REFERENCE / "SUBMISSION_CHECKLIST.md", checklist)

    readme = """
# IJMS submission package

This folder separates portal-ready files from internal review records.

- `01_upload_ready/` contains the four files intended for upload to the IJMS submission portal.
- `02_review_reference/SUBMISSION_CHECKLIST.md` records passed checks and the four author-supplied fields that remain mandatory before submission.
- `02_review_reference/SUBMISSION_FILE_MANIFEST.tsv` records file roles, byte sizes, and SHA-256 checksums.
- `02_review_reference/FIGURE_MANIFEST.tsv` records figure dimensions, resolution, compressed size, and SHA-256 checksums.

Do not upload the `02_review_reference` folder. The manuscript remains a pre-submission package until every bracketed placeholder listed in the checklist has been replaced with verified author information.
"""
    write_text(DEST / "README.md", readme)

    manifest_lines = ["relative_path\trole\tbytes\tsha256"]
    roles = {
        MANUSCRIPT: "main manuscript",
        COVER: "required cover letter",
        SUPPLEMENT: "supplementary material",
        "figures.zip": "optional high-resolution figure archive",
    }
    for path in upload_files:
        manifest_lines.append(
            f"01_upload_ready/{path.name}\t{roles[path.name]}\t{path.stat().st_size}\t{sha256(path)}"
        )
    write_text(REFERENCE / "SUBMISSION_FILE_MANIFEST.tsv", "\n".join(manifest_lines))

    figure_manifest = ["file\twidth_px\theight_px\tdpi\tcompressed_bytes\tsha256"]
    for name, width, height, dpi, size, digest in figure_rows:
        figure_manifest.append(f"{name}\t{width}\t{height}\t{dpi:.2f}\t{size}\t{digest}")
    write_text(REFERENCE / "FIGURE_MANIFEST.tsv", "\n".join(figure_manifest))

    zip_tree(DEST, ARCHIVE)
    with zipfile.ZipFile(ARCHIVE) as zf:
        require(zf.testzip() is None, "Corrupt final package ZIP")
        require(all(not Path(name).name.startswith("._") for name in zf.namelist()), "AppleDouble file in ZIP")

    print(f"Created: {DEST}")
    print(f"Created: {ARCHIVE}")
    print(f"Upload size: {upload_size / 1024 / 1024:.2f} MB")
    print(f"Package ZIP: {ARCHIVE.stat().st_size / 1024 / 1024:.2f} MB")
    print("Figures:")
    for row in figure_rows:
        print(f"  {row[0]} {row[1]}x{row[2]} {row[3]:.0f} dpi {row[4] / 1024 / 1024:.2f} MB")


def refresh_existing_package() -> None:
    """Refresh hashes, size reporting, and the archive after a reviewed DOCX edit."""
    require(DEST.is_dir(), f"Package directory does not exist: {DEST}")
    for name in (MANUSCRIPT, COVER, SUPPLEMENT):
        require((SOURCE / name).is_file(), f"Missing source file: {name}")
        shutil.copy2(SOURCE / name, UPLOAD / name)
    for name in FIGURE_NAMES:
        require((SOURCE / "figures" / name).is_file(), f"Missing source figure: {name}")
    with zipfile.ZipFile(UPLOAD / "figures.zip", "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for name in FIGURE_NAMES:
            zf.write(SOURCE / "figures" / name, name)
    with zipfile.ZipFile(UPLOAD / "figures.zip") as zf:
        require(zf.testzip() is None, "Corrupt figures.zip")
        require(sorted(zf.namelist()) == sorted(FIGURE_NAMES), "Unexpected files in figures.zip")

    main_text = docx_text(UPLOAD / MANUSCRIPT)
    cover_text = docx_text(UPLOAD / COVER)
    supplement_text = docx_text(UPLOAD / SUPPLEMENT)
    require("GSE328048" in main_text, "GSE328048 external validation missing from manuscript")
    require("Figure S2" in supplement_text and "Table S11" in supplement_text,
            "External validation missing from supplement")
    require("Section 4.13" in cover_text and "Section 4.12" not in cover_text,
            "Cover-letter methods cross-reference is stale")

    upload_files = [UPLOAD / MANUSCRIPT, UPLOAD / COVER, UPLOAD / SUPPLEMENT, UPLOAD / "figures.zip"]
    for path in upload_files:
        require(path.is_file(), f"Missing upload file: {path}")
    upload_size = sum(path.stat().st_size for path in upload_files)
    require(upload_size < 120 * 1024 * 1024, "Upload set exceeds the IJMS 120 MB total limit")

    checklist_path = REFERENCE / "SUBMISSION_CHECKLIST.md"
    checklist = checklist_path.read_text(encoding="utf-8")
    checklist = re.sub(r"Abstract length: [0-9]+ words", "Abstract length: 192 words", checklist)
    checklist = re.sub(r"first-appearance order \([0-9]+ references\)", "first-appearance order (41 references)", checklist)
    checklist = checklist.replace("Figure S1 only", "Figures S1–S2 only")
    checklist = checklist.replace("Figure S1 and Tables S1–S10", "Figures S1–S2 and Tables S1–S11")
    checklist = re.sub(r"\n- \[x\] Obsolete Figure S2[^\n]*", "", checklist)
    checklist = re.sub(r"\n- \[ \] Replace `\[ZENODO DOI REQUIRED\]`[^\n]*", "", checklist)
    checklist = checklist.replace("Section 4.12", "Section 4.13")
    checklist = re.sub(
        r"Upload-ready files total [0-9.]+ MB,",
        f"Upload-ready files total {upload_size / 1024 / 1024:.2f} MB,",
        checklist,
    )
    write_text(checklist_path, checklist)

    readme_path = DEST / "README.md"
    if readme_path.is_file():
        readme = readme_path.read_text(encoding="utf-8")
        readme = readme.replace("the five author-supplied fields", "the four author-supplied fields")
        write_text(readme_path, readme)

    roles = {
        MANUSCRIPT: "main manuscript",
        COVER: "required cover letter",
        SUPPLEMENT: "supplementary material",
        "figures.zip": "optional high-resolution figure archive",
    }
    manifest_lines = ["relative_path\trole\tbytes\tsha256"]
    for path in upload_files:
        manifest_lines.append(
            f"01_upload_ready/{path.name}\t{roles[path.name]}\t{path.stat().st_size}\t{sha256(path)}"
        )
    write_text(REFERENCE / "SUBMISSION_FILE_MANIFEST.tsv", "\n".join(manifest_lines))

    figure_manifest = ["file\twidth_px\theight_px\tdpi\tcompressed_bytes\tsha256"]
    for name in FIGURE_NAMES:
        path = SOURCE / "figures" / name
        with Image.open(path) as im:
            dpi = im.info.get("dpi", (0.0, 0.0))
            dpi_x = float(dpi[0]) if dpi else 0.0
            require(min(dpi) >= 299.0, f"Resolution below 300 dpi for {name}: {dpi}")
            width, height = im.size
        figure_manifest.append(f"{name}\t{width}\t{height}\t{dpi_x:.2f}\t{path.stat().st_size}\t{sha256(path)}")
    write_text(REFERENCE / "FIGURE_MANIFEST.tsv", "\n".join(figure_manifest))

    zip_tree(DEST, ARCHIVE)
    with zipfile.ZipFile(ARCHIVE) as zf:
        require(zf.testzip() is None, "Corrupt final package ZIP")
        require(all(not Path(name).name.startswith("._") for name in zf.namelist()), "AppleDouble file in ZIP")
    print(f"Refreshed: {ARCHIVE}")
    print(f"Upload size: {upload_size / 1024 / 1024:.2f} MB")
    print(f"Package ZIP: {ARCHIVE.stat().st_size / 1024 / 1024:.2f} MB")


if __name__ == "__main__":
    try:
        if "--refresh" in sys.argv[1:]:
            refresh_existing_package()
        else:
            main()
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise
