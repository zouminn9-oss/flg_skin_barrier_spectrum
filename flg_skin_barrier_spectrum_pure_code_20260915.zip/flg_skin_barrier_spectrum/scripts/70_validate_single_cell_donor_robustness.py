#!/usr/bin/env python3
"""Validate the GSE267929 paired-donor robustness outputs."""

from __future__ import annotations

import csv
import math
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
MECH = (
    ROOT
    / "results/exploratory_snf/selected_positive_reml_z_q05"
    / "optimized_AD_ACD_branch/mechanism"
)
OUT = MECH / "single_cell_donor_robustness"


def rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


summary = rows(OUT / "donor_robustness_summary.tsv")
permutations = rows(OUT / "paired_label_swap_null.tsv")
loo = rows(OUT / "leave_one_donor_out.tsv")
primary = {
    row["celltype"]: row
    for row in rows(MECH / "single_cell_localization/celltype_program_scores.tsv")
}

checks: list[tuple[str, bool]] = []
checks.append(("two_compartments", {r["compartment"] for r in summary} == {"APC", "KRT"}))
checks.append(("64_permutation_rows", len(permutations) == 64))
checks.append(("10_leave_one_donor_rows", len(loo) == 10))

for record in summary:
    compartment = record["compartment"]
    observed = float(record["observed_score"])
    original = float(primary[compartment]["driver_pathway_score"])
    checks.append((f"{compartment}_observed_matches_primary", math.isclose(observed, original, abs_tol=1e-12)))

    null = [float(r["driver_program_score"]) for r in permutations if r["compartment"] == compartment]
    checks.append((f"{compartment}_32_exact_permutations", len(null) == 32))
    checks.append((f"{compartment}_null_contains_observed", any(math.isclose(x, observed, abs_tol=1e-12) for x in null)))
    checks.append((f"{compartment}_null_is_sign_symmetric", all(any(math.isclose(-x, y, abs_tol=1e-8) for y in null) for x in null)))

    if record["expected_direction"] == "positive":
        expected_p = sum(x >= observed - 1e-12 for x in null) / len(null)
    else:
        expected_p = sum(x <= observed + 1e-12 for x in null) / len(null)
    checks.append(
        (
            f"{compartment}_exact_p_recomputed",
            math.isclose(expected_p, float(record["exact_label_swap_p_one_sided"]), abs_tol=1e-12),
        )
    )

    loo_subset = [r for r in loo if r["compartment"] == compartment]
    checks.append((f"{compartment}_five_leave_one_out_runs", len(loo_subset) == 5))
    checks.append((f"{compartment}_all_common_donors_omitted", {r["omitted_donor"] for r in loo_subset} == {"P1", "P2", "P3", "P4", "P8"}))

failed = [name for name, passed in checks if not passed]
report = OUT / "VALIDATION_SUMMARY.tsv"
with report.open("w", newline="", encoding="utf-8") as handle:
    writer = csv.writer(handle, delimiter="\t")
    writer.writerow(["check", "passed"])
    writer.writerows((name, str(passed).upper()) for name, passed in checks)

print(f"Validated {len(checks)} checks; failures={len(failed)}")
if failed:
    raise SystemExit("Failed checks: " + ", ".join(failed))
