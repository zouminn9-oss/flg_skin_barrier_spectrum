#!/usr/bin/env python3
"""Prepare a compact scFEA input and summarize inferred fluxes at the donor level."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
import scipy.io


def sign_flip_pvalue(x: np.ndarray) -> float:
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x)]
    if not len(x):
        return np.nan
    observed = abs(x.mean())
    signs = np.array(np.meshgrid(*[[-1.0, 1.0]] * len(x))).T.reshape(-1, len(x))
    null = np.abs((signs * x).mean(axis=1))
    return float(np.mean(null >= observed - 1e-12))


def bh(p: np.ndarray) -> np.ndarray:
    p = np.asarray(p, dtype=float)
    out = np.full_like(p, np.nan)
    ok = np.isfinite(p)
    vals = p[ok]
    order = np.argsort(vals)
    q = vals[order] * len(vals) / np.arange(1, len(vals) + 1)
    q = np.minimum.accumulate(q[::-1])[::-1]
    inv = np.empty_like(q)
    inv[order] = np.minimum(q, 1.0)
    out[ok] = inv
    return out


def prepare(bundle: Path, module_file: Path, output: Path) -> None:
    counts = scipy.io.mmread(bundle / "counts_genes_by_cells.mtx").tocsr()
    genes = pd.read_csv(bundle / "genes.tsv", sep="\t").iloc[:, 0].astype(str).values
    cells = pd.read_csv(bundle / "barcodes.tsv", sep="\t").iloc[:, 0].astype(str).values
    modules = pd.read_csv(module_file, index_col=0)
    metabolic = set(modules.stack().dropna().astype(str))
    keep = np.array([g in metabolic for g in genes])
    frame = pd.DataFrame.sparse.from_spmatrix(counts[keep, :], index=genes[keep], columns=cells)
    output.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(output)
    metadata = {
        "input_bundle": str(bundle),
        "module_file": str(module_file),
        "genes_in_input": int(keep.sum()),
        "cells_in_input": int(len(cells)),
        "matrix_orientation": "genes_by_cells",
        "raw_UMI_counts": True,
    }
    output.with_suffix(".json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")


def summarize(flux_file: Path, metadata_file: Path, output_dir: Path) -> None:
    flux = pd.read_csv(flux_file, index_col=0)
    meta = pd.read_csv(metadata_file, sep="\t", index_col=0).loc[flux.index]
    rows = []
    for (patient, lesion, celltype), idx in meta.groupby(["Patient", "Lesion", "Basic_Celltype"], observed=True).groups.items():
        med = flux.loc[list(idx)].median(axis=0)
        rows.extend(
            {"Patient": patient, "Lesion": lesion, "Basic_Celltype": celltype, "module": m, "median_flux": v}
            for m, v in med.items()
        )
    donor = pd.DataFrame(rows)
    output_dir.mkdir(parents=True, exist_ok=True)
    donor.to_csv(output_dir / "scfea_donor_condition_celltype_flux.tsv", sep="\t", index=False)
    tests = []
    for (celltype, module), sub in donor.groupby(["Basic_Celltype", "module"], observed=True):
        wide = sub.pivot(index="Patient", columns="Lesion", values="median_flux")
        if not {"Day4_Allergy", "Irritant"}.issubset(wide.columns):
            continue
        diff = (wide["Day4_Allergy"] - wide["Irritant"]).dropna()
        tests.append(
            {
                "Basic_Celltype": celltype,
                "module": module,
                "donors": len(diff),
                "median_paired_difference": float(diff.median()),
                "mean_paired_difference": float(diff.mean()),
                "same_direction_donors": int(max((diff > 0).sum(), (diff < 0).sum())),
                "exact_sign_flip_pvalue": sign_flip_pvalue(diff.values),
            }
        )
    tests = pd.DataFrame(tests)
    tests["qvalue_within_celltype"] = tests.groupby("Basic_Celltype")["exact_sign_flip_pvalue"].transform(lambda x: bh(x.values))
    tests.sort_values(["Basic_Celltype", "qvalue_within_celltype", "exact_sign_flip_pvalue"]).to_csv(
        output_dir / "scfea_paired_flux_tests.tsv", sep="\t", index=False
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=["prepare", "summarize"], required=True)
    parser.add_argument("--bundle", type=Path, default=Path("data/processed/advanced_single_cell_inputs/paired_day4_irritant_balanced"))
    parser.add_argument("--module-file", type=Path, default=Path("external_tools/scFEA/data/module_gene_m168.csv"))
    parser.add_argument("--input-csv", type=Path, default=Path("results/advanced_single_cell/metabolism/scFEA/input/scfea_metabolic_counts.csv"))
    parser.add_argument("--flux-file", type=Path, default=Path("results/advanced_single_cell/metabolism/scFEA/scfea_flux.csv"))
    parser.add_argument("--output-dir", type=Path, default=Path("results/advanced_single_cell/metabolism/scFEA"))
    args = parser.parse_args()
    if args.mode == "prepare":
        prepare(args.bundle, args.module_file, args.input_csv)
    else:
        summarize(args.flux_file, args.bundle / "metadata.tsv", args.output_dir)


if __name__ == "__main__":
    main()
