#!/usr/bin/env python3
"""Update IJMS supplement terminology and 16-gene biological interpretation."""

from pathlib import Path

from docx import Document


ROOT = Path("/Volumes/brilliant/flg_skin_barrier_spectrum")
DOCX = ROOT / "paper_rewriting_output/ijms_submission/supplementary_information.docx"

REPLACEMENTS = {
    "Supplementary Figure S2. External validation of the frozen 16-gene score in GSE328048":
        "Supplementary Figure S2. External validation of the prespecified 16-gene score in GSE328048",
    "(a) Frozen rank-score distributions": "(a) Prespecified rank-score distributions",
    "the frozen-core title-cluster difference": "the prespecified-core title-cluster difference",
    "Table S11. GSE328048 frozen-score external validation and sensitivity analyses":
        "Table S11. GSE328048 prespecified-score external validation and sensitivity analyses",
    "The 16 genes, equal positive weights, rank-score equation, primary contrast and randomization plan were locked before count inspection.":
        "The 16 genes, equal positive weights, rank-score equation, primary contrast and randomization plan were specified independently of GSE328048 and applied without refitting.",
    "the inferential object is the frozen set": "the inferential object is the prespecified set",
    "Interpretation boundary: the frozen score externally generalizes as a whole-biopsy AD state, but its fixed proliferation-adjusted coefficient is null.":
        "Interpretation boundary: the prespecified score externally generalizes as a whole-biopsy AD state, but its proliferation-adjusted coefficient is null.",
    "frozen_reference": "reference_file",
    "Frozen analysis plan": "Prespecified analysis plan",
    "Frozen primary rule supported": "Prespecified primary rule supported",
}

OLD_FUNCTION = (
    "Genes are ordered by functional group, not by effect size. Group assignment is descriptive and based on "
    "Reactome pathway membership; the ubiquitin and proteostasis components are the least mechanism-specific "
    "members of the core."
)
NEW_FUNCTION = (
    "Genes are ordered by functional group, not by effect size. Together they span damage recognition and "
    "single-stranded-DNA handling, repair synthesis, replication-stress checkpoint control, fork recovery, "
    "cell-cycle coupling and proteostasis. The coordinated set is intended as a research readout of "
    "replication-surveillance demand across tissues or cell compartments, not as 16 independent biomarkers. "
    "The ubiquitin and proteostasis components are the least mechanism-specific members. Interpretation requires "
    "cell-type, proliferation and orthogonal damage controls."
)


def replace_text(text: str) -> str:
    if text == OLD_FUNCTION:
        return NEW_FUNCTION
    for old, new in REPLACEMENTS.items():
        text = text.replace(old, new)
    return text


def update_paragraph(paragraph) -> int:
    updated = replace_text(paragraph.text)
    if updated == paragraph.text:
        return 0
    paragraph.text = updated
    return 1


def main() -> None:
    doc = Document(DOCX)
    changes = sum(update_paragraph(paragraph) for paragraph in doc.paragraphs)
    for table in doc.tables:
        for row in table.rows:
            for cell in row.cells:
                changes += sum(update_paragraph(paragraph) for paragraph in cell.paragraphs)
    if changes == 0:
        raise SystemExit("No matching supplement text found; refusing a no-op update")
    doc.save(DOCX)
    print(f"Updated {DOCX} ({changes} paragraphs/cells)")


if __name__ == "__main__":
    main()
