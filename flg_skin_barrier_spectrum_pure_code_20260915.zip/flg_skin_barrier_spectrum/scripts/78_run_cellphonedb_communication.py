#!/usr/bin/env python3
"""Run CellPhoneDB v5 permutation analysis in the paired balanced skin dataset."""

from __future__ import annotations

import argparse
import json
from importlib.metadata import version
from pathlib import Path

import anndata as ad
import numpy as np
import pandas as pd
import scipy.io
import scipy.sparse as sp
from cellphonedb.src.core.methods import cpdb_statistical_analysis_method

cpdb_version = version("cellphonedb")


def bh(p: np.ndarray) -> np.ndarray:
    p = np.asarray(p, dtype=float)
    out = np.full_like(p, np.nan)
    ok = np.isfinite(p)
    vals = p[ok]
    order = np.argsort(vals)
    ranked = vals[order]
    q = ranked * len(ranked) / np.arange(1, len(ranked) + 1)
    q = np.minimum.accumulate(q[::-1])[::-1]
    restored = np.empty_like(q)
    restored[order] = np.minimum(q, 1.0)
    out[ok] = restored
    return out


def load_input(bundle: Path) -> tuple[sp.csr_matrix, np.ndarray, np.ndarray, pd.DataFrame]:
    counts = scipy.io.mmread(bundle / "counts_genes_by_cells.mtx").tocsr().T
    genes = pd.read_csv(bundle / "genes.tsv", sep="\t").iloc[:, 0].astype(str).values
    cells = pd.read_csv(bundle / "barcodes.tsv", sep="\t").iloc[:, 0].astype(str).values
    meta = pd.read_csv(bundle / "metadata.tsv", sep="\t", index_col=0).loc[cells]
    return counts, genes, cells, meta


def long_results(pvalues: pd.DataFrame, means: pd.DataFrame) -> pd.DataFrame:
    pair_cols = [c for c in pvalues.columns if "|" in str(c)]
    id_cols = [c for c in ["id_cp_interaction", "interacting_pair", "partner_a", "partner_b", "gene_a", "gene_b", "annotation_strategy"] if c in pvalues.columns]
    records = []
    for pair in pair_cols:
        sub = pvalues[id_cols].copy()
        sub["cellpair"] = pair
        sub["pvalue"] = pd.to_numeric(pvalues[pair], errors="coerce")
        sub["mean"] = pd.to_numeric(means[pair], errors="coerce")
        sub["qvalue_within_cellpair"] = bh(sub["pvalue"].values)
        records.append(sub)
    return pd.concat(records, ignore_index=True)


def run_condition(
    condition: str,
    counts: sp.csr_matrix,
    genes: np.ndarray,
    cells: np.ndarray,
    meta: pd.DataFrame,
    db_zip: Path,
    output_root: Path,
    iterations: int,
) -> pd.DataFrame:
    keep = np.flatnonzero(meta["Lesion"].astype(str).values == condition)
    out_dir = output_root / condition
    input_dir = out_dir / "inputs"
    input_dir.mkdir(parents=True, exist_ok=True)
    obs = meta.iloc[keep].copy()
    adata = ad.AnnData(X=counts[keep, :].astype(np.float32), obs=obs)
    adata.obs_names = cells[keep]
    adata.var_names = genes
    adata.var_names_make_unique()
    h5ad = input_dir / "raw_counts.h5ad"
    adata.write_h5ad(h5ad)
    cpmeta = pd.DataFrame({"cell": adata.obs_names, "cell_type": obs["Basic_Celltype"].astype(str).values})
    meta_path = input_dir / "cellphonedb_meta.tsv"
    cpmeta.to_csv(meta_path, sep="\t", index=False)
    result = cpdb_statistical_analysis_method.call(
        cpdb_file_path=str(db_zip),
        meta_file_path=str(meta_path),
        counts_file_path=str(h5ad),
        counts_data="hgnc_symbol",
        output_path=str(out_dir),
        iterations=iterations,
        threshold=0.1,
        threads=1,
        debug_seed=20260910,
        result_precision=6,
        pvalue=0.05,
        subsampling=False,
        separator="|",
        debug=False,
        output_suffix=condition,
        score_interactions=False,
    )
    long = long_results(result["pvalues"], result["means"])
    long.to_csv(out_dir / "cellphonedb_interactions_long.tsv", sep="\t", index=False)
    sig = long[(long["qvalue_within_cellpair"] < 0.10) & (long["mean"] > 0)].copy()
    sig.sort_values(["qvalue_within_cellpair", "mean"], ascending=[True, False]).to_csv(
        out_dir / "cellphonedb_interactions_q10.tsv", sep="\t", index=False
    )
    metadata = {
        "method": "CellPhoneDB statistical_analysis",
        "cellphonedb_version": cpdb_version,
        "database_release": "v5.0.0",
        "condition": condition,
        "cells": int(len(keep)),
        "cell_types": sorted(cpmeta["cell_type"].unique()),
        "iterations": iterations,
        "threshold_fraction_expressing": 0.1,
        "threads": 1,
        "debug_seed": 20260910,
        "multiple_testing": "Benjamini-Hochberg within each directed cell-type pair",
        "interaction_score_product": False,
        "qvalue_threshold": 0.10,
        "significant_rows": int(len(sig)),
    }
    (out_dir / "cellphonedb_run_metadata.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    return sig


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--bundle", type=Path, default=Path("data/processed/advanced_single_cell_inputs/paired_day4_irritant_balanced"))
    parser.add_argument("--database", type=Path, default=Path("external_tools/CellPhoneDB_data/cellphonedb.zip"))
    parser.add_argument("--output-root", type=Path, default=Path("results/advanced_single_cell/communication/CellPhoneDB"))
    parser.add_argument("--iterations", type=int, default=1000)
    args = parser.parse_args()
    counts, genes, cells, meta = load_input(args.bundle)
    sig_by_condition = {}
    for condition in ("Irritant", "Day4_Allergy"):
        sig_by_condition[condition] = run_condition(
            condition, counts, genes, cells, meta, args.database, args.output_root, args.iterations
        )
    keys = ["interacting_pair", "cellpair"]
    left = sig_by_condition["Irritant"][keys + ["mean", "qvalue_within_cellpair"]].rename(
        columns={"mean": "mean_Irritant", "qvalue_within_cellpair": "q_Irritant"}
    )
    right = sig_by_condition["Day4_Allergy"][keys + ["mean", "qvalue_within_cellpair"]].rename(
        columns={"mean": "mean_Day4_Allergy", "qvalue_within_cellpair": "q_Day4_Allergy"}
    )
    comp = left.merge(right, on=keys, how="outer")
    comp["significance_class"] = np.select(
        [comp["q_Irritant"].notna() & comp["q_Day4_Allergy"].notna(), comp["q_Day4_Allergy"].notna(), comp["q_Irritant"].notna()],
        ["shared", "Day4_Allergy_only", "Irritant_only"],
        default="none",
    )
    comp.to_csv(args.output_root / "cellphonedb_condition_comparison_q10.tsv", sep="\t", index=False)


if __name__ == "__main__":
    main()
