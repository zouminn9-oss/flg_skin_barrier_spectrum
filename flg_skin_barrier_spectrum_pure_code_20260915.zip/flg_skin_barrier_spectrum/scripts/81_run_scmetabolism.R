#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(Matrix)
  library(scMetabolism)
  library(GSEABase)
})

set.seed(20260910)
bundle <- "data/processed/advanced_single_cell_inputs/paired_day4_irritant_balanced"
out_root <- "results/advanced_single_cell/metabolism/scMetabolism"
dir.create(out_root, recursive = TRUE, showWarnings = FALSE)

counts <- readMM(file.path(bundle, "counts_genes_by_cells.mtx"))
genes <- read.delim(file.path(bundle, "genes.tsv"), check.names = FALSE)[[1]]
cells <- read.delim(file.path(bundle, "barcodes.tsv"), check.names = FALSE)[[1]]
meta <- read.delim(file.path(bundle, "metadata.tsv"), row.names = 1, check.names = FALSE)
rownames(counts) <- make.unique(as.character(genes))
colnames(counts) <- as.character(cells)
meta <- meta[cells, , drop = FALSE]

gmt_files <- c(
  KEGG = system.file("data", "KEGG_metabolism_nc.gmt", package = "scMetabolism"),
  REACTOME = system.file("data", "REACTOME_metabolism.gmt", package = "scMetabolism")
)
gmt_genes <- unique(unlist(lapply(gmt_files, function(f) geneIds(getGmt(f)))))
keep_genes <- intersect(rownames(counts), gmt_genes)
if (length(keep_genes) < 100L) stop("Too few scMetabolism signature genes overlap the input")
analysis_counts <- as.matrix(counts)

run_score <- function(method, signature_type) {
  message("scMetabolism: ", method, " / ", signature_type)
  score <- sc.metabolism(
    countexp = analysis_counts,
    method = method,
    imputation = FALSE,
    ncores = 2,
    metabolism.type = signature_type
  )
  score <- as.matrix(score)
  if (!all(cells %in% colnames(score)) && all(cells %in% rownames(score))) score <- t(score)
  if (!all(cells %in% colnames(score))) stop("Score matrix cell identifiers do not match input")
  score <- score[, cells, drop = FALSE]
  write.table(score, file.path(out_root, paste0("scmetabolism_", tolower(method), "_", tolower(signature_type), "_scores.tsv")),
              sep = "\t", quote = FALSE, col.names = NA)
  score
}

score_sets <- list()
for (signature_type in c("KEGG", "REACTOME")) {
  for (method in c("AUCell", "VISION")) {
    score_sets[[paste(method, signature_type, sep = "|")]] <- run_score(method, signature_type)
  }
}

summarise_scores <- function(scores, method, signature_type) {
  long_rows <- vector("list", nrow(scores) * length(unique(interaction(meta$Patient, meta$Lesion, meta$Basic_Celltype, drop = TRUE))))
  k <- 0L
  group_ix <- split(seq_len(nrow(meta)), interaction(meta$Patient, meta$Lesion, meta$Basic_Celltype, drop = TRUE))
  for (pathway in rownames(scores)) {
    x <- as.numeric(scores[pathway, ])
    for (ix in group_ix) {
      k <- k + 1L
      long_rows[[k]] <- data.frame(
        method = method,
        signature_type = signature_type,
        pathway = pathway,
        Patient = as.character(meta$Patient[ix[1]]),
        Lesion = as.character(meta$Lesion[ix[1]]),
        Basic_Celltype = as.character(meta$Basic_Celltype[ix[1]]),
        median_score = median(x[ix], na.rm = TRUE),
        mean_score = mean(x[ix], na.rm = TRUE),
        n_cells = length(ix),
        stringsAsFactors = FALSE
      )
    }
  }
  do.call(rbind, long_rows[seq_len(k)])
}

donor_rows <- list()
for (nm in names(score_sets)) {
  parts <- strsplit(nm, "\\|", fixed = FALSE)[[1]]
  donor_rows[[nm]] <- summarise_scores(score_sets[[nm]], parts[1], parts[2])
}
donor <- do.call(rbind, donor_rows)
rownames(donor) <- NULL
write.table(donor, file.path(out_root, "scmetabolism_donor_condition_scores.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)

exact_signflip_p <- function(delta) {
  delta <- delta[is.finite(delta)]
  n <- length(delta)
  if (!n) return(NA_real_)
  observed <- abs(mean(delta))
  grid <- expand.grid(rep(list(c(-1, 1)), n))
  perm <- abs(as.matrix(grid) %*% delta / n)
  mean(perm >= observed - 1e-12)
}

test_groups <- split(seq_len(nrow(donor)), interaction(donor$method, donor$signature_type, donor$pathway, donor$Basic_Celltype, drop = TRUE))
test_rows <- lapply(test_groups, function(ix) {
  z <- donor[ix, , drop = FALSE]
  wide <- reshape(z[c("Patient", "Lesion", "median_score")], idvar = "Patient", timevar = "Lesion", direction = "wide")
  needed <- c("median_score.Irritant", "median_score.Day4_Allergy")
  if (!all(needed %in% names(wide))) return(NULL)
  delta <- wide[["median_score.Day4_Allergy"]] - wide[["median_score.Irritant"]]
  data.frame(
    method = z$method[1],
    signature_type = z$signature_type[1],
    pathway = z$pathway[1],
    Basic_Celltype = z$Basic_Celltype[1],
    n_donors = sum(is.finite(delta)),
    mean_paired_delta = mean(delta, na.rm = TRUE),
    median_paired_delta = median(delta, na.rm = TRUE),
    positive_donors = sum(delta > 0, na.rm = TRUE),
    negative_donors = sum(delta < 0, na.rm = TRUE),
    exact_signflip_p = exact_signflip_p(delta),
    stringsAsFactors = FALSE
  )
})
tests <- do.call(rbind, test_rows)
tests$q_BH_within_method_library_celltype <- ave(
  tests$exact_signflip_p,
  interaction(tests$method, tests$signature_type, tests$Basic_Celltype),
  FUN = function(x) p.adjust(x, method = "BH")
)
write.table(tests, file.path(out_root, "scmetabolism_paired_donor_tests.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)

effect_key <- paste(tests$signature_type, tests$pathway, tests$Basic_Celltype, sep = "|")
au <- tests[tests$method == "AUCell", c("signature_type", "pathway", "Basic_Celltype", "mean_paired_delta")]
vi <- tests[tests$method == "VISION", c("signature_type", "pathway", "Basic_Celltype", "mean_paired_delta")]
names(au)[4] <- "AUCell_delta"
names(vi)[4] <- "VISION_delta"
comparison <- merge(au, vi, by = c("signature_type", "pathway", "Basic_Celltype"), all = FALSE)
comparison$direction_concordant <- sign(comparison$AUCell_delta) == sign(comparison$VISION_delta)
write.table(comparison, file.path(out_root, "scmetabolism_cross_method_effects.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)

corr_rows <- lapply(split(seq_len(nrow(comparison)), interaction(comparison$signature_type, comparison$Basic_Celltype)), function(ix) {
  z <- comparison[ix, , drop = FALSE]
  data.frame(
    signature_type = z$signature_type[1],
    Basic_Celltype = z$Basic_Celltype[1],
    n_pathways = nrow(z),
    spearman_rho = cor(z$AUCell_delta, z$VISION_delta, method = "spearman", use = "complete.obs"),
    direction_concordance = mean(z$direction_concordant, na.rm = TRUE),
    stringsAsFactors = FALSE
  )
})
corr <- do.call(rbind, corr_rows)
write.table(corr, file.path(out_root, "scmetabolism_cross_method_summary.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)

writeLines(c(
  paste0("scMetabolism_version\t", packageVersion("scMetabolism")),
  paste0("VISION_version\t", packageVersion("VISION")),
  paste0("AUCell_version\t", packageVersion("AUCell")),
  paste0("cells\t", ncol(analysis_counts)),
  paste0("input_genes\t", nrow(analysis_counts)),
  paste0("signature_gene_overlap\t", length(keep_genes)),
  "conditions\tIrritant,Day4_Allergy",
  "donors\t5 paired",
  "cell_types\tAPC,KRT,LYMPH",
  "methods\tAUCell,VISION",
  "signature_libraries\tKEGG,REACTOME",
  "imputation\tFALSE",
  "inference\texact two-sided sign-flip test over paired donor deltas"
), file.path(out_root, "scmetabolism_run_metadata.tsv"))
