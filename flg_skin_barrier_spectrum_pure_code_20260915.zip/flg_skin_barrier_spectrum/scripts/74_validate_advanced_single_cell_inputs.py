#!/usr/bin/env python3
"""Validate frozen Matrix Market bundles without third-party dependencies."""

from __future__ import annotations

import csv
import hashlib
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "data/processed/advanced_single_cell_inputs"
BUNDLES = (
    "paired_day4_irritant_full",
    "paired_day4_irritant_balanced",
    "state_continuum_APC",
    "state_continuum_KRT",
)


def tsv_rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def matrix_shape(path: Path) -> tuple[int, int, int]:
    with path.open(encoding="ascii") as handle:
        for line in handle:
            if not line.startswith("%"):
                return tuple(map(int, line.split()))  # type: ignore[return-value]
    raise ValueError(f"No Matrix Market shape in {path}")


def md5(path: Path) -> str:
    digest = hashlib.md5()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


checks: list[tuple[str, bool]] = []
summary = {r["bundle"]: r for r in tsv_rows(BASE / "INPUT_BUNDLE_SUMMARY.tsv")}
checks.append(("all_four_bundles_summarized", set(summary) == set(BUNDLES)))

for name in BUNDLES:
    bundle = BASE / name
    shape = matrix_shape(bundle / "counts_genes_by_cells.mtx")
    genes = tsv_rows(bundle / "genes.tsv")
    barcodes = tsv_rows(bundle / "barcodes.tsv")
    metadata = tsv_rows(bundle / "metadata.tsv")
    checks.append((f"{name}_21499_genes", shape[0] == len(genes) == 21499))
    checks.append((f"{name}_cell_dimensions_match", shape[1] == len(barcodes) == len(metadata)))
    checks.append((f"{name}_summary_cells_match", shape[1] == int(summary[name]["cells"])))
    checks.append((f"{name}_barcode_order_matches_metadata", [r["barcode"] for r in barcodes] == [r["barcode"] for r in metadata]))
    checks.append((f"{name}_five_donors", len({r["Patient"] for r in metadata}) == 5))
    checks.append((f"{name}_nonzero_entries", shape[2] > 0))

    expected = {r["file"]: r["md5"] for r in tsv_rows(bundle / "MD5SUMS.tsv")}
    checks.append((f"{name}_four_checksums", len(expected) == 4))
    for filename, digest in expected.items():
        checks.append((f"{name}_{filename}_md5", md5(bundle / filename) == digest))

balanced_meta = tsv_rows(BASE / "paired_day4_irritant_balanced/metadata.tsv")
balance_counts: dict[tuple[str, str, str], int] = {}
for row in balanced_meta:
    key = (row["Patient"], row["Basic_Celltype"], row["Lesion"])
    balance_counts[key] = balance_counts.get(key, 0) + 1
for donor, celltype, _condition in list(balance_counts):
    a = balance_counts.get((donor, celltype, "Day4_Allergy"), 0)
    b = balance_counts.get((donor, celltype, "Irritant"), 0)
    checks.append((f"balanced_{donor}_{celltype}_equal_conditions", a == b))
    checks.append((f"balanced_{donor}_{celltype}_cap", a <= 200))

failed = [name for name, passed in checks if not passed]
with (BASE / "VALIDATION_SUMMARY.tsv").open("w", newline="", encoding="utf-8") as handle:
    writer = csv.writer(handle, delimiter="\t")
    writer.writerow(["check", "passed"])
    writer.writerows((name, str(passed).upper()) for name, passed in checks)

print(f"Validated {len(checks)} checks; failures={len(failed)}")
if failed:
    raise SystemExit("Failed checks: " + ", ".join(failed))
