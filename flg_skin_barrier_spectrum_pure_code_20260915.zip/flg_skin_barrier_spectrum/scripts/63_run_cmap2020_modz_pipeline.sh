#!/bin/zsh
set -euo pipefail

PROJECT_DIR="/Volumes/brilliant/flg_skin_barrier_spectrum"
RAW_DIR="$PROJECT_DIR/data/raw/perturbations/cmap2020_modz"
RESULT_DIR="$PROJECT_DIR/results/exploratory_snf/selected_positive_reml_z_q05/optimized_AD_ACD_branch/mechanism/cmap2020_modz_full_background_sensitivity"
RECEIPT="$RAW_DIR/download_receipt.json"
LOG="$RESULT_DIR/pipeline.log"

mkdir -p "$RESULT_DIR"
cd "$PROJECT_DIR"

{
  print -- "[$(date -u +%Y-%m-%dT%H:%M:%SZ)] waiting_for_download_receipt"
  while [[ ! -s "$RECEIPT" ]]; do
    sleep 30
  done

  if [[ -s "$RESULT_DIR/SOURCE_AND_SCHEMA_QC.json" ]]; then
    print -- "[$(date -u +%Y-%m-%dT%H:%M:%SZ)] source_and_schema_already_verified"
  else
    print -- "[$(date -u +%Y-%m-%dT%H:%M:%SZ)] inspect_source_and_schema"
    PYTHONPATH=environment/python_packages python3 scripts/59_inspect_cmap2020_modz.py
  fi

  print -- "[$(date -u +%Y-%m-%dT%H:%M:%SZ)] score_full_background"
  PYTHONPATH=environment/python_packages python3 scripts/60_score_cmap2020_modz_full_background.py

  print -- "[$(date -u +%Y-%m-%dT%H:%M:%SZ)] validate_outputs"
  PYTHONPATH=environment/python_packages python3 scripts/61_validate_cmap2020_modz_full_background.py

  print -- "[$(date -u +%Y-%m-%dT%H:%M:%SZ)] build_report"
  PYTHONPATH=environment/python_packages python3 scripts/62_build_cmap2020_modz_report.py

  print -- "[$(date -u +%Y-%m-%dT%H:%M:%SZ)] pipeline_complete"
} 2>&1 | tee -a "$LOG"
