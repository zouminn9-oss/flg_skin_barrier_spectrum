#!/usr/bin/env python3
"""Map GEO library titles to published clinical sample IDs using QC cell totals.

The Nature source-data proportions are exact ratios of integer cell counts. Their
denominators recover each post-QC sample total. GEO matrix column counts are then
matched within disease strata by a minimum-cost assignment. Signature-expression
values are never used in this mapping.
"""

from __future__ import annotations

import argparse
import csv
import math
from collections import defaultdict
from fractions import Fraction
from pathlib import Path


def hungarian(cost: list[list[float]]) -> list[int]:
    """Return the minimum-cost column assigned to each row (square matrix)."""
    n = len(cost)
    u = [0.0] * (n + 1)
    v = [0.0] * (n + 1)
    p = [0] * (n + 1)
    way = [0] * (n + 1)
    for i in range(1, n + 1):
        p[0] = i
        j0 = 0
        minv = [float("inf")] * (n + 1)
        used = [False] * (n + 1)
        while True:
            used[j0] = True
            i0 = p[j0]
            delta = float("inf")
            j1 = 0
            for j in range(1, n + 1):
                if used[j]:
                    continue
                cur = cost[i0 - 1][j - 1] - u[i0] - v[j]
                if cur < minv[j]:
                    minv[j] = cur
                    way[j] = j0
                if minv[j] < delta:
                    delta = minv[j]
                    j1 = j
            for j in range(n + 1):
                if used[j]:
                    u[p[j]] += delta
                    v[j] -= delta
                else:
                    minv[j] -= delta
            j0 = j1
            if p[j0] == 0:
                break
        while True:
            j1 = way[j0]
            p[j0] = p[j1]
            j0 = j1
            if j0 == 0:
                break
    assignment = [-1] * n
    for j in range(1, n + 1):
        assignment[p[j] - 1] = j - 1
    return assignment


def published_cell_totals(source_csv: Path) -> dict[str, int]:
    denominators: dict[str, list[int]] = defaultdict(list)
    with source_csv.open(newline="") as handle:
        for row in csv.DictReader(handle):
            ratio = (Fraction(row["prop"]) / 100).limit_denominator(100_000)
            denominators[row["sampleID"]].append(ratio.denominator)
    totals = {}
    for sample_id, values in denominators.items():
        totals[sample_id] = math.lcm(*values)
    if len(totals) != 116:
        raise RuntimeError(f"Expected 116 published sample totals; found {len(totals)}")
    return totals


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--sample-qc", type=Path, required=True)
    parser.add_argument("--clinical", type=Path, required=True)
    parser.add_argument("--source-proportions", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    with args.sample_qc.open(newline="") as handle:
        geo_rows = list(csv.DictReader(handle, delimiter="\t"))
    with args.clinical.open(newline="") as handle:
        clinical_rows = list(csv.DictReader(handle))
    totals = published_cell_totals(args.source_proportions)
    clinical_by_id = {row["sampleID"]: row for row in clinical_rows}
    disease_to_group = {"Healthy": "HC", "Lesional": "LAD", "Non-lesional": "NAD"}

    mapped: list[dict[str, str]] = []
    for group in ("HC", "NAD", "LAD"):
        libraries = [row for row in geo_rows if row["group"] == group]
        samples = [row for row in clinical_rows if disease_to_group[row["disease"]] == group]
        if len(libraries) != len(samples):
            raise RuntimeError(f"Group-size mismatch for {group}: {len(libraries)} vs {len(samples)}")
        cost: list[list[float]] = []
        for library in libraries:
            raw_n = int(library["filtered_cells"])
            threshold_n = int(library["threshold_pass_cells"])
            row_cost = []
            for sample in samples:
                final_n = totals[sample["sampleID"]]
                # The final published total follows doublet/ambient-RNA removal and
                # therefore should not exceed our simple UMI/mitochondrial threshold.
                relative_gap = abs(math.log((threshold_n + 1) / (final_n + 1)))
                invalid_penalty = 4.0 * max(0, final_n - threshold_n) / max(1, threshold_n)
                raw_gap = 0.05 * abs(math.log((raw_n + 1) / (final_n + 1)))
                row_cost.append(relative_gap + invalid_penalty + raw_gap)
            cost.append(row_cost)
        assignment = hungarian(cost)
        for i, j in enumerate(assignment):
            library = libraries[i]
            sample = samples[j]
            ordered = sorted(cost[i])
            published_n = totals[sample["sampleID"]]
            mapped.append({
                **library,
                "clinical_sample_id": sample["sampleID"],
                "patient_id": sample["pat"],
                "clinical_disease": sample["disease"],
                "source": sample["Source"],
                "visit": sample["visit"],
                "age": sample["Age"],
                "sex": sample["Sex"],
                "race": sample["Race"],
                "severity": sample["Severity"],
                "severity_score": sample["Score"],
                "published_qc_cells": str(published_n),
                "qc_cells_removed": str(int(library["threshold_pass_cells"]) - published_n),
                "assignment_cost": f"{cost[i][j]:.8g}",
                "within_library_cost_margin": f"{ordered[1] - ordered[0]:.8g}",
            })

    mapped.sort(key=lambda row: int(row["gsm"].removeprefix("GSM")))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(mapped[0]), delimiter="\t", lineterminator="\n")
        writer.writeheader()
        writer.writerows(mapped)

    exact_or_near = sum(abs(int(row["qc_cells_removed"])) <= 50 for row in mapped)
    negative = sum(int(row["qc_cells_removed"]) < 0 for row in mapped)
    print(f"Mapped {len(mapped)} libraries; <=50-cell gaps: {exact_or_near}; negative gaps: {negative}")


if __name__ == "__main__":
    main()
