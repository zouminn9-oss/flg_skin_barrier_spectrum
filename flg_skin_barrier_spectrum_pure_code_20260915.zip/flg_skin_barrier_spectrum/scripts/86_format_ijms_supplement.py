#!/usr/bin/env python3
"""Improve wide-table readability in the IJMS supplementary DOCX."""

from pathlib import Path

from docx import Document
from docx.enum.section import WD_ORIENT
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt


ROOT = Path("/Volumes/brilliant/flg_skin_barrier_spectrum")
TARGETS = [
    ROOT / "paper_rewriting_output/ijms_submission/supplementary_information.docx",
    ROOT / "paper_rewriting_output/ijms_submission/upload_ready/supplementary_information.docx",
    ROOT / "submission/IJMS_Submission_20260911/01_upload_ready/supplementary_information.docx",
]


def set_table_full_width(table) -> None:
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = True
    tbl_pr = table._tbl.tblPr
    tbl_w = tbl_pr.find(qn("w:tblW"))
    if tbl_w is None:
        tbl_w = OxmlElement("w:tblW")
        tbl_pr.append(tbl_w)
    tbl_w.set(qn("w:type"), "pct")
    tbl_w.set(qn("w:w"), "5000")


def format_document(path: Path) -> None:
    doc = Document(path)
    for section in doc.sections:
        section.orientation = WD_ORIENT.LANDSCAPE
        section.page_width = Inches(11)
        section.page_height = Inches(8.5)
        section.top_margin = Inches(0.5)
        section.bottom_margin = Inches(0.5)
        section.left_margin = Inches(0.5)
        section.right_margin = Inches(0.5)

    for table in doc.tables:
        set_table_full_width(table)
        font_size = Pt(7.0 if len(table.columns) >= 7 else 7.5)
        for row in table.rows:
            for cell in row.cells:
                cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.TOP
                for paragraph in cell.paragraphs:
                    paragraph.paragraph_format.space_before = Pt(0)
                    paragraph.paragraph_format.space_after = Pt(0)
                    paragraph.paragraph_format.line_spacing = 1
                    for run in paragraph.runs:
                        run.font.size = font_size

    doc.save(path)
    print(f"Formatted: {path}")


def main() -> None:
    for path in TARGETS:
        if not path.is_file():
            raise FileNotFoundError(path)
        format_document(path)


if __name__ == "__main__":
    main()
