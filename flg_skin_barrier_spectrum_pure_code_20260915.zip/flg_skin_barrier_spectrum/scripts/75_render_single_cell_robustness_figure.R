#!/usr/bin/env Rscript

# Render an audit figure from the completed donor and subtype robustness tables.

root <- normalizePath(getwd())
mech <- file.path(
  root, "results", "exploratory_snf", "selected_positive_reml_z_q05",
  "optimized_AD_ACD_branch", "mechanism"
)
donor_dir <- file.path(mech, "single_cell_donor_robustness")
subtype_dir <- file.path(mech, "single_cell_subtype_robustness")
fig_dir <- file.path(mech, "single_cell_robustness_figures")
dir.create(fig_dir, recursive = TRUE, showWarnings = FALSE)

summary <- read.delim(file.path(donor_dir, "donor_robustness_summary.tsv"), check.names = FALSE)
null <- read.delim(file.path(donor_dir, "paired_label_swap_null.tsv"), check.names = FALSE)
loo <- read.delim(file.path(donor_dir, "leave_one_donor_out.tsv"), check.names = FALSE)
subtypes <- read.delim(file.path(subtype_dir, "subtype_program_summary.tsv"), check.names = FALSE)

png(
  file.path(fig_dir, "single_cell_donor_subtype_robustness.png"),
  width = 2400, height = 1800, res = 300, bg = "white"
)
par(mfrow = c(2, 2), mar = c(4.2, 4.5, 3.0, 1.0), mgp = c(2.5, 0.8, 0), las = 1)

colors <- c(APC = "#D95F02", KRT = "#1B9E77")
for (compartment in c("APC", "KRT")) {
  values <- null$driver_program_score[null$compartment == compartment]
  observed <- summary$observed_score[summary$compartment == compartment]
  p <- summary$exact_label_swap_p_one_sided[summary$compartment == compartment]
  hist(
    values, breaks = 10, col = "#D9D9D9", border = "white",
    xlab = "Refitted driver-program score", ylab = "Exact label assignments",
    main = paste0(compartment, " paired label-swap null")
  )
  abline(v = 0, col = "#666666", lty = 2)
  abline(v = observed, col = colors[[compartment]], lwd = 2.5)
  legend(
    "topright", legend = sprintf("Observed %.3f; P=%.3f", observed, p),
    lwd = 2.5, col = colors[[compartment]], bty = "n", cex = 0.82
  )
}

donor_order <- c("P1", "P2", "P3", "P4", "P8")
plot(
  NA, xlim = c(0.7, 5.3), ylim = range(c(loo$driver_program_score, 0)) + c(-0.12, 0.12),
  xaxt = "n", xlab = "Omitted donor", ylab = "Leave-one-donor-out score",
  main = "Compartment direction after donor deletion"
)
axis(1, at = seq_along(donor_order), labels = donor_order)
abline(h = 0, col = "#666666", lty = 2)
for (compartment in c("APC", "KRT")) {
  block <- loo[loo$compartment == compartment, ]
  block <- block[match(donor_order, block$omitted_donor), ]
  offset <- if (compartment == "APC") -0.08 else 0.08
  points(
    seq_along(donor_order) + offset, block$driver_program_score,
    pch = if (compartment == "APC") 16 else 17,
    col = colors[[compartment]], cex = 1.15
  )
  lines(seq_along(donor_order) + offset, block$driver_program_score, col = colors[[compartment]])
}
legend(
  "topright", legend = c("APC", "KRT"), col = colors, pch = c(16, 17),
  lty = 1, bty = "n", cex = 0.85
)

subtypes <- subtypes[order(subtypes$observed_score), ]
labels <- paste0(subtypes$parent, ": ", subtypes$subtype)
dot_colors <- unname(colors[subtypes$parent])
score_span <- diff(range(c(subtypes$observed_score, 0)))
subtype_xlim <- range(c(subtypes$observed_score, 0)) + c(-0.12, 0.22) * score_span
plot(
  subtypes$observed_score, seq_len(nrow(subtypes)), pch = 16, col = dot_colors,
  yaxt = "n", ylab = "", xlab = "Driver-program score",
  xlim = subtype_xlim,
  main = "Eligible detailed cell states"
)
axis(2, at = seq_len(nrow(subtypes)), labels = labels, las = 1, cex.axis = 0.82)
abline(v = 0, col = "#666666", lty = 2)
text(
  subtypes$observed_score, seq_len(nrow(subtypes)),
  labels = sprintf("  P=%.3f", subtypes$exact_p_directional),
  pos = ifelse(subtypes$observed_score > 0.45, 2, 4), cex = 0.72
)

mtext(
  "Fixed AD-ACD pathway program: donor-level and fine-state robustness audit",
  outer = TRUE, line = -1.2, cex = 1.0, font = 2
)
dev.off()

cat(file.path(fig_dir, "single_cell_donor_subtype_robustness.png"), "\n")
