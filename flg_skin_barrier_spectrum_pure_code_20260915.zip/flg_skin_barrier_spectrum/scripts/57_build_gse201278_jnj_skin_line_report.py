#!/usr/bin/env python3
"""Build the executed notebook and MCP report artifact for GSE201278."""

from datetime import datetime, timezone
from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
LOCAL_PACKAGES = ROOT / "environment/python_packages"
if LOCAL_PACKAGES.exists():
    sys.path.insert(0, str(LOCAL_PACKAGES))

import nbformat
from nbclient import NotebookClient
import pandas as pd

MECH = ROOT / "results/exploratory_snf/selected_positive_reml_z_q05/optimized_AD_ACD_branch/mechanism"
OUT = MECH / "gse201278_jnj_skin_line_validation"
DISPOSITION_PATH = OUT / "GSE201278_JNJ_DISPOSITION.json"
SCORE_PATH = OUT / "frozen_score_panel.tsv"
SENSITIVITY_PATH = OUT / "transformation_sensitivity.tsv"
PAIRWISE_PATH = OUT / "processed_column_pairwise_audit.tsv"
SOURCE_PATH = OUT / "SOURCE_AND_SCHEMA_QC.json"
VALIDATION_PATH = OUT / "VALIDATION_SUMMARY.json"
ARTIFACT = OUT / "report_artifact.json"
NOTEBOOK = ROOT / "notebooks/gse201278_jnj_skin_line_validation.executed.ipynb"

disposition = json.loads(DISPOSITION_PATH.read_text())
source_qc = json.loads(SOURCE_PATH.read_text())
validation = json.loads(VALIDATION_PATH.read_text())
score = pd.read_csv(SCORE_PATH, sep="\t").iloc[0]
sensitivity = pd.read_csv(SENSITIVITY_PATH, sep="\t")
pairwise = pd.read_csv(PAIRWISE_PATH, sep="\t")
generated_at = datetime.now(timezone.utc).isoformat()

chart_rows = [
    {"score": "APC genome rank", "reversal": disposition["apc_genome_rank_reversal"], "evidence_family": "GSE201278 APC", "scope": "3,735 genes"},
    {"score": "APC genome weighted", "reversal": disposition["apc_genome_weighted_reversal"], "evidence_family": "GSE201278 APC", "scope": "3,735 genes"},
    {"score": "APC program rank", "reversal": disposition["apc_program_rank_reversal"], "evidence_family": "GSE201278 APC", "scope": "214 genes"},
    {"score": "APC program weighted", "reversal": disposition["apc_program_weighted_reversal"], "evidence_family": "GSE201278 APC", "scope": "214 genes"},
    {"score": "APC composite", "reversal": disposition["apc_composite_reversal"], "evidence_family": "GSE201278 APC", "scope": "equal-weight four-score mean"},
    {"score": "External composite", "reversal": disposition["external_composite_reversal"], "evidence_family": "GSE201278 external", "scope": "E-MTAB-9501 statistic"},
    {"score": "Targeted LINCS composite", "reversal": disposition["targeted_lincs_median_composite"], "evidence_family": "Prior LINCS", "scope": "median of 297 conditions"},
]

robustness_rows = [
    {"audit": row["analysis"], "audit_type": "transform", "apc_composite_reversal": float(row["apc_composite_reversal"]), "positive": bool(row["apc_composite_reversal"] > 0)}
    for _, row in sensitivity.iterrows()
] + [
    {"audit": f"{row['jnj_column']} vs {row['control_column']}", "audit_type": "processed-column pair", "apc_composite_reversal": float(row["apc_composite_reversal"]), "positive": bool(row["apc_composite_reversal"] > 0)}
    for _, row in pairwise.iterrows()
]

summary_rows = [{
    "frozen_label": disposition["frozen_label"],
    "apc_composite": disposition["apc_composite_reversal"],
    "external_composite": disposition["external_composite_reversal"],
    "alignment_fraction": disposition["gene_label_alignment_fraction"],
    "registered_runs_per_arm": disposition["registered_biological_samples_per_arm"],
    "metadata_ambiguity": disposition["metadata_ambiguity_severity"],
}]

score_source = {
    "id": "score_source",
    "label": "GSE201278 frozen score outputs",
    "path": str(SCORE_PATH),
    "href": "https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE201278",
    "query": {
        "engine": "DuckDB over frozen TSV/JSON outputs",
        "language": "sql",
        "sql": f"SELECT * FROM read_csv_auto('{SCORE_PATH}', delim='\\t', header=true)",
        "description": "Read the frozen four-score, external-direction and toxicity results produced from the provider FPKM matrix.",
        "executed_at": generated_at,
        "tables_used": [str(SCORE_PATH), str(DISPOSITION_PATH)],
        "filters": ["Frozen 12,327-gene LINCS universe", "No fold-change or significance-based gene selection"],
        "metric_definitions": [
            "Reversal is negative correlation between the JNJ-minus-DMSO expression contrast and the frozen disease statistic.",
            "APC composite is the equal-weight mean of genome-rank, genome-weighted, program-rank, and program-weighted reversal.",
            "Gene-label alignment fraction is a 10,000-permutation alignment diagnostic, not a treatment-effect P value or FDR.",
        ],
    },
}
qc_source = {
    "id": "qc_source",
    "label": "GSE201278 source and schema QC",
    "path": str(SOURCE_PATH),
    "href": "https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE201278",
    "query": {
        "engine": "DuckDB over frozen JSON output",
        "language": "sql",
        "sql": f"SELECT * FROM read_json_auto('{SOURCE_PATH}')",
        "description": "Audit GEO/SRA registration, processed-column structure, exact hashes, missingness, and frozen gene coverage.",
        "executed_at": source_qc["checked_at_utc"],
        "tables_used": [str(SOURCE_PATH), str(ROOT / "data/raw/perturbations/GSE201278/GSE201278_fpkm.txt.gz")],
        "filters": ["GSE201278 only", "SK-MEL-2; JNJ 1.75 uM; 48 h versus DMSO"],
        "metric_definitions": ["Registered runs per arm counts SRA runs, not provider-processed FPKM columns."],
    },
}
sources = [score_source, qc_source]

manifest = {
    "version": 1,
    "surface": "report",
    "title": "JNJ-7706621 independent SK-MEL-2 direction check",
    "description": "Technical report for frozen GSE201278 directional validation.",
    "generatedAt": generated_at,
    "sources": sources,
    "blocks": [
        {"id": "title", "type": "markdown", "body": "# JNJ-7706621 independent SK-MEL-2 direction check", "layout": "full"},
        {"id": "technical_summary", "type": "markdown", "sourceId": "score_source", "body": (
            "## Technical Summary\n\n"
            f"The independent GSE201278 contrast does **not** support the carried-forward JNJ direction under the frozen rule. "
            f"The APC composite is {disposition['apc_composite_reversal']:+.5f}: both genome-wide scores are positive, but both locked-program scores are negative. "
            f"The external composite is positive ({disposition['external_composite_reversal']:+.5f}), yet the gene-label alignment fraction is "
            f"{disposition['gene_label_alignment_fraction']:.1%} and the prespecified transform/pairwise audits are not uniformly positive. "
            "The frozen label is `independent_skin_line_not_supported`. This leaves the prior LINCS label `positive_not_top5` intact but prevents promotion to independent replication."
        ), "layout": "full"},
        {"id": "headline", "type": "metric-strip", "cardIds": ["label_card", "apc_card", "external_card", "alignment_card"], "layout": "full"},
        {"id": "split_finding", "type": "markdown", "sourceId": "score_source", "body": (
            "## Genome-wide Direction and the Locked Program Disagree\n\n"
            f"Genome-rank and genome-weighted reversal are {disposition['apc_genome_rank_reversal']:+.4f} and "
            f"{disposition['apc_genome_weighted_reversal']:+.4f}; program-rank and program-weighted reversal are "
            f"{disposition['apc_program_rank_reversal']:+.4f} and {disposition['apc_program_weighted_reversal']:+.4f}. "
            "The chart uses a shared signed-correlation scale: bars right of zero support reversal, while bars left of zero oppose it. "
            "The negative program components dominate the equal-weight composite, so a genome-only positive reading would be incomplete."
        ), "layout": "full"},
        {"id": "score_chart_block", "type": "chart", "chartId": "score_chart", "layout": "full"},
        {"id": "data_scope", "type": "markdown", "sourceId": "qc_source", "body": (
            "## The Dataset Is Direct but Has High Replicate-Metadata Ambiguity\n\n"
            "GSE201278 directly treats SK-MEL-2 skin melanoma cells with JNJ-7706621 at 1.75 uM for 48 h. GEO/SRA registers one raw run per arm, while the provider FPKM file contains two processed columns per arm without a documented raw-run mapping. "
            f"The file covers all {disposition['apc_genes']:,} frozen APC genes and all {disposition['apc_program_genes']:,} program genes, with no missing or negative FPKM values. "
            "The processed columns are therefore useful for sensitivity checks but cannot be counted as independent biological replicates."
        ), "layout": "full"},
        {"id": "robustness_intro", "type": "markdown", "sourceId": "score_source", "body": (
            "## Robustness Audits Do Not Rescue the Primary Result\n\n"
            "Four prespecified expression transformations and all four processed-column cross-comparisons were retained. At least one result in each audit family is non-positive, so neither transformation robustness nor column-pair robustness passes. "
            "Exact values are shown below; these are sensitivity diagnostics, not independent-sample estimates."
        ), "layout": "full"},
        {"id": "robustness_table_block", "type": "table", "tableId": "robustness_table", "layout": "full"},
        {"id": "methodology", "type": "markdown", "sourceId": "score_source", "body": (
            "## Frozen Method and Decision Rule\n\n"
            "The primary contrast is the difference between arm means of log2(FPKM+1), collapsed by median for duplicate gene symbols and restricted to the same 12,327-gene LINCS universe. "
            "The four reversal correlations, independent external statistic, toxicity axes, toxicity-gene removal, four transformation sensitivities, four processed-column comparisons and 10,000 seeded gene-label permutations were frozen before score inspection. "
            "A non-positive primary composite deterministically maps to `independent_skin_line_not_supported`."
        ), "layout": "full"},
        {"id": "limitations", "type": "markdown", "sourceId": "qc_source", "body": (
            "## Limitations and Claim Boundary\n\n"
            "This is one skin-derived melanoma cell line, not normal keratinocytes or diseased skin. Only one raw SRA run is registered per arm, and the extra processed columns have undocumented provenance. FPKM is provider processed, and the analysis cannot estimate treatment-level biological variance. "
            "The alignment fraction is not a treatment-effect P value or FDR. The result does not establish efficacy, safety, target causality or CDK2 specificity and does not change Gate 3."
        ), "layout": "full"},
        {"id": "next_steps", "type": "markdown", "body": (
            "## Recommended Next Step\n\n"
            "Do not relax the score rule. The remaining clean data-only route is a truly replicated JNJ perturbation in normal human keratinocytes/skin, if one becomes publicly available, or a checksum-pinned recovery of the original 2021 LINCS object strictly as version sensitivity. Until then, retain JNJ as `positive_not_top5` in heterogeneous LINCS and `independent_skin_line_not_supported` in GSE201278."
        ), "layout": "full"},
        {"id": "further_questions", "type": "markdown", "body": (
            "## Further Questions\n\n"
            "Can the two processed columns per arm be mapped to undocumented biological libraries? Would a normal-keratinocyte contrast preserve the positive genome-wide direction without reversing the locked program? Is the negative 48-h program direction caused by melanoma context, dose, duration, or an AUF1-linked inflammatory response?"
        ), "layout": "full"},
    ],
    "cards": [
        {"id": "label_card", "dataset": "summary", "sourceId": "score_source", "description": "Frozen independent directional disposition.", "metrics": [{"label": "Disposition", "field": "frozen_label"}]},
        {"id": "apc_card", "dataset": "summary", "sourceId": "score_source", "description": "Equal-weight mean of the four frozen APC reversal scores.", "metrics": [{"label": "APC composite", "field": "apc_composite", "format": "number"}]},
        {"id": "external_card", "dataset": "summary", "sourceId": "score_source", "description": "Reversal against the independent E-MTAB-9501 disease statistic.", "metrics": [{"label": "External composite", "field": "external_composite", "format": "number"}]},
        {"id": "alignment_card", "dataset": "summary", "sourceId": "score_source", "description": "Gene-label alignment diagnostic; not a treatment-effect P value.", "metrics": [{"label": "Alignment fraction", "field": "alignment_fraction", "format": "percent"}]},
    ],
    "charts": [{
        "id": "score_chart",
        "title": "JNJ reversal scores across independent and prior evidence",
        "subtitle": "Signed correlations; positive values support reversal and negative values oppose it.",
        "type": "bar",
        "options": {"orientation": "horizontal", "grouping": "grouped"},
        "intent": "comparison",
        "question": "Which frozen score components support or oppose JNJ direction in GSE201278?",
        "rationale": "A signed horizontal bar comparison makes the genome/program split and zero boundary visible with readable labels.",
        "dataset": "score_chart",
        "sourceId": "score_source",
        "encodings": {
            "x": {"field": "score", "type": "nominal", "label": "Score"},
            "y": {"field": "reversal", "type": "quantitative", "label": "Reversal correlation", "format": "number"},
            "color": {"field": "evidence_family", "type": "nominal", "label": "Evidence family"},
            "tooltip": [{"field": "scope", "type": "nominal", "label": "Scope"}],
        },
        "comparisonContext": {"zero": "no directional alignment", "positive": "disease-signature reversal", "negative": "same-direction or program opposition"},
        "combinationRationale": "Color separates GSE201278 APC, its external-statistic check, and prior LINCS context; axis labels provide non-color identification.",
        "maxRows": 7,
        "layout": "full",
    }],
    "tables": [{
        "id": "robustness_table",
        "title": "Prespecified transformation and processed-column audits",
        "subtitle": "All eight sensitivity results; processed-column rows are not independent biological replicates.",
        "dataset": "robustness",
        "sourceId": "score_source",
        "layout": "full",
        "density": "spacious",
        "defaultSort": {"field": "apc_composite_reversal", "direction": "desc"},
        "columns": [
            {"field": "audit", "label": "Audit", "type": "text"},
            {"field": "audit_type", "label": "Type", "type": "text"},
            {"field": "apc_composite_reversal", "label": "APC composite", "type": "number"},
            {"field": "positive", "label": "Positive", "type": "text"},
        ],
    }],
}

snapshot = {
    "version": 1,
    "generatedAt": generated_at,
    "status": "ready",
    "datasets": {"summary": summary_rows, "score_chart": chart_rows, "robustness": robustness_rows},
}
artifact = {"surface": "report", "manifest": manifest, "snapshot": snapshot, "sources": sources}
ARTIFACT.write_text(json.dumps(artifact, indent=2, allow_nan=False) + "\n")

nb = nbformat.v4.new_notebook(cells=[
    nbformat.v4.new_markdown_cell(
        "# JNJ-7706621 independent SK-MEL-2 direction check\n\n"
        "Reproducible audit of GSE201278 source quality, frozen scores, robustness and disposition."
    ),
    nbformat.v4.new_code_cell(
        "from pathlib import Path\nimport json\nimport numpy as np\nimport pandas as pd\n"
        "ROOT = Path('/Volumes/brilliant/flg_skin_barrier_spectrum')\n"
        "OUT = ROOT / 'results/exploratory_snf/selected_positive_reml_z_q05/optimized_AD_ACD_branch/mechanism/gse201278_jnj_skin_line_validation'\n"
        "disposition = json.loads((OUT / 'GSE201278_JNJ_DISPOSITION.json').read_text())\n"
        "source_qc = json.loads((OUT / 'SOURCE_AND_SCHEMA_QC.json').read_text())\n"
        "score = pd.read_csv(OUT / 'frozen_score_panel.tsv', sep='\\t')\n"
        "sensitivity = pd.read_csv(OUT / 'transformation_sensitivity.tsv', sep='\\t')\n"
        "pairwise = pd.read_csv(OUT / 'processed_column_pairwise_audit.tsv', sep='\\t')\n"
        "disposition['frozen_label'], score.shape, sensitivity.shape, pairwise.shape"
    ),
    nbformat.v4.new_code_cell(
        "pd.DataFrame([{k: disposition[k] for k in ['apc_genome_rank_reversal','apc_genome_weighted_reversal','apc_program_rank_reversal','apc_program_weighted_reversal','apc_composite_reversal','external_composite_reversal','gene_label_alignment_fraction']}]).T.rename(columns={0:'value'})"
    ),
    nbformat.v4.new_code_cell(
        "assert disposition['apc_composite_reversal'] < 0\n"
        "assert disposition['frozen_label'] == 'independent_skin_line_not_supported'\n"
        "assert disposition['formal_replication'] is False\n"
        "assert source_qc['metadata_ambiguity_severity'] == 'high'\n"
        "pd.concat([sensitivity[['analysis','apc_composite_reversal']].rename(columns={'analysis':'audit'}), pairwise.assign(audit=lambda x: x.jnj_column + ' vs ' + x.control_column)[['audit','apc_composite_reversal']]], ignore_index=True)"
    ),
    nbformat.v4.new_code_cell(
        "validation = json.loads((OUT / 'VALIDATION_SUMMARY.json').read_text())\n"
        "assert validation['status'] == 'pass'\nvalidation['checks_passed']"
    ),
])
nb.metadata.kernelspec = {"display_name": "Python 3", "language": "python", "name": "python3"}
nb.metadata.language_info = {"name": "python", "version": "3"}
executed = NotebookClient(nb, timeout=120, kernel_name="python3").execute(cwd=str(ROOT))
NOTEBOOK.write_text(nbformat.writes(executed))

print(json.dumps({
    "artifact": str(ARTIFACT),
    "notebook": str(NOTEBOOK),
    "datasets": {key: len(value) for key, value in snapshot["datasets"].items()},
    "validation_checks": validation["checks_passed"],
}, indent=2))
