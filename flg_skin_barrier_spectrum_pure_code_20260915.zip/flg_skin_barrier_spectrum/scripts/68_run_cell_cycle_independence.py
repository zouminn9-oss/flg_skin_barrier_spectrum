#!/usr/bin/env python3
"""
Cell-cycle-independence analysis for the AD-ACD replication-surveillance program.

Question addressed
------------------
The driver-pathway program contains both DNA-repair pathways and pathways that
also index replication / cell-cycle progression. This script tests whether the
compartment-resolved result in GSE267929 (allergy-high in APCs, irritant-high in
keratinocytes) is carried by the repair-specific part of the program, or is a
restatement of proliferation differences between the two challenges.

Design
------
1. Reproduce the published compartment scores over the fixed top-20 driver set.
2. Partition the driver set by mitotic gene content: a driver pathway is
   'repair-specific' when its overlap with Reactome 'Cell Cycle, Mitotic' is
   below MITOTIC_OVERLAP_MAX; otherwise 'replication-coupled'.
3. Recompute the compartment score in each partition, with the same
   size-decile-matched pathway permutation used for the primary analysis.
4. Score an independent proliferation reference (Reactome 'Cell Cycle, Mitotic'
   pathway members, and a curated mitotic marker gene set) in each compartment,
   as a comparator with the same machinery.

No thresholds from the primary analysis are changed; nothing here is used to
select the program, which stays fixed at the published top-20 pathways.
"""
import csv, json, math, os, random
from collections import defaultdict

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
GMT = os.path.join(ROOT, "data/raw/pathways/reactome_v97/ReactomePathways.gmt")
DRIVERS = os.path.join(ROOT, "results/exploratory_snf/selected_positive_reml_z_q05",
                      "optimized_AD_ACD_branch/mechanism/top_AD_ACD_pathway_drivers.tsv")
SC = os.path.join(ROOT, "results/tables/single_cell_validation")
OUT = os.path.join(ROOT, "results/exploratory_snf/selected_positive_reml_z_q05",
                   "optimized_AD_ACD_branch/mechanism/cell_cycle_independence")
os.makedirs(OUT, exist_ok=True)

SEED = 20260909
N_PERM = 10000
MITOTIC_OVERLAP_MAX = 0.05
COMPARTMENTS = {"APC": "APC", "KRT": "KRT", "LYMPH": "LYMPH", "all_cells": "all cells"}
MITOTIC_MARKERS = ["MKI67","TOP2A","CCNB1","CCNB2","CCNA2","CDK1","AURKA","AURKB",
                   "PLK1","BUB1","BUB1B","BIRC5","UBE2C","CENPF","NUSAP1","TPX2",
                   "KIF11","KIF23","ASPM","PTTG1"]

def read_gmt(path):
    sets = {}
    with open(path) as fh:
        for line in fh:
            f = line.rstrip("\n").split("\t")
            if len(f) > 2:
                sets[f[0]] = set(g for g in f[2:] if g)
    return sets

def signed_z(direction, pvalue):
    """Two-sided p and direction -> signed z, matching the primary analysis."""
    p = max(float(pvalue), 1e-300)
    p = min(p, 1.0)
    z = abs(norm_isf(p / 2.0))
    return z if str(direction).strip().lower().startswith("up") else -z

def norm_isf(p):
    """Inverse survival function of the standard normal (Acklam, refined once)."""
    if p <= 0: return float("inf")
    if p >= 1: return float("-inf")
    q = 1.0 - p
    a = [-3.969683028665376e+01, 2.209460984245205e+02, -2.759285104469687e+02,
         1.383577518672690e+02, -3.066479806614716e+01, 2.506628277459239e+00]
    b = [-5.447609879822406e+01, 1.615858368580409e+02, -1.556989798598866e+02,
         6.680131188771972e+01, -1.328068155288572e+01]
    c = [-7.784894002430293e-03, -3.223964580411365e-01, -2.400758277161838e+00,
         -2.549732539343734e+00, 4.374664141464968e+00, 2.938163982698783e+00]
    d = [7.784695709041462e-03, 3.224671290700398e-01, 2.445134137142996e+00,
         3.754408661907416e+00]
    pl, ph = 0.02425, 1 - 0.02425
    if q < pl:
        r = math.sqrt(-2 * math.log(q))
        x = (((((c[0]*r+c[1])*r+c[2])*r+c[3])*r+c[4])*r+c[5]) / ((((d[0]*r+d[1])*r+d[2])*r+d[3])*r+1)
    elif q <= ph:
        r = q - 0.5; s = r * r
        x = (((((a[0]*s+a[1])*s+a[2])*s+a[3])*s+a[4])*s+a[5])*r / (((((b[0]*s+b[1])*s+b[2])*s+b[3])*s+b[4])*s+1)
    else:
        r = math.sqrt(-2 * math.log(1 - q))
        x = -(((((c[0]*r+c[1])*r+c[2])*r+c[3])*r+c[4])*r+c[5]) / ((((d[0]*r+d[1])*r+d[2])*r+d[3])*r+1)
    e = 0.5 * math.erfc(-x / math.sqrt(2)) - q
    u = e * math.sqrt(2 * math.pi) * math.exp(x * x / 2)
    x = x - u / (1 + x * u / 2)
    return x

def read_tsv(path):
    with open(path) as fh:
        return list(csv.DictReader(fh, delimiter="\t"))

def decile_bins(sizes):
    order = sorted(sizes)
    n = len(order)
    cuts = [order[min(int(round(q * n / 10.0)), n - 1)] for q in range(1, 10)]
    def which(s):
        i = 0
        while i < len(cuts) and s > cuts[i]:
            i += 1
        return i
    return which

def permute_score(pool, target_sizes, which_bin, n_perm, rng):
    by_bin = defaultdict(list)
    for name, (z, size) in pool.items():
        by_bin[which_bin(size)].append(z)
    need = defaultdict(int)
    for s in target_sizes:
        need[which_bin(s)] += 1
    null = []
    for _ in range(n_perm):
        vals = []
        for b, k in need.items():
            src = by_bin.get(b) or [z for zs in by_bin.values() for z in zs]
            vals.extend(rng.sample(src, k) if k <= len(src) else [rng.choice(src) for _ in range(k)])
        null.append(sum(vals) / len(vals))
    return null

def main():
    rng = random.Random(SEED)
    gmt = read_gmt(GMT)
    # Mitosis-specific reference: M-phase members that are not part of the
    # replication or repair machinery the program itself is built from.
    mitotic = gmt.get("M Phase", set()) - gmt.get("Synthesis of DNA", set()) - gmt.get("DNA Repair", set())
    drivers = [r["pathway"] for r in read_tsv(DRIVERS)][:20]

    # ---- partition drivers by mitotic gene content -------------------------
    partition, overlap_tbl = {}, []
    for pw in drivers:
        genes = gmt.get(pw, set())
        ov = len(genes & mitotic) / len(genes) if genes else 0.0
        cls = "repair_specific" if ov < MITOTIC_OVERLAP_MAX else "mitosis_coupled"
        partition[pw] = cls
        overlap_tbl.append({"pathway": pw, "n_genes": len(genes),
                            "n_mitotic": len(genes & mitotic),
                            "mitotic_fraction": round(ov, 3), "partition": cls})

    with open(os.path.join(OUT, "driver_mitotic_partition.tsv"), "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=list(overlap_tbl[0].keys()), delimiter="\t")
        w.writeheader(); w.writerows(overlap_tbl)

    # ---- compartment scores ------------------------------------------------
    results = []
    for comp in COMPARTMENTS:
        path = os.path.join(SC, f"GSE267929_{comp}_reactome.tsv")
        rows = read_tsv(path)
        pool = {r["pathway"]: (signed_z(r["Direction"], r["PValue"]), int(r["NGenes"]))
                for r in rows if r["pathway"] and r["PValue"]}
        which_bin = decile_bins([s for _, s in pool.values()])

        sets = {
            "driver_full":            [p for p in drivers if p in pool],
            "driver_mitosis_depleted": [p for p in drivers if p in pool and partition[p] == "repair_specific"],
            "mitotic_reference":      [p for p in pool if p in gmt and gmt[p] and
                                       len(gmt[p] & mitotic) / len(gmt[p]) >= 0.50 and p not in drivers],
        }
        for label, members in sets.items():
            if not members:
                continue
            zs = [pool[p][0] for p in members]
            score = sum(zs) / len(zs)
            null = permute_score(pool, [pool[p][1] for p in members], which_bin, N_PERM, rng)
            if score >= 0:
                pv = (1 + sum(1 for x in null if x >= score)) / (N_PERM + 1)
            else:
                pv = (1 + sum(1 for x in null if x <= score)) / (N_PERM + 1)
            results.append({
                "compartment": comp, "pathway_set": label,
                "n_pathways": len(members),
                "n_up_in_allergy": sum(1 for z in zs if z > 0),
                "score": round(score, 3), "permutation_P": round(pv, 4),
            })

    # BH within compartment across the driver partitions
    for comp in COMPARTMENTS:
        block = [r for r in results if r["compartment"] == comp and r["pathway_set"].startswith("driver")]
        block.sort(key=lambda r: r["permutation_P"])
        m = len(block); prev = 1.0
        for i in range(m - 1, -1, -1):
            q = min(prev, block[i]["permutation_P"] * m / (i + 1))
            block[i]["q_within_compartment"] = round(q, 4); prev = q
    for r in results:
        r.setdefault("q_within_compartment", "")

    with open(os.path.join(OUT, "compartment_partition_scores.tsv"), "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=list(results[0].keys()), delimiter="\t")
        w.writeheader(); w.writerows(results)

    # ---- gene-level mitotic marker comparator ------------------------------
    gene_rows = []
    for comp in ("APC", "KRT"):
        rows = read_tsv(os.path.join(SC, f"GSE267929_{comp}_gene_effects.tsv"))
        stats = {}
        for r in rows:
            try:
                lfc = float(r["logFC"]); pv = float(r["PValue"]); cpm = float(r["logCPM"])
            except (ValueError, KeyError):
                continue
            stats[r["gene_symbol"]] = (signed_z("Up" if lfc > 0 else "Down", pv), cpm)
        present = [g for g in MITOTIC_MARKERS if g in stats]
        if not present:
            gene_rows.append({"compartment": comp, "gene_set": "mitotic_markers",
                              "n_genes_measured": 0, "n_up_in_allergy": 0,
                              "score": "", "permutation_P": "", "genes": ""})
            continue
        zs = [stats[g][0] for g in present]
        score = sum(zs) / len(zs)
        which_bin = decile_bins([c for _, c in stats.values()])
        pool = {g: (z, c) for g, (z, c) in stats.items()}
        null = permute_score(pool, [stats[g][1] for g in present], which_bin, N_PERM, rng)
        pv = ((1 + sum(1 for x in null if x >= score)) if score >= 0
              else (1 + sum(1 for x in null if x <= score))) / (N_PERM + 1)
        gene_rows.append({"compartment": comp, "gene_set": "mitotic_markers",
                          "n_genes_measured": len(present),
                          "n_up_in_allergy": sum(1 for z in zs if z > 0),
                          "score": round(score, 3), "permutation_P": round(pv, 4),
                          "genes": ";".join(present)})
    with open(os.path.join(OUT, "mitotic_marker_gene_scores.tsv"), "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=list(gene_rows[0].keys()), delimiter="\t")
        w.writeheader(); w.writerows(gene_rows)

    json.dump({"seed": SEED, "n_permutations": N_PERM,
               "mitotic_overlap_max": MITOTIC_OVERLAP_MAX,
               "reactome_release": "v97", "drivers": drivers,
               "partition": partition},
              open(os.path.join(OUT, "RUN_PARAMETERS.json"), "w"), indent=2)

    for r in results: print(r)
    print()
    for r in gene_rows: print({k: v for k, v in r.items() if k != "genes"})

if __name__ == "__main__":
    main()
