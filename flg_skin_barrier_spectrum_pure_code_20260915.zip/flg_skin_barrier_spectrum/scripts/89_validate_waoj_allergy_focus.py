#!/usr/bin/env python3
"""Bounded checks for the contact-allergy revision; no pipeline rerun."""
from pathlib import Path
import csv, hashlib, json, re, shutil, zipfile
from collections import Counter
from docx import Document
from PIL import Image

ROOT=Path(__file__).resolve().parents[1]
OLD=ROOT/'submission/WAOJ_Submission_20260913'
PACK=ROOT/'submission/WAOJ_Submission_20260914_AllergyFocus'
UP=PACK/'01_submission_files'; REV=PACK/'02_author_review'; EDIT=PACK/'03_editable_sources'
checks=[]
def check(label, passed):
    assert passed,label
    checks.append(label)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def rows(p):
    with p.open() as f:return list(csv.DictReader(f,delimiter='\t'))
def bh(vals):
    order=sorted(range(len(vals)),key=lambda i:vals[i]); out=[0.0]*len(vals); v=1.0
    for j in range(len(vals)-1,-1,-1):
        i=order[j];v=min(v,vals[i]*len(vals)/(j+1));out[i]=v
    return out
def references(md):return dict((int(n),s) for n,s in re.findall(r'^(\d+)\. (.*)$',md.split('## References\n')[1].split('## Table\n')[0],re.M))

metrics=json.loads((REV/'BUILD_METRICS.json').read_text())
prior=OLD/'03_editable_sources/waoj_manuscript.md'
check('9月13日 WAOJ 源稿未改动',sha(prior)==metrics['previous_manuscript_sha256']=='4c9042249505d789fbbab20a0fb60ecd6eb54c86e495a91e22466352532ab754')
check('原 IJMS 源稿未改动',sha(ROOT/'paper_rewriting_output/ijms_submission/manuscript/ijms_manuscript.md')=='d7c5ff8506fb8c29691bf726d0ddffba63f06c8c72f3ef4481d9f37eb01bb45a')
check('9月13日完整 ZIP 未改动',sha(OLD.with_suffix('.zip'))=='f340bbcf516fda8c19c3628658f43a32984a834208058de7da5a52c5660e41c4')
oldmanifest=rows(OLD/'02_author_review/FILE_MANIFEST.tsv')
check('旧包清单内全部文件仍与已交付哈希一致',all(sha(OLD/r['path'])==r['sha256'] for r in oldmanifest))
md=(EDIT/'waoj_manuscript.md').read_text(); oldmd=prior.read_text()
refmap={int(k):v for k,v in metrics['reference_map_from_20260913'].items()}
check('41条文献内容逐条保留，仅重排编号',len(references(md))==41 and all(references(md)[v]==references(oldmd)[k] for k,v in refmap.items()))
seen=[]
for group in re.findall(r'\[([\d, ]+)\]',md.split('## Introduction\n')[1].split('## Abbreviations\n')[0]):
    for n in map(int,group.replace(' ','').split(',')):
        if n not in seen:seen.append(n)
check('正文引用首次出现顺序为1至41',seen==list(range(1,42)))
results=md.split('## Results\n')[1].split('## Discussion\n')[0]
check('主图在结果中首次出现顺序为1至6',list(dict.fromkeys(re.findall(r'Figure ([1-6])',results)))==list('123456'))
check('核心配对比较为结果第二节',re.findall(r'^### (.*)',results,re.M)[1]=='Allergic and irritant challenges produce opposite APC and keratinocyte responses')
check('主图图注为1至6且图2为细胞比较',re.findall(r'^\*\*Figure (\d)\.\*\*',md,re.M)==list('123456') and '**Figure 2.** The fixed pathway program has opposite APC' in md)
check('最终字数266/4969已同步',metrics['abstract_words']==266 and metrics['main_text_words']==4969 and 'Abstract: 266 words. Main text: 4969 words' in (EDIT/'title_page.md').read_text())
docs=sorted(p for p in UP.glob('*.docx') if not p.name.startswith('.'))
check('5个提交用DOCX齐全',len(docs)==5)
for p in docs:
    with zipfile.ZipFile(p) as z:
        check(p.name+'容器完整',z.testzip() is None)
        xml='\n'.join(z.read(n).decode() for n in z.namelist() if n.endswith('.xml'))
        check(p.name+'无旧期刊抬头',not any(s in xml for s in ['IJMS','International Journal of Molecular Sciences']))
        if p.name in ['waoj_manuscript_blinded.docx','supplementary_information.docx']:
            check(p.name+'未检出作者姓名邮箱',not any(s in xml for s in ['Yue-Min Zou','Si-Ran Bao','Yi-Ming Qi','Jie Ma','majiexyyy@126.com']))
            check(p.name+'无修订或实际批注',not re.search(r'<w:(ins|del|comment)\b',xml))
oldtab=Document(OLD/'01_submission_files/waoj_manuscript_blinded.docx').tables[0]
newtab=Document(UP/'waoj_manuscript_blinded.docx').tables[0]
check('主表仅调整行序，所有单元格内容保留',Counter(tuple(c.text for c in r.cells) for r in oldtab.rows)==Counter(tuple(c.text for c in r.cells) for r in newtab.rows))
a=Document(OLD/'01_submission_files/supplementary_information.docx');b=Document(UP/'supplementary_information.docx')
check('补充材料保留16个表格及2幅嵌图',len(a.tables)==len(b.tables)==16 and len(a.inline_shapes)==len(b.inline_shapes)==2)
changed=[]
for ti,(ta,tb) in enumerate(zip(a.tables,b.tables)):
    check(f'补充表对象{ti+1}行列数不变',len(ta.rows)==len(tb.rows) and len(ta.columns)==len(tb.columns))
    for ra,rb in zip(ta.rows,tb.rows):
        for ca,cb in zip(ra.cells,rb.cells):
            if ca.text!=cb.text:changed.append((ca.text,cb.text))
check('补充表数值未变，仅更新主稿路径',len(changed)==1 and changed[0][0].replace('WAOJ_Submission_20260913','WAOJ_Submission_20260914_AllergyFocus')==changed[0][1])
with zipfile.ZipFile(OLD/'01_submission_files/supplementary_information.docx') as za,zipfile.ZipFile(UP/'supplementary_information.docx') as zb:
    check('补充嵌图原始字节保留',all(za.read(n)==zb.read(n) for n in za.namelist() if n.startswith('word/media/')))
figmap={str(k):str(v) for k,v in metrics['figure_map_from_20260913'].items()};figmap.update({'S1':'S1','S2':'S2'})
check('8个TIFF齐全',len([p for p in UP.glob('*.tif') if not p.name.startswith('.')])==8)
figlines=['previous_file\tcurrent_file\twidth_px\theight_px\tdpi\tsha256']
for k,v in figmap.items():
    p=UP/f'figure{v}.tif'
    check(f'图{k}至图{v}仅更名未改图像',sha(p)==sha(OLD/f'01_submission_files/figure{k}.tif'))
    with Image.open(p) as im:
        check(f'图{v}可读且至少300dpi',min(im.info.get('dpi',(0,0)))>=300)
        figlines.append(f'figure{k}.tif\t{p.name}\t{im.width}\t{im.height}\t{im.info["dpi"]}\t{sha(p)}')

loc=ROOT/'results/exploratory_snf/selected_positive_reml_z_q05/optimized_AD_ACD_branch/mechanism/single_cell_localization'
cell=rows(loc/'celltype_program_scores.tsv'); bycell={r['celltype']:r for r in cell}
for prefix in ['driver_pathway','core_gene']:
    ps=[float(r[prefix+'_empirical_p_two_sided']) for r in cell]
    check(prefix+'双侧P为较小尾概率的两倍',all(abs(ps[i]-min(1,2*min(float(r[prefix+'_empirical_p_up']),float(r[prefix+'_empirical_p_down']))))<1e-12 for i,r in enumerate(cell)))
    check(prefix+'四组BH校正重算一致',all(abs(q-float(r[prefix+'_q_BH_4celltypes']))<1e-12 for q,r in zip(bh(ps),cell)))
effects=rows(loc/'driver_pathway_single_cell_effects.tsv')
for ct,total,positive,negative,q in [('APC',19,17,2,.044),('KRT',16,2,14,.009)]:
    rr=[r for r in effects if r['celltype']==ct]
    check(ct+'方向计数及q值与摘要一致',len(rr)==total and sum(float(r['signed_z'])>0 for r in rr)==positive and sum(float(r['signed_z'])<0 for r in rr)==negative and round(float(bycell[ct]['driver_pathway_q_BH_4celltypes']),3)==q)
    check(ct+'直接核心基因评分阴性且为五供者',round(float(bycell[ct]['core_gene_q_BH_4celltypes']),3)==.895 and int(bycell[ct]['paired_donors'])==5)
loo=rows(loc/'driver_pathway_leave_one_out.tsv')
check('全部APC/KRT通路逐一删除保持方向',all(r['same_direction_as_full_score']=='True' for r in loo if r['celltype'] in ['APC','KRT']))
ex=ROOT/'results/external_validation/GSE328048/analysis'
r=rows(ex/'primary_LAD_vs_HC_biopsy.tsv')[0]
check('外部AD样本量及AUC和置信区间一致',r['n_x']=='54' and r['n_y']=='23' and tuple(round(float(r[k]),3) for k in ['auc','auc_ci_low','auc_ci_high'])==(.827,.721,.913))
adj=rows(ex/'title_cluster_proliferation_adjusted.tsv')[0]
check('增殖调整后P为0.904并保留于正文',adj['term']=='LAD' and round(float(adj['p_two_sided']),3)==.904 and 'P = 0.904' in md)
check('未声称正式交互检验或临床鉴别验证',all(s in md for s in ['not themselves a formal condition-by-compartment interaction test','does not validate clinical discrimination between ACD and ICD','does not demonstrate statistical cancellation']))

qa=Path('/private/tmp')
check('主稿30页及作者页2页渲染齐全',len(list((qa/'waoj_20260914_releaseqa/waoj_manuscript_blinded').glob('page-*.png')))==30 and len(list((qa/'waoj_20260914_releaseqa/title_page').glob('page-*.png')))==2)
check('作者页第二页与已检查版本像素一致',sha(qa/'waoj_20260914_releaseqa/title_page/page-2.png')==sha(qa/'waoj_20260914_qa/title_page/page-2.png'))
check('补充材料除第1和5页外与已审阅9月13日版本像素一致',all(sha(qa/f'waoj_20260914_finalqa/supplementary_information/page-{n}.png')==sha(qa/f'waoj_20260913_releaseqa/supplementary_information/page-{n}.png') for n in range(1,17) if n not in [1,5]))
(REV/'FIGURE_MANIFEST.tsv').write_text('\n'.join(figlines)+'\n')
(REV/'VERIFICATION_REPORT.md').write_text(f'''# 变态反应主线版有限范围核查

日期：2026-09-14。摘要266词，正文4969词，41条文献，6幅主图及2幅补图。

本次为叙事重构、文档完整性、引用映射和关键数值交叉核对，不是全分析复现或41篇参考文献的重新全文审计。未新增实验或在线投稿。

## 通过的程序检查

'''+ '\n'.join('- '+s for s in checks)+'''

## 排版复核

主稿30页全部渲染并逐页查看。作者页2页、投稿信1页、Highlights 1页均已检查。补充材料16页中变更的第1和5页重新查看，其余14页与此前已审阅版本逐像素一致。未见遮挡、裁切或缺失嵌图。源图仅更名，未编辑像素。

## 证据来源和范围

单细胞数值来源：results/exploratory_snf/selected_positive_reml_z_q05/optimized_AD_ACD_branch/mechanism/single_cell_localization/ 内 celltype_program_scores.tsv、driver_pathway_single_cell_effects.tsv、driver_pathway_leave_one_out.tsv。

外部AD来源：results/external_validation/GSE328048/analysis/ 内 primary_LAD_vs_HC_biopsy.tsv、title_cluster_proliferation_adjusted.tsv。

## 提交前仍需确认

沿用9月13日指南访问受限记录，本次字数及文件配置不是官方2026年现行格式认证。实际投稿系统的文章类型、文件要求及声明仍须核对。作者信息、全体作者批准、伦理适用性、资金与利益冲突、AI使用范围及远程代码完整性须由作者确认。作者已告知IJMS拒稿，但本次未见拒稿信，不声称逐条回应审稿意见。未提交、付款、签名或推送远程代码。
''')
shutil.copy2(Path(__file__),EDIT/Path(__file__).name)
manifest=REV/'FILE_MANIFEST.tsv'
files=sorted(p for p in PACK.rglob('*') if p.is_file() and not any(s.startswith('.') for s in p.relative_to(PACK).parts) and p!=manifest)
manifest.write_text('path\tbytes\tsha256\n'+'\n'.join(f'{p.relative_to(PACK)}\t{p.stat().st_size}\t{sha(p)}' for p in files)+'\n')
archive=PACK.with_suffix('.zip')
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in files+[manifest]:z.write(p,Path(PACK.name)/p.relative_to(PACK))
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
print(json.dumps({'checks_passed':len(checks),'archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive)},indent=2))
