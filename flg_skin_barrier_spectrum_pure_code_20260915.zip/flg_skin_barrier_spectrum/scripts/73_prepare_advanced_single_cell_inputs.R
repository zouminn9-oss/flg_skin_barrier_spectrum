#!/usr/bin/env Rscript

# Freeze interoperable count/metadata bundles for trajectory, communication,
# metabolism and imputed-modality analyses.  No normalization or feature
# selection is performed here; each downstream tool receives the same raw UMI
# counts and audited metadata.

suppressPackageStartupMessages(library(Matrix))

root <- normalizePath(getwd())
raw <- file.path(root, "data", "raw")
sc_raw <- file.path(raw, "expression", "geo", "GSE267929")
meta_path <- file.path(raw, "geo", "GSE267929", "GSE267929_meta.data.tsv.gz")
out <- file.path(root, "data", "processed", "advanced_single_cell_inputs")
dir.create(out, recursive = TRUE, showWarnings = FALSE)

seed <- 20260910L
common_donors <- c("P1", "P2", "P3", "P4", "P8")
paired_conditions <- c("Day4_Allergy", "Irritant")
communication_celltypes <- c("APC", "KRT", "LYMPH")
balanced_cap <- 200L
balanced_minimum <- 10L

counts <- readMM(gzfile(file.path(sc_raw, "GSE267929_matrix.mtx.gz")))
genes <- read.delim(
  gzfile(file.path(sc_raw, "GSE267929_genes.tsv.gz")), header = FALSE,
  stringsAsFactors = FALSE
)
barcodes <- readLines(gzfile(file.path(sc_raw, "GSE267929_barcodes.tsv.gz")))
meta <- read.table(
  gzfile(meta_path), header = TRUE, row.names = 1, check.names = FALSE,
  stringsAsFactors = FALSE
)
stopifnot(nrow(counts) == nrow(genes), ncol(counts) == length(barcodes))
stopifnot(identical(barcodes, rownames(meta)))
rownames(counts) <- make.unique(genes[[2]])
colnames(counts) <- barcodes

metadata_columns <- c(
  "Patient", "Disease", "Lesion", "Basic_Celltype", "Detailed_Celltype",
  "Semi_Detailed_Celltype", "nCount_RNA", "nFeature_RNA", "sex",
  "Lesion_severity_score", "DE_inclusion_factor"
)

write_bundle <- function(name, selected) {
  selected <- which(selected)
  bundle <- file.path(out, name)
  dir.create(bundle, recursive = TRUE, showWarnings = FALSE)
  matrix_path <- file.path(bundle, "counts_genes_by_cells.mtx")
  genes_path <- file.path(bundle, "genes.tsv")
  barcodes_path <- file.path(bundle, "barcodes.tsv")
  metadata_path <- file.path(bundle, "metadata.tsv")

  writeMM(counts[, selected, drop = FALSE], matrix_path)
  write.table(
    data.frame(gene_symbol = rownames(counts), stringsAsFactors = FALSE),
    genes_path, sep = "\t", quote = FALSE, row.names = FALSE
  )
  write.table(
    data.frame(barcode = colnames(counts)[selected], stringsAsFactors = FALSE),
    barcodes_path, sep = "\t", quote = FALSE, row.names = FALSE
  )
  md <- meta[colnames(counts)[selected], metadata_columns, drop = FALSE]
  md$barcode <- rownames(md)
  md <- md[, c("barcode", metadata_columns), drop = FALSE]
  write.table(md, metadata_path, sep = "\t", quote = FALSE, row.names = FALSE, na = "NA")

  checksums <- tools::md5sum(c(matrix_path, genes_path, barcodes_path, metadata_path))
  write.table(
    data.frame(file = basename(names(checksums)), md5 = unname(checksums)),
    file.path(bundle, "MD5SUMS.tsv"), sep = "\t", quote = FALSE, row.names = FALSE
  )
  cell_counts <- as.data.frame(xtabs(~ Patient + Lesion + Basic_Celltype, data = md))
  names(cell_counts)[4] <- "cells"
  write.table(
    cell_counts, file.path(bundle, "cell_counts.tsv"), sep = "\t",
    quote = FALSE, row.names = FALSE
  )
  data.frame(
    bundle = name, genes = nrow(counts), cells = length(selected),
    donors = length(unique(md$Patient)), conditions = paste(sort(unique(md$Lesion)), collapse = ";"),
    basic_celltypes = paste(sort(unique(md$Basic_Celltype)), collapse = ";"),
    stringsAsFactors = FALSE
  )
}

summaries <- list()

paired_full <- meta$Patient %in% common_donors &
  meta$Lesion %in% paired_conditions &
  meta$Basic_Celltype %in% communication_celltypes
summaries[["paired_full"]] <- write_bundle("paired_day4_irritant_full", paired_full)

# Equalize allergy and irritant cell counts within every donor/cell-type pair.
# The same number is sampled from each condition and is capped at 200 to prevent
# the very large P3 allergy sample from dominating expression-based networks.
set.seed(seed)
balanced_barcodes <- character()
balance_rows <- list()
for (donor in common_donors) {
  for (celltype in communication_celltypes) {
    pools <- lapply(paired_conditions, function(condition) {
      rownames(meta)[
        meta$Patient == donor & meta$Lesion == condition & meta$Basic_Celltype == celltype
      ]
    })
    names(pools) <- paired_conditions
    target <- min(lengths(pools), balanced_cap)
    if (target < balanced_minimum) next
    selected <- unlist(lapply(pools, sample, size = target, replace = FALSE), use.names = FALSE)
    balanced_barcodes <- c(balanced_barcodes, selected)
    balance_rows[[length(balance_rows) + 1L]] <- data.frame(
      Patient = donor, Basic_Celltype = celltype,
      available_Day4_Allergy = length(pools[["Day4_Allergy"]]),
      available_Irritant = length(pools[["Irritant"]]),
      sampled_per_condition = target, stringsAsFactors = FALSE
    )
  }
}
balanced <- colnames(counts) %in% balanced_barcodes
summaries[["paired_balanced"]] <- write_bundle("paired_day4_irritant_balanced", balanced)
write.table(
  do.call(rbind, balance_rows), file.path(out, "paired_day4_irritant_balanced", "sampling_audit.tsv"),
  sep = "\t", quote = FALSE, row.names = FALSE
)

for (celltype in c("APC", "KRT")) {
  selected <- meta$Patient %in% common_donors &
    meta$Lesion %in% c("Nonlesional", "Day2_Allergy", "Day4_Allergy", "Irritant") &
    meta$Basic_Celltype == celltype
  key <- paste0("state_", celltype)
  summaries[[key]] <- write_bundle(paste0("state_continuum_", celltype), selected)
}

summary <- do.call(rbind, summaries)
rownames(summary) <- NULL
write.table(summary, file.path(out, "INPUT_BUNDLE_SUMMARY.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
writeLines(c(
  paste0("seed\t", seed),
  paste0("common_donors\t", paste(common_donors, collapse = ";")),
  paste0("paired_conditions\t", paste(paired_conditions, collapse = ";")),
  paste0("communication_celltypes\t", paste(communication_celltypes, collapse = ";")),
  paste0("balanced_cap_per_donor_condition_celltype\t", balanced_cap),
  paste0("balanced_minimum_per_donor_condition_celltype\t", balanced_minimum),
  "matrix_orientation\tgenes_by_cells",
  "normalization\tnone_raw_UMI_counts"
), file.path(out, "RUN_PARAMETERS.tsv"))

print(summary)
