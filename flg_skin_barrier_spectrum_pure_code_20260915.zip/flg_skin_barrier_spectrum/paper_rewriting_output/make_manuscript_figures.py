from pathlib import Path

try:
    import matplotlib.pyplot as plt
    from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
except ModuleNotFoundError:
    plt = None


OUT = Path(__file__).resolve().parent / "final_paper"
OUT.mkdir(parents=True, exist_ok=True)


def make_with_pillow() -> None:
    from PIL import Image, ImageDraw, ImageFont

    width, height = 4200, 1680
    image = Image.new("RGB", (width, height), "white")
    draw = ImageDraw.Draw(image)
    font_root = Path("/System/Library/Fonts/Supplemental")
    bold = font_root / "Arial Bold.ttf"
    regular = font_root / "Arial.ttf"

    def font(path: Path, size: int):
        return ImageFont.truetype(str(path), size)

    title_font = font(bold, 66)
    header_font = font(bold, 39)
    body_font = font(regular, 37)
    footer_font = font(regular, 36)

    title = "Progressive resolution of the AD–ACD replication-surveillance program"
    draw.text((width / 2, 150), title, font=title_font, fill="#17212B", anchor="mm")

    blocks = [
        (130, "Cross-disease atlas", "7 inflammatory skin\nconditions\n13 bulk contrasts", "#315B7D"),
        (950, "Pathway synthesis", "Cohort-aware effects\nREML sensitivity grid\n1,444 positive pathways", "#3E7C78"),
        (1770, "Calibrated network", "396 SNF specifications\n10,000 permutations\n500 grid-level nulls", "#C76A35"),
        (2590, "Program resolution", "20 driver pathways\nDNA repair and\nreplication surveillance\n16-gene core", "#B74D59"),
        (3410, "Cell localization", "GSE267929\n5 paired donors\nAPC: allergy-high\nKRT: irritant-high", "#6A4C93"),
    ]
    top, box_w, box_h, header_h = 390, 650, 780, 170
    for index, (left, heading, body, color) in enumerate(blocks):
        draw.rounded_rectangle((left, top, left + box_w, top + box_h), radius=28,
                               fill="white", outline=color, width=7)
        draw.rounded_rectangle((left, top, left + box_w, top + header_h), radius=28,
                               fill=color, outline=color, width=1)
        draw.rectangle((left, top + header_h - 28, left + box_w, top + header_h), fill=color)
        draw.text((left + box_w / 2, top + header_h / 2), heading, font=header_font,
                  fill="white", anchor="mm")
        draw.multiline_text((left + box_w / 2, top + 470), body, font=body_font,
                            fill="#1E2732", anchor="mm", align="center", spacing=18)
        if index < len(blocks) - 1:
            next_left = blocks[index + 1][0]
            y = top + box_h / 2
            draw.line((left + box_w + 25, y, next_left - 45, y), fill="#536273", width=10)
            draw.polygon(((next_left - 45, y - 28), (next_left - 45, y + 28),
                          (next_left - 12, y)), fill="#536273")

    footer = ("Disease topology  →  SNF-grid-calibrated edge  →  pathway architecture  →  "
              "recurrent genes  →  cellular compartment")
    draw.text((width / 2, 1450), footer, font=footer_font, fill="#536273", anchor="mm")
    image.save(OUT / "figure1_workflow.png", dpi=(300, 300))


if plt is None:
    make_with_pillow()
    raise SystemExit(0)

fig, ax = plt.subplots(figsize=(14, 5.6))
ax.set_xlim(0, 14)
ax.set_ylim(0, 6)
ax.axis("off")

blocks = [
    (0.3, 1.65, 2.25, 2.6, "Cross-disease atlas", "7 inflammatory skin\nconditions\n13 bulk contrasts", "#315B7D"),
    (3.05, 1.65, 2.25, 2.6, "Pathway synthesis", "Cohort-aware effects\nREML sensitivity grid\n1,444 positive pathways", "#3E7C78"),
    (5.8, 1.65, 2.25, 2.6, "Calibrated network", "396 SNF specifications\n10,000 permutations\n500 grid-level nulls", "#C76A35"),
    (8.55, 1.65, 2.25, 2.6, "Program resolution", "20 driver pathways\nDNA repair and\nreplication surveillance\n16-gene core", "#B74D59"),
    (11.3, 1.65, 2.35, 2.6, "Cell localization", "GSE267929\n5 paired donors\nAPC: allergy-high\nKRT: irritant-high", "#6A4C93"),
]

for i, (x, y, w, h, title, body, color) in enumerate(blocks):
    patch = FancyBboxPatch(
        (x, y), w, h,
        boxstyle="round,pad=0.04,rounding_size=0.12",
        linewidth=1.8, edgecolor=color, facecolor="#FFFFFF"
    )
    ax.add_patch(patch)
    ax.add_patch(FancyBboxPatch(
        (x, y + h - 0.65), w, 0.65,
        boxstyle="round,pad=0.04,rounding_size=0.12",
        linewidth=0, facecolor=color
    ))
    ax.text(x + w / 2, y + h - 0.33, title, ha="center", va="center",
            color="white", fontsize=12.5, fontweight="bold")
    ax.text(x + w / 2, y + 0.95, body, ha="center", va="center",
            color="#1E2732", fontsize=11.5, linespacing=1.35)
    if i < len(blocks) - 1:
        nx = blocks[i + 1][0]
        ax.add_patch(FancyArrowPatch(
            (x + w + 0.08, y + h / 2), (nx - 0.08, y + h / 2),
            arrowstyle="-|>", mutation_scale=18, linewidth=2.0, color="#536273"
        ))

ax.text(7, 5.35, "Progressive resolution of the AD–ACD replication-surveillance program",
        ha="center", va="center", fontsize=19, fontweight="bold", color="#17212B")
ax.text(7, 0.65,
        "Disease topology  →  SNF-grid-calibrated edge  →  pathway architecture  →  recurrent genes  →  cellular compartment",
        ha="center", va="center", fontsize=12.5, color="#536273")

fig.tight_layout()
fig.savefig(OUT / "figure1_workflow.png", dpi=300, bbox_inches="tight", facecolor="white")
plt.close(fig)
