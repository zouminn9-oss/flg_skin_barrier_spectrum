#!/usr/bin/env python3
"""Apply compact, journal-ready styling to short submission documents."""

from pathlib import Path
import sys

from docx import Document
from docx.shared import Inches, Pt


def format_docx(path: Path):
    doc = Document(path)
    for section in doc.sections:
        section.top_margin = Inches(0.62)
        section.bottom_margin = Inches(0.62)
        section.left_margin = Inches(0.78)
        section.right_margin = Inches(0.78)
    for style_name in ("Normal", "Body Text", "First Paragraph"):
        if style_name in doc.styles:
            style = doc.styles[style_name]
            style.font.name = "Times New Roman"
            style.font.size = Pt(10.3)
            style.paragraph_format.space_after = Pt(5)
            style.paragraph_format.line_spacing = 1.0
    for p in doc.paragraphs:
        p.paragraph_format.space_after = Pt(5)
        p.paragraph_format.line_spacing = 1.0
        for run in p.runs:
            run.font.name = "Times New Roman"
            if not run.font.size or run.font.size.pt > 11:
                run.font.size = Pt(10.3)
    doc.save(path)


if __name__ == "__main__":
    for item in sys.argv[1:]:
        format_docx(Path(item))
