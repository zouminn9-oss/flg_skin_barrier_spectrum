from docx import Document
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt


PATH = "final_paper/paper.docx"


def set_cell_width(cell, width_inches: float) -> None:
    width = int(Inches(width_inches))
    cell.width = Inches(width_inches)
    tc_pr = cell._tc.get_or_add_tcPr()
    tc_w = tc_pr.find(qn("w:tcW"))
    if tc_w is None:
        tc_w = OxmlElement("w:tcW")
        tc_pr.append(tc_w)
    tc_w.set(qn("w:w"), str(width))
    tc_w.set(qn("w:type"), "dxa")


def set_cell_margins(cell, top=60, start=90, bottom=60, end=90) -> None:
    tc_pr = cell._tc.get_or_add_tcPr()
    tc_mar = tc_pr.first_child_found_in("w:tcMar")
    if tc_mar is None:
        tc_mar = OxmlElement("w:tcMar")
        tc_pr.append(tc_mar)
    for edge, value in (("top", top), ("start", start), ("bottom", bottom), ("end", end)):
        tag = "w:" + edge
        element = tc_mar.find(qn(tag))
        if element is None:
            element = OxmlElement(tag)
            tc_mar.append(element)
        element.set(qn("w:w"), str(value))
        element.set(qn("w:type"), "dxa")


doc = Document(PATH)

# LibreOffice collapses the tab used by pandoc's tenth subsection number.
for paragraph in doc.paragraphs:
    if paragraph.text.startswith("4.10\t"):
        for run in paragraph.runs:
            run.text = run.text.replace("4.10\t", "4.10 ")

# The dataset ledger is the only dense four-column table. Give narrative fields
# most of the width, use a compact journal-table font, and repeat the header.
dataset_table = doc.tables[1]
dataset_table.autofit = False
widths = (1.40, 0.75, 1.55, 2.80)
for row_index, row in enumerate(dataset_table.rows):
    tr_pr = row._tr.get_or_add_trPr()
    cant_split = OxmlElement("w:cantSplit")
    tr_pr.append(cant_split)
    for column_index, cell in enumerate(row.cells):
        set_cell_width(cell, widths[column_index])
        set_cell_margins(cell)
        cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
        for paragraph in cell.paragraphs:
            paragraph.paragraph_format.space_before = Pt(0)
            paragraph.paragraph_format.space_after = Pt(2)
            paragraph.paragraph_format.line_spacing = 1.0
            for run in paragraph.runs:
                run.font.name = "Times New Roman"
                run.font.size = Pt(9.5)
                run._element.get_or_add_rPr().rFonts.set(qn("w:ascii"), "Times New Roman")
                run._element.get_or_add_rPr().rFonts.set(qn("w:hAnsi"), "Times New Roman")
    if row_index == 0:
        repeat = OxmlElement("w:tblHeader")
        repeat.set(qn("w:val"), "true")
        tr_pr.append(repeat)

# Citeproc emits the bibliography entries but not a section heading when the
# source is LaTeX. Insert a normal manuscript heading before the first entry.
for paragraph in doc.paragraphs:
    if paragraph.text.startswith("[1]"):
        heading = OxmlElement("w:p")
        p_pr = OxmlElement("w:pPr")
        style = OxmlElement("w:pStyle")
        style.set(qn("w:val"), "Heading1")
        p_pr.append(style)
        heading.append(p_pr)
        run = OxmlElement("w:r")
        text = OxmlElement("w:t")
        text.text = "References"
        run.append(text)
        heading.append(run)
        paragraph._p.addprevious(heading)
        break

doc.save(PATH)
