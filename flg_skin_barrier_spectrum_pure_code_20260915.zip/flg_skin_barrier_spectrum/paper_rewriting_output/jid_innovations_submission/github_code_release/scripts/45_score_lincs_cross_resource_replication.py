#!/usr/bin/env python3
"""Apply the frozen four-score reversal analysis to targeted LINCS signatures."""

from pathlib import Path
import json
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
LOCAL_PACKAGES = ROOT / "environment/python_packages"
if LOCAL_PACKAGES.exists():
    sys.path.insert(0, str(LOCAL_PACKAGES))

import numpy as np
import pandas as pd
from scipy.stats import rankdata


SEED = 20260825
N_PERM = 1000
MECH = ROOT / "results/exploratory_snf/selected_positive_reml_z_q05/optimized_AD_ACD_branch/mechanism"
OUT = MECH / "lincs_cross_resource_replication"
SCIPLEX = MECH / "drug_signature_reversal"
COHORTS = [
    "AD_GSE121212_acute", "AD_GSE32924", "AD_GSE36842_acute",
    "ACD_GSE282562", "ACD_GSE6281_48h",
]


def bh(pvalues):
    p = np.asarray(pvalues, dtype=float)
    order = np.argsort(p)
    ranked = p[order]
    adjusted = np.minimum.accumulate((ranked * len(p) / np.arange(1, len(p) + 1))[::-1])[::-1]
    out = np.empty_like(adjusted)
    out[order] = np.minimum(adjusted, 1.0)
    return out


def weighted_corr_scores(y, x, weights):
    w = np.asarray(weights, dtype=np.float64)
    w = w / w.sum()
    x = np.asarray(x, dtype=np.float64)
    mx = float(w @ x)
    xc = x - mx
    my = w @ y
    yc = y - my
    cov = (w * xc) @ y
    vx = float(w @ (xc * xc))
    vy = np.sum(w[:, None] * yc * yc, axis=0)
    denom = np.sqrt(vx * vy)
    return np.divide(-cov, denom, out=np.full(y.shape[1], np.nan), where=denom > 0)


def rank_corr_scores(y, x):
    xr = rankdata(x).astype(np.float64)
    yr = rankdata(y, axis=0).astype(np.float64)
    xc = xr - xr.mean()
    yc = yr - yr.mean(axis=0)
    denom = np.sqrt(np.sum(xc * xc) * np.sum(yc * yc, axis=0))
    return np.divide(-(xc @ yc), denom, out=np.full(y.shape[1], np.nan), where=denom > 0)


def observed_four(y, x, genome_weights, program_mask, program_weights):
    return {
        "genome_rank": rank_corr_scores(y, x),
        "genome_weighted": weighted_corr_scores(y, x, genome_weights),
        "program_rank": rank_corr_scores(y[program_mask], x[program_mask]),
        "program_weighted": weighted_corr_scores(
            y[program_mask], x[program_mask], program_weights[program_mask]
        ),
    }


def permutation_composite(y, x, genome_weights, program_mask, program_weights, rng):
    """Frozen common-complete global gene-label null for every condition."""
    ncond = y.shape[1]
    yr = rankdata(y, axis=0).astype(np.float32)
    yc = yr - yr.mean(axis=0)
    ynorm = np.sqrt(np.sum(yc * yc, axis=0))
    xr = rankdata(x).astype(np.float32)
    perms = np.vstack([rng.permutation(len(x)) for _ in range(N_PERM)])
    xp = xr[perms]
    xp -= xp.mean(axis=1, keepdims=True)
    xnorm = np.sqrt(np.sum(xp * xp, axis=1))
    null_gr = -(xp @ yc) / (xnorm[:, None] * ynorm[None, :])

    w = np.asarray(genome_weights, dtype=np.float32)
    w /= w.sum()
    ymean = w @ y
    ycw = (y - ymean).astype(np.float32)
    ynormw = np.sqrt(np.sum(w[:, None] * ycw * ycw, axis=0))
    xperm = np.asarray(x, dtype=np.float32)[perms]
    xmean = xperm @ w
    ax = (xperm - xmean[:, None]) * w[None, :]
    xnormw = np.sqrt(np.sum(w[None, :] * (xperm - xmean[:, None]) ** 2, axis=1))
    null_gw = -(ax @ ycw) / (xnormw[:, None] * ynormw[None, :])

    yp = y[program_mask]
    xv = np.asarray(x[program_mask], dtype=np.float32)
    wp = np.asarray(program_weights[program_mask], dtype=np.float32)
    wp /= wp.sum()
    ypr = rankdata(yp, axis=0).astype(np.float32)
    yprc = ypr - ypr.mean(axis=0)
    yprnorm = np.sqrt(np.sum(yprc * yprc, axis=0))
    xpr = rankdata(xv).astype(np.float32)
    pperm = np.vstack([rng.permutation(len(xv)) for _ in range(N_PERM)])
    xprp = xpr[pperm]
    xprp -= xprp.mean(axis=1, keepdims=True)
    xprnorm = np.sqrt(np.sum(xprp * xprp, axis=1))
    null_pr = -(xprp @ yprc) / (xprnorm[:, None] * yprnorm[None, :])

    ypmean = wp @ yp
    ypc = (yp - ypmean).astype(np.float32)
    ypnorm = np.sqrt(np.sum(wp[:, None] * ypc * ypc, axis=0))
    xpp = xv[pperm]
    xpmean = xpp @ wp
    ap = (xpp - xpmean[:, None]) * wp[None, :]
    xpnorm = np.sqrt(np.sum(wp[None, :] * (xpp - xpmean[:, None]) ** 2, axis=1))
    null_pw = -(ap @ ypc) / (xpnorm[:, None] * ypnorm[None, :])
    assert null_gr.shape == null_gw.shape == null_pr.shape == null_pw.shape == (N_PERM, ncond)
    return ((null_gr + null_gw + null_pr + null_pw) / 4.0).astype(np.float32)


def min_leave_one(values):
    values = np.asarray(values, dtype=float)
    if len(values) < 2:
        return np.nan
    return min(np.median(np.delete(values, i)) for i in range(len(values)))


started = time.perf_counter()
bundle = np.load(OUT / "prepared_lincs_effects.npz")
genes = bundle["genes"].astype(str)
condition_ids = bundle["condition_ids"].astype(str)
effects = bundle["effects"].astype(np.float32)
assert effects.shape == (len(genes), len(condition_ids)) and np.isfinite(effects).all()

conditions = pd.read_csv(OUT / "condition_metadata.tsv", sep="\t").set_index("signature_id").loc[condition_ids].reset_index()
disease = pd.read_csv(SCIPLEX / "locked_disease_signatures.tsv", sep="\t").set_index("gene").reindex(genes)

# Every file is complete, so the common universe is selected by locked disease
# availability, not by a target, cell, dose, time, or observed reversal score.
complete = np.isfinite(effects).all(axis=1)
program_global = disease["program_weight"].fillna(0).gt(0).to_numpy()
primary_mask = complete & disease["apc_signed_stat"].notna().to_numpy()
primary_program = program_global[primary_mask]
y = effects[primary_mask]
x = disease.loc[primary_mask, "apc_signed_stat"].to_numpy(float)
cap = np.quantile(np.abs(x), 0.95)
genome_weights = np.minimum(np.abs(x), cap)
program_weights = disease.loc[primary_mask, "program_weight"].fillna(0).to_numpy(float)
assert primary_program.sum() > 0

primary = observed_four(y, x, genome_weights, primary_program, program_weights)
composite = np.mean(np.vstack(list(primary.values())), axis=0)
gene_null = permutation_composite(
    y, x, genome_weights, primary_program, program_weights, np.random.default_rng(SEED)
)
condition_gene_p = (1 + np.sum(gene_null >= composite[None, :], axis=0)) / (N_PERM + 1)

# Independent E-MTAB-9501 reversal, using its own available LINCS overlap.
external_mask = complete & disease["external_t"].notna().to_numpy()
ey = effects[external_mask]
ex = disease.loc[external_mask, "external_t"].to_numpy(float)
external_program = program_global[external_mask]
external_weights = np.minimum(np.abs(ex), np.quantile(np.abs(ex), 0.95))
external_program_weights = disease.loc[external_mask, "program_weight"].fillna(0).to_numpy(float)
external = observed_four(ey, ex, external_weights, external_program, external_program_weights)
external_composite = np.mean(np.vstack(list(external.values())), axis=0)

# Five upstream cohorts remain a non-independent direction audit.
internal_scores = {}
for cohort in COHORTS:
    col = f"t__{cohort}"
    mask = complete & disease[col].notna().to_numpy()
    iy = effects[mask]
    ix = disease.loc[mask, col].to_numpy(float)
    iw = np.minimum(np.abs(ix), np.quantile(np.abs(ix), 0.95))
    internal_scores[cohort] = np.mean(
        np.vstack([rank_corr_scores(iy, ix), weighted_corr_scores(iy, ix, iw)]), axis=0
    )

# The same frozen Reactome-based toxicity axes and removal sensitivity.
z = (effects[complete] - effects[complete].mean(axis=0)) / effects[complete].std(axis=0, ddof=1)
tox_axes = {}
for label, column, sign in [
    ("cell_death_induction", "tox_cell_death", 1.0),
    ("translation_shutdown", "tox_translation_ribosome", -1.0),
    ("cellcycle_replication_arrest", "tox_cellcycle_replication", -1.0),
]:
    mask = disease[column].fillna(False).to_numpy()[complete]
    assert mask.sum() > 0
    tox_axes[label] = sign * z[mask].mean(axis=0)
tox_index = np.max(np.vstack(list(tox_axes.values())), axis=0)

remove = disease.loc[primary_mask, "tox_any"].fillna(False).to_numpy()
kept = ~remove
kept_program = primary_program[kept]
removed = observed_four(y[kept], x[kept], genome_weights[kept], kept_program, program_weights[kept])
removed_composite = np.mean(np.vstack(list(removed.values())), axis=0)
attenuation = np.divide(
    composite - removed_composite, np.abs(composite),
    out=np.full_like(composite, np.nan), where=np.abs(composite) > 1e-12,
)
condition_toxic = (tox_index >= 0.5) & ((removed_composite <= 0) | (attenuation >= 0.5))

condition = conditions.copy()
for key, values in primary.items():
    condition[f"apc_{key}_reversal"] = values
condition["apc_composite_reversal"] = composite
condition["apc_gene_label_empirical_p"] = condition_gene_p
condition["common_complete_APC_genes"] = int(primary_mask.sum())
condition["common_complete_program_genes"] = int(primary_program.sum())
for key, values in external.items():
    condition[f"external_{key}_reversal"] = values
condition["external_composite_reversal"] = external_composite
for cohort, values in internal_scores.items():
    condition[f"internal_{cohort}_reversal"] = values
for key, values in tox_axes.items():
    condition[key] = values
condition["toxicity_index"] = tox_index
condition["tox_removed_apc_composite_reversal"] = removed_composite
condition["tox_removal_attenuation_fraction"] = attenuation
condition["condition_toxicity_dominated"] = condition_toxic
condition.to_csv(OUT / "condition_level_lincs_reversal.tsv", sep="\t", index=False)

# Aggregate after all condition-level results are retained. Compound P values
# are the frozen median-over-conditions gene-label null, not a favorable-
# condition selection and not a full-background FDR.
component_cols = [f"apc_{key}_reversal" for key in primary]
compound_rows, independent_rows, internal_rows, toxicity_rows = [], [], [], []
for target_key, group in condition.groupby("target_key", sort=True):
    idx = group.index.to_numpy()
    observed = float(group["apc_composite_reversal"].median())
    null_median = np.median(gene_null[:, idx], axis=1)
    empirical_p = float((1 + np.sum(null_median >= observed)) / (N_PERM + 1))
    med = {column: float(group[column].median()) for column in component_cols}
    scores = group["apc_composite_reversal"].to_numpy()
    cell_loo = []
    for cell in sorted(group["cell_line"].astype(str).unique()):
        remain = group.loc[group["cell_line"].astype(str).ne(cell), "apc_composite_reversal"]
        if len(remain):
            cell_loo.append(float(remain.median()))
    min_cell_loo = min(cell_loo) if group["cell_line"].nunique() >= 2 else np.nan
    min_cond_loo = min_leave_one(scores)
    positive_fraction = float(np.mean(scores > 0))
    stable = bool(
        len(group) >= 2 and group["cell_line"].nunique() >= 2 and positive_fraction >= 2 / 3
        and min_cond_loo > 0 and min_cell_loo > 0
    )
    removed_median = float(group["tox_removed_apc_composite_reversal"].median())
    tox_fraction = float(group["condition_toxicity_dominated"].mean())
    compound_attenuation = (
        (observed - removed_median) / abs(observed) if abs(observed) > 1e-12 else np.nan
    )
    tox_dominated = bool(
        tox_fraction >= 0.5 or removed_median <= 0
        or (observed > 0 and removed_median < 0.5 * observed)
    )
    compound_rows.append({
        "target_key": target_key, "lincs_pert_names": ";".join(sorted(group["pert_name"].astype(str).unique())),
        "n_conditions": len(group), "n_cell_lines": group["cell_line"].nunique(),
        "n_doses": group["dose"].nunique(), "n_times": group["time"].nunique(),
        **{f"median_{key}": value for key, value in med.items()},
        "median_apc_composite_reversal": observed,
        "direction_positive_fraction": positive_fraction,
        "min_leave_one_condition_median": min_cond_loo,
        "min_leave_one_cell_line_median": min_cell_loo,
        "multi_condition_stable": stable,
        "primary_five_score_screen": bool(all(value > 0 for value in med.values()) and observed > 0),
        "gene_label_empirical_p": empirical_p,
        "median_external_composite_reversal": float(group["external_composite_reversal"].median()),
        "external_direction_supported": bool(group["external_composite_reversal"].median() > 0),
        "toxicity_dominated_fraction": tox_fraction,
        "median_tox_removed_apc_composite_reversal": removed_median,
        "tox_removal_attenuation_fraction": compound_attenuation,
        "toxicity_dominated": tox_dominated,
    })
    independent_rows.append({
        "target_key": target_key, "n_conditions": len(group),
        **{f"median_external_{key}_reversal": float(group[f'external_{key}_reversal'].median()) for key in external},
        "median_external_composite_reversal": float(group["external_composite_reversal"].median()),
        "external_direction_supported": bool(group["external_composite_reversal"].median() > 0),
    })
    audits = {cohort: float(group[f"internal_{cohort}_reversal"].median()) for cohort in COHORTS}
    internal_rows.append({
        "target_key": target_key, **{f"median_{key}_reversal": value for key, value in audits.items()},
        "positive_internal_cohorts": sum(value > 0 for value in audits.values()),
        "internal_cohorts": len(COHORTS), "validation_status": "not_independent_upstream_contributors",
    })
    toxicity_rows.append({
        "target_key": target_key, "n_conditions": len(group),
        **{f"median_{key}": float(group[key].median()) for key in tox_axes},
        "median_toxicity_index": float(group["toxicity_index"].median()),
        "toxicity_dominated_fraction": tox_fraction,
        "median_unfiltered_apc_composite_reversal": observed,
        "median_tox_removed_apc_composite_reversal": removed_median,
        "tox_removal_attenuation_fraction": compound_attenuation,
        "toxicity_dominated": tox_dominated,
    })

compounds = pd.DataFrame(compound_rows)
compounds["targeted_BH_q"] = bh(compounds["gene_label_empirical_p"])
compounds["targeted_fdr_scope"] = "covered_locked_targets_only_not_full_background"
compounds = compounds.sort_values("median_apc_composite_reversal", ascending=False).reset_index(drop=True)
compounds.insert(0, "targeted_rank", np.arange(1, len(compounds) + 1))
compounds.to_csv(OUT / "covered_compound_aggregation.tsv", sep="\t", index=False)
pd.DataFrame(independent_rows).to_csv(OUT / "independent_validation.tsv", sep="\t", index=False)
pd.DataFrame(internal_rows).to_csv(OUT / "internal_five_cohort_direction_audit.tsv", sep="\t", index=False)
pd.DataFrame(toxicity_rows).to_csv(OUT / "toxicity_cell_cycle_sensitivity.tsv", sep="\t", index=False)

# Frozen cross-resource classifications, retaining absent named leads and G007-LK.
inventory = pd.read_csv(OUT / "target_coverage_inventory.tsv", sep="\t")
sciplex = pd.read_csv(SCIPLEX / "compound_level_ranking.tsv", sep="\t")
sciplex = sciplex.rename(columns={
    "compound": "target_key", "median_apc_composite_reversal": "sciplex_median_apc_composite_reversal",
    "compound_label_empirical_p": "sciplex_empirical_p", "compound_label_BH_q": "sciplex_full_background_BH_q",
    "evidence_tier": "sciplex_evidence_tier", "multi_condition_stable": "sciplex_multi_condition_stable",
    "external_direction_supported": "sciplex_external_direction_supported",
    "toxicity_dominated": "sciplex_toxicity_dominated",
})
sciplex_cols = [
    "target_key", "sciplex_median_apc_composite_reversal", "sciplex_empirical_p",
    "sciplex_full_background_BH_q", "sciplex_evidence_tier", "sciplex_multi_condition_stable",
    "sciplex_external_direction_supported", "sciplex_toxicity_dominated",
]
comparison = inventory.merge(compounds, on="target_key", how="left").merge(sciplex[sciplex_cols], on="target_key", how="left")

classes = []
for row in comparison.itertuples(index=False):
    if row.coverage == "not_covered":
        classes.append("not_covered")
        continue
    lincs_pass = bool(
        row.primary_five_score_screen and row.targeted_BH_q < 0.05 and row.multi_condition_stable
        and row.external_direction_supported and not row.toxicity_dominated
    )
    if row.target_group == "named_prior_lead":
        classes.append("LINCS_support_only" if lincs_pass else "LINCS_no_support")
        continue
    lin_pos = row.median_apc_composite_reversal > 0
    sci_pos = row.sciplex_median_apc_composite_reversal > 0
    if lin_pos and sci_pos:
        classes.append("replicated" if lincs_pass else "direction_only")
    elif lin_pos != sci_pos:
        classes.append("discordant")
    else:
        classes.append("negative_both")
comparison["cross_resource_classification"] = classes
comparison["clinical_evidence"] = False
comparison["analysis_status"] = "post_hoc_exploratory_cross_resource_replication"
comparison.to_csv(OUT / "all_target_classification.tsv", sep="\t", index=False)
comparison.loc[comparison["target_group"].eq("sciplex_audit")].to_csv(
    OUT / "sciplex_lincs_comparison.tsv", sep="\t", index=False
)

run = {
    "seed": SEED, "gene_label_permutations": N_PERM,
    "conditions": len(condition), "covered_targeted_compounds": len(compounds),
    "targeted_BH_scope": "covered_locked_targets_only_not_full_background",
    "common_complete_APC_genes": int(primary_mask.sum()),
    "common_complete_program_genes": int(primary_program.sum()),
    "external_genes": int(external_mask.sum()), "external_program_genes": int(external_program.sum()),
    "elapsed_seconds": time.perf_counter() - started,
    "status": "post_hoc_exploratory_computational_cross_resource_replication",
}
(OUT / "RUN_PARAMETERS.json").write_text(json.dumps(run, indent=2) + "\n")
print(comparison["cross_resource_classification"].value_counts().to_string())
print(compounds[[
    "targeted_rank", "target_key", "median_apc_composite_reversal", "gene_label_empirical_p",
    "targeted_BH_q", "multi_condition_stable", "external_direction_supported", "toxicity_dominated",
]].to_string(index=False))
print(json.dumps(run, indent=2))
