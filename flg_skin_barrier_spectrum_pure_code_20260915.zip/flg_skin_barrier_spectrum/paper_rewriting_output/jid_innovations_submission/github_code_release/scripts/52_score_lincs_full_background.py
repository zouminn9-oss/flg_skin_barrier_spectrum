#!/usr/bin/env python3
"""Stream the frozen reversal scores across the complete LINCS cp matrix."""

from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
import json
import math
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
LOCAL_PACKAGES = ROOT / "environment/python_packages"
if LOCAL_PACKAGES.exists():
    sys.path.insert(0, str(LOCAL_PACKAGES))

import h5py
import numpy as np
import pandas as pd
from scipy.stats import rankdata, spearmanr


SEED = 20260825
BLOCK_SIZE = 1024
EXPECTED_BYTES = 36_084_518_760
GCTX = ROOT / "data/raw/perturbations/lincs_2021_full/cp_coeff_mat.gctx"
MECH = ROOT / "results/exploratory_snf/selected_positive_reml_z_q05/optimized_AD_ACD_branch/mechanism"
SCIPLEX = MECH / "drug_signature_reversal"
TARGETED = MECH / "lincs_cross_resource_replication"
OUT = MECH / "lincs_full_background_calibration"
PARTS = OUT / "condition_score_parts"
COLUMN_METADATA = OUT / "gctx_column_metadata.parquet"
OUT.mkdir(parents=True, exist_ok=True)
PARTS.mkdir(parents=True, exist_ok=True)

COHORTS = [
    "AD_GSE121212_acute", "AD_GSE32924", "AD_GSE36842_acute",
    "ACD_GSE282562", "ACD_GSE6281_48h",
]
PRIMARY_COMPONENTS = [
    "apc_genome_rank_reversal", "apc_genome_weighted_reversal",
    "apc_program_rank_reversal", "apc_program_weighted_reversal",
]


def decode(values: np.ndarray) -> np.ndarray:
    values = np.asarray(values)
    if values.dtype.kind == "S":
        return np.char.decode(values, "utf-8")
    if values.dtype.kind == "O":
        return np.asarray([
            value.decode("utf-8") if isinstance(value, (bytes, np.bytes_)) else str(value)
            for value in values
        ])
    return values.astype(str)


def weighted_corr_scores(y, x, weights):
    w = np.asarray(weights, dtype=np.float64)
    w = w / w.sum()
    x = np.asarray(x, dtype=np.float64)
    mx = float(w @ x)
    xc = x - mx
    my = w @ y
    yc = y - my
    cov = (w * xc) @ y
    vx = float(w @ (xc * xc))
    vy = np.sum(w[:, None] * yc * yc, axis=0)
    denom = np.sqrt(vx * vy)
    return np.divide(-cov, denom, out=np.full(y.shape[1], np.nan), where=denom > 0)


def rank_corr_scores(y, x):
    xr = rankdata(x).astype(np.float64)
    yr = rankdata(y, axis=0).astype(np.float64)
    xc = xr - xr.mean()
    yc = yr - yr.mean(axis=0)
    denom = np.sqrt(np.sum(xc * xc) * np.sum(yc * yc, axis=0))
    return np.divide(-(xc @ yc), denom, out=np.full(y.shape[1], np.nan), where=denom > 0)


def observed_four(y, x, genome_weights, program_mask, program_weights):
    return {
        "genome_rank": rank_corr_scores(y, x),
        "genome_weighted": weighted_corr_scores(y, x, genome_weights),
        "program_rank": rank_corr_scores(y[program_mask], x[program_mask]),
        "program_weighted": weighted_corr_scores(
            y[program_mask], x[program_mask], program_weights[program_mask]
        ),
    }


def min_leave_one(values):
    values = np.asarray(values, dtype=float)
    if len(values) < 2:
        return np.nan
    # Removing the largest observation minimizes the median of the remainder.
    return float(np.median(np.sort(values)[:-1]))


def min_leave_one_cell(group):
    cells = sorted(group["cell_line"].dropna().astype(str).unique())
    if len(cells) < 2:
        return np.nan
    values = group["apc_composite_reversal"].to_numpy(float)
    labels = group["cell_line"].astype(str).to_numpy()
    medians = [np.median(values[labels != cell]) for cell in cells if np.any(labels != cell)]
    return float(min(medians)) if medians else np.nan


def competitive_tail(values):
    values = pd.Series(values, dtype=float)
    count_ge = values.rank(method="max", ascending=False).astype(int)
    return (1 + count_ge) / (1 + len(values))


started = time.perf_counter()
if GCTX.stat().st_size != EXPECTED_BYTES:
    raise RuntimeError(f"Full GCTX is incomplete: {GCTX.stat().st_size} != {EXPECTED_BYTES}")

disease = pd.read_csv(SCIPLEX / "locked_disease_signatures.tsv", sep="\t").set_index("gene")
targeted_condition = pd.read_csv(TARGETED / "condition_level_lincs_reversal.tsv", sep="\t")
column_metadata = pd.read_parquet(COLUMN_METADATA).sort_values("column_index").reset_index(drop=True)

with h5py.File(GCTX, "r") as handle:
    row_ids = decode(handle["/0/META/ROW/id"][:])
    condition_ids = decode(handle["/0/META/COL/id"][:])
    matrix = handle["/0/DATA/0/matrix"]
    if matrix.shape == (len(condition_ids), len(row_ids)):
        orientation = "condition_by_gene_gctx_transposed"
    elif matrix.shape == (len(row_ids), len(condition_ids)):
        orientation = "gene_by_condition"
    else:
        raise RuntimeError((matrix.shape, len(row_ids), len(condition_ids)))

    if len(condition_ids) != len(column_metadata) or not column_metadata["gctx_sig_id"].astype(str).equals(
        pd.Series(condition_ids)
    ):
        raise RuntimeError("Broad siginfo crosswalk does not cover every GCTX sig_id in order")
    if len(set(condition_ids)) != len(condition_ids) or len(set(row_ids)) != len(row_ids):
        raise RuntimeError("Duplicate GCTX identifiers")

    locked_gene_universe = np.isin(row_ids, disease.index.astype(str).to_numpy())
    aligned = disease.reindex(row_ids)
    program_global = aligned["program_weight"].fillna(0).gt(0).to_numpy()
    primary_mask = aligned["apc_signed_stat"].notna().to_numpy()
    primary_program = program_global[primary_mask]
    x = aligned.loc[primary_mask, "apc_signed_stat"].to_numpy(float)
    cap = np.quantile(np.abs(x), 0.95)
    genome_weights = np.minimum(np.abs(x), cap)
    program_weights = aligned.loc[primary_mask, "program_weight"].fillna(0).to_numpy(float)
    if int(primary_program.sum()) != 214 or int(primary_mask.sum()) != 3735:
        raise RuntimeError((int(primary_mask.sum()), int(primary_program.sum())))

    external_mask = aligned["external_t"].notna().to_numpy()
    ex = aligned.loc[external_mask, "external_t"].to_numpy(float)
    external_program = program_global[external_mask]
    external_weights = np.minimum(np.abs(ex), np.quantile(np.abs(ex), 0.95))
    external_program_weights = aligned.loc[external_mask, "program_weight"].fillna(0).to_numpy(float)

    internal_inputs = {}
    for cohort in COHORTS:
        mask = aligned[f"t__{cohort}"].notna().to_numpy()
        ix = aligned.loc[mask, f"t__{cohort}"].to_numpy(float)
        iw = np.minimum(np.abs(ix), np.quantile(np.abs(ix), 0.95))
        internal_inputs[cohort] = (mask, ix, iw)

    tox_masks = {
        "cell_death_induction": aligned["tox_cell_death"].fillna(False).to_numpy()[locked_gene_universe],
        "translation_shutdown": aligned["tox_translation_ribosome"].fillna(False).to_numpy()[locked_gene_universe],
        "cellcycle_replication_arrest": aligned["tox_cellcycle_replication"].fillna(False).to_numpy()[locked_gene_universe],
    }
    tox_signs = {
        "cell_death_induction": 1.0,
        "translation_shutdown": -1.0,
        "cellcycle_replication_arrest": -1.0,
    }
    remove = aligned.loc[primary_mask, "tox_any"].fillna(False).to_numpy()
    kept = ~remove
    kept_program = primary_program[kept]

    total_blocks = math.ceil(len(condition_ids) / BLOCK_SIZE)
    for block_number, start in enumerate(range(0, len(condition_ids), BLOCK_SIZE), start=1):
        stop = min(start + BLOCK_SIZE, len(condition_ids))
        part = PARTS / f"part_{start:09d}_{stop:09d}.parquet"
        if part.exists():
            existing = pd.read_parquet(part, columns=["signature_id"])
            if len(existing) != stop - start:
                raise RuntimeError(f"Invalid checkpoint: {part}")
            print(f"skip {block_number}/{total_blocks} {start}:{stop}", flush=True)
            continue

        if orientation == "condition_by_gene_gctx_transposed":
            effects = np.asarray(matrix[start:stop, :], dtype=np.float32).T
        else:
            effects = np.asarray(matrix[:, start:stop], dtype=np.float32)
        if effects.shape != (len(row_ids), stop - start) or not np.isfinite(effects).all():
            raise RuntimeError(f"Non-finite or malformed block {start}:{stop}")

        primary = observed_four(
            effects[primary_mask], x, genome_weights, primary_program, program_weights
        )
        composite = np.mean(np.vstack(list(primary.values())), axis=0)
        external = observed_four(
            effects[external_mask], ex, external_weights, external_program, external_program_weights
        )
        external_composite = np.mean(np.vstack(list(external.values())), axis=0)

        internal_scores = {}
        for cohort, (mask, ix, iw) in internal_inputs.items():
            iy = effects[mask]
            internal_scores[cohort] = np.mean(
                np.vstack([rank_corr_scores(iy, ix), weighted_corr_scores(iy, ix, iw)]), axis=0
            )

        tox_effects = effects[locked_gene_universe]
        mean = tox_effects.mean(axis=0)
        std = tox_effects.std(axis=0, ddof=1)
        if np.any(std <= 0):
            raise RuntimeError(f"Zero within-condition gene SD {start}:{stop}")
        z = (tox_effects - mean) / std
        tox_axes = {
            label: tox_signs[label] * z[mask].mean(axis=0)
            for label, mask in tox_masks.items()
        }
        tox_index = np.max(np.vstack(list(tox_axes.values())), axis=0)

        removed = observed_four(
            effects[primary_mask][kept], x[kept], genome_weights[kept],
            kept_program, program_weights[kept],
        )
        removed_composite = np.mean(np.vstack(list(removed.values())), axis=0)
        attenuation = np.divide(
            composite - removed_composite, np.abs(composite),
            out=np.full_like(composite, np.nan), where=np.abs(composite) > 1e-12,
        )
        condition_toxic = (tox_index >= 0.5) & ((removed_composite <= 0) | (attenuation >= 0.5))

        ids = condition_ids[start:stop]
        context = column_metadata.iloc[start:stop]
        dose = np.where(
            context["pert_dose"].notna(),
            context["pert_dose"].astype(str) + " " + context["pert_dose_unit"].fillna("").astype(str),
            None,
        )
        pert_time = np.where(
            context["pert_time"].notna(),
            context["pert_time"].astype(str) + " " + context["pert_time_unit"].fillna("").astype(str),
            None,
        )
        frame = pd.DataFrame({
            "condition_index": np.arange(start, stop, dtype=np.int64),
            "signature_id": ids,
            "pert_id": context["pert_id"].astype(str).to_numpy(),
            "pert_name": context["cmap_name"].astype(str).to_numpy(),
            "cell_line": context["cell_iname"].astype(str).to_numpy(),
            "dose": dose,
            "time": pert_time,
            "is_hiq": context["is_hiq"].to_numpy(),
            "qc_pass": context["qc_pass"].to_numpy(),
        })
        for key, values in primary.items():
            frame[f"apc_{key}_reversal"] = values
        frame["apc_composite_reversal"] = composite
        for key, values in external.items():
            frame[f"external_{key}_reversal"] = values
        frame["external_composite_reversal"] = external_composite
        for cohort, values in internal_scores.items():
            frame[f"internal_{cohort}_reversal"] = values
        for key, values in tox_axes.items():
            frame[key] = values
        frame["toxicity_index"] = tox_index
        frame["tox_removed_apc_composite_reversal"] = removed_composite
        frame["tox_removal_attenuation_fraction"] = attenuation
        frame["condition_toxicity_dominated"] = condition_toxic
        frame.to_parquet(part, index=False, compression="zstd")
        print(f"score {block_number}/{total_blocks} {start}:{stop}", flush=True)

condition = pd.read_parquet(PARTS).sort_values("condition_index").reset_index(drop=True)
if len(condition) != len(condition_ids) or not condition["signature_id"].astype(str).equals(pd.Series(condition_ids)):
    raise RuntimeError("Condition part assembly mismatch")

# Exact comparison against every frozen targeted signature.
recon_columns = PRIMARY_COMPONENTS + ["apc_composite_reversal"]
full_targeted = condition.loc[condition["signature_id"].isin(targeted_condition["cmap_id"]), [
    "signature_id", *recon_columns,
]].copy()
reconciliation = targeted_condition[["signature_id", "cmap_id", "target_key", *recon_columns]].merge(
    full_targeted, left_on="cmap_id", right_on="signature_id", how="outer",
    suffixes=("_targeted", "_full"), indicator=True
)
for column in recon_columns:
    reconciliation[f"abs_diff__{column}"] = (
        reconciliation[f"{column}_targeted"] - reconciliation[f"{column}_full"]
    ).abs()
reconciliation.to_csv(OUT / "targeted_full_score_reconciliation.tsv", sep="\t", index=False)

score_qc = []
for column in recon_columns:
    left = reconciliation[f"{column}_targeted"]
    right = reconciliation[f"{column}_full"]
    score_qc.append({
        "score": column,
        "overlap": int((reconciliation["_merge"] == "both").sum()),
        "max_absolute_difference": float((left - right).abs().max()),
        "spearman_correlation": float(spearmanr(left, right).statistic),
        "sign_agreement_fraction": float((np.sign(left) == np.sign(right)).mean()),
    })
score_qc = pd.DataFrame(score_qc)
compatible = bool(
    reconciliation["_merge"].eq("both").all()
    and score_qc["max_absolute_difference"].le(1e-6).all()
    and score_qc["sign_agreement_fraction"].eq(1).all()
)
near_compatible = bool(
    reconciliation["_merge"].eq("both").all()
    and score_qc["spearman_correlation"].ge(0.999).all()
    and score_qc["sign_agreement_fraction"].ge(0.999).all()
)
reconciliation_status = "compatible" if compatible else ("near_compatible" if near_compatible else "version_divergent")
score_qc.to_csv(OUT / "targeted_full_score_reconciliation_summary.tsv", sep="\t", index=False)

# Aggregate only after all condition scores and the complete negative background exist.
rows = []
for pert_name, group in condition.groupby("pert_name", sort=True, dropna=False):
    scores = group["apc_composite_reversal"].to_numpy(float)
    component_medians = {column: float(group[column].median()) for column in PRIMARY_COMPONENTS}
    observed = float(np.median(scores))
    min_condition = min_leave_one(scores)
    min_cell = min_leave_one_cell(group)
    positive_fraction = float(np.mean(scores > 0))
    n_cells = int(group["cell_line"].nunique(dropna=True))
    stable = bool(
        len(group) >= 2 and n_cells >= 2 and positive_fraction >= 2 / 3
        and min_condition > 0 and min_cell > 0
    )
    removed_median = float(group["tox_removed_apc_composite_reversal"].median())
    tox_fraction = float(group["condition_toxicity_dominated"].mean())
    compound_attenuation = (
        (observed - removed_median) / abs(observed) if abs(observed) > 1e-12 else np.nan
    )
    tox_dominated = bool(
        tox_fraction >= 0.5 or removed_median <= 0
        or (observed > 0 and removed_median < 0.5 * observed)
    )
    rows.append({
        "pert_name": pert_name,
        "n_conditions": len(group), "n_cell_lines": n_cells,
        "n_doses": int(group["dose"].nunique(dropna=True)),
        "n_times": int(group["time"].nunique(dropna=True)),
        **{f"median_{key}": value for key, value in component_medians.items()},
        "median_apc_composite_reversal": observed,
        "direction_positive_fraction": positive_fraction,
        "min_leave_one_condition_median": min_condition,
        "min_leave_one_cell_line_median": min_cell,
        "multi_condition_stable": stable,
        "primary_five_score_screen": bool(all(value > 0 for value in component_medians.values()) and observed > 0),
        "median_external_composite_reversal": float(group["external_composite_reversal"].median()),
        "external_direction_supported": bool(group["external_composite_reversal"].median() > 0),
        "toxicity_dominated_fraction": tox_fraction,
        "median_toxicity_index": float(group["toxicity_index"].median()),
        "median_tox_removed_apc_composite_reversal": removed_median,
        "tox_removal_attenuation_fraction": compound_attenuation,
        "toxicity_dominated": tox_dominated,
        **{
            f"median_internal_{cohort}_reversal": float(group[f"internal_{cohort}_reversal"].median())
            for cohort in COHORTS
        },
    })

compounds = pd.DataFrame(rows).sort_values(
    ["median_apc_composite_reversal", "pert_name"], ascending=[False, True]
).reset_index(drop=True)
compounds["all_compound_rank"] = compounds["median_apc_composite_reversal"].rank(
    method="min", ascending=False
).astype(int)
compounds["all_compound_competitive_upper_tail_fraction"] = competitive_tail(
    compounds["median_apc_composite_reversal"]
)
eligible = compounds["n_conditions"].ge(2) & compounds["n_cell_lines"].ge(2)
eligible_values = compounds.loc[eligible, "median_apc_composite_reversal"]
compounds["stable_eligible_rank"] = pd.Series(pd.NA, index=compounds.index, dtype="Int64")
compounds.loc[eligible, "stable_eligible_rank"] = eligible_values.rank(method="min", ascending=False).astype(int)
compounds["stable_eligible_competitive_upper_tail_fraction"] = np.nan
compounds.loc[eligible, "stable_eligible_competitive_upper_tail_fraction"] = competitive_tail(eligible_values)
compounds["calibration_quantity_type"] = "competitive_rank_fraction_not_null_p_not_fdr"
compounds.to_csv(OUT / "full_background_compound_ranking.tsv", sep="\t", index=False)
compounds.to_parquet(OUT / "full_background_compound_ranking.parquet", index=False)

jnj_rows = compounds.loc[compounds["pert_name"].eq("JNJ-7706621")]
if len(jnj_rows) != 1:
    raise RuntimeError(f"Expected one JNJ aggregate, found {len(jnj_rows)}")
jnj = jnj_rows.iloc[0]
direction_pass = bool(jnj["primary_five_score_screen"])
all_top5 = bool(jnj["all_compound_competitive_upper_tail_fraction"] <= 0.05)
eligible_top5 = bool(jnj["stable_eligible_competitive_upper_tail_fraction"] <= 0.05)
robustness_pass = bool(
    jnj["multi_condition_stable"] and jnj["external_direction_supported"]
    and not jnj["toxicity_dominated"]
)
source_pass = reconciliation_status in {"compatible", "near_compatible"}
if direction_pass and all_top5 and eligible_top5 and robustness_pass and source_pass:
    label = "full_background_competitive"
elif direction_pass and robustness_pass and source_pass:
    label = "positive_not_top5"
else:
    label = "full_background_not_supported"

targeted_jnj = pd.read_csv(TARGETED / "covered_compound_aggregation.tsv", sep="\t").set_index("target_key").loc["JNJ-7706621"]
disposition = {
    "candidate": "JNJ-7706621",
    "input_label": "balanced_posthoc_nominal_candidate",
    "full_background_label": label,
    "full_background_conditions": int(jnj["n_conditions"]),
    "full_background_compounds": int(len(compounds)),
    "stable_eligible_background_compounds": int(eligible.sum()),
    "median_apc_composite_reversal": float(jnj["median_apc_composite_reversal"]),
    "all_compound_rank": int(jnj["all_compound_rank"]),
    "all_compound_competitive_upper_tail_fraction": float(jnj["all_compound_competitive_upper_tail_fraction"]),
    "stable_eligible_rank": int(jnj["stable_eligible_rank"]),
    "stable_eligible_competitive_upper_tail_fraction": float(jnj["stable_eligible_competitive_upper_tail_fraction"]),
    "all_four_and_composite_positive": direction_pass,
    "top5_all_background": all_top5,
    "top5_stable_eligible_background": eligible_top5,
    "multi_condition_stable": bool(jnj["multi_condition_stable"]),
    "external_direction_supported": bool(jnj["external_direction_supported"]),
    "toxicity_dominated": bool(jnj["toxicity_dominated"]),
    "source_reconciliation": reconciliation_status,
    "frozen_targeted_gene_label_empirical_p": float(targeted_jnj["gene_label_empirical_p"]),
    "frozen_targeted_BH_q": float(targeted_jnj["targeted_BH_q"]),
    "competitive_fraction_is_null_p": False,
    "library_wide_fdr_computed": False,
    "formal_replication": False,
    "clinical_evidence": False,
    "gate3_changed": False,
}
(OUT / "JNJ7706621_FULL_BACKGROUND_DISPOSITION.json").write_text(json.dumps(disposition, indent=2) + "\n")

run = {
    "completed_at_utc": datetime.now(timezone.utc).isoformat(),
    "seed": SEED, "block_size": BLOCK_SIZE,
    "gctx_matrix_orientation": orientation,
    "gctx_rows": len(row_ids), "conditions": len(condition),
    "compounds": len(compounds), "stable_eligible_compounds": int(eligible.sum()),
    "common_complete_APC_genes": int(primary_mask.sum()),
    "common_complete_program_genes": int(primary_program.sum()),
    "external_genes": int(external_mask.sum()),
    "targeted_source_reconciliation": reconciliation_status,
    "targeted_BH_reused_as_library_FDR": False,
    "library_wide_FDR_computed": False,
    "elapsed_seconds": time.perf_counter() - started,
    "status": "post_hoc_exploratory_computational_full_background_calibration",
}
(OUT / "RUN_PARAMETERS.json").write_text(json.dumps(run, indent=2) + "\n")
print(json.dumps(disposition, indent=2))
print(json.dumps(run, indent=2))
