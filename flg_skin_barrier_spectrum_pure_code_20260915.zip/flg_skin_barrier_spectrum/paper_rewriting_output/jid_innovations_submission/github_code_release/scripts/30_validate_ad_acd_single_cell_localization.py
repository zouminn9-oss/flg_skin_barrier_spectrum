#!/usr/bin/env python3
import csv
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "results/exploratory_snf/selected_positive_reml_z_q05/optimized_AD_ACD_branch/mechanism/single_cell_localization"


def rows(path):
    with path.open(newline="") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


scores = {r["celltype"]: r for r in rows(OUT / "celltype_program_scores.tsv")}
assert set(scores) == {"KRT", "APC", "LYMPH", "all_cells"}
assert all(int(r["paired_donors"]) == 5 for r in scores.values())
assert float(scores["KRT"]["driver_pathway_score"]) < -0.9
assert float(scores["KRT"]["driver_pathway_q_BH_4celltypes"]) < 0.01
assert int(scores["KRT"]["driver_pathways_up"]) == 2
assert float(scores["APC"]["driver_pathway_score"]) > 0.55
assert float(scores["APC"]["driver_pathway_q_BH_4celltypes"]) < 0.05
assert int(scores["APC"]["driver_pathways_up"]) == 17
assert float(scores["LYMPH"]["driver_pathway_q_BH_4celltypes"]) > 0.05
assert float(scores["all_cells"]["driver_pathway_q_BH_4celltypes"]) > 0.05
assert all(float(r["core_gene_q_BH_4celltypes"]) > 0.05 for r in scores.values())

loo = rows(OUT / "driver_pathway_leave_one_out.tsv")
assert len(loo) == 72
assert all(r["same_direction_as_full_score"] == "True" for r in loo)

summary = rows(OUT / "single_cell_localization_summary.tsv")[0]
assert summary["positive_localization_celltype"] == "APC"
assert summary["negative_localization_celltype"] == "KRT"
assert int(summary["pathway_program_tests_significant_q_0_05"]) == 2
assert int(summary["core_gene_tests_significant_q_0_05"]) == 0

for name in ("celltype_driver_program_scores.png", "driver_pathway_celltype_heatmap.png"):
    assert (OUT / "figures" / name).stat().st_size > 20_000
report = (ROOT / "AD_ACD_SINGLE_CELL_LOCALIZATION_REPORT.md").read_text()
for phrase in ("APC", "q=0.0436", "q=0.00880", "16/16", "五名"):
    assert phrase in report

print("PASS: single-cell pathway localization, matched permutations, LOO stability, figures, and report are consistent")
