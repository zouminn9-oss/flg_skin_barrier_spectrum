#!/usr/bin/env python3
"""Extract GEO sample metadata without loading platform/expression tables."""

import csv
import gzip
import json
import pathlib
import re


ROOT = pathlib.Path(__file__).resolve().parents[1]
GEO = ROOT / "data" / "raw" / "geo"
OUT = ROOT / "metadata" / "geo_samples.tsv"
SUMMARY = ROOT / "metadata" / "geo_metadata_summary.tsv"


KEEP = {
    "!Sample_title",
    "!Sample_geo_accession",
    "!Sample_source_name_ch1",
    "!Sample_source_name_ch2",
    "!Sample_organism_ch1",
    "!Sample_characteristics_ch1",
    "!Sample_characteristics_ch2",
    "!Sample_treatment_protocol_ch1",
    "!Sample_description",
    "!Sample_platform_id",
    "!Sample_relation",
    "!Sample_supplementary_file",
}


def parse_characteristic(text):
    if ":" in text:
        key, value = text.split(":", 1)
        key = re.sub(r"\s+", " ", key.strip().lower())
        return key, value.strip()
    return "unparsed", text.strip()


def flush(accession, current, output):
    if not current:
        return
    characteristics = {}
    for text in current.get("!Sample_characteristics_ch1", []):
        key, value = parse_characteristic(text)
        characteristics.setdefault(key, []).append(value)
    row = {
        "series": accession,
        "gsm": current.get("^SAMPLE", [""])[0],
        "title": " | ".join(current.get("!Sample_title", [])),
        "source_ch1": " | ".join(current.get("!Sample_source_name_ch1", [])),
        "platform": " | ".join(current.get("!Sample_platform_id", [])),
        "characteristics_json": json.dumps(characteristics, ensure_ascii=False, sort_keys=True),
        "description": " | ".join(current.get("!Sample_description", [])),
        "treatment": " | ".join(current.get("!Sample_treatment_protocol_ch1", [])),
        "relations": " | ".join(current.get("!Sample_relation", [])),
        "supplementary_files": " | ".join(current.get("!Sample_supplementary_file", [])),
    }
    output.append(row)


def parse_soft(path):
    accession = path.name.split("_", 1)[0]
    output = []
    current = None
    with gzip.open(path, "rt", encoding="utf-8", errors="replace") as handle:
        for raw in handle:
            line = raw.rstrip("\n\r")
            if line.startswith("^SAMPLE = "):
                flush(accession, current, output)
                current = {"^SAMPLE": [line.split(" = ", 1)[1]]}
                continue
            if current is None or not line.startswith("!") or " = " not in line:
                continue
            key, value = line.split(" = ", 1)
            if key in KEEP:
                current.setdefault(key, []).append(value)
    flush(accession, current, output)
    return output


def main():
    all_rows = []
    summaries = []
    paths = [path for path in GEO.glob("*/*_family.soft.gz") if not path.name.startswith("._")]
    for path in sorted(paths):
        rows = parse_soft(path)
        if not rows:
            raise RuntimeError(f"No samples parsed from {path}")
        all_rows.extend(rows)
        summaries.append({
            "series": rows[0]["series"],
            "samples": len(rows),
            "platforms": ";".join(sorted({row["platform"] for row in rows if row["platform"]})),
            "unique_titles": len({row["title"] for row in rows}),
            "unique_gsm": len({row["gsm"] for row in rows}),
        })
    OUT.parent.mkdir(parents=True, exist_ok=True)
    with OUT.open("w", newline="") as handle:
        fields = list(all_rows[0])
        writer = csv.DictWriter(handle, delimiter="\t", fieldnames=fields)
        writer.writeheader()
        writer.writerows(all_rows)
    with SUMMARY.open("w", newline="") as handle:
        fields = list(summaries[0])
        writer = csv.DictWriter(handle, delimiter="\t", fieldnames=fields)
        writer.writeheader()
        writer.writerows(summaries)
    print(f"SOFT_PARSE_OK series={len(summaries)} samples={len(all_rows)}")


if __name__ == "__main__":
    main()
