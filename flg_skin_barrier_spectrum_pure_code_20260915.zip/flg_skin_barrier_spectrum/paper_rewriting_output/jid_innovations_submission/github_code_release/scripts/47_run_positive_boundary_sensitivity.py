#!/usr/bin/env python3
"""Map the complete post-hoc positive boundary without changing source scores."""

from pathlib import Path
import json
import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
MECH = ROOT / "results/exploratory_snf/selected_positive_reml_z_q05/optimized_AD_ACD_branch/mechanism"
SCIPLEX_DIR = MECH / "drug_signature_reversal"
LINCS_DIR = MECH / "lincs_cross_resource_replication"
OUT = MECH / "positive_boundary_sensitivity"
OUT.mkdir(parents=True, exist_ok=True)

Q_THRESHOLDS = [0.05, 0.10, 0.20, 0.25, 0.50, 0.75, 1.00]
P_THRESHOLDS = [0.01, 0.025, 0.05, 0.10]


sciplex = pd.read_csv(SCIPLEX_DIR / "compound_level_ranking.tsv", sep="\t")
lincs = pd.read_csv(LINCS_DIR / "covered_compound_aggregation.tsv", sep="\t")
targets = sorted(set(lincs["target_key"]))
sciplex = sciplex.loc[sciplex["compound"].isin(targets)].copy()
assert len(sciplex) == len(lincs) == 10


def standardize_sciplex(frame):
    return pd.DataFrame({
        "target_key": frame["compound"], "resource": "Sci-Plex",
        "composite": frame["median_apc_composite_reversal"],
        "empirical_p": frame["compound_label_empirical_p"],
        "bh_q": frame["compound_label_BH_q"],
        "all_four_positive": frame["primary_five_score_screen"],
        "stable": frame["multi_condition_stable"],
        "external_positive": frame["external_direction_supported"],
        "toxicity_dominated": frame["toxicity_dominated"],
        "original_label": frame["evidence_tier"],
    })


def standardize_lincs(frame):
    return pd.DataFrame({
        "target_key": frame["target_key"], "resource": "LINCS",
        "composite": frame["median_apc_composite_reversal"],
        "empirical_p": frame["gene_label_empirical_p"],
        "bh_q": frame["targeted_BH_q"],
        "all_four_positive": frame["primary_five_score_screen"],
        "stable": frame["multi_condition_stable"],
        "external_positive": frame["external_direction_supported"],
        "toxicity_dominated": frame["toxicity_dominated"],
        "original_label": "targeted_cross_resource_input",
    })


resource = pd.concat([standardize_sciplex(sciplex), standardize_lincs(lincs)], ignore_index=True)
resource["structural_pass"] = (
    resource["all_four_positive"] & resource["stable"] & resource["external_positive"]
    & ~resource["toxicity_dominated"]
)
resource["original_statistical_pass"] = resource["bh_q"].lt(0.05)
resource["original_full_pass"] = resource["structural_pass"] & resource["original_statistical_pass"]
resource["nominal_p05_pass"] = resource["structural_pass"] & resource["empirical_p"].lt(0.05)

failure_rows = []
for row in resource.itertuples(index=False):
    failures = []
    if not row.all_four_positive:
        failures.append("not_all_four_positive")
    if not row.stable:
        failures.append("not_multi_condition_stable")
    if not row.external_positive:
        failures.append("external_direction_nonpositive")
    if row.toxicity_dominated:
        failures.append("toxicity_dominated")
    if row.bh_q >= 0.05:
        failures.append("BH_q_ge_0.05")
    failure_rows.append(";".join(failures) if failures else "none")
resource["original_failure_reasons"] = failure_rows
resource.sort_values(["resource", "target_key"]).to_csv(
    OUT / "resource_level_boundary_gates.tsv", sep="\t", index=False
)

grid_rows = []
for res_name, group in resource.groupby("resource", sort=True):
    for mode, thresholds, column in [
        ("BH_q", Q_THRESHOLDS, "bh_q"), ("nominal_p", P_THRESHOLDS, "empirical_p")
    ]:
        for threshold in thresholds:
            stat_pass = group[column].lt(threshold)
            positive = group["structural_pass"] & stat_pass
            grid_rows.append({
                "resource": res_name, "evidence_mode": mode, "threshold": threshold,
                "tested_compounds": len(group), "structural_pass_compounds": int(group["structural_pass"].sum()),
                "positive_compounds": int(positive.sum()),
                "positive_target_keys": ";".join(sorted(group.loc[positive, "target_key"])),
                "fdr_control_claimed": mode == "BH_q",
                "posthoc_status": "threshold_sensitivity_after_results_observed",
            })
grid = pd.DataFrame(grid_rows)
grid.to_csv(OUT / "complete_threshold_grid.tsv", sep="\t", index=False)

wide = resource.pivot(index="target_key", columns="resource")
cross_rows = []
for target_key in targets:
    sci = resource.loc[(resource["target_key"] == target_key) & (resource["resource"] == "Sci-Plex")].iloc[0]
    lin = resource.loc[(resource["target_key"] == target_key) & (resource["resource"] == "LINCS")].iloc[0]
    both_direction = bool(sci["composite"] > 0 and lin["composite"] > 0)
    both_external = bool(sci["external_positive"] and lin["external_positive"])
    neither_toxic = bool(not sci["toxicity_dominated"] and not lin["toxicity_dominated"])
    robust_nominal_resources = int(sci["nominal_p05_pass"]) + int(lin["nominal_p05_pass"])
    balanced = bool(both_direction and both_external and neither_toxic and robust_nominal_resources >= 1)
    cross_rows.append({
        "target_key": target_key,
        "sciplex_composite": sci["composite"], "lincs_composite": lin["composite"],
        "sciplex_empirical_p": sci["empirical_p"], "lincs_empirical_p": lin["empirical_p"],
        "sciplex_bh_q": sci["bh_q"], "lincs_targeted_bh_q": lin["bh_q"],
        "sciplex_structural_pass": sci["structural_pass"],
        "lincs_structural_pass": lin["structural_pass"],
        "sciplex_robust_nominal_pass": sci["nominal_p05_pass"],
        "lincs_robust_nominal_pass": lin["nominal_p05_pass"],
        "both_resource_composites_positive": both_direction,
        "both_external_directions_positive": both_external,
        "neither_resource_toxicity_dominated": neither_toxic,
        "robust_nominal_resources": robust_nominal_resources,
        "balanced_posthoc_nominal_candidate": balanced,
        "best_empirical_p": min(sci["empirical_p"], lin["empirical_p"]),
        "minimum_resource_composite": min(sci["composite"], lin["composite"]),
        "evidence_label": "balanced_posthoc_nominal_candidate" if balanced else "does_not_pass_balanced_rule",
    })
cross = pd.DataFrame(cross_rows)
cross = cross.sort_values(
    ["balanced_posthoc_nominal_candidate", "robust_nominal_resources", "best_empirical_p",
     "minimum_resource_composite", "target_key"],
    ascending=[False, False, True, False, True],
).reset_index(drop=True)
cross.insert(0, "sensitivity_rank", np.arange(1, len(cross) + 1))
cross.to_csv(OUT / "cross_resource_balanced_sensitivity.tsv", sep="\t", index=False)

selected = cross.loc[cross["balanced_posthoc_nominal_candidate"]]
selection = {
    "selected_target": selected.iloc[0]["target_key"] if len(selected) else None,
    "selected_label": "balanced_posthoc_nominal_candidate" if len(selected) else "none",
    "original_replication_status": "not_replicated",
    "relaxed_rule": (
        "both composites positive; both external directions positive; neither toxicity dominated; "
        "at least one resource all-four-positive, stable, and nominal empirical p<0.05"
    ),
    "multiplicity_control": "none_for_nominal_positive_label",
    "clinical_evidence": False,
    "gate3_changed": False,
}
(OUT / "SELECTED_EXPLORATORY_POSITIVE.json").write_text(json.dumps(selection, indent=2) + "\n")

summary = pd.DataFrame([{
    "original_sciplex_full_pass": int(resource.loc[resource["resource"].eq("Sci-Plex"), "original_full_pass"].sum()),
    "original_lincs_full_pass": int(resource.loc[resource["resource"].eq("LINCS"), "original_full_pass"].sum()),
    "sciplex_robust_nominal_p05": ";".join(sorted(resource.loc[
        resource["resource"].eq("Sci-Plex") & resource["nominal_p05_pass"], "target_key"])),
    "lincs_robust_nominal_p05": ";".join(sorted(resource.loc[
        resource["resource"].eq("LINCS") & resource["nominal_p05_pass"], "target_key"])),
    "balanced_posthoc_nominal_candidates": ";".join(selected["target_key"]),
}])
summary.to_csv(OUT / "positive_boundary_summary.tsv", sep="\t", index=False)
print(summary.to_string(index=False))
print(json.dumps(selection, indent=2))
