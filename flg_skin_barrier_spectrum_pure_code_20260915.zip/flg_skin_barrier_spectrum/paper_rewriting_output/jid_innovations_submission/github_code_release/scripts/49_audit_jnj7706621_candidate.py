#!/usr/bin/env python3
"""Audit JNJ-7706621 context transportability and CDK2-token specificity."""

from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
LOCAL_PACKAGES = ROOT / "environment/python_packages"
if LOCAL_PACKAGES.exists():
    sys.path.insert(0, str(LOCAL_PACKAGES))

import numpy as np
import pandas as pd
from scipy.stats import spearmanr, wilcoxon


SEED = 20260825
N_BOOT = 5000
MECH = ROOT / "results/exploratory_snf/selected_positive_reml_z_q05/optimized_AD_ACD_branch/mechanism"
LINCS = MECH / "lincs_cross_resource_replication"
OUT = MECH / "jnj7706621_candidate_audit"
OUT.mkdir(parents=True, exist_ok=True)
CDK2_COMPOUNDS = ["JNJ-7706621", "BMS-265246", "BMS-536924", "Bosutinib", "PF-573228", "Roscovitine"]
COMPONENTS = [
    "apc_genome_rank_reversal", "apc_genome_weighted_reversal",
    "apc_program_rank_reversal", "apc_program_weighted_reversal",
]


def bh(pvalues):
    p = np.asarray(pvalues, dtype=float)
    order = np.argsort(p)
    ranked = p[order]
    adjusted = np.minimum.accumulate((ranked * len(p) / np.arange(1, len(p) + 1))[::-1])[::-1]
    out = np.empty_like(adjusted)
    out[order] = np.minimum(adjusted, 1.0)
    return out


def cluster_bootstrap_ci(group, rng):
    clusters = [x["apc_composite_reversal"].to_numpy(float) for _, x in group.groupby("cell_line")]
    if not clusters:
        return np.nan, np.nan
    medians = np.empty(N_BOOT, dtype=float)
    for index in range(N_BOOT):
        sampled = rng.integers(0, len(clusters), size=len(clusters))
        medians[index] = np.median(np.concatenate([clusters[i] for i in sampled]))
    return tuple(np.quantile(medians, [0.025, 0.975]))


condition = pd.read_csv(LINCS / "condition_level_lincs_reversal.tsv", sep="\t")
jnj = condition.loc[condition["target_key"].eq("JNJ-7706621")].copy()
assert len(jnj) == 297 and jnj["cell_line"].nunique() == 98
jnj["skin_context"] = np.where(jnj["tissue"].eq("skin of body"), "skin", "non_skin")
jnj["dose_uM"] = jnj["dose"].str.replace(" uM", "", regex=False).astype(float)
jnj["time_h"] = jnj["time"].str.replace(" h", "", regex=False).astype(float)


def summarize(group, dimension, level, rng):
    lo, hi = cluster_bootstrap_ci(group, rng)
    row = {
        "dimension": dimension, "level": str(level), "n_conditions": len(group),
        "n_cell_lines": group["cell_line"].nunique(), "n_tissues": group["tissue"].nunique(),
    }
    for column in COMPONENTS:
        row[f"median_{column}"] = float(group[column].median())
    row.update({
        "median_composite": float(group["apc_composite_reversal"].median()),
        "cluster_bootstrap_ci_low": lo, "cluster_bootstrap_ci_high": hi,
        "positive_fraction": float(group["apc_composite_reversal"].gt(0).mean()),
        "median_external_composite": float(group["external_composite_reversal"].median()),
        "external_positive_fraction": float(group["external_composite_reversal"].gt(0).mean()),
        "toxicity_dominated_fraction": float(group["condition_toxicity_dominated"].mean()),
        "median_toxicity_index": float(group["toxicity_index"].median()),
        "median_tox_removed_composite": float(group["tox_removed_apc_composite_reversal"].median()),
    })
    return row


rng = np.random.default_rng(SEED)
stratum_rows = [summarize(jnj, "overall", "all", rng)]
for dimension, column in [
    ("dose", "dose"), ("time", "time"), ("skin_context", "skin_context"), ("tissue", "tissue")
]:
    for level, group in jnj.groupby(column, sort=True):
        stratum_rows.append(summarize(group, dimension, level, rng))
strata = pd.DataFrame(stratum_rows)
strata.to_csv(OUT / "context_stratum_summary.tsv", sep="\t", index=False)

# Preserve all 16 skin conditions for direct review.
jnj.loc[jnj["skin_context"].eq("skin")].sort_values(
    ["cell_line", "dose_uM", "time_h", "signature_id"]
).to_csv(OUT / "skin_condition_scores.tsv", sep="\t", index=False)

# Leave-one-level sensitivity for each prespecified context factor.
deletion_rows = []
for dimension, column in [("dose", "dose"), ("time", "time"), ("tissue", "tissue")]:
    for level in sorted(jnj[column].astype(str).unique()):
        kept = jnj.loc[jnj[column].astype(str).ne(level)]
        deletion_rows.append({
            "dimension": dimension, "deleted_level": level, "remaining_conditions": len(kept),
            "remaining_cell_lines": kept["cell_line"].nunique(),
            "remaining_median_composite": float(kept["apc_composite_reversal"].median()),
            "remaining_positive_fraction": float(kept["apc_composite_reversal"].gt(0).mean()),
            "remaining_median_external": float(kept["external_composite_reversal"].median()),
            "remaining_toxicity_dominated_fraction": float(kept["condition_toxicity_dominated"].mean()),
        })
deletions = pd.DataFrame(deletion_rows)
deletions.to_csv(OUT / "leave_one_context_robustness.tsv", sep="\t", index=False)

# Matched within-cell context trends. Replicate signatures are median-collapsed.
collapsed = jnj.groupby(["cell_line", "time_h", "dose_uM"], as_index=False)[
    "apc_composite_reversal"
].median()
dose_trend_rows = []
for (cell, time_h), group in collapsed.groupby(["cell_line", "time_h"]):
    if group["dose_uM"].nunique() < 2:
        continue
    rho = spearmanr(group["dose_uM"], group["apc_composite_reversal"]).statistic
    dose_trend_rows.append({
        "cell_line": cell, "time_h": time_h, "dose_levels": group["dose_uM"].nunique(),
        "spearman_dose_composite": rho, "lowest_dose_composite": group.loc[group["dose_uM"].idxmin(), "apc_composite_reversal"],
        "highest_dose_composite": group.loc[group["dose_uM"].idxmax(), "apc_composite_reversal"],
    })
dose_trends = pd.DataFrame(dose_trend_rows)
dose_trends.to_csv(OUT / "matched_dose_trends.tsv", sep="\t", index=False)

collapsed_time = jnj.groupby(["cell_line", "dose_uM", "time_h"], as_index=False)[
    "apc_composite_reversal"
].median()
time_trend_rows = []
for (cell, dose), group in collapsed_time.groupby(["cell_line", "dose_uM"]):
    if group["time_h"].nunique() < 2:
        continue
    rho = spearmanr(group["time_h"], group["apc_composite_reversal"]).statistic
    time_trend_rows.append({
        "cell_line": cell, "dose_uM": dose, "time_levels": group["time_h"].nunique(),
        "spearman_time_composite": rho, "earliest_composite": group.loc[group["time_h"].idxmin(), "apc_composite_reversal"],
        "latest_composite": group.loc[group["time_h"].idxmax(), "apc_composite_reversal"],
    })
time_trends = pd.DataFrame(time_trend_rows)
time_trends.to_csv(OUT / "matched_time_trends.tsv", sep="\t", index=False)

# Exact cell-line × dose × time comparisons against all other CDK2-token drugs.
class_conditions = condition.loc[condition["target_key"].isin(CDK2_COMPOUNDS)].copy()
class_collapsed = class_conditions.groupby(
    ["target_key", "cell_line", "dose", "time"], as_index=False
)["apc_composite_reversal"].median()
jbase = class_collapsed.loc[class_collapsed["target_key"].eq("JNJ-7706621")].drop(columns="target_key")
comparison_rows = []
for comparator in CDK2_COMPOUNDS[1:]:
    other = class_collapsed.loc[class_collapsed["target_key"].eq(comparator)].drop(columns="target_key")
    matched = jbase.merge(other, on=["cell_line", "dose", "time"], suffixes=("_jnj", "_comparator"))
    diff = matched["apc_composite_reversal_jnj"] - matched["apc_composite_reversal_comparator"]
    p = float(wilcoxon(diff, alternative="greater").pvalue) if len(diff) and np.any(diff != 0) else 1.0
    comparison_rows.append({
        "comparator": comparator, "matched_strata": len(matched),
        "matched_cell_lines": matched["cell_line"].nunique(),
        "median_jnj": float(matched["apc_composite_reversal_jnj"].median()) if len(matched) else np.nan,
        "median_comparator": float(matched["apc_composite_reversal_comparator"].median()) if len(matched) else np.nan,
        "median_paired_difference_jnj_minus_comparator": float(diff.median()) if len(diff) else np.nan,
        "positive_difference_fraction": float(diff.gt(0).mean()) if len(diff) else np.nan,
        "paired_wilcoxon_greater_p": p,
    })
comparisons = pd.DataFrame(comparison_rows)
comparisons["paired_wilcoxon_BH_q"] = bh(comparisons["paired_wilcoxon_greater_p"])
comparisons.to_csv(OUT / "matched_cdk2_token_comparison.tsv", sep="\t", index=False)

covered = pd.read_csv(LINCS / "covered_compound_aggregation.tsv", sep="\t")
class_rank = covered.loc[covered["target_key"].isin(CDK2_COMPOUNDS), [
    "target_key", "n_conditions", "n_cell_lines", "median_apc_composite_reversal",
    "gene_label_empirical_p", "targeted_BH_q", "multi_condition_stable",
    "external_direction_supported", "toxicity_dominated",
]].sort_values("median_apc_composite_reversal", ascending=False).reset_index(drop=True)
class_rank.insert(0, "cdk2_token_rank", np.arange(1, len(class_rank) + 1))
class_rank.to_csv(OUT / "cdk2_token_class_ranking.tsv", sep="\t", index=False)

# Source-backed pharmacology matrix: identity and activity are evidence; disease
# relevance remains an inference and is not upgraded by these oncology studies.
pharmacology = pd.DataFrame([
    {
        "source": "Emanuel et al. 2005 Cancer Research", "source_type": "primary preclinical study",
        "identifier": "PMID:16204078; DOI:10.1158/0008-5472.CAN-05-0882",
        "url": "https://pubmed.ncbi.nlm.nih.gov/16204078/",
        "supported_claim": "dual inhibition of several CDKs and Aurora kinases; cell-cycle arrest, apoptosis and dose-related cytotoxicity in tumor models",
        "limitation": "oncology cell lines/xenografts; not skin inflammatory disease; compound is not CDK2-selective",
    },
    {
        "source": "Matsuhashi et al. 2012", "source_type": "primary mechanistic cell study",
        "identifier": "PMID:22463590; DOI:10.2174/156800912801784839",
        "url": "https://pubmed.ncbi.nlm.nih.gov/22463590/",
        "supported_claim": "G1/G2 arrest and mitotic defects consistent with combined CDK/Aurora pathway interference",
        "limitation": "cancer-cell mechanism study; does not isolate CDK2 or establish disease benefit",
    },
    {
        "source": "LINCS Small Molecules Portal", "source_type": "official compound registry",
        "identifier": "LSM-5294; PubChem CID:5330790; ChEMBL:CHEMBL191003",
        "url": "https://lincsportal.ccs.miami.edu/SmallMolecules/view/LSM-5294",
        "supported_claim": "compound identity used for LINCS matching",
        "limitation": "registry identity is not efficacy, selectivity or safety evidence",
    },
])
pharmacology.to_csv(OUT / "pharmacology_evidence_matrix.tsv", sep="\t", index=False)

# Frozen disposition labels.
lookup = strata.set_index(["dimension", "level"])
dose_positive = bool((strata.loc[strata["dimension"].eq("dose"), "median_composite"] > 0).all())
time_positive = bool((strata.loc[strata["dimension"].eq("time"), "median_composite"] > 0).all())
skin_positive = bool(lookup.loc[("skin_context", "skin"), "median_composite"] > 0)
non_skin_positive = bool(lookup.loc[("skin_context", "non_skin"), "median_composite"] > 0)
loo_positive = bool((deletions["remaining_median_composite"] > 0).all())
overall_ci_positive = bool(lookup.loc[("overall", "all"), "cluster_bootstrap_ci_low"] > 0)
skin_ci_positive = bool(lookup.loc[("skin_context", "skin"), "cluster_bootstrap_ci_low"] > 0)
median_direction_bundle = dose_positive and time_positive and skin_positive and non_skin_positive and loo_positive
if median_direction_bundle and overall_ci_positive and skin_ci_positive:
    transport = "broad_transportable"
elif median_direction_bundle:
    transport = "directionally_broad_uncertain"
else:
    transport = "context_limited"

positive_comparator_diffs = int(comparisons["median_paired_difference_jnj_minus_comparator"].gt(0).sum())
significant_comparators = int(comparisons["paired_wilcoxon_BH_q"].lt(0.05).sum())
jnj_rank = int(class_rank.loc[class_rank["target_key"].eq("JNJ-7706621"), "cdk2_token_rank"].iloc[0])
class_descriptive = bool(jnj_rank == 1 and positive_comparator_diffs >= 4)
class_inferential = bool(class_descriptive and significant_comparators >= 3)

disposition = {
    "candidate": "JNJ-7706621", "input_label": "balanced_posthoc_nominal_candidate",
    "transportability": transport, "dose_medians_all_positive": dose_positive,
    "time_medians_all_positive": time_positive, "skin_median_positive": skin_positive,
    "non_skin_median_positive": non_skin_positive, "all_leave_one_context_medians_positive": loo_positive,
    "overall_cluster_bootstrap_lower_positive": overall_ci_positive,
    "skin_cluster_bootstrap_lower_positive": skin_ci_positive,
    "cdk2_token_rank": jnj_rank, "positive_matched_comparator_differences": positive_comparator_diffs,
    "BH_significant_matched_comparators": significant_comparators,
    "class_leading_descriptive": class_descriptive, "class_leading_inferential": class_inferential,
    "cdk2_specificity_supported": False,
    "specificity_note": "known multi-CDK/Aurora inhibitor; transcriptomic class comparison cannot isolate CDK2",
    "transportability_scope": "prespecified composite-direction and deletion criteria only",
    "negative_tissue_median_levels": sorted(strata.loc[
        strata["dimension"].eq("tissue") & strata["median_composite"].le(0), "level"
    ].tolist()),
    "nonpositive_tox_removed_primary_levels": sorted(strata.loc[
        strata["dimension"].isin(["dose", "time", "skin_context"])
        & strata["median_tox_removed_composite"].le(0), ["dimension", "level"]
    ].astype(str).agg("=".join, axis=1).tolist()),
    "nonpositive_external_primary_levels": sorted(strata.loc[
        strata["dimension"].isin(["dose", "time", "skin_context"])
        & strata["median_external_composite"].le(0), ["dimension", "level"]
    ].astype(str).agg("=".join, axis=1).tolist()),
    "formal_replication": False, "clinical_evidence": False, "gate3_changed": False,
}
(OUT / "CANDIDATE_DISPOSITION.json").write_text(json.dumps(disposition, indent=2) + "\n")

run = {
    "seed": SEED, "cell_line_cluster_bootstraps": N_BOOT, "jnj_conditions": len(jnj),
    "jnj_cell_lines": jnj["cell_line"].nunique(), "skin_conditions": int(jnj["skin_context"].eq("skin").sum()),
    "dose_trend_strata": len(dose_trends), "time_trend_strata": len(time_trends),
    "cdk2_token_compounds": len(CDK2_COMPOUNDS), "gpu_hours": 0,
}
(OUT / "RUN_PARAMETERS.json").write_text(json.dumps(run, indent=2) + "\n")
print(strata.loc[strata["dimension"].isin(["overall", "dose", "time", "skin_context"]), [
    "dimension", "level", "n_conditions", "median_composite", "cluster_bootstrap_ci_low",
    "cluster_bootstrap_ci_high", "positive_fraction", "toxicity_dominated_fraction",
]].to_string(index=False))
print(comparisons.to_string(index=False))
print(json.dumps(disposition, indent=2))
