#!/usr/bin/env Rscript

.libPaths(c(file.path("environment", "R_libs"), .libPaths()))
suppressPackageStartupMessages({
  library(data.table); library(metafor); library(limma); library(parallel)
})

set.seed(20260825)
dir.create("results/tables/meta", recursive = TRUE, showWarnings = FALSE)
dir.create("results/tables/pathways", recursive = TRUE, showWarnings = FALSE)

groups <- list(
  AD = c("AD_GSE121212_acute", "AD_GSE32924", "AD_GSE36842_acute"),
  ACD = c("ACD_GSE282562", "ACD_GSE6281_48h"),
  PSORIASIS = c("PSO_GSE13355", "PSO_GSE121212"),
  HS = c("HS_GSE137141", "HS_GSE72702")
)

read_effect <- function(id) {
  x <- fread(file.path("results/tables/cohort_effects", paste0(id, ".tsv")), select = c("gene", "logFC", "SE", "t", "p_value", "FDR"))
  setnames(x, setdiff(names(x), "gene"), paste0(setdiff(names(x), "gene"), "__", id))
  x
}

fit_one <- function(i, dat, cohorts) {
  yi <- as.numeric(dat[i, paste0("logFC__", cohorts), with = FALSE])
  sei <- as.numeric(dat[i, paste0("SE__", cohorts), with = FALSE])
  valid <- is.finite(yi) & is.finite(sei) & sei > 0
  yi <- yi[valid]; sei <- sei[valid]
  if (length(yi) < 2) return(rep(NA_real_, 13))
  # Modified Knapp-Hartung: prevent the small-k adjustment from producing
  # standard errors smaller than the conventional random-effects SE.
  model <- try(suppressWarnings(rma.uni(yi = yi, sei = sei, method = "REML", test = "adhoc")), silent = TRUE)
  if (inherits(model, "try-error")) model <- rma.uni(yi = yi, sei = sei, method = "REML", test = "z")
  beta <- as.numeric(model$b); se <- model$se
  pi_half <- 1.96 * sqrt(se^2 + model$tau2)
  loo <- vapply(seq_along(yi), function(j) {
    keep <- seq_along(yi) != j
    w <- 1 / sei[keep]^2
    sum(w * yi[keep]) / sum(w)
  }, numeric(1))
  stable <- all(sign(loo[loo != 0]) == sign(beta))
  c(beta, se, model$ci.lb, model$ci.ub, model$pval, model$tau2, model$I2, model$QE, model$QEp,
    beta - pi_half, beta + pi_half, sum(sign(yi) == sign(beta)), as.numeric(stable))
}

meta_results <- list()
available_cores <- detectCores(logical = FALSE)
if (!is.finite(available_cores) || available_cores < 1) available_cores <- 1L
for (disease in names(groups)) {
  cohorts <- groups[[disease]]
  merged <- Reduce(function(a, b) merge(a, b, by = "gene", all = FALSE), lapply(cohorts, read_effect))
  values <- mclapply(seq_len(nrow(merged)), fit_one, dat = merged, cohorts = cohorts,
                     mc.cores = min(4L, max(1L, available_cores - 1L)))
  values <- do.call(rbind, values)
  colnames(values) <- c("meta_logFC", "SE", "CI_low", "CI_high", "p_value", "tau2", "I2", "Q", "Q_p_value",
                        "prediction_low_approx", "prediction_high_approx", "direction_agree_n", "LODO_direction_stable")
  result <- cbind(merged[, .(gene)], as.data.table(values))
  result[, `:=`(FDR = p.adjust(p_value, "BH"), cohorts = length(cohorts), disease = disease)]
  setorder(result, p_value)
  fwrite(result, file.path("results/tables/meta", paste0(disease, "_gene_meta.tsv")), sep = "\t")
  meta_results[[disease]] <- result
}

# Read Reactome v97 GMT and convert sets to indices for a named statistic.
gmt_lines <- readLines("data/raw/pathways/reactome_v97/ReactomePathways.gmt")
gmt <- lapply(strsplit(gmt_lines, "\t", fixed = TRUE), function(x) x[-c(1, 2)])
names(gmt) <- vapply(strsplit(gmt_lines, "\t", fixed = TRUE), `[`, character(1), 1)

run_camera <- function(statistic, id, disease, layer) {
  statistic <- statistic[is.finite(statistic)]
  idx <- lapply(gmt, function(genes) which(names(statistic) %in% genes))
  idx <- idx[lengths(idx) >= 10 & lengths(idx) <= 500]
  result <- as.data.table(cameraPR(statistic, index = idx, inter.gene.cor = 0.01, use.ranks = TRUE), keep.rownames = "pathway")
  result[, `:=`(cohort = id, disease = disease, layer = layer,
                signed_z = qnorm(pmax(PValue / 2, .Machine$double.xmin), lower.tail = FALSE) * ifelse(Direction == "Up", 1, -1))]
  setorder(result, PValue)
  fwrite(result, file.path("results/tables/pathways", paste0(id, "_reactome_v97.tsv")), sep = "\t")
  result
}

pathway_results <- list()
all_cohorts <- unique(unlist(groups))
single_cohorts <- c("ACNE_GSE53795", "ROSACEA_GSE65914", "ICD_GSE18206_SLS_24h", "ICD_GSE18206_NON_24h")
cohort_disease <- c(AD_GSE121212_acute="AD", AD_GSE32924="AD", AD_GSE36842_acute="AD",
                    ACD_GSE282562="ACD", ACD_GSE6281_48h="ACD", PSO_GSE13355="PSORIASIS",
                    PSO_GSE121212="PSORIASIS", HS_GSE137141="HS", HS_GSE72702="HS",
                    ACNE_GSE53795="ACNE", ROSACEA_GSE65914="ROSACEA",
                    ICD_GSE18206_SLS_24h="ICD", ICD_GSE18206_NON_24h="ICD")
for (id in c(all_cohorts, single_cohorts)) {
  x <- fread(file.path("results/tables/cohort_effects", paste0(id, ".tsv")))
  stat <- x$t; names(stat) <- x$gene
  pathway_results[[id]] <- run_camera(stat, id, cohort_disease[[id]], "cohort")
}
for (disease in names(meta_results)) {
  x <- meta_results[[disease]]
  stat <- x$meta_logFC / x$SE; names(stat) <- x$gene
  pathway_results[[paste0(disease, "_META")]] <- run_camera(stat, paste0(disease, "_META"), disease, "gene_meta")
}

path_all <- rbindlist(pathway_results, fill = TRUE)
fwrite(path_all, "results/tables/pathways/all_reactome_v97.tsv", sep = "\t")

# Cohort replication audit by disease and pathway.
replication <- path_all[layer == "cohort" & cohort %in% all_cohorts,
                        .(cohorts_tested = uniqueN(cohort), cohorts_FDR_005 = sum(FDR < .05),
                          up_n = sum(Direction == "Up"), down_n = sum(Direction == "Down"),
                          all_direction_agree = uniqueN(Direction) == 1), by = .(disease, pathway)]
replication[, replicated := cohorts_FDR_005 >= 2 & all_direction_agree]
fwrite(replication, "results/tables/pathways/pathway_replication_audit.tsv", sep = "\t")

summary <- rbindlist(lapply(names(meta_results), function(disease_id) {
  x <- meta_results[[disease_id]]
  data.table(disease = disease_id, genes = nrow(x), FDR_005 = sum(x$FDR < .05, na.rm = TRUE),
             direction_complete = sum(x$direction_agree_n == x$cohorts, na.rm = TRUE),
             LODO_direction_stable = sum(x$LODO_direction_stable == 1, na.rm = TRUE),
             pathways_replicated = replication[disease == disease_id & replicated == TRUE, .N])
}))
fwrite(summary, "results/tables/meta/meta_summary.tsv", sep = "\t")
cat("META_PATHWAY_OK diseases=", length(meta_results), " pathways=", nrow(path_all), "\n", sep = "")
