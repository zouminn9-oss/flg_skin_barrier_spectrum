#!/usr/bin/env python3
"""Score exploratory computational Sci-Plex drug-signature reversal."""

from pathlib import Path
import json
import re
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
LOCAL_PACKAGES = ROOT / "environment/python_packages"
if LOCAL_PACKAGES.exists():
    sys.path.insert(0, str(LOCAL_PACKAGES))

import numpy as np
import pandas as pd
from scipy.stats import rankdata, spearmanr, mannwhitneyu


SEED = 20260825
N_PERM = 1000
MECH = ROOT / "results/exploratory_snf/selected_positive_reml_z_q05/optimized_AD_ACD_branch/mechanism"
OUT = MECH / "drug_signature_reversal"
COHORTS = [
    "AD_GSE121212_acute", "AD_GSE32924", "AD_GSE36842_acute",
    "ACD_GSE282562", "ACD_GSE6281_48h",
]
CANDIDATES = {
    "IRF1": ["I-2", "I-19"],
    "HSF1": ["DTHIB", "SISU-102"],
    "ATR": ["camonsertib", "ceralasertib", "elimusertib"],
    "PCNA": ["AOH1996"],
    "CDK2": ["INX-315", "AZD8421"],
    "E2F4": ["HLM006474"],
    "YY1": [],
    "E2F6": [],
}


def bh(pvalues):
    p = np.asarray(pvalues, dtype=float)
    order = np.argsort(p)
    ranked = p[order]
    adjusted = np.minimum.accumulate((ranked * len(p) / np.arange(1, len(p) + 1))[::-1])[::-1]
    out = np.empty_like(adjusted)
    out[order] = np.minimum(adjusted, 1.0)
    return out


def weighted_corr_scores(y, x, weights):
    """Negative weighted Pearson correlations, columns of y are conditions."""
    w = np.asarray(weights, dtype=np.float64)
    w = w / w.sum()
    x = np.asarray(x, dtype=np.float64)
    mx = float(w @ x)
    xc = x - mx
    my = w @ y
    yc = y - my
    cov = (w * xc) @ y
    vx = float(w @ (xc * xc))
    vy = np.sum(w[:, None] * yc * yc, axis=0)
    denom = np.sqrt(vx * vy)
    return np.divide(-cov, denom, out=np.full(y.shape[1], np.nan), where=denom > 0)


def rank_corr_scores(y, x):
    xr = rankdata(x).astype(np.float64)
    yr = rankdata(y, axis=0).astype(np.float64)
    xc = xr - xr.mean()
    yc = yr - yr.mean(axis=0)
    denom = np.sqrt(np.sum(xc * xc) * np.sum(yc * yc, axis=0))
    return np.divide(-(xc @ yc), denom, out=np.full(y.shape[1], np.nan), where=denom > 0)


def observed_four(y, x, genome_weights, program_mask, program_weights):
    return {
        "genome_rank": rank_corr_scores(y, x),
        "genome_weighted": weighted_corr_scores(y, x, genome_weights),
        "program_rank": rank_corr_scores(y[program_mask], x[program_mask]),
        "program_weighted": weighted_corr_scores(
            y[program_mask], x[program_mask], program_weights[program_mask]
        ),
    }


def permutation_composite(y, x, genome_weights, program_mask, program_weights, rng):
    """Exact common-complete gene-label null with fixed prespecified weights."""
    ncond = y.shape[1]
    # Genome rank null.
    yr = rankdata(y, axis=0).astype(np.float32)
    yc = yr - yr.mean(axis=0)
    ynorm = np.sqrt(np.sum(yc * yc, axis=0))
    xr = rankdata(x).astype(np.float32)
    perms = np.vstack([rng.permutation(len(x)) for _ in range(N_PERM)])
    xp = xr[perms]
    xp -= xp.mean(axis=1, keepdims=True)
    xnorm = np.sqrt(np.sum(xp * xp, axis=1))
    null_gr = -(xp @ yc) / (xnorm[:, None] * ynorm[None, :])

    # Genome weighted null; weights stay attached to genes as frozen reliability weights.
    w = np.asarray(genome_weights, dtype=np.float32)
    w /= w.sum()
    ymean = w @ y
    ycw = (y - ymean).astype(np.float32)
    ynormw = np.sqrt(np.sum(w[:, None] * ycw * ycw, axis=0))
    xperm = np.asarray(x, dtype=np.float32)[perms]
    xmean = xperm @ w
    ax = (xperm - xmean[:, None]) * w[None, :]
    xnormw = np.sqrt(np.sum(w[None, :] * (xperm - xmean[:, None]) ** 2, axis=1))
    null_gw = -(ax @ ycw) / (xnormw[:, None] * ynormw[None, :])

    # Program null uses a separate within-program label permutation.
    yp = y[program_mask]
    xv = np.asarray(x[program_mask], dtype=np.float32)
    wp = np.asarray(program_weights[program_mask], dtype=np.float32)
    wp /= wp.sum()
    ypr = rankdata(yp, axis=0).astype(np.float32)
    yprc = ypr - ypr.mean(axis=0)
    yprnorm = np.sqrt(np.sum(yprc * yprc, axis=0))
    xpr = rankdata(xv).astype(np.float32)
    pperm = np.vstack([rng.permutation(len(xv)) for _ in range(N_PERM)])
    xprp = xpr[pperm]
    xprp -= xprp.mean(axis=1, keepdims=True)
    xprnorm = np.sqrt(np.sum(xprp * xprp, axis=1))
    null_pr = -(xprp @ yprc) / (xprnorm[:, None] * yprnorm[None, :])

    ypmean = wp @ yp
    ypc = (yp - ypmean).astype(np.float32)
    ypnorm = np.sqrt(np.sum(wp[:, None] * ypc * ypc, axis=0))
    xpp = xv[pperm]
    xpmean = xpp @ wp
    ap = (xpp - xpmean[:, None]) * wp[None, :]
    xpnorm = np.sqrt(np.sum(wp[None, :] * (xpp - xpmean[:, None]) ** 2, axis=1))
    null_pw = -(ap @ ypc) / (xpnorm[:, None] * ypnorm[None, :])
    assert null_gr.shape == null_gw.shape == null_pr.shape == null_pw.shape == (N_PERM, ncond)
    return (null_gr + null_gw + null_pr + null_pw) / 4.0


def pairwise_four(effects, stat, genome_weights, program_weights, program_mask):
    rows = []
    for j in range(effects.shape[1]):
        valid = np.isfinite(effects[:, j]) & np.isfinite(stat)
        pv = valid & program_mask
        y, x = effects[valid, j], stat[valid]
        yp, xp = effects[pv, j], stat[pv]
        gr = -spearmanr(y, x).statistic
        gw = weighted_corr_scores(y[:, None], x, genome_weights[valid])[0]
        pr = -spearmanr(yp, xp).statistic
        pw = weighted_corr_scores(yp[:, None], xp, program_weights[pv])[0]
        rows.append((valid.sum(), pv.sum(), gr, gw, pr, pw, np.mean([gr, gw, pr, pw])))
    return np.asarray(rows)


def compound_label_p(scores, sizes, rng):
    observed = []
    offsets = np.cumsum([0] + list(sizes))
    for lo, hi in zip(offsets[:-1], offsets[1:]):
        observed.append(np.median(scores[lo:hi]))
    null = np.empty((N_PERM, len(sizes)), dtype=np.float32)
    for b in range(N_PERM):
        shuffled = rng.permutation(scores)
        for j, (lo, hi) in enumerate(zip(offsets[:-1], offsets[1:])):
            null[b, j] = np.median(shuffled[lo:hi])
    observed = np.asarray(observed)
    p = (1 + np.sum(null >= observed[None, :], axis=0)) / (N_PERM + 1)
    return observed, p


def min_leave_one(values):
    values = np.asarray(values, dtype=float)
    if len(values) < 2:
        return np.nan
    return min(np.median(np.delete(values, i)) for i in range(len(values)))


started = time.perf_counter()
bundle = np.load(OUT / "prepared_sciplex_effects.npz")
genes = bundle["genes"].astype(str)
condition_ids = bundle["condition_ids"].astype(str)
effects = bundle["effects"].astype(np.float32)
conditions = pd.read_csv(OUT / "condition_metadata.tsv", sep="\t").set_index("condition_id").loc[condition_ids].reset_index()
disease = pd.read_csv(OUT / "locked_disease_signatures.tsv", sep="\t").set_index("gene").reindex(genes)

# Primary common-complete analysis universe.
complete = np.isfinite(effects).all(axis=1)
apc_mask = complete & disease["apc_signed_stat"].notna().to_numpy()
program_mask_global = disease["program_weight"].fillna(0).gt(0).to_numpy()
primary_mask = apc_mask
primary_program = program_mask_global[primary_mask]
y = effects[primary_mask].astype(np.float32)
x = disease.loc[primary_mask, "apc_signed_stat"].to_numpy(float)
cap = np.quantile(np.abs(x), 0.95)
genome_weights = np.minimum(np.abs(x), cap)
program_weights = disease.loc[primary_mask, "program_weight"].fillna(0).to_numpy(float)
assert y.shape == (3692, 2302)
assert primary_program.sum() == 213

primary = observed_four(y, x, genome_weights, primary_program, program_weights)
composite = np.mean(np.vstack(list(primary.values())), axis=0)
gene_null = permutation_composite(
    y, x, genome_weights, primary_program, program_weights, np.random.default_rng(SEED)
)
condition_gene_p = (1 + np.sum(gene_null >= composite[None, :], axis=0)) / (N_PERM + 1)

# Missingness sensitivity uses every available source overlap pairwise.
all_apc = disease["apc_signed_stat"].notna().to_numpy()
all_effects = effects[all_apc]
all_stat = disease.loc[all_apc, "apc_signed_stat"].to_numpy(float)
all_program = program_mask_global[all_apc]
all_genome_weights = np.minimum(np.abs(all_stat), np.quantile(np.abs(all_stat), 0.95))
all_program_weights = disease.loc[all_apc, "program_weight"].to_numpy(float)
pairwise = pairwise_four(
    all_effects, all_stat, all_genome_weights, all_program_weights, all_program
)

# Independent disease reversal on its own common-complete universe.
ext_mask = complete & disease["external_t"].notna().to_numpy()
ext_y = effects[ext_mask]
ext_x = disease.loc[ext_mask, "external_t"].to_numpy(float)
ext_prog = program_mask_global[ext_mask]
ext_gw = np.minimum(np.abs(ext_x), np.quantile(np.abs(ext_x), 0.95))
ext_pw = disease.loc[ext_mask, "program_weight"].fillna(0).to_numpy(float)
external = observed_four(ext_y, ext_x, ext_gw, ext_prog, ext_pw)
external_composite = np.mean(np.vstack(list(external.values())), axis=0)

# Five internal cohorts are an explicitly non-independent direction audit.
internal_scores = {}
for cohort in COHORTS:
    col = f"t__{cohort}"
    mask = complete & disease[col].notna().to_numpy()
    iy = effects[mask]
    ix = disease.loc[mask, col].to_numpy(float)
    iw = np.minimum(np.abs(ix), np.quantile(np.abs(ix), 0.95))
    internal_scores[cohort] = np.mean(
        np.vstack([rank_corr_scores(iy, ix), weighted_corr_scores(iy, ix, iw)]), axis=0
    )

# Toxicity axes and toxicity/cell-cycle-removed APC sensitivity.
all_complete_effects = effects[complete]
z = (all_complete_effects - all_complete_effects.mean(axis=0)) / all_complete_effects.std(axis=0, ddof=1)
tox_axes = {}
for label, column, sign in [
    ("cell_death_induction", "tox_cell_death", 1.0),
    ("translation_shutdown", "tox_translation_ribosome", -1.0),
    ("cellcycle_replication_arrest", "tox_cellcycle_replication", -1.0),
]:
    mask = disease[column].fillna(False).to_numpy()[complete]
    tox_axes[label] = sign * z[mask].mean(axis=0)
tox_index = np.max(np.vstack(list(tox_axes.values())), axis=0)

remove = disease.loc[primary_mask, "tox_any"].fillna(False).to_numpy()
kept = ~remove
kept_program = primary_program[kept]
removed_scores = observed_four(
    y[kept], x[kept], genome_weights[kept], kept_program, program_weights[kept]
)
removed_composite = np.mean(np.vstack(list(removed_scores.values())), axis=0)
attenuation = np.divide(
    composite - removed_composite, np.abs(composite),
    out=np.full_like(composite, np.nan), where=np.abs(composite) > 1e-12,
)
condition_toxic = (tox_index >= 0.5) & ((removed_composite <= 0) | (attenuation >= 0.5))

# Full condition table.
condition = conditions[["condition_id", "compound", "compound_normalized", "cell_line", "dose", "time"]].copy()
for key, values in primary.items():
    condition[f"apc_{key}_reversal"] = values
condition["apc_composite_reversal"] = composite
condition["apc_gene_label_empirical_p"] = condition_gene_p
condition["common_complete_APC_genes"] = int(primary_mask.sum())
condition["common_complete_program_genes"] = int(primary_program.sum())
condition[[
    "pairwise_APC_genes", "pairwise_program_genes", "pairwise_apc_genome_rank_reversal",
    "pairwise_apc_genome_weighted_reversal", "pairwise_apc_program_rank_reversal",
    "pairwise_apc_program_weighted_reversal", "pairwise_apc_composite_reversal",
]] = pairwise
for key, values in external.items():
    condition[f"external_{key}_reversal"] = values
condition["external_composite_reversal"] = external_composite
for cohort, values in internal_scores.items():
    condition[f"internal_{cohort}_reversal"] = values
for key, values in tox_axes.items():
    condition[key] = values
condition["toxicity_index"] = tox_index
condition["tox_removed_apc_composite_reversal"] = removed_composite
condition["tox_removal_attenuation_fraction"] = attenuation
condition["condition_toxicity_dominated"] = condition_toxic
condition.to_csv(OUT / "condition_level_reversal.tsv", sep="\t", index=False)

# Sort once by compound so permutation groups preserve the observed group sizes.
condition = condition.sort_values(["compound_normalized", "condition_id"]).reset_index(drop=True)
grouped = list(condition.groupby("compound_normalized", sort=True))
sizes = [len(group) for _, group in grouped]
ordered_scores = condition["apc_composite_reversal"].to_numpy()
observed_medians, primary_p = compound_label_p(
    ordered_scores, sizes, np.random.default_rng(SEED + 1)
)
_, external_p = compound_label_p(
    condition["external_composite_reversal"].to_numpy(), sizes, np.random.default_rng(SEED + 2)
)

compound_rows, independent_rows, internal_rows, toxicity_rows = [], [], [], []
component_cols = [f"apc_{x}_reversal" for x in primary]
for j, (compound_name, group) in enumerate(grouped):
    med = {col: float(group[col].median()) for col in component_cols}
    scores = group["apc_composite_reversal"].to_numpy()
    cell_loo = []
    for cell in sorted(group["cell_line"].unique()):
        remain = group.loc[group["cell_line"].ne(cell), "apc_composite_reversal"]
        if len(remain):
            cell_loo.append(float(remain.median()))
    min_cell_loo = min(cell_loo) if len(group["cell_line"].unique()) >= 2 else np.nan
    min_cond_loo = min_leave_one(scores)
    direction_fraction = float(np.mean(scores > 0))
    stable = bool(
        len(group) >= 2 and group["cell_line"].nunique() >= 2
        and direction_fraction >= 2 / 3 and min_cond_loo > 0 and min_cell_loo > 0
    )
    primary_screen = bool(all(value > 0 for value in med.values()) and observed_medians[j] > 0)
    removed_median = float(group["tox_removed_apc_composite_reversal"].median())
    tox_fraction = float(group["condition_toxicity_dominated"].mean())
    compound_attenuation = (
        (observed_medians[j] - removed_median) / abs(observed_medians[j])
        if abs(observed_medians[j]) > 1e-12 else np.nan
    )
    tox_dominated = bool(
        tox_fraction >= 0.5 or removed_median <= 0
        or (observed_medians[j] > 0 and removed_median < 0.5 * observed_medians[j])
    )
    compound_rows.append({
        "compound": group.iloc[0]["compound"], "compound_normalized": compound_name,
        "n_conditions": len(group), "n_cell_lines": group["cell_line"].nunique(),
        "n_doses": group["dose"].nunique(), "n_times": group["time"].nunique(),
        **{f"median_{key}": value for key, value in med.items()},
        "median_apc_composite_reversal": observed_medians[j],
        "direction_positive_fraction": direction_fraction,
        "min_leave_one_condition_median": min_cond_loo,
        "min_leave_one_cell_line_median": min_cell_loo,
        "multi_condition_stable": stable,
        "primary_five_score_screen": primary_screen,
        "compound_label_empirical_p": primary_p[j],
        "median_external_composite_reversal": float(group["external_composite_reversal"].median()),
        "external_direction_supported": bool(group["external_composite_reversal"].median() > 0),
        "toxicity_dominated_fraction": tox_fraction,
        "median_tox_removed_apc_composite_reversal": removed_median,
        "tox_removal_attenuation_fraction": compound_attenuation,
        "toxicity_dominated": tox_dominated,
    })
    independent_rows.append({
        "compound": group.iloc[0]["compound"], "compound_normalized": compound_name,
        "n_conditions": len(group),
        **{f"median_external_{key}_reversal": float(group[f"external_{key}_reversal"].median()) for key in external},
        "median_external_composite_reversal": float(group["external_composite_reversal"].median()),
        "external_direction_supported": bool(group["external_composite_reversal"].median() > 0),
        "external_compound_label_empirical_p": external_p[j],
    })
    audits = {cohort: float(group[f"internal_{cohort}_reversal"].median()) for cohort in COHORTS}
    internal_rows.append({
        "compound": group.iloc[0]["compound"], "compound_normalized": compound_name,
        **{f"median_{key}_reversal": value for key, value in audits.items()},
        "positive_internal_cohorts": sum(value > 0 for value in audits.values()),
        "internal_cohorts": len(COHORTS), "validation_status": "not_independent_upstream_contributors",
    })
    toxicity_rows.append({
        "compound": group.iloc[0]["compound"], "compound_normalized": compound_name,
        "n_conditions": len(group),
        **{f"median_{key}": float(group[key].median()) for key in tox_axes},
        "median_toxicity_index": float(group["toxicity_index"].median()),
        "toxicity_dominated_fraction": tox_fraction,
        "median_unfiltered_apc_composite_reversal": observed_medians[j],
        "median_tox_removed_apc_composite_reversal": removed_median,
        "tox_removal_attenuation_fraction": compound_attenuation,
        "toxicity_dominated": tox_dominated,
    })

compounds = pd.DataFrame(compound_rows)
compounds["compound_label_BH_q"] = bh(compounds["compound_label_empirical_p"])
compounds["evidence_tier"] = "Reject"
tier_a = (
    compounds["primary_five_score_screen"] & compounds["compound_label_BH_q"].lt(0.05)
    & compounds["multi_condition_stable"] & compounds["external_direction_supported"]
    & ~compounds["toxicity_dominated"]
)
tier_b = (
    compounds["primary_five_score_screen"] & compounds["compound_label_BH_q"].lt(0.05)
    & compounds["multi_condition_stable"] & ~compounds["external_direction_supported"]
    & ~compounds["toxicity_dominated"]
)
tier_c = (
    compounds["median_apc_composite_reversal"].gt(0)
    & compounds["compound_label_empirical_p"].lt(0.05)
    & ~compounds["toxicity_dominated"] & ~tier_a & ~tier_b
)
compounds.loc[tier_a, "evidence_tier"] = "Tier A"
compounds.loc[tier_b, "evidence_tier"] = "Tier B"
compounds.loc[tier_c, "evidence_tier"] = "Tier C"
compounds["posthoc_status"] = "exploratory_computational_hypothesis_generation"
compounds = compounds.sort_values(
    ["evidence_tier", "median_apc_composite_reversal"],
    key=lambda s: s.map({"Tier A": 0, "Tier B": 1, "Tier C": 2, "Reject": 3}) if s.name == "evidence_tier" else -s,
).reset_index(drop=True)
compounds.insert(0, "rank", np.arange(1, len(compounds) + 1))
compounds.to_csv(OUT / "compound_level_ranking.tsv", sep="\t", index=False)

independent = pd.DataFrame(independent_rows)
independent["external_compound_label_BH_q"] = bh(independent["external_compound_label_empirical_p"])
independent.to_csv(OUT / "independent_validation.tsv", sep="\t", index=False)
pd.DataFrame(internal_rows).to_csv(OUT / "internal_five_cohort_direction_audit.tsv", sep="\t", index=False)
pd.DataFrame(toxicity_rows).to_csv(OUT / "toxicity_cell_cycle_sensitivity.tsv", sep="\t", index=False)

# Candidate aliases and provider target-token matches versus all 188 compounds.
aliases = []
for target, agents in CANDIDATES.items():
    if agents:
        for agent in agents:
            aliases.append({"target": target, "lead_agent_alias": agent, "alias_normalized": " ".join(agent.lower().split())})
    else:
        aliases.append({"target": target, "lead_agent_alias": "", "alias_normalized": ""})
alias_table = pd.DataFrame(aliases)
alias_table.to_csv(OUT / "candidate_aliases.tsv", sep="\t", index=False)

meta_cols = conditions.groupby("compound_normalized", as_index=False).first()[
    ["compound_normalized", "drh_target", "drh_moa", "drh_clinical_phase", "drh_fda_approved"]
]
ranked_meta = compounds.merge(meta_cols, on="compound_normalized", how="left")
matched_rows, summary_rows = [], []
for target, agents in CANDIDATES.items():
    alias_norm = {" ".join(agent.lower().split()) for agent in agents}
    exact = ranked_meta["compound_normalized"].isin(alias_norm)
    token = ranked_meta["drh_target"].fillna("").map(
        lambda value: target in {piece.strip() for piece in str(value).split("|")}
    )
    hit = exact | token
    subset = ranked_meta.loc[hit].copy()
    if len(subset):
        for _, row in subset.iterrows():
            matched_rows.append({
                "candidate_target": target, "screened_compound": row["compound"],
                "exact_lead_agent_alias": bool(row["compound_normalized"] in alias_norm),
                "provider_exact_target_token": bool(token.loc[row.name]),
                "background_rank": int(row["rank"]), "evidence_tier": row["evidence_tier"],
                "median_apc_composite_reversal": row["median_apc_composite_reversal"],
                "compound_label_BH_q": row["compound_label_BH_q"],
                "multi_condition_stable": row["multi_condition_stable"],
                "external_direction_supported": row["external_direction_supported"],
                "toxicity_dominated": row["toxicity_dominated"],
            })
    candidate_scores = subset["median_apc_composite_reversal"].to_numpy()
    background_scores = ranked_meta.loc[~hit, "median_apc_composite_reversal"].to_numpy()
    mw_p = (
        mannwhitneyu(candidate_scores, background_scores, alternative="greater").pvalue
        if len(candidate_scores) and len(background_scores) else np.nan
    )
    summary_rows.append({
        "candidate_target": target, "named_lead_agents": ";".join(agents),
        "exact_lead_agents_screened": int(exact.sum()),
        "provider_target_annotated_compounds": int(token.sum()),
        "unique_candidate_group_compounds": int(hit.sum()),
        "candidate_group_median_reversal": float(np.median(candidate_scores)) if len(candidate_scores) else np.nan,
        "full_background_compounds": int((~hit).sum()),
        "full_background_median_reversal": float(np.median(background_scores)) if len(background_scores) else np.nan,
        "candidate_greater_Mann_Whitney_p": mw_p,
        "candidate_group_Tier_A": int((subset["evidence_tier"] == "Tier A").sum()),
        "candidate_group_Tier_B": int((subset["evidence_tier"] == "Tier B").sum()),
        "candidate_group_Tier_C": int((subset["evidence_tier"] == "Tier C").sum()),
        "coverage_note": "unmatched means absent from this 188-compound screen, not pharmacologic failure",
    })
pd.DataFrame(summary_rows).to_csv(OUT / "candidate_vs_background.tsv", sep="\t", index=False)
pd.DataFrame(matched_rows, columns=[
    "candidate_target", "screened_compound", "exact_lead_agent_alias", "provider_exact_target_token",
    "background_rank", "evidence_tier", "median_apc_composite_reversal", "compound_label_BH_q",
    "multi_condition_stable", "external_direction_supported", "toxicity_dominated",
]).to_csv(OUT / "candidate_matched_compounds.tsv", sep="\t", index=False)

run = {
    "seed": SEED, "gene_label_permutations": N_PERM, "compound_label_permutations": N_PERM,
    "conditions": len(condition), "compounds": len(compounds),
    "common_complete_APC_genes": int(primary_mask.sum()),
    "common_complete_program_genes": int(primary_program.sum()),
    "elapsed_seconds": time.perf_counter() - started,
    "status": "post_hoc_exploratory_computational",
}
(OUT / "RUN_PARAMETERS.json").write_text(json.dumps(run, indent=2) + "\n")
print(compounds["evidence_tier"].value_counts().to_string())
print(compounds.head(15)[[
    "rank", "compound", "evidence_tier", "median_apc_composite_reversal",
    "compound_label_BH_q", "multi_condition_stable",
    "external_direction_supported", "toxicity_dominated",
]].to_string(index=False))
print(json.dumps(run, indent=2))
