#!/usr/bin/env python3
"""Build explicit statistical-unit maps from the audited primary metadata."""

import collections
import csv
import gzip
import json
import pathlib
import re


ROOT = pathlib.Path(__file__).resolve().parents[1]
GEO_INPUT = ROOT / "metadata" / "geo_samples.tsv"
GEO_OUTPUT = ROOT / "metadata" / "geo_analysis_sample_map.tsv"
AE_OUTPUT = ROOT / "metadata" / "arrayexpress_sample_map.tsv"
GSE267_OUTPUT = ROOT / "metadata" / "GSE267929_donor_condition_counts.tsv"
SUMMARY = ROOT / "metadata" / "analysis_unit_summary.tsv"


def first(characteristics, key, default=""):
    values = characteristics.get(key, [])
    return values[0] if values else default


def infer(row):
    series, title = row["series"], row["title"]
    c = json.loads(row["characteristics_json"])
    out = dict(participant_id="", disease="", condition="", time="", exposure="", replicate="biological", derivation="")

    if series == "GSE121212":
        condition = first(c, "skin type")
        participant = re.sub(r"_(lesional|non-lesional|chronic_lesion|healthy)$", "", title)
        out.update(participant_id=participant, disease=first(c, "patient's condition"), condition=condition,
                   derivation="title prefix after removing frozen skin-state suffix")
    elif series == "GSE32924":
        out.update(participant_id=first(c, "individual"), disease="AD" if first(c, "condition") != "Normal" else "CTRL",
                   condition=first(c, "condition"), derivation="SOFT Characteristics[individual/condition]")
    elif series == "GSE36842":
        group = first(c, "group")
        out.update(participant_id=first(c, "patient"), disease="CTRL" if group == "Normal" else "AD",
                   condition=group, derivation="SOFT Characteristics[patient/group]")
    elif series == "GSE6281":
        match = re.search(r"_(k\d+|P\d+)$", title)
        time_match = re.search(r"_(0|7|48|96)hours?nickel", title)
        participant = match.group(1) if match else "UNRESOLVED"
        allergic = "nickel_allergic_subject" in title
        out.update(participant_id=participant, disease="ACD" if allergic else "nonallergic_control",
                   condition="nickel_challenge" if "nickel" in title else "baseline",
                   time=time_match.group(1) + "h" if time_match else "UNRESOLVED",
                   exposure="nickel", derivation="sample-title subject and time tokens")
    elif series == "GSE282562":
        sample_id = title.split(",", 1)[0].strip()
        condition = first(c, "condition")
        prefix = "ACD" if condition == "allergic contact dermatitis" else "CTRL"
        out.update(participant_id=f"{prefix}_{sample_id}", disease="ACD" if prefix == "ACD" else "CTRL",
                   condition=condition, time="day4", exposure=first(c, "allergen"),
                   derivation="article confirms 40 ACD patients and 19 separate control patients; sample ID is participant unit")
    elif series == "GSE18206":
        match = re.search(r"subject\s+(\d+)_([^_]+)(?:_e)?_(SLS|NON)", title)
        if match:
            participant, time, agent = match.groups()
            time = time.replace("05h", "0.5h")
        else:
            participant, time, agent = "UNRESOLVED", "UNRESOLVED", "UNRESOLVED"
        out.update(participant_id=participant, disease="ICD", condition="irritant_challenge", time=time,
                   exposure={"SLS": "sodium lauryl sulfate", "NON": "nonanoic acid"}.get(agent, agent),
                   derivation="sample-title subject/time/agent tokens")
    elif series == "GSE267929":
        out.update(participant_id=title, disease="ACD_ICD_experimental" if title.startswith("P") else "CTRL",
                   condition="multi-condition library" if title.startswith("P") else "healthy nonlesional",
                   derivation="GEO library title; condition-level units are reconstructed separately from meta.data.tsv")
    elif series == "GSE13355":
        match = re.match(r"Individual_(.+?)_(NN|PN|PP)_sample", title)
        participant, code = match.groups() if match else ("UNRESOLVED", "UNRESOLVED")
        state = {"NN": "healthy_control", "PN": "psoriasis_nonlesional", "PP": "psoriasis_lesional"}.get(code, code)
        out.update(participant_id=participant, disease="CTRL" if code == "NN" else "psoriasis",
                   condition=state, derivation="sample-title individual and NN/PN/PP tokens")
    elif series == "GSE53795":
        out.update(participant_id=first(c, "patient id#"), disease="acne", condition=first(c, "tissue subgroup"),
                   derivation="SOFT Characteristics[patient id#/tissue subgroup]")
    elif series == "GSE65914":
        bracket = re.search(r"\[([^]]+)\]", title)
        token = bracket.group(1).strip() if bracket else title
        participant = re.sub(r"_[12]$", "", token)
        replicate = re.search(r"_([12])$", token)
        out.update(participant_id=participant, disease="CTRL" if first(c, "group") == "Healthy volunteer" else "rosacea",
                   condition=first(c, "group"), replicate=f"technical_{replicate.group(1)}" if replicate else "UNRESOLVED",
                   derivation="bracket token with terminal _1/_2 technical replicate removed")
    elif series == "GSE137141":
        match = re.search(r"_(\d+)$", title)
        participant = match.group(1) if match else "UNRESOLVED"
        out.update(participant_id=participant, disease=first(c, "condition"), condition=first(c, "site"),
                   derivation="title terminal subject number plus SOFT condition/site")
    elif series == "GSE72702":
        out.update(participant_id=first(c, "subject"), disease="HS", condition=first(c, "skin"),
                   time=first(c, "visit"), derivation="SOFT Characteristics[subject/skin/visit]")
    else:
        raise ValueError(f"No resolver for {series}")
    return out


def build_geo():
    with GEO_INPUT.open(newline="") as handle:
        input_rows = list(csv.DictReader(handle, delimiter="\t"))
    rows = []
    for row in input_rows:
        derived = infer(row)
        rows.append({"series": row["series"], "gsm": row["gsm"], "title": row["title"], **derived})
    with GEO_OUTPUT.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, delimiter="\t", fieldnames=list(rows[0]))
        writer.writeheader(); writer.writerows(rows)
    if any(row["participant_id"] == "UNRESOLVED" for row in rows):
        unresolved = [(row["series"], row["gsm"], row["title"]) for row in rows if row["participant_id"] == "UNRESOLVED"]
        raise RuntimeError(f"Unresolved participant identifiers: {unresolved[:10]}")
    return rows


def build_arrayexpress():
    output = []
    for accession in ("E-MTAB-8945", "E-MTAB-9501"):
        path = ROOT / "data" / "raw" / "arrayexpress" / accession / f"{accession}.sdrf.txt"
        with path.open(newline="", errors="replace") as handle:
            rows = list(csv.DictReader(handle, delimiter="\t"))
        for row in rows:
            individual = row.get("Characteristics[individual]", "")
            if accession == "E-MTAB-8945" and individual == "not included":
                continue
            output.append({
                "accession": accession,
                "source_name": row.get("Source Name", ""),
                "participant_or_specimen_id": individual,
                "sex": row.get("Characteristics[sex]", ""),
                "age": row.get("Characteristics[age]", ""),
                "disease": row.get("Characteristics[disease]", ""),
                "stimulus": row.get("Characteristics[stimulus]", ""),
                "time": row.get("Factor Value[time]", "48") if accession == "E-MTAB-8945" else "48",
                "array_file": row.get("Array Data File", ""),
                "study_family": "HELSINKI_FIOH_CONTACT_DERMATITIS",
                "independence_status": "DEPENDENT_UNTIL_PROVEN_OTHERWISE",
            })
    with AE_OUTPUT.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, delimiter="\t", fieldnames=list(output[0]))
        writer.writeheader(); writer.writerows(output)
    return output


def build_gse267():
    path = ROOT / "data" / "raw" / "geo" / "GSE267929" / "GSE267929_meta.data.tsv.gz"
    with gzip.open(path, "rt") as handle:
        reader = csv.reader(handle, delimiter=" ", quotechar='"', skipinitialspace=True)
        header = ["cell_barcode"] + next(reader)
        rows = [dict(zip(header, values)) for values in reader]
    counts = collections.Counter((r["Patient"], r["orig.ident"], r["Disease"], r["Lesion"], r["Sequence_date"],
                                  r["Sequence_instrument"], r["Anatomic_site"], r["sex"]) for r in rows)
    output = []
    for key, cells in sorted(counts.items()):
        participant, library, disease, lesion, sequence_date, instrument, site, sex = key
        output.append({"participant": participant, "library": library, "disease": disease, "condition": lesion,
                       "sequence_date": sequence_date, "instrument": instrument, "site": site, "sex": sex,
                       "cells": cells, "independence_unit": "participant"})
    with GSE267_OUTPUT.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, delimiter="\t", fieldnames=list(output[0]))
        writer.writeheader(); writer.writerows(output)
    return output


def build_summary(geo_rows, ae_rows, gse267_rows):
    summary = []
    for series in sorted({row["series"] for row in geo_rows}):
        subset = [row for row in geo_rows if row["series"] == series]
        summary.append({"dataset": series, "records": len(subset), "independent_units": len({row["participant_id"] for row in subset}),
                        "notes": "technical replicates collapse before inference" if series == "GSE65914" else "participant derived and frozen"})
    for accession in sorted({row["accession"] for row in ae_rows}):
        subset = [row for row in ae_rows if row["accession"] == accession]
        summary.append({"dataset": accession, "records": len(subset),
                        "independent_units": len({row["participant_or_specimen_id"] for row in subset}),
                        "notes": "same Helsinki/FIOH study family; do not count as independent replication"})
    summary.append({"dataset": "GSE267929_condition_map", "records": len(gse267_rows),
                    "independent_units": len({row["participant"] for row in gse267_rows}),
                    "notes": "conditions and sequencing batches nested within participant"})
    with SUMMARY.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, delimiter="\t", fieldnames=list(summary[0]))
        writer.writeheader(); writer.writerows(summary)


def main():
    geo_rows = build_geo()
    ae_rows = build_arrayexpress()
    gse267_rows = build_gse267()
    build_summary(geo_rows, ae_rows, gse267_rows)
    print(f"SAMPLE_MAP_OK geo={len(geo_rows)} arrayexpress={len(ae_rows)} gse267_condition_units={len(gse267_rows)}")


if __name__ == "__main__":
    main()
