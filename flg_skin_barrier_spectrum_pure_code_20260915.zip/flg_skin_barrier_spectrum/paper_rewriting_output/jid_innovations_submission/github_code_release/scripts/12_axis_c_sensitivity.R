#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(limma)
  library(edgeR)
  library(Matrix)
})

root <- normalizePath(getwd())
out_dir <- file.path(root, "results/tables/axis_tests")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

adaptive_pathways <- c(
  "Differentiation of naive CD4+ T cells to T helper 2 cells (Th2 cells)",
  "Differentiation of T cells",
  "TCR signaling",
  "Immunoregulatory interactions between a Lymphoid and a non-Lymphoid cell",
  "Generation of second messenger molecules",
  "Phosphorylation of CD3 and TCR zeta chains",
  "Translocation of ZAP-70 to Immunological synapse"
)

read_gmt <- function(path) {
  x <- strsplit(readLines(path, warn = FALSE), "\t", fixed = TRUE)
  sets <- lapply(x, function(z) unique(z[-c(1, 2)]))
  names(sets) <- vapply(x, `[[`, character(1), 1)
  sets
}
reactome <- read_gmt(file.path(root, "data/raw/pathways/reactome_v97/ReactomePathways.gmt"))
if (!all(adaptive_pathways %in% names(reactome))) stop("Adaptive pathway name missing from Reactome v97")
adaptive_genes <- sort(unique(unlist(reactome[adaptive_pathways])))
write.table(data.frame(pathway = adaptive_pathways), file.path(out_dir, "adaptive_module_reactome_v97_pathways.tsv"),
            sep = "\t", quote = FALSE, row.names = FALSE)
write.table(data.frame(gene_symbol = adaptive_genes), file.path(out_dir, "adaptive_module_reactome_v97_genes.tsv"),
            sep = "\t", quote = FALSE, row.names = FALSE)

test_module <- function(stat) {
  stat <- stat[is.finite(stat)]
  idx <- which(names(stat) %in% adaptive_genes)
  if (length(idx) < 10L) stop("Too few adaptive module genes")
  x <- cameraPR(stat, index = list(ADAPTIVE = idx), use.ranks = TRUE,
                inter.gene.cor = 0.01, sort = FALSE)
  data.frame(module_genes_tested = x$NGenes, direction = x$Direction,
             p_value = x$PValue, fdr_single_prespecified_module = x$PValue)
}

emt <- readRDS(file.path(root, "data/processed/expression/E-MTAB-9501/normalized_gene_expression.rds"))
emt$metadata$group <- unname(c(
  "PPD" = "ACD", "epoxy resin" = "ACD", "methylchloroisothiazolinone" = "ACD", "nickel" = "ACD",
  "nonanoic acid" = "ICD", "sodium lauryl sulfate" = "ICD", "baseline" = "BASELINE"
)[emt$metadata$stimulus])

fit_emt <- function(drop_stimulus = NA_character_) {
  m <- emt$metadata
  keep <- m$group %in% c("ACD", "ICD")
  if (!is.na(drop_stimulus)) keep <- keep & m$stimulus != drop_stimulus
  m <- droplevels(m[keep, , drop = FALSE])
  y <- emt$expression[, keep, drop = FALSE]
  m$group <- factor(m$group, levels = c("ICD", "ACD"))
  design <- model.matrix(~ group + scale(age) + sex + dye, data = m)
  corfit <- duplicateCorrelation(y, design, block = m$array_id)
  fit <- eBayes(lmFit(y, design, block = m$array_id, correlation = corfit$consensus), trend = TRUE, robust = TRUE)
  stat <- fit$t[, "groupACD"]
  names(stat) <- rownames(fit$t)
  cbind(data.frame(dataset = "E-MTAB-9501", sensitivity = ifelse(is.na(drop_stimulus), "main", paste0("leave_out_", drop_stimulus)),
                   n_ACD = sum(m$group == "ACD"), n_ICD = sum(m$group == "ICD")), test_module(stat))
}
emt_results <- do.call(rbind, lapply(c(NA, sort(unique(emt$metadata$stimulus[emt$metadata$group %in% c("ACD", "ICD")]))), fit_emt))

pb <- readRDS(file.path(root, "data/processed/expression/GSE267929/pseudobulk_all_cells.rds"))
fit_gse <- function(min_cells = 20L, leave_out_donor = NA_character_) {
  parts <- do.call(rbind, strsplit(colnames(pb), "__", fixed = TRUE))
  m <- data.frame(sample = colnames(pb), participant = parts[, 1], condition = parts[, 2],
                  cells = attr(pb, "cell_counts"), stringsAsFactors = FALSE)
  m <- m[m$condition %in% c("Day4_Allergy", "Irritant") & m$cells >= min_cells, , drop = FALSE]
  paired <- names(which(table(m$participant) == 2L))
  m <- m[m$participant %in% paired, , drop = FALSE]
  if (!is.na(leave_out_donor)) m <- m[m$participant != leave_out_donor, , drop = FALSE]
  paired <- names(which(table(m$participant) == 2L))
  m <- m[m$participant %in% paired, , drop = FALSE]
  m$participant <- factor(m$participant)
  m$condition <- factor(m$condition, levels = c("Irritant", "Day4_Allergy"))
  design <- model.matrix(~ participant + condition, data = m)
  dge <- DGEList(counts = pb[, m$sample, drop = FALSE])
  keep <- filterByExpr(dge, design = design, min.count = 5)
  dge <- normLibSizes(dge[keep, , keep.lib.sizes = FALSE])
  dge <- estimateDisp(dge, design, robust = TRUE)
  fit <- glmQLFit(dge, design, robust = TRUE)
  qlf <- glmQLFTest(fit, coef = "conditionDay4_Allergy")
  stat <- sign(qlf$table$logFC) * sqrt(pmax(qlf$table$F, 0))
  names(stat) <- rownames(qlf$table)
  sens <- paste0("min", min_cells, "cells")
  if (!is.na(leave_out_donor)) sens <- paste0(sens, "_leave_out_", leave_out_donor)
  cbind(data.frame(dataset = "GSE267929", sensitivity = sens, n_ACD = length(paired), n_ICD = length(paired)), test_module(stat))
}
gse_results <- do.call(rbind, lapply(c(5L, 10L, 20L), function(n) fit_gse(n)))
main_donors <- c("P1", "P2", "P3", "P4", "P8")
gse_lodo <- do.call(rbind, lapply(main_donors, function(d) fit_gse(20L, d)))

res <- rbind(emt_results, gse_results, gse_lodo)
res$passes_direction_and_fdr <- res$direction == "Up" & res$fdr_single_prespecified_module < 0.05
write.table(res, file.path(out_dir, "axis_c_adaptive_module_sensitivity.tsv"),
            sep = "\t", quote = FALSE, row.names = FALSE)
print(res)
