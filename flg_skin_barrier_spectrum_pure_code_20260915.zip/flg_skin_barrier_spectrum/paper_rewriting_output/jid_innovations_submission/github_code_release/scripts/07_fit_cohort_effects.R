#!/usr/bin/env Rscript

.libPaths(c(file.path("environment", "R_libs"), .libPaths()))
suppressPackageStartupMessages({
  library(GEOquery); library(Biobase); library(edgeR); library(limma)
  library(matrixStats); library(data.table); library(AnnotationDbi)
  library(hgu133plus2.db); library(org.Hs.eg.db); library(jsonlite)
})

set.seed(20260825)
dir.create("results/tables/cohort_effects", recursive = TRUE, showWarnings = FALSE)
dir.create("data/processed/expression", recursive = TRUE, showWarnings = FALSE)

sample_map <- fread("metadata/geo_analysis_sample_map.tsv")
geo_meta <- fread("metadata/geo_samples.tsv")

collapse_log_by_symbol <- function(mat, symbols) {
  keep <- is.finite(rowIQRs(mat, na.rm = TRUE)) & !is.na(symbols) & symbols != ""
  mat <- mat[keep, , drop = FALSE]
  symbols <- symbols[keep]
  iqr <- rowIQRs(mat, na.rm = TRUE)
  chosen <- !duplicated(symbols[order(-iqr)])
  idx <- order(-iqr)[chosen]
  result <- mat[idx, , drop = FALSE]
  rownames(result) <- symbols[idx]
  result[order(rownames(result)), , drop = FALSE]
}

aggregate_counts_by_symbol <- function(mat, symbols) {
  keep <- !is.na(symbols) & symbols != ""
  rowsum(mat[keep, , drop = FALSE], group = symbols[keep], reorder = TRUE)
}

map_ensembl_or_symbol <- function(ids) {
  clean <- sub("\\..*$", "", ids)
  is_ens <- grepl("^ENSG[0-9]+$", clean)
  symbols <- clean
  if (any(is_ens)) {
    mapped <- mapIds(org.Hs.eg.db, keys = unique(clean[is_ens]), keytype = "ENSEMBL", column = "SYMBOL", multiVals = "first")
    symbols[is_ens] <- unname(mapped[clean[is_ens]])
  }
  symbols
}

load_matrix <- function(accession) {
  map <- sample_map[series == accession]
  if (accession == "GSE121212") {
    x <- fread("data/raw/expression/geo/GSE121212/GSE121212_readcount.txt.gz", check.names = FALSE)
    ids <- x[[1]]; mat <- as.matrix(x[, -1]); storage.mode(mat) <- "numeric"
    mat <- aggregate_counts_by_symbol(mat, ids)
    idx <- match(colnames(mat), map$title); if (anyNA(idx)) stop("GSE121212 map mismatch")
    map <- map[idx]
    return(list(mat = mat, map = map, counts = TRUE))
  }
  if (accession == "GSE282562") {
    x <- fread("data/raw/expression/geo/GSE282562/GSE282562_CountsTable.csv.gz", sep = ";", dec = ",", check.names = FALSE)
    ids <- x[[1]]; mat <- as.matrix(x[, -1]); storage.mode(mat) <- "numeric"
    mat <- collapse_log_by_symbol(mat, map_ensembl_or_symbol(ids))
    short_id <- sub(",.*$", "", map$title)
    idx <- match(colnames(mat), short_id); if (anyNA(idx)) stop("GSE282562 map mismatch")
    map <- map[idx]
    return(list(mat = mat, map = map, counts = FALSE))
  }
  path <- file.path("data/raw/expression/geo", accession, paste0(accession, "_series_matrix.txt.gz"))
  eset <- getGEO(filename = path, GSEMatrix = TRUE, getGPL = FALSE); if (is.list(eset)) eset <- eset[[1]]
  mat <- exprs(eset)
  if (unname(quantile(mat, .99, na.rm = TRUE)) > 100) mat <- log2(mat + 1)
  if (accession == "GSE137141") {
    symbols <- unname(mapIds(org.Hs.eg.db, keys = rownames(mat), keytype = "ENTREZID", column = "SYMBOL", multiVals = "first"))
  } else {
    probes <- sub("_PM", "", rownames(mat), fixed = TRUE)
    symbols <- unname(mapIds(hgu133plus2.db, keys = probes, keytype = "PROBEID", column = "SYMBOL", multiVals = "first"))
  }
  mat <- collapse_log_by_symbol(mat, symbols)
  idx <- match(colnames(mat), map$gsm); if (anyNA(idx)) stop(accession, " map mismatch")
  list(mat = mat, map = map[idx], counts = FALSE)
}

fit_effect <- function(cohort_id, loaded, keep, meta, formula, coefficient, group_for_filter = NULL) {
  mat <- loaded$mat[, keep, drop = FALSE]
  if (ncol(mat) != nrow(meta)) stop(cohort_id, ": meta/matrix mismatch")
  design <- model.matrix(formula, data = meta)
  if (qr(design)$rank < ncol(design)) stop(cohort_id, ": rank-deficient design")
  if (!coefficient %in% colnames(design)) stop(cohort_id, ": missing coefficient ", coefficient,
                                                "; available: ", paste(colnames(design), collapse = ","))
  if (loaded$counts) {
    dge <- DGEList(mat)
    keep_gene <- filterByExpr(dge, design = design, group = group_for_filter)
    dge <- calcNormFactors(dge[keep_gene, , keep.lib.sizes = FALSE])
    transformed <- voom(dge, design = design, plot = FALSE)
    fit <- lmFit(transformed, design)
    ave <- rowMeans(transformed$E)
  } else {
    fit <- lmFit(mat, design)
    ave <- rowMeans(mat)
  }
  fit <- eBayes(fit, robust = TRUE, trend = !loaded$counts)
  j <- match(coefficient, colnames(fit$coefficients))
  se <- fit$stdev.unscaled[, j] * sqrt(fit$s2.post)
  result <- data.table(
    gene = rownames(fit$coefficients), logFC = fit$coefficients[, j], SE = se,
    t = fit$t[, j], p_value = fit$p.value[, j], FDR = p.adjust(fit$p.value[, j], "BH"),
    AveExpr = ave, n_samples = ncol(mat), n_participants = uniqueN(meta$participant),
    cohort = cohort_id
  )
  setorder(result, p_value)
  fwrite(result, file.path("results/tables/cohort_effects", paste0(cohort_id, ".tsv")), sep = "\t")
  saveRDS(list(cohort = cohort_id, design = design, coefficient = coefficient,
               samples = colnames(mat), participants = meta$participant,
               result = result), file.path("data/processed/expression", paste0(cohort_id, ".rds")))
  data.table(cohort = cohort_id, genes_tested = nrow(result), samples = ncol(mat), participants = uniqueN(meta$participant),
             FDR_005 = sum(result$FDR < .05), positive_FDR_005 = sum(result$FDR < .05 & result$logFC > 0),
             negative_FDR_005 = sum(result$FDR < .05 & result$logFC < 0))
}

paired_complete <- function(map, state_a, state_b) {
  tab <- table(map$participant_id, map$condition)
  participants <- rownames(tab)[tab[, state_a] > 0 & tab[, state_b] > 0]
  map$participant_id %in% participants & map$condition %in% c(state_a, state_b)
}

summaries <- list()

# AD: GSE121212 acute lesional versus paired nonlesional.
x <- load_matrix("GSE121212"); keep <- x$map$disease == "AD" & x$map$condition %in% c("lesional", "non-lesional")
complete <- paired_complete(x$map[keep], "lesional", "non-lesional"); idx <- which(keep)[complete]
m <- data.frame(participant = factor(x$map$participant_id[idx]), state = relevel(factor(x$map$condition[idx]), "non-lesional"))
summaries[["AD_GSE121212_acute"]] <- fit_effect("AD_GSE121212_acute", x, idx, m, ~ participant + state, "statelesional", m$state)

# AD: GSE32924 AL versus paired ANL.
x <- load_matrix("GSE32924"); keep <- x$map$disease == "AD" & x$map$condition %in% c("AL", "ANL")
complete <- paired_complete(x$map[keep], "AL", "ANL"); idx <- which(keep)[complete]
m <- data.frame(participant = factor(x$map$participant_id[idx]), state = relevel(factor(x$map$condition[idx]), "ANL"))
summaries[["AD_GSE32924"]] <- fit_effect("AD_GSE32924", x, idx, m, ~ participant + state, "stateAL")

# AD: GSE36842 acute lesion versus paired NL.
x <- load_matrix("GSE36842"); keep <- x$map$disease == "AD" & x$map$condition %in% c("ALS", "NL")
complete <- paired_complete(x$map[keep], "ALS", "NL"); idx <- which(keep)[complete]
m <- data.frame(participant = factor(x$map$participant_id[idx]), state = relevel(factor(x$map$condition[idx]), "NL"))
summaries[["AD_GSE36842_acute"]] <- fit_effect("AD_GSE36842_acute", x, idx, m, ~ participant + state, "stateALS")

# ACD: GSE282562 unpaired covariate-adjusted model.
x <- load_matrix("GSE282562"); idx <- seq_len(ncol(x$mat)); raw <- geo_meta[series == "GSE282562"]
raw <- raw[match(x$map$gsm, raw$gsm)]
json_text <- raw$characteristics_json
json_text <- sub('^"(.*)"$', '\\1', json_text)
json_text <- gsub('""', '"', json_text, fixed = TRUE)
chars <- lapply(json_text, fromJSON)
extract <- function(key) vapply(chars, function(z) if (!is.null(z[[key]])) as.character(z[[key]][1]) else NA_character_, character(1))
m <- data.frame(participant = factor(x$map$participant_id),
                state = relevel(factor(ifelse(x$map$disease == "ACD", "ACD", "CTRL")), "CTRL"),
                age = as.numeric(extract("age")), sex = factor(extract("sex")), batch = factor(extract("batch")),
                technician = factor(extract("technician")))
summaries[["ACD_GSE282562"]] <- fit_effect("ACD_GSE282562", x, idx, m, ~ state + age + sex + batch + technician, "stateACD")

# ACD: GSE6281 incomplete repeated time course, 48 h versus 0 h.
x <- load_matrix("GSE6281"); idx <- which(x$map$disease == "ACD" & x$map$time %in% c("0h", "7h", "48h", "96h"))
m <- data.frame(participant = factor(x$map$participant_id[idx]),
                time = relevel(factor(x$map$time[idx], levels = c("0h", "7h", "48h", "96h")), "0h"))
summaries[["ACD_GSE6281_48h"]] <- fit_effect("ACD_GSE6281_48h", x, idx, m, ~ participant + time, "time48h")

# Psoriasis paired primary and GSE121212 sensitivity.
x <- load_matrix("GSE13355"); keep <- x$map$condition %in% c("psoriasis_lesional", "psoriasis_nonlesional")
complete <- paired_complete(x$map[keep], "psoriasis_lesional", "psoriasis_nonlesional"); idx <- which(keep)[complete]
m <- data.frame(participant = factor(x$map$participant_id[idx]), state = relevel(factor(x$map$condition[idx]), "psoriasis_nonlesional"))
summaries[["PSO_GSE13355"]] <- fit_effect("PSO_GSE13355", x, idx, m, ~ participant + state, "statepsoriasis_lesional")

x <- load_matrix("GSE121212"); keep <- x$map$disease == "PSO" & x$map$condition %in% c("lesional", "non-lesional")
complete <- paired_complete(x$map[keep], "lesional", "non-lesional"); idx <- which(keep)[complete]
m <- data.frame(participant = factor(x$map$participant_id[idx]), state = relevel(factor(x$map$condition[idx]), "non-lesional"))
summaries[["PSO_GSE121212"]] <- fit_effect("PSO_GSE121212", x, idx, m, ~ participant + state, "statelesional", m$state)

# Acne paired lesion/nonlesion.
x <- load_matrix("GSE53795"); idx <- seq_len(ncol(x$mat))
m <- data.frame(participant = factor(x$map$participant_id), state = relevel(factor(x$map$condition), "non-lesional skin"))
summaries[["ACNE_GSE53795"]] <- fit_effect("ACNE_GSE53795", x, idx, m, ~ participant + state, "statelesional skin")

# Rosacea: collapse technical replicates, then combined disease versus healthy.
x <- load_matrix("GSE65914"); participants <- unique(x$map$participant_id)
collapsed <- sapply(participants, function(p) rowMeans(x$mat[, x$map$participant_id == p, drop = FALSE]))
if (is.vector(collapsed)) collapsed <- matrix(collapsed, ncol = 1)
colnames(collapsed) <- participants
map_collapsed <- x$map[match(participants, x$map$participant_id)]
x2 <- list(mat = collapsed, map = map_collapsed, counts = FALSE)
m <- data.frame(participant = factor(participants), state = relevel(factor(ifelse(map_collapsed$disease == "rosacea", "rosacea", "CTRL")), "CTRL"))
summaries[["ROSACEA_GSE65914"]] <- fit_effect("ROSACEA_GSE65914", x2, seq_along(participants), m, ~ state, "staterosacea")

# HS paired cohorts.
for (accession in c("GSE137141", "GSE72702")) {
  x <- load_matrix(accession)
  states <- if (accession == "GSE137141") c("lesional site (LS)", "non-lesional site (NL)") else c("lesion", "non-lesion")
  keep <- x$map$condition %in% states
  complete <- paired_complete(x$map[keep], states[1], states[2]); idx <- which(keep)[complete]
  m <- data.frame(participant = factor(x$map$participant_id[idx]), state = relevel(factor(x$map$condition[idx]), states[2]))
  coef <- paste0("state", states[1])
  id <- paste0("HS_", accession)
  summaries[[id]] <- fit_effect(id, x, idx, m, ~ participant + state, coef)
}

# ICD time courses, agent-specific 24 h versus 0 h.
x <- load_matrix("GSE18206")
for (agent in c("sodium lauryl sulfate", "nonanoic acid")) {
  idx <- which(x$map$exposure == agent & x$map$time %in% c("0h", "0.5h", "4h", "24h", "d11"))
  m <- data.frame(participant = factor(x$map$participant_id[idx]),
                  time = relevel(factor(x$map$time[idx], levels = c("0h", "0.5h", "4h", "24h", "d11")), "0h"))
  id <- if (agent == "sodium lauryl sulfate") "ICD_GSE18206_SLS_24h" else "ICD_GSE18206_NON_24h"
  summaries[[id]] <- fit_effect(id, x, idx, m, ~ participant + time, "time24h")
}

summary <- rbindlist(summaries)
fwrite(summary, "results/tables/cohort_effect_summary.tsv", sep = "\t")
cat("COHORT_EFFECTS_OK contrasts=", nrow(summary), "\n", sep = "")
