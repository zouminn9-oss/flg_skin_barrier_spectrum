#!/usr/bin/env Rscript

.libPaths(c(file.path("environment", "R_libs"), .libPaths()))
suppressPackageStartupMessages({
  library(GEOquery)
  library(Biobase)
  library(edgeR)
  library(limma)
  library(matrixStats)
  library(data.table)
  library(ggplot2)
})

set.seed(20260825)
dir.create("results/tables", recursive = TRUE, showWarnings = FALSE)
dir.create("results/figures/qc", recursive = TRUE, showWarnings = FALSE)

sample_map <- fread("metadata/geo_analysis_sample_map.tsv")
series <- c("GSE121212", "GSE282562", "GSE32924", "GSE36842", "GSE6281",
            "GSE18206", "GSE13355", "GSE53795", "GSE65914", "GSE137141", "GSE72702")

robust_z <- function(x) {
  scale <- mad(x, center = median(x, na.rm = TRUE), constant = 1.4826, na.rm = TRUE)
  if (!is.finite(scale) || scale == 0) return(rep(0, length(x)))
  (x - median(x, na.rm = TRUE)) / scale
}

load_expression <- function(accession) {
  if (accession == "GSE121212") {
    x <- fread("data/raw/expression/geo/GSE121212/GSE121212_readcount.txt.gz", check.names = FALSE)
    ids <- x[[1]]
    mat <- as.matrix(x[, -1])
    storage.mode(mat) <- "numeric"
    rownames(mat) <- make.unique(ids)
    return(list(mat = mat, scale = "raw_integer_counts", transformed = FALSE, sample_key = "title"))
  }
  if (accession == "GSE282562") {
    x <- fread("data/raw/expression/geo/GSE282562/GSE282562_CountsTable.csv.gz",
               sep = ";", dec = ",", check.names = FALSE)
    ids <- x[[1]]
    mat <- as.matrix(x[, -1])
    storage.mode(mat) <- "numeric"
    rownames(mat) <- make.unique(ids)
    return(list(mat = mat, scale = "author_processed_log_expression", transformed = FALSE, sample_key = "short_id"))
  }
  path <- file.path("data/raw/expression/geo", accession, paste0(accession, "_series_matrix.txt.gz"))
  eset <- getGEO(filename = path, GSEMatrix = TRUE, getGPL = FALSE)
  if (is.list(eset)) eset <- eset[[1]]
  mat <- exprs(eset)
  q99 <- unname(quantile(mat, 0.99, na.rm = TRUE))
  transformed <- FALSE
  scale_name <- "author_processed_log_expression"
  if (q99 > 100) {
    mat <- log2(mat + 1)
    transformed <- TRUE
    scale_name <- "log2_from_positive_intensity"
  }
  list(mat = mat, scale = scale_name, transformed = transformed, sample_key = "gsm")
}

qc_rows <- list()
flag_rows <- list()
dataset_rows <- list()

for (accession in series) {
  loaded <- load_expression(accession)
  mat <- loaded$mat
  map <- sample_map[series == accession]

  if (loaded$sample_key == "gsm") {
    idx <- match(colnames(mat), map$gsm)
  } else if (loaded$sample_key == "title") {
    idx <- match(colnames(mat), map$title)
  } else {
    short_id <- sub(",.*$", "", map$title)
    idx <- match(colnames(mat), short_id)
  }
  if (anyNA(idx)) stop(accession, ": expression columns failed sample-map match: ", paste(colnames(mat)[is.na(idx)], collapse = ","))
  map <- map[idx]

  missing_fraction <- colMeans(!is.finite(mat))
  if (loaded$scale == "raw_integer_counts") {
    library_size <- colSums(mat, na.rm = TRUE)
    detected <- colSums(mat > 0, na.rm = TRUE)
    qc_mat <- cpm(DGEList(mat), log = TRUE, prior.count = 2)
  } else {
    library_size <- rep(NA_real_, ncol(mat))
    detected <- colSums(is.finite(mat), na.rm = TRUE)
    qc_mat <- mat
  }

  sample_median <- colMedians(qc_mat, na.rm = TRUE)
  sample_iqr <- colIQRs(qc_mat, na.rm = TRUE)
  variable <- order(rowVars(qc_mat, na.rm = TRUE), decreasing = TRUE)[seq_len(min(5000, nrow(qc_mat)))]
  pca <- prcomp(t(qc_mat[variable, , drop = FALSE]), center = TRUE, scale. = FALSE)
  pc1 <- pca$x[, 1]
  pc2 <- if (ncol(pca$x) >= 2) pca$x[, 2] else rep(0, ncol(mat))
  cor_mat <- suppressWarnings(cor(qc_mat[variable, , drop = FALSE], use = "pairwise.complete.obs"))
  group_label <- paste(map$condition, map$time, map$exposure, sep = "|")
  mean_cor <- rep(NA_real_, ncol(mat))
  for (group in unique(group_label)) {
    members <- which(group_label == group)
    if (length(members) >= 3) {
      block <- cor_mat[members, members, drop = FALSE]
      mean_cor[members] <- (rowSums(block, na.rm = TRUE) - 1) / pmax(1, rowSums(is.finite(block)) - 1)
    }
  }
  fallback <- (rowSums(cor_mat, na.rm = TRUE) - 1) / pmax(1, rowSums(is.finite(cor_mat)) - 1)
  mean_cor[!is.finite(mean_cor)] <- fallback[!is.finite(mean_cor)]
  flag <- abs(robust_z(sample_median)) > 4 | abs(robust_z(sample_iqr)) > 4 |
          robust_z(mean_cor) < -4 | missing_fraction > 0.01

  qc_rows[[accession]] <- data.table(
    dataset = accession, sample = colnames(mat), gsm = map$gsm, participant = map$participant_id,
    disease = map$disease, condition = map$condition, time = map$time, exposure = map$exposure, replicate = map$replicate,
    library_size = library_size, detected_features = detected, missing_fraction = missing_fraction,
    median = sample_median, iqr = sample_iqr, mean_topvar_correlation = mean_cor,
    pc1 = pc1, pc2 = pc2, qc_flag = flag
  )
  flag_rows[[accession]] <- qc_rows[[accession]][qc_flag == TRUE]
  dataset_rows[[accession]] <- data.table(
    dataset = accession, features = nrow(mat), samples = ncol(mat), participants = uniqueN(map$participant_id),
    input_scale = loaded$scale, transformation_applied = loaded$transformed,
    minimum = min(mat, na.rm = TRUE), median = median(mat, na.rm = TRUE), maximum = max(mat, na.rm = TRUE),
    missing_values = sum(!is.finite(mat)), qc_flags = sum(flag)
  )

  plot_data <- qc_rows[[accession]]
  plot_data[, label := ifelse(qc_flag, sample, "")]
  p <- ggplot(plot_data, aes(pc1, pc2, colour = condition, shape = qc_flag)) +
    geom_point(size = 2.2, alpha = 0.85) +
    geom_text(aes(label = label), check_overlap = TRUE, size = 2.4, vjust = -0.6) +
    labs(title = paste(accession, "expression PCA"), subtitle = "Top variable features; QC flags are diagnostic, not automatic exclusions",
         x = "PC1", y = "PC2", colour = "Condition", shape = "QC flag") +
    theme_bw(base_size = 9) + theme(legend.position = "bottom")
  ggsave(file.path("results/figures/qc", paste0(accession, "_pca.png")), p, width = 7, height = 5, dpi = 160)
}

fwrite(rbindlist(dataset_rows), "results/tables/qc_dataset_summary.tsv", sep = "\t")
fwrite(rbindlist(qc_rows), "results/tables/qc_sample_metrics.tsv", sep = "\t")
flags <- rbindlist(flag_rows, fill = TRUE)
if (!nrow(flags)) flags <- rbindlist(qc_rows)[0]
fwrite(flags, "results/tables/qc_flags.tsv", sep = "\t")

cat("EXPRESSION_QC_OK datasets=", length(series), " flags=", nrow(flags), "\n", sep = "")
