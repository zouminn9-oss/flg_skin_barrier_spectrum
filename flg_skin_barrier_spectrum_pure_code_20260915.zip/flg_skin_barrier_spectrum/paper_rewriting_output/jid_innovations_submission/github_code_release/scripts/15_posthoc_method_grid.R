#!/usr/bin/env Rscript

suppressPackageStartupMessages({ library(data.table); library(metafor) })

set.seed(20260825)
root <- normalizePath(getwd())
out_dir <- file.path(root, "results/exploratory_sensitivity")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

groups <- list(
  AD = c("AD_GSE121212_acute", "AD_GSE32924", "AD_GSE36842_acute"),
  ACD = c("ACD_GSE282562", "ACD_GSE6281_48h"),
  PSORIASIS = c("PSO_GSE13355", "PSO_GSE121212"),
  HS = c("HS_GSE137141", "HS_GSE72702")
)

configs <- data.table(
  method_id = c("reml_mkh_q05", "reml_z_q05", "reml_z_q10", "dl_z_q05", "fixed_z_q05", "fixed_z_q10"),
  estimator = c("REML", "REML", "REML", "DL", "FE", "FE"),
  test = c("adhoc", "z", "z", "z", "z", "z"),
  fdr_threshold = c(0.05, 0.05, 0.10, 0.05, 0.05, 0.10),
  role = c("frozen_reference", rep("posthoc_exploratory", 5))
)

read_effects <- function(id) {
  x <- fread(file.path(root, "results/tables/pathway_effects", paste0(id, ".tsv")),
             select = c("pathway", "effect", "SE"))
  setnames(x, c("effect", "SE"), paste0(c("effect__", "SE__"), id))
  x
}

fit_grid <- function(disease, ids) {
  merged <- Reduce(function(a, b) merge(a, b, by = "pathway", all = FALSE), lapply(ids, read_effects))
  all_cfg <- lapply(seq_len(nrow(configs)), function(ci) {
    cfg <- configs[ci]
    vals <- lapply(seq_len(nrow(merged)), function(i) {
      yi <- as.numeric(merged[i, paste0("effect__", ids), with = FALSE])
      sei <- as.numeric(merged[i, paste0("SE__", ids), with = FALSE])
      ok <- is.finite(yi) & is.finite(sei) & sei > 0
      yi <- yi[ok]; sei <- sei[ok]
      model <- try(suppressWarnings(rma.uni(yi = yi, sei = sei, method = cfg$estimator, test = cfg$test)), silent = TRUE)
      if (inherits(model, "try-error")) return(rep(NA_real_, 9))
      beta <- as.numeric(model$b)
      loo <- vapply(seq_along(yi), function(j) {
        if (length(yi) == 2L) return(yi[-j])
        w <- 1 / sei[-j]^2
        sum(w * yi[-j]) / sum(w)
      }, numeric(1))
      c(effect = beta, SE = model$se, CI_low = model$ci.lb, CI_high = model$ci.ub,
        p_value = model$pval, tau2 = model$tau2, I2 = model$I2,
        direction_agree_n = sum(sign(yi) == sign(beta)),
        LODO_direction_stable = all(sign(loo[loo != 0]) == sign(beta)))
    })
    v <- as.data.table(do.call(rbind, vals))
    x <- cbind(merged[, .(pathway)], v)
    x[, `:=`(FDR = p.adjust(p_value, "BH"), disease = disease, cohorts = length(ids),
              method_id = cfg$method_id, estimator = cfg$estimator, test = cfg$test,
              fdr_threshold = cfg$fdr_threshold, role = cfg$role)]
    x
  })
  rbindlist(all_cfg)
}

grid <- rbindlist(lapply(names(groups), function(d) fit_grid(d, groups[[d]])))
grid[, significant := FDR < fdr_threshold]
fwrite(grid, file.path(out_dir, "pathway_meta_complete_grid.tsv"), sep = "\t")

method_summary <- grid[, .(
  pathways_tested = .N,
  significant = sum(significant, na.rm = TRUE),
  significant_direction_complete = sum(significant & direction_agree_n == cohorts, na.rm = TRUE),
  significant_lodo_stable = sum(significant & LODO_direction_stable == 1, na.rm = TRUE)
), by = .(method_id, estimator, test, fdr_threshold, role, disease)]
fwrite(method_summary, file.path(out_dir, "method_grid_summary.tsv"), sep = "\t")

barrier_pathways <- c(
  "Formation of the cornified envelope", "Keratinization", "Fatty acid metabolism",
  "Peroxisomal lipid metabolism", "Sphingolipid metabolism", "Cholesterol biosynthesis",
  "Glycerophospholipid biosynthesis", "Glycosphingolipid metabolism"
)
barrier <- grid[disease == "AD" & pathway %in% barrier_pathways]
barrier[, candidate_support := significant & direction_agree_n == cohorts & LODO_direction_stable == 1]
fwrite(barrier, file.path(out_dir, "axis_a_barrier_grid.tsv"), sep = "\t")

shared_rows <- list()
shared_summary <- list()
for (mid in configs$method_id) {
  ad <- grid[method_id == mid & disease == "AD"]
  acd <- grid[method_id == mid & disease == "ACD"]
  z <- merge(ad[, .(pathway, effect_AD = effect, FDR_AD = FDR, significant_AD = significant)],
             acd[, .(pathway, effect_ACD = effect, FDR_ACD = FDR, significant_ACD = significant)], by = "pathway")
  z[, same_direction := sign(effect_AD) == sign(effect_ACD)]
  z[, shared_significant := significant_AD & significant_ACD & same_direction]
  z[, method_id := mid]
  shared_rows[[mid]] <- z[shared_significant == TRUE][order(pmax(FDR_AD, FDR_ACD))]
  shared_summary[[mid]] <- data.table(method_id = mid, shared_same_direction_significant = sum(z$shared_significant))
}
shared <- rbindlist(shared_rows, fill = TRUE)
shared_sum <- rbindlist(shared_summary)
fwrite(shared, file.path(out_dir, "axis_b_shared_pathways_grid.tsv"), sep = "\t")

specificity <- fread(file.path(root, "results/tables/similarity/AD_ACD_background_specificity.tsv"))
background_pass <- isTRUE(specificity$exceeds_threshold[1]) && specificity$permutation_q[1] < 0.05

adaptive_pathways <- c(
  "Differentiation of naive CD4+ T cells to T helper 2 cells (Th2 cells)",
  "Differentiation of T cells", "TCR signaling",
  "Immunoregulatory interactions between a Lymphoid and a non-Lymphoid cell",
  "Generation of second messenger molecules", "Phosphorylation of CD3 and TCR zeta chains",
  "Translocation of ZAP-70 to Immunological synapse"
)
emt <- fread(file.path(root, "results/tables/direct_comparison/E-MTAB-9501_ACD_vs_ICD_reactome.tsv"))
gse <- fread(file.path(root, "results/tables/single_cell_validation/GSE267929_all_cells_reactome.tsv"))
emt_n <- emt[pathway %in% adaptive_pathways & Direction == "Up" & FDR < .05, .N]
gse_n <- gse[pathway %in% adaptive_pathways & Direction == "Up" & FDR < .05, .N]
axis_c_favorable <- emt_n >= 1L && gse_n >= 1L

axis_decisions <- merge(configs, shared_sum, by = "method_id", all.x = TRUE)
axis_decisions[, axis_a_candidate := method_id %in% barrier[candidate_support == TRUE, unique(method_id)]]
axis_decisions[, axis_b_candidate := shared_same_direction_significant >= 1L & background_pass]
axis_decisions[, `:=`(
  axis_c_candidate_favorable_rule = axis_c_favorable,
  axis_c_emt_significant_adaptive_pathways = emt_n,
  axis_c_gse_significant_adaptive_pathways = gse_n,
  frozen_axis_c_sensitivity_omitted = TRUE
)]
axis_decisions[, candidate_axes_passed := axis_a_candidate + axis_b_candidate + axis_c_candidate_favorable_rule]
axis_decisions[, candidate_project_positive_before_snf := candidate_axes_passed >= 2 & !(candidate_axes_passed == 1 & axis_c_candidate_favorable_rule)]
setorder(axis_decisions, -candidate_axes_passed, -shared_same_direction_significant)
fwrite(axis_decisions, file.path(out_dir, "exploratory_axis_decisions.tsv"), sep = "\t")

best <- axis_decisions[1]
fwrite(best, file.path(out_dir, "most_favorable_branch.tsv"), sep = "\t")
print(method_summary)
cat("\nMost favorable branch (post-hoc only):\n")
print(best)
