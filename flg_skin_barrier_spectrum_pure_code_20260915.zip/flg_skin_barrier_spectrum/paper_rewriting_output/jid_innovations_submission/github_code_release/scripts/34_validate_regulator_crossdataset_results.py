#!/usr/bin/env python3
import csv
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "results/exploratory_snf/selected_positive_reml_z_q05/optimized_AD_ACD_branch/mechanism/regulator_crossdataset_validation"


def rows(path):
    with path.open(newline="") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


summary = rows(OUT / "regulator_crossdataset_validation_summary.tsv")[0]
assert int(summary["locked_candidates"]) == 5
assert int(summary["permutations_per_dataset"]) == 10000
assert int(summary["independent_q_lt_0_05"]) == 0
assert summary["YY1_external_direction_match"] == "False"
assert abs(float(summary["YY1_external_score"])) < 0.04
assert summary["E2F4_external_direction_match"] == "False"
assert float(summary["E2F4_external_score"]) < -2.3
assert summary["internal_5of5_positive_TFs"] == "IRF1;E2F4;HSF1"

all_results = rows(OUT / "candidate_TF_crossdataset_activity.tsv")
assert len(all_results) == 35
external = {r["TF"]: r for r in all_results if r["role"] == "independent_direct_bulk_validation"}
assert all(float(r["empirical_q_BH_5TF"]) > 0.05 for r in external.values())
assert float(external["E2F4"]["empirical_p_two_sided"]) < 0.02
assert float(external["E2F4"]["empirical_q_BH_5TF"]) > 0.05

synthesis = {r["TF"]: r for r in rows(OUT / "candidate_TF_validation_synthesis.tsv")}
for tf in ("IRF1", "E2F4", "HSF1"):
    assert int(synthesis[tf]["internal_bulk_positive_cohorts"]) == 5
assert int(synthesis["YY1"]["internal_bulk_positive_cohorts"]) == 3
assert int(synthesis["E2F6"]["internal_bulk_positive_cohorts"]) == 0

branch = {r["gene"]: r for r in rows(OUT / "E_MTAB_9501_YY1_E2F4_branch_gene_effects.tsv")}
for gene in ("YY1", "PCNA", "BRCA1"):
    assert float(branch[gene]["logFC_ACD_minus_ICD"]) < 0
    assert float(branch[gene]["FDR"]) > 0.05

figure = OUT / "figures/candidate_TF_crossdataset_activity_heatmap.png"
assert figure.stat().st_size > 30_000
report = (ROOT / "AD_ACD_REGULATOR_CROSSDATA_VALIDATION_REPORT.md").read_text()
for phrase in ("没有任何候选", "YY1–PCNA/BRCA1", "5/5", "E2F6", "独立检验"):
    assert phrase in report

print("PASS: locked TF candidates, independent direct validation, internal direction audit, heatmap, and report are consistent")
