#!/usr/bin/env python3
"""Validate coverage, integrity, scoring, and classification invariants."""

from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
LOCAL_PACKAGES = ROOT / "environment/python_packages"
if LOCAL_PACKAGES.exists():
    sys.path.insert(0, str(LOCAL_PACKAGES))

import numpy as np
import pandas as pd


MECH = ROOT / "results/exploratory_snf/selected_positive_reml_z_q05/optimized_AD_ACD_branch/mechanism"
OUT = MECH / "lincs_cross_resource_replication"


def bh(pvalues):
    p = np.asarray(pvalues, dtype=float)
    order = np.argsort(p)
    ranked = p[order]
    adjusted = np.minimum.accumulate((ranked * len(p) / np.arange(1, len(p) + 1))[::-1])[::-1]
    out = np.empty_like(adjusted)
    out[order] = np.minimum(adjusted, 1.0)
    return out


protocol = (ROOT / "LINCS_CROSS_RESOURCE_REPLICATION_PROTOCOL.md").read_text()
assert "Frozen: 2026-08-25" in protocol
assert "Pre-score integrity amendment" in protocol and "does not change coverage" in protocol

inventory = pd.read_csv(OUT / "target_coverage_inventory.tsv", sep="\t")
assert len(inventory) == 21 and inventory["target_key"].is_unique
assert (inventory["target_group"] == "sciplex_audit").sum() == 11
assert (inventory["target_group"] == "named_prior_lead").sum() == 10
assert inventory.loc[inventory["target_group"].eq("named_prior_lead"), "matched_signatures"].eq(0).all()
assert inventory.set_index("target_key").loc["G007-LK", "coverage"] == "not_covered"
assert inventory.loc[inventory["target_group"].eq("sciplex_audit"), "coverage"].value_counts().to_dict() == {
    "covered": 10, "not_covered": 1,
}

metadata = pd.read_csv(OUT / "condition_metadata.tsv", sep="\t")
assert len(metadata) == 2787 and metadata["signature_id"].is_unique
assert set(metadata["target_key"]) == set(inventory.loc[inventory["coverage"].eq("covered"), "target_key"])
assert metadata[["persistent_id", "expected_sha256", "cell_line", "dose", "time"]].notna().all().all()
assert metadata["signature_strength_available"].eq(False).all()

integrity = pd.read_csv(OUT / "persistent_file_integrity.tsv", sep="\t")
assert len(integrity) == len(metadata) and integrity["signature_id"].is_unique
assert integrity["verified"].all() and integrity["etag_body_md5_verified"].all()
assert integrity["observed_sha256"].str.fullmatch(r"[0-9a-f]{64}").all()
assert integrity["s3_etag"].str.fullmatch(r"[0-9a-f]{32}").all()
assert (~integrity["api_sha256_matches"]).any() and (~integrity["api_md5_matches"]).any()

bundle = np.load(OUT / "prepared_lincs_effects.npz")
genes = bundle["genes"].astype(str)
condition_ids = bundle["condition_ids"].astype(str)
effects = bundle["effects"]
assert len(genes) == len(set(genes)) and len(condition_ids) == len(set(condition_ids))
assert effects.shape == (len(genes), len(condition_ids)) and np.isfinite(effects).all()
assert condition_ids.tolist() == metadata["signature_id"].astype(str).tolist()

condition = pd.read_csv(OUT / "condition_level_lincs_reversal.tsv", sep="\t")
assert len(condition) == len(metadata) and set(condition["signature_id"]) == set(metadata["signature_id"])
score_cols = [
    "apc_genome_rank_reversal", "apc_genome_weighted_reversal", "apc_program_rank_reversal",
    "apc_program_weighted_reversal", "apc_composite_reversal", "external_composite_reversal",
    "tox_removed_apc_composite_reversal",
]
assert condition[score_cols].notna().all().all()
assert np.allclose(condition["apc_composite_reversal"], condition[score_cols[:4]].mean(axis=1))
assert condition["apc_gene_label_empirical_p"].between((1 / 1001) - 1e-12, 1).all()

compounds = pd.read_csv(OUT / "covered_compound_aggregation.tsv", sep="\t")
assert len(compounds) == 10 and compounds["target_key"].is_unique
assert compounds["targeted_fdr_scope"].eq("covered_locked_targets_only_not_full_background").all()
assert np.allclose(compounds["targeted_BH_q"], bh(compounds["gene_label_empirical_p"]))
assert compounds["gene_label_empirical_p"].between((1 / 1001) - 1e-12, 1).all()

for row in compounds.itertuples(index=False):
    group = condition.loc[condition["target_key"].eq(row.target_key)]
    assert len(group) == row.n_conditions
    assert np.isclose(group["apc_composite_reversal"].median(), row.median_apc_composite_reversal)
    assert np.isclose((group["apc_composite_reversal"] > 0).mean(), row.direction_positive_fraction)
    cell_loo = []
    for cell in sorted(group["cell_line"].astype(str).unique()):
        remain = group.loc[group["cell_line"].astype(str).ne(cell), "apc_composite_reversal"]
        if len(remain):
            cell_loo.append(float(remain.median()))
    min_cell = min(cell_loo) if group["cell_line"].nunique() >= 2 else np.nan
    stable = bool(
        len(group) >= 2 and group["cell_line"].nunique() >= 2
        and (group["apc_composite_reversal"] > 0).mean() >= 2 / 3
        and row.min_leave_one_condition_median > 0 and min_cell > 0
    )
    assert stable == row.multi_condition_stable

classification = pd.read_csv(OUT / "all_target_classification.tsv", sep="\t")
assert len(classification) == len(inventory) and classification["target_key"].is_unique
assert classification.loc[classification["coverage"].eq("not_covered"), "cross_resource_classification"].eq("not_covered").all()
assert classification.loc[classification["target_group"].eq("named_prior_lead"), "cross_resource_classification"].eq("not_covered").all()
assert classification["clinical_evidence"].eq(False).all()
assert classification["analysis_status"].eq("post_hoc_exploratory_cross_resource_replication").all()

comparison = pd.read_csv(OUT / "sciplex_lincs_comparison.tsv", sep="\t")
assert len(comparison) == 11 and comparison["sciplex_median_apc_composite_reversal"].notna().all()
covered = comparison["coverage"].eq("covered")
for row in comparison.loc[covered].itertuples(index=False):
    lin_pos = row.median_apc_composite_reversal > 0
    sci_pos = row.sciplex_median_apc_composite_reversal > 0
    lincs_pass = bool(
        row.primary_five_score_screen and row.targeted_BH_q < 0.05 and row.multi_condition_stable
        and row.external_direction_supported and not row.toxicity_dominated
    )
    expected = (
        "replicated" if lin_pos and sci_pos and lincs_pass else
        "direction_only" if lin_pos and sci_pos else
        "discordant" if lin_pos != sci_pos else "negative_both"
    )
    assert row.cross_resource_classification == expected

run = json.loads((OUT / "RUN_PARAMETERS.json").read_text())
assert run["seed"] == 20260825 and run["gene_label_permutations"] == 1000
assert run["conditions"] == len(condition) and run["covered_targeted_compounds"] == len(compounds)
assert run["targeted_BH_scope"] == "covered_locked_targets_only_not_full_background"

report = (ROOT / "AD_ACD_LINCS_CROSS_RESOURCE_REPLICATION_REPORT.md").read_text()
for required in [
    "post hoc", "targeted BH", "not full-background", "G007-LK", "not_covered",
    "API", "ETag", "Gate 3", "clinical",
]:
    assert required.lower() in report.lower(), required

summary = {
    "validation": "PASS", "targets": len(inventory), "covered_compounds": len(compounds),
    "conditions": len(condition), "genes": len(genes),
    "classifications": classification["cross_resource_classification"].value_counts().to_dict(),
    "api_sha256_match_files": int(integrity["api_sha256_matches"].sum()),
    "etag_verified_files": int(integrity["etag_body_md5_verified"].sum()),
}
(OUT / "VALIDATION_SUMMARY.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps(summary, indent=2))
