#!/usr/bin/env Rscript

suppressPackageStartupMessages({ library(data.table); library(parallel) })

set.seed(20260825)
root <- normalizePath(getwd())
out_dir <- file.path(root, "results/exploratory_snf/selected_positive_reml_z_q05")
fig_dir <- file.path(out_dir, "figures")
dir.create(fig_dir, recursive = TRUE, showWarnings = FALSE)

f <- fread(file.path(out_dir, "snf_positive_pathway_feature_matrix.tsv"))
pathways <- f$pathway
x <- as.matrix(f[, -"pathway"])
rownames(x) <- pathways
assignments <- fread(file.path(out_dir, "snf_view_assignments.tsv"))
assignments <- assignments[match(pathways, pathway)]
diseases <- colnames(x)
n <- length(diseases)
if (n != 7L) stop("Expected seven transcriptomic disease nodes")

view_names <- c("all_positive", "immune_adaptive", "barrier_lipid", "stress_damage")
K <- 3L
alpha <- 0.5
iterations <- 20L
available_cores <- detectCores(logical = FALSE)
if (!is.finite(available_cores) || available_cores < 1L) available_cores <- 1L
worker_cores <- min(4L, available_cores)

scale_features <- function(m) {
  # disease x pathway
  s <- apply(m, 2, sd, na.rm = TRUE)
  keep <- is.finite(s) & s > 0
  m <- m[, keep, drop = FALSE]
  scale(m)
}

make_views <- function(mat, bootstrap = FALSE, permute_rows = FALSE) {
  lapply(view_names, function(v) {
    keep <- if (v == "all_positive") rep(TRUE, nrow(assignments)) else assignments[[v]]
    z <- t(mat[keep, , drop = FALSE])
    if (bootstrap) z <- z[, sample(seq_len(ncol(z)), ncol(z), replace = TRUE), drop = FALSE]
    if (permute_rows) {
      z <- t(vapply(seq_len(nrow(z)), function(i) sample(z[i, ]), numeric(ncol(z))))
      rownames(z) <- diseases
    }
    scale_features(z)
  })
}

affinity <- function(z, k = K, a = alpha) {
  sq <- rowSums(z^2)
  d2 <- outer(sq, sq, "+") - 2 * tcrossprod(z)
  d2[d2 < 0] <- 0
  local <- vapply(seq_len(nrow(d2)), function(i) mean(sort(d2[i, -i])[seq_len(min(k, nrow(d2) - 1L))]), numeric(1))
  mu <- (outer(local, local, "+") + d2) / 3
  w <- exp(-d2 / pmax(a * mu, 1e-12))
  diag(w) <- 1
  dimnames(w) <- list(rownames(z), rownames(z))
  w
}

normalize_w <- function(w) {
  w <- (w + t(w)) / 2
  diag(w) <- 0
  rs <- rowSums(w)
  p <- w / pmax(rs, 1e-12)
  p <- (p + t(p)) / 2
  diag(p) <- 0.5
  p / rowSums(p)
}

dominant <- function(w, k = K) {
  s <- matrix(0, nrow(w), ncol(w), dimnames = dimnames(w))
  for (i in seq_len(nrow(w))) {
    idx <- order(w[i, ], decreasing = TRUE)[seq_len(min(k, ncol(w)))]
    s[i, idx] <- w[i, idx]
  }
  s <- s / pmax(rowSums(s), 1e-12)
  s
}

fuse <- function(views) {
  ws <- lapply(views, affinity)
  p <- lapply(ws, normalize_w)
  s <- lapply(ws, dominant)
  for (iter in seq_len(iterations)) {
    p <- lapply(seq_along(p), function(i) {
      others <- Reduce("+", p[-i]) / (length(p) - 1L)
      normalize_w(s[[i]] %*% others %*% t(s[[i]]))
    })
  }
  out <- Reduce("+", p) / length(p)
  out <- (out + t(out)) / 2
  diag(out) <- 1
  out
}

spectral_cluster <- function(w, k) {
  a <- w; diag(a) <- 0
  d <- rowSums(a)
  norm <- diag(1 / sqrt(pmax(d, 1e-12))) %*% a %*% diag(1 / sqrt(pmax(d, 1e-12)))
  e <- eigen((norm + t(norm)) / 2, symmetric = TRUE)
  u <- e$vectors[, seq_len(k), drop = FALSE]
  u <- u / sqrt(rowSums(u^2))
  set.seed(20260825 + k)
  km <- kmeans(u, centers = k, nstart = 100, iter.max = 100)
  list(cluster = km$cluster, eigenvalues = e$values)
}

mean_silhouette <- function(cluster, w) {
  d <- 1 - w
  vals <- vapply(seq_len(nrow(d)), function(i) {
    same <- which(cluster == cluster[i] & seq_len(nrow(d)) != i)
    if (!length(same)) return(0)
    a <- mean(d[i, same])
    other_groups <- setdiff(unique(cluster), cluster[i])
    b <- min(vapply(other_groups, function(g) mean(d[i, cluster == g]), numeric(1)))
    (b - a) / max(a, b)
  }, numeric(1))
  mean(vals)
}

obs_views <- make_views(x)
view_w <- lapply(obs_views, affinity)
names(view_w) <- view_names
fused <- fuse(obs_views)

for (v in view_names) {
  fwrite(data.table(disease = diseases, as.data.frame(view_w[[v]])),
         file.path(out_dir, paste0("view_similarity_", v, ".tsv")), sep = "\t")
}
fwrite(data.table(disease = diseases, as.data.frame(fused)), file.path(out_dir, "snf_fused_similarity.tsv"), sep = "\t")

models <- rbindlist(lapply(2:4, function(k) {
  cl <- spectral_cluster(fused, k)
  data.table(k = k, silhouette = mean_silhouette(cl$cluster, fused), eigengap = cl$eigenvalues[k] - cl$eigenvalues[k + 1L],
             clusters = paste(sprintf("%s:%s", diseases, cl$cluster), collapse = ";"))
}))
setorder(models, -silhouette, -eigengap, k)
chosen_k <- models$k[1]
obs_cluster <- spectral_cluster(fused, chosen_k)$cluster
names(obs_cluster) <- diseases
fwrite(models, file.path(out_dir, "snf_cluster_model_selection.tsv"), sep = "\t")
fwrite(data.table(disease = diseases, cluster = obs_cluster), file.path(out_dir, "snf_cluster_assignments.tsv"), sep = "\t")

edge_index <- which(upper.tri(fused), arr.ind = TRUE)
edge_names <- paste(diseases[edge_index[, 1]], diseases[edge_index[, 2]], sep = "--")
obs_edges <- fused[edge_index]

# 1,000 pathway-resampling bootstraps.
bootstrap_n <- 1000L
boot_worker <- function(seed) {
  set.seed(seed)
  wf <- fuse(make_views(x, bootstrap = TRUE))
  cl <- spectral_cluster(wf, chosen_k)$cluster
  c(edges = wf[edge_index], cocluster = as.numeric(outer(cl, cl, "==")))
}
boot <- mclapply(20260825 + seq_len(bootstrap_n), boot_worker,
                 mc.cores = worker_cores, mc.preschedule = TRUE)
boot <- do.call(rbind, boot)
boot_edges <- boot[, seq_len(nrow(edge_index)), drop = FALSE]
boot_co <- matrix(colMeans(boot[, nrow(edge_index) + seq_len(n * n), drop = FALSE]), nrow = n, byrow = FALSE,
                  dimnames = list(diseases, diseases))
fwrite(data.table(disease = diseases, as.data.frame(boot_co)), file.path(out_dir, "snf_bootstrap_coclustering.tsv"), sep = "\t")

# 10,000 pathway-label permutations; independently break pathway alignment for
# each disease while preserving its selected-feature distribution.
perm_n <- 10000L
perm_worker <- function(seed) {
  set.seed(seed)
  wf <- fuse(make_views(x, permute_rows = TRUE))
  wf[edge_index]
}
perm <- mclapply(20260825 + 100000L + seq_len(perm_n), perm_worker,
                 mc.cores = worker_cores, mc.preschedule = TRUE)
perm <- do.call(rbind, perm)
perm_p <- vapply(seq_along(obs_edges), function(j) (1 + sum(perm[, j] >= obs_edges[j])) / (perm_n + 1), numeric(1))

edge_table <- data.table(
  disease_1 = diseases[edge_index[, 1]], disease_2 = diseases[edge_index[, 2]],
  fused_similarity = obs_edges,
  bootstrap_mean = colMeans(boot_edges),
  bootstrap_ci_low = apply(boot_edges, 2, quantile, 0.025),
  bootstrap_ci_high = apply(boot_edges, 2, quantile, 0.975),
  bootstrap_coclustering = boot_co[edge_index],
  permutation_p = perm_p,
  permutation_q = p.adjust(perm_p, "BH"),
  same_observed_cluster = obs_cluster[diseases[edge_index[, 1]]] == obs_cluster[diseases[edge_index[, 2]]]
)
setorder(edge_table, -fused_similarity)
fwrite(edge_table, file.path(out_dir, "snf_edge_statistics.tsv"), sep = "\t")

node_support <- vapply(diseases, function(d) {
  mates <- diseases[obs_cluster == obs_cluster[d] & diseases != d]
  if (!length(mates)) return(NA_real_)
  mean(boot_co[d, mates])
}, numeric(1))
cluster_table <- data.table(disease = diseases, cluster = obs_cluster, bootstrap_cluster_support = node_support)
fwrite(cluster_table, file.path(out_dir, "snf_cluster_support.tsv"), sep = "\t")

target <- edge_table[(disease_1 == "AD" & disease_2 == "ACD") | (disease_1 == "ACD" & disease_2 == "AD")]
summary <- data.table(
  selected_method = "REML_z_BH_FDR_0.05",
  nodes = n,
  positive_pathways = nrow(x),
  views = length(view_names),
  K = K,
  iterations = iterations,
  selected_clusters = chosen_k,
  AD_ACD_similarity = target$fused_similarity,
  AD_ACD_similarity_rank = which(edge_table$disease_1 == target$disease_1 & edge_table$disease_2 == target$disease_2),
  AD_ACD_permutation_q = target$permutation_q,
  AD_ACD_bootstrap_coclustering = target$bootstrap_coclustering,
  AD_ACD_same_cluster = target$same_observed_cluster,
  clusters_all_nodes_support_ge_075 = all(cluster_table$bootstrap_cluster_support >= .75, na.rm = TRUE),
  IV_included = FALSE,
  scope = "posthoc selected-positive multi-view transcriptomic SNF"
)
fwrite(summary, file.path(out_dir, "snf_summary.tsv"), sep = "\t")

png(file.path(fig_dir, "snf_fused_similarity_heatmap.png"), width = 1250, height = 1100, res = 160)
heatmap(fused, symm = TRUE, margins = c(10, 10), main = "Selected-positive REML-z SNF similarity")
dev.off()

dmat <- 1 - fused
dmat[dmat < 0] <- 0
coords <- cmdscale(as.dist(dmat), k = 2)
png(file.path(fig_dir, "snf_network.png"), width = 1300, height = 1050, res = 160)
plot(coords, type = "n", xlab = "MDS1", ylab = "MDS2", main = "Selected-positive REML-z multi-view SNF")
sig_edges <- edge_table[permutation_q < .05]
for (i in seq_len(nrow(sig_edges))) {
  a <- sig_edges$disease_1[i]; b <- sig_edges$disease_2[i]
  segments(coords[a, 1], coords[a, 2], coords[b, 1], coords[b, 2],
           lwd = 1 + 6 * sig_edges$fused_similarity[i], col = adjustcolor("#4C78A8", alpha.f = 0.45))
}
cols <- c("#E45756", "#4C78A8", "#72B7B2", "#F2CF5B")[obs_cluster]
points(coords, pch = 21, bg = cols, col = "white", cex = 4, lwd = 1.5)
text(coords, labels = diseases, pos = 3, cex = 0.95, font = 2)
dev.off()

print(summary)
print(cluster_table)
print(edge_table[1:min(10, .N)])
