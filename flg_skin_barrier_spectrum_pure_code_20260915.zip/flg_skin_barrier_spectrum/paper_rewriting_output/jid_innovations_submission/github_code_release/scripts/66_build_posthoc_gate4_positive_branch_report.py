#!/usr/bin/env python3
"""Build the durable post-hoc exploratory Gate 4 positive-branch report."""

from pathlib import Path
import json
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "results/posthoc_exploratory_gate4_positive_branch"
REPORT = ROOT / "POSTHOC_EXPLORATORY_GATE4_POSITIVE_BRANCH_REPORT.md"

disposition = json.loads((OUT / "GATE4_DISPOSITION.json").read_text())
entry = pd.read_csv(OUT / "positive_branch_entry_audit.tsv", sep="\t")
coverage = pd.read_csv(OUT / "layer_coverage_audit.tsv", sep="\t")
candidate = pd.read_csv(OUT / "downstream_candidate_annotation_audit.tsv", sep="\t").iloc[0]


def value(x):
    if isinstance(x, (float, int)) and not isinstance(x, bool):
        return f"{x:.6g}"
    return str(x)


entry_rows = []
for row in entry.itertuples(index=False):
    entry_rows.append(f"| {row.check} | {value(row.observed)} | {row.threshold} | {'PASS' if row.passed else 'FAIL'} |")

coverage_rows = []
for row in coverage.itertuples(index=False):
    coverage_rows.append(
        f"| {int(row.layer_id)} | {row.layer} | {int(row.discovery_nodes_with_comparable_features)}/"
        f"{int(row.total_discovery_nodes)} | {row.covered_discovery_nodes} | "
        f"{'yes' if row.eligible_for_complete_fusion else 'no'} | {row.limitation} |"
    )

text = f"""# Post-hoc exploratory Gate 4 positive-branch report

## Executive disposition

The user-directed, post-hoc, exploratory Gate 4 disposition is
**`{disposition['label']}`**.

All seven frozen transcriptomic entry checks passed. However, only the
transcriptomic/pathway layer provides comparable features for all seven
discovery disease nodes. A complete multilayer fusion requires at least two
eligible layers, so the full multilayer Gate 4 is not evaluable and no
multilayer-positive claim is made.

This is not confirmatory Gate 4, not independent replication, and not a rescue
or replacement of frozen Gate 3. Gate 3 remains negative with 0/3 core axes
passing.

## Fixed positive-branch entry signal

- Selected branch: `{disposition['selected_branch']}`
  (`{disposition['selected_branch_id']}`), K={disposition['selected_K']},
  alpha={disposition['selected_alpha']}, {disposition['selected_iterations']}
  fusion iterations.
- Complete search: {disposition['branches_screened']} branches.
- Resampling: {disposition['nominal_permutations']:,} nominal permutations,
  {disposition['bootstrap_replicates']:,} bootstraps, and
  {disposition['selection_adjustment_permutations']} whole-search selection
  permutations.
- AD–ACD similarity: {disposition['AD_ACD_similarity']:.6f}; edge rank:
  {disposition['AD_ACD_edge_rank']}/21.

| Frozen check | Observed | Threshold | Result |
|---|---:|---:|---|
{chr(10).join(entry_rows)}

No threshold was relaxed after inspecting this result.

## Four-layer evidence coverage audit

| Layer | Evidence layer | Comparable discovery nodes | Covered nodes | Eligible for complete fusion | Limitation |
|---:|---|---:|---|---|---|
{chr(10).join(coverage_rows)}

The frozen planned weights remain 0.40, 0.30, 0.20 and 0.10. They were not
renormalized into an invented multilayer result because only one complete
seven-node layer exists. No missing layer was filled with zero, mean-imputed,
copied between diseases, or replaced with the drug score. Consequently, no
`multilayer_fused_similarity.tsv` was produced.

## JNJ-7706621 annotation boundary

JNJ-7706621 retains the LINCS characteristic-direction full-background label
**`{candidate['annotation']}`** and targeted BH q={candidate['targeted_BH_q']:.6f}.
It is a downstream computational candidate annotation only, not a
disease-network layer and not evidence that supplies the missing genetic,
functional, network, cell, or spatial coverage.

This candidate label is not formal or independent replication. It is not
evidence of clinical efficacy, safety, skin-disease benefit, target
specificity, or treatment suitability.

## Interpretation

The allowed conclusion is narrow: the user-selected transcriptomic AD–ACD
positive branch passes its frozen exploratory Gate 4 transcriptomic sub-gate,
including adjustment for the 396-branch search. The available project data do
not identify a complete multilayer disease graph. Therefore the result cannot
be described as full, confirmatory, or independently replicated Gate 4.

Unfavorable prior results remain visible: frozen Gate 3 is negative 0/3; no
compound achieved frozen cross-resource replication; the independent
GSE201278 JNJ direction check was unsupported; and the MODZ sensitivity result
was `modz_full_background_not_supported`.

## Reproducibility outputs

- `results/posthoc_exploratory_gate4_positive_branch/GATE4_DISPOSITION.json`
- `results/posthoc_exploratory_gate4_positive_branch/positive_branch_entry_audit.tsv`
- `results/posthoc_exploratory_gate4_positive_branch/layer_coverage_audit.tsv`
- `results/posthoc_exploratory_gate4_positive_branch/downstream_candidate_annotation_audit.tsv`
- `results/posthoc_exploratory_gate4_positive_branch/RUN_PARAMETERS.json`
- `results/posthoc_exploratory_gate4_positive_branch/SOURCE_MANIFEST.json`
- `results/posthoc_exploratory_gate4_positive_branch/VALIDATION_SUMMARY.json`
- `results/posthoc_exploratory_gate4_positive_branch/pipeline.log`
"""

REPORT.write_text(text)
artifact = {
    "report": str(REPORT.relative_to(ROOT)),
    "title": "Post-hoc exploratory Gate 4 positive-branch report",
    "disposition": disposition["label"],
    "transcriptomic_subgate_pass": disposition["transcriptomic_subgate_pass"],
    "full_multilayer_gate4_evaluable": disposition["full_multilayer_gate4_evaluable"],
    "gate3_changed": disposition["gate3_changed"],
}
(OUT / "REPORT_ARTIFACT.json").write_text(json.dumps(artifact, indent=2) + "\n")
print(json.dumps(artifact, indent=2))
