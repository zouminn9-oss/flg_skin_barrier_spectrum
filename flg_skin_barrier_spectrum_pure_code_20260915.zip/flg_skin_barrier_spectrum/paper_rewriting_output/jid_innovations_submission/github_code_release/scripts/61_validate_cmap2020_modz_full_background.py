#!/usr/bin/env python3
"""Validate the CMap2020 MODZ full-background method sensitivity analysis."""

from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
LOCAL_PACKAGES = ROOT / "environment/python_packages"
if LOCAL_PACKAGES.exists():
    sys.path.insert(0, str(LOCAL_PACKAGES))

import numpy as np
import pandas as pd

MECH = ROOT / "results/exploratory_snf/selected_positive_reml_z_q05/optimized_AD_ACD_branch/mechanism"
OUT = MECH / "cmap2020_modz_full_background_sensitivity"
TARGETED = MECH / "lincs_cross_resource_replication"
PROTOCOL = ROOT / "CMAP2020_MODZ_FULL_BACKGROUND_SENSITIVITY_PROTOCOL.md"
EXPECTED_CONDITIONS = 720_216
EXPECTED_BYTES = 35_518_405_386
EXPECTED_VERSION = "ljLz1nWDJ4co.kG6bSrfEs7mrklxiVS4"
EXPECTED_UNSCORABLE = 62

checks = []


def check(name, condition, detail=""):
    passed = bool(condition)
    checks.append({"check": name, "passed": passed, "detail": str(detail)})
    if not passed:
        raise AssertionError(f"{name}: {detail}")


source = json.loads((OUT / "SOURCE_AND_SCHEMA_QC.json").read_text())
run = json.loads((OUT / "RUN_PARAMETERS.json").read_text())
disposition = json.loads((OUT / "JNJ7706621_MODZ_DISPOSITION.json").read_text())
protocol = PROTOCOL.read_text()
ranking = pd.read_csv(OUT / "full_background_compound_ranking.tsv", sep="\t")
unscorable_audit = pd.read_csv(OUT / "UNSCORABLE_ALL_ZERO_CONDITIONS.tsv", sep="\t")
recon = pd.read_csv(OUT / "cd_modz_score_reconciliation.tsv", sep="\t")
recon_summary = pd.read_csv(OUT / "cd_modz_score_reconciliation_summary.tsv", sep="\t")
condition = pd.read_parquet(OUT / "condition_score_parts", columns=[
    "signature_id", "pert_name", "cell_line", "dose", "time",
    "apc_genome_rank_reversal", "apc_genome_weighted_reversal",
    "apc_program_rank_reversal", "apc_program_weighted_reversal",
    "apc_composite_reversal", "external_composite_reversal", "toxicity_index",
    "tox_removed_apc_composite_reversal", "condition_toxicity_dominated",
])
targeted = pd.read_csv(TARGETED / "covered_compound_aggregation.tsv", sep="\t").set_index("target_key")

check("protocol exists", PROTOCOL.exists())
check("protocol is post hoc exploratory computational", all(token in protocol for token in ["post hoc", "exploratory", "computational"]))
check("protocol labels processing-method sensitivity", "processing-method sensitivity" in protocol)
check("protocol prohibits independent-replication claim", "not an independent biological replication" in protocol)
check("protocol freezes top-five-percent boundary", "top 5%" in protocol)
check("protocol freezes immutable version ID", EXPECTED_VERSION in protocol)
check("protocol records MIA2 mapping before scoring", "Entrez 4253" in protocol and "Entrez 117153" in protocol)
check("protocol records all-zero source QC", "exactly 62 of 720,216" in protocol and "condition_scorable=false" in protocol)

check("matrix bytes exact", source["local_bytes"] == EXPECTED_BYTES, source["local_bytes"])
check("matrix version exact", source["version_id"] == EXPECTED_VERSION)
check("matrix SHA-256 recorded", len(source["local_sha256"]) == 64)
check("download receipt verified", source["download_receipt_verified"])
check("multipart ETag not interpreted as MD5", source["multipart_etag_not_interpreted_as_md5"])
check("matrix condition count", source["column_identifiers"] == EXPECTED_CONDITIONS)
check("matrix row count", source["row_identifiers"] == 12_328)
check("canonical symbol count", source["canonical_gene_symbols"] == 12_327)
check("MIA2 canonical row frozen", source["duplicate_symbol_resolution"]["included_gene_id"] == 4253)
check("legacy MIA2 row excluded", source["duplicate_symbol_resolution"]["excluded_gene_id"] == 117153)
check("siginfo full count", source["broad_siginfo"]["full_records"] == 1_201_944)
check("siginfo trt_cp count", source["broad_siginfo"]["trt_cp_records"] == EXPECTED_CONDITIONS)
check("siginfo covers all columns", source["broad_siginfo"]["all_gctx_columns_covered"])
check("all targeted conditions overlap", source["targeted_cmap_id_overlap"] == 2787)
check("all JNJ conditions present", source["jnj_conditions"] == 297)

check("run condition count", run["conditions"] == EXPECTED_CONDITIONS)
check("run scorable condition count", run["scorable_conditions"] == EXPECTED_CONDITIONS - EXPECTED_UNSCORABLE)
check("run unscorable condition count", run["unscorable_all_zero_conditions"] == EXPECTED_UNSCORABLE)
check("run canonical row count", run["canonical_gene_symbols"] == 12_327)
check("run APC genes frozen", run["common_complete_APC_genes"] == 3735)
check("run program genes frozen", run["common_complete_program_genes"] == 214)
check("run is method sensitivity", "processing_method_sensitivity" in run["status"])
check("no library-wide FDR", not run["library_wide_FDR_computed"])
check("targeted BH not reused", not run["targeted_BH_reused_as_library_FDR"])

check("condition rows complete", len(condition) == EXPECTED_CONDITIONS, len(condition))
check("condition IDs unique", condition["signature_id"].is_unique)
score_columns = [column for column in condition if column.endswith("reversal") or column == "toxicity_index"]
condition_scorable = condition["apc_composite_reversal"].notna()
check("condition scorable count", condition_scorable.sum() == EXPECTED_CONDITIONS - EXPECTED_UNSCORABLE)
check("scorable condition scores finite", np.isfinite(condition.loc[condition_scorable, score_columns].to_numpy(float)).all())
check("unscorable condition scores missing", condition.loc[~condition_scorable, score_columns].isna().all().all())
check("unscorable audit count", len(unscorable_audit) == EXPECTED_UNSCORABLE)
check("unscorable audit excludes JNJ", not unscorable_audit["pert_name"].eq("JNJ-7706621").any())
check("condition toxicity flags complete", condition["condition_toxicity_dominated"].notna().all())

expected_compounds = source["broad_siginfo"]["unique_gctx_compound_names"]
check("ranking covers all compounds", len(ranking) == expected_compounds, (len(ranking), expected_compounds))
check("ranking compound names unique", ranking["pert_name"].is_unique)
check("ranking retains positive results", ranking["median_apc_composite_reversal"].gt(0).any())
check("ranking retains negative results", ranking["median_apc_composite_reversal"].le(0).any())
check("competitive fractions bounded", ranking["all_compound_competitive_upper_tail_fraction"].between(0, 1).all())
check("competitive quantity is not P/FDR", ranking["calibration_quantity_type"].eq("competitive_rank_fraction_not_null_p_not_fdr").all())

check("method comparison covers all targeted rows", len(recon) == 2787 and recon["_merge"].eq("both").all())
check("method comparison covers five scores", len(recon_summary) == 5)
check("method comparison correlations finite", np.isfinite(recon_summary["spearman_correlation"]).all())
check("method comparison status complete", run["cd_modz_method_comparison"] == "complete")

jnj = ranking.loc[ranking["pert_name"].eq("JNJ-7706621")]
check("one JNJ aggregate", len(jnj) == 1, len(jnj))
jnj = jnj.iloc[0]
check("JNJ retains 297 conditions", jnj["n_conditions"] == 297)
check("JNJ retains 98 cell lines", jnj["n_cell_lines"] == 98)
check("JNJ rank matches disposition", disposition["all_compound_rank"] == jnj["all_compound_rank"])
check("JNJ eligible rank matches disposition", disposition["stable_eligible_rank"] == jnj["stable_eligible_rank"])
check("targeted nominal P preserved", np.isclose(disposition["frozen_targeted_gene_label_empirical_p"], targeted.loc["JNJ-7706621", "gene_label_empirical_p"]))
check("targeted q preserved", np.isclose(disposition["frozen_targeted_BH_q"], targeted.loc["JNJ-7706621", "targeted_BH_q"]))
check("CD label preserved", disposition["cd_full_background_label"] == "positive_not_top5")
check("GSE201278 label preserved", disposition["gse201278_label"] == "independent_skin_line_not_supported")
check("formal replication remains false", not disposition["formal_replication"])
check("independent replication remains false", not disposition["independent_biological_replication"])
check("clinical evidence remains false", not disposition["clinical_evidence"])
check("CDK2 specificity remains false", not disposition["cdk2_specificity_established"])
check("Gate 3 unchanged", not disposition["gate3_changed"])

direction = bool(jnj["primary_five_score_screen"])
top_all = bool(jnj["all_compound_competitive_upper_tail_fraction"] <= 0.05)
top_eligible = bool(jnj["stable_eligible_competitive_upper_tail_fraction"] <= 0.05)
robust = bool(jnj["multi_condition_stable"] and jnj["external_direction_supported"] and not jnj["toxicity_dominated"])
expected_label = (
    "modz_full_background_method_robust" if direction and top_all and top_eligible and robust
    else "modz_positive_not_top5" if direction and robust
    else "modz_full_background_not_supported"
)
check("frozen MODZ disposition applied exactly", disposition["modz_full_background_label"] == expected_label, (disposition["modz_full_background_label"], expected_label))

summary = {"status": "pass", "checks_passed": len(checks), "checks_failed": 0, "checks": checks}
(OUT / "VALIDATION_SUMMARY.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps({"status": "pass", "checks_passed": len(checks)}, indent=2))
