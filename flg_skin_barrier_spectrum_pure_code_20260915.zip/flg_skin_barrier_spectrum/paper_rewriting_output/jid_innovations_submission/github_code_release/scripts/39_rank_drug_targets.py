#!/usr/bin/env python3
"""Rank direct TF and mechanism-node drug targets with explicit evidence rules."""

from pathlib import Path
import json

import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
MECH = ROOT / "results/exploratory_snf/selected_positive_reml_z_q05/optimized_AD_ACD_branch/mechanism"
OUT = MECH / "drug_target_ranking"
OUT.mkdir(parents=True, exist_ok=True)
AS_OF = "2026-08-25"

tf_validation = pd.read_csv(
    MECH / "regulator_crossdataset_validation/candidate_TF_validation_synthesis.tsv", sep="\t"
).set_index("TF")
virtual_ko = pd.read_csv(MECH / "virtual_knockout/single_tf_virtual_knockout.tsv", sep="\t").set_index("TF")
direct = pd.read_csv(
    ROOT / "results/tables/direct_comparison/E-MTAB-9501_ACD_vs_ICD_gene_effects.tsv", sep="\t"
).set_index("gene_symbol")
core = pd.read_csv(MECH / "core_genes/tier1_core_genes.tsv", sep="\t").set_index("gene")

# Drug-development facts were checked against primary studies, ChEMBL, and
# ClinicalTrials.gov on AS_OF. Scores are fixed ordinal bins, not fitted weights.
curated = {
    "IRF1": {
        "target_layer": "direct_TF", "lead_agent": "I-2 / I-19",
        "development_stage": "preclinical_skin_mouse", "stage_score": 8,
        "specificity_score": 5, "skin_relevance_score": 10, "direction_safety_score": 7,
        "agent_note": "IRF1-DBD candidates; mouse radiation-skin injury protection; no clinical validation",
        "source_url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC11291999/",
    },
    "HSF1": {
        "target_layer": "direct_TF", "lead_agent": "DTHIB (SISU-102)",
        "development_stage": "direct_preclinical", "stage_score": 8,
        "specificity_score": 7, "skin_relevance_score": 2, "direction_safety_score": 5,
        "agent_note": "direct HSF1 binding/degradation in cancer models; no clinical trial identified",
        "source_url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC10571035/",
    },
    "E2F4": {
        "target_layer": "direct_TF", "lead_agent": "HLM006474",
        "development_stage": "nonselective_preclinical", "stage_score": 4,
        "specificity_score": 3, "skin_relevance_score": 0, "direction_safety_score": 3,
        "agent_note": "pan-E2F DNA-binding inhibitor; not E2F4-selective",
        "source_url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC3615411/",
    },
    "YY1": {
        "target_layer": "direct_TF", "lead_agent": "none validated",
        "development_stage": "no_direct_agent", "stage_score": 0,
        "specificity_score": 0, "skin_relevance_score": 0, "direction_safety_score": 3,
        "agent_note": "genetic perturbation target; no validated selective direct compound located",
        "source_url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC11603335/",
    },
    "E2F6": {
        "target_layer": "direct_TF", "lead_agent": "none validated",
        "development_stage": "no_direct_agent", "stage_score": 0,
        "specificity_score": 0, "skin_relevance_score": 0, "direction_safety_score": 2,
        "agent_note": "no validated selective direct compound located",
        "source_url": "https://www.ebi.ac.uk/gxa/genes/ENSG00000169016",
    },
    "ATR": {
        "target_layer": "core_mechanism", "lead_agent": "camonsertib / ceralasertib / elimusertib",
        "development_stage": "clinical_phase1_2", "stage_score": 14,
        "specificity_score": 10, "skin_relevance_score": 0, "direction_safety_score": 0,
        "agent_note": "multiple selective oncology inhibitors; blocking a genome-protective checkpoint is a major skin-disease liability",
        "source_url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC10287555/",
    },
    "PCNA": {
        "target_layer": "core_mechanism", "lead_agent": "AOH1996",
        "development_stage": "clinical_phase1", "stage_score": 12,
        "specificity_score": 8, "skin_relevance_score": 0, "direction_safety_score": 0,
        "agent_note": "phase-1 cancer-associated PCNA inhibitor; independent bulk gene direction is opposite",
        "source_url": "https://clinicaltrials.gov/study/NCT05227326",
    },
    "CDK2": {
        "target_layer": "core_mechanism", "lead_agent": "INX-315 / AZD8421",
        "development_stage": "clinical_phase1_2", "stage_score": 14,
        "specificity_score": 10, "skin_relevance_score": 0, "direction_safety_score": 1,
        "agent_note": "selective inhibitors in recruiting oncology trials; broad antiproliferative liability",
        "source_url": "https://clinicaltrials.gov/study/NCT05735080",
    },
}


def external_bulk_score(target):
    """0-20: independent E-MTAB-9501 support, never called confirmed if q>=0.05."""
    if target in tf_validation.index:
        row = tf_validation.loc[target]
        matches = bool(row["external_direction_matches_APC"])
        q = float(row["external_E_MTAB_9501_q_5TF"])
        if matches and q < 0.05:
            return 20, "confirmed_q_lt_0.05"
        if matches and q < 0.50:
            return 10, "direction_supported_not_significant"
        if matches:
            return 4, "direction_only_weak"
        return 0, "direction_mismatch"
    row = direct.loc[target]
    if row["logFC"] > 0 and row["adj.P.Val"] < 0.05:
        return 20, "confirmed_gene_FDR_lt_0.05"
    if row["logFC"] > 0 and row["P.Value"] < 0.05:
        return 12, "nominal_positive_not_FDR"
    if row["logFC"] > 0:
        return 4, "positive_not_significant"
    return 0, "negative_direction"


def local_program_score(target):
    """0-15: virtual-KO support for TFs or recurrence for core nodes."""
    if target in virtual_ko.index:
        row = virtual_ko.loc[target]
        probability = float(row["bootstrap_probability_reduction_gt_0"])
        max_p = float(row["max5_network_null_p"])
        if bool(row["strict_screen_pass"]):
            return 15
        if probability >= 0.90 and max_p < 0.05:
            return 12
        if probability >= 0.80 and max_p < 0.10:
            return 8
        if probability >= 0.80:
            return 4
        return 0
    return 15 * float(core.loc[target, "top20_pathway_count"]) / 15


rows = []
for target, evidence in curated.items():
    bulk_score, bulk_status = external_bulk_score(target)
    local_score = local_program_score(target)
    total = (
        bulk_score + local_score + evidence["stage_score"] + evidence["specificity_score"]
        + evidence["skin_relevance_score"] + evidence["direction_safety_score"]
    )
    row = {
        "target": target,
        "target_layer": evidence["target_layer"],
        "independent_bulk_status": bulk_status,
        "independent_bulk_score_0_20": bulk_score,
        "local_program_score_0_15": local_score,
        "development_stage_score_0_20": evidence["stage_score"],
        "specificity_score_0_10": evidence["specificity_score"],
        "skin_relevance_score_0_10": evidence["skin_relevance_score"],
        "direction_safety_score_0_10": evidence["direction_safety_score"],
        "total_score_0_85": total,
        "lead_agent": evidence["lead_agent"],
        "development_stage": evidence["development_stage"],
        "agent_note": evidence["agent_note"],
        "source_url": evidence["source_url"],
        "as_of_date": AS_OF,
    }
    if target in tf_validation.index:
        x = tf_validation.loc[target]
        row.update({
            "external_bulk_effect": x["external_E_MTAB_9501_score"],
            "external_bulk_p": x["external_E_MTAB_9501_p"],
            "external_bulk_q": x["external_E_MTAB_9501_q_5TF"],
            "internal_positive_cohorts": x["internal_bulk_positive_cohorts"],
            "internal_cohorts": x["internal_bulk_cohorts"],
        })
    else:
        x = direct.loc[target]
        row.update({
            "external_bulk_effect": x["logFC"],
            "external_bulk_p": x["P.Value"],
            "external_bulk_q": x["adj.P.Val"],
            "internal_positive_cohorts": core.loc[target, "positive_cohorts"],
            "internal_cohorts": core.loc[target, "cohorts_available"],
        })
    rows.append(row)

ranking = pd.DataFrame(rows).sort_values(
    ["total_score_0_85", "independent_bulk_score_0_20"], ascending=False
).reset_index(drop=True)
ranking.insert(0, "overall_rank", range(1, len(ranking) + 1))
ranking["within_layer_rank"] = ranking.groupby("target_layer")["total_score_0_85"].rank(
    method="first", ascending=False
).astype(int)
ranking["recommendation"] = "deprioritize"
ranking.loc[
    ranking["target_layer"].eq("direct_TF") & ranking["within_layer_rank"].le(2), "recommendation"
] = "priority_pharmacology_probe"
ranking.loc[
    ranking["target_layer"].eq("core_mechanism"), "recommendation"
] = "mechanism_probe_only_not_therapy"
ranking.to_csv(OUT / "drug_target_ranking.tsv", sep="\t", index=False)

tf_candidates = ranking.loc[ranking["target_layer"].eq("direct_TF")].copy()
tf_candidates.to_csv(OUT / "direct_TF_target_ranking.tsv", sep="\t", index=False)
mechanism = ranking.loc[ranking["target_layer"].eq("core_mechanism")].copy()
mechanism.to_csv(OUT / "core_mechanism_target_ranking.tsv", sep="\t", index=False)

bulk_confirmation = pd.DataFrame([{
    "candidate_TFs_tested": len(tf_validation),
    "independent_bulk_confirmed_q_lt_0_05": int((
        tf_validation["external_direction_matches_APC"]
        & tf_validation["external_E_MTAB_9501_q_5TF"].lt(0.05)
    ).sum()),
    "direction_supported_not_significant": ";".join(
        tf_validation.index[tf_validation["external_direction_matches_APC"]].tolist()
    ),
    "direction_mismatch": ";".join(
        tf_validation.index[~tf_validation["external_direction_matches_APC"]].tolist()
    ),
    "top_direct_TF_target": tf_candidates.iloc[0]["target"],
    "top_mechanism_probe_target": mechanism.iloc[0]["target"],
    "as_of_date": AS_OF,
}])
bulk_confirmation.to_csv(OUT / "independent_bulk_confirmation_summary.tsv", sep="\t", index=False)

scoring = {
    "independent_bulk_score_0_20": "20 confirmed direction-consistent q<0.05; 10 direction-consistent q<0.5; 4 weaker direction-only; 0 mismatch/negative",
    "local_program_score_0_15": "TF virtual-KO tiers or core-gene top20 recurrence scaled to 15",
    "development_stage_score_0_20": "14 phase1/2; 12 phase1; 8 direct preclinical; 4 nonselective preclinical; 0 no agent",
    "specificity_score_0_10": "ordinal direct/selectivity assessment from primary pharmacology",
    "skin_relevance_score_0_10": "10 direct preclinical skin evidence; 2 indirect stress relevance; 0 none",
    "direction_safety_score_0_10": "penalizes essential DNA repair/cell-cycle blockade and broad transcriptional effects",
}
(OUT / "SCORING_RULES.json").write_text(json.dumps(scoring, ensure_ascii=False, indent=2) + "\n")

print(bulk_confirmation.to_string(index=False))
print(ranking[[
    "overall_rank", "target", "target_layer", "independent_bulk_status",
    "total_score_0_85", "lead_agent", "recommendation",
]].to_string(index=False))

