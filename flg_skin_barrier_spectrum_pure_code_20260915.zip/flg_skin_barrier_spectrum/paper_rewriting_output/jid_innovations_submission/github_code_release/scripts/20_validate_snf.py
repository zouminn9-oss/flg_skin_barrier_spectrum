#!/usr/bin/env python3

from pathlib import Path
import pandas as pd

root = Path(__file__).resolve().parents[1]
out = root / "results/exploratory_snf/selected_positive_reml_z_q05"

summary = pd.read_csv(out / "snf_summary.tsv", sep="\t").iloc[0]
views = pd.read_csv(out / "snf_view_summary.tsv", sep="\t")
edges = pd.read_csv(out / "snf_edge_statistics.tsv", sep="\t")
clusters = pd.read_csv(out / "snf_cluster_support.tsv", sep="\t")
models = pd.read_csv(out / "snf_cluster_model_selection.tsv", sep="\t")

assert int(summary["nodes"]) == 7
assert int(summary["positive_pathways"]) == 1444
assert int(summary["views"]) == 4
assert int(summary["selected_clusters"]) == 2
assert not bool(summary["IV_included"])
assert set(views["view"]) == {"all_positive", "immune_adaptive", "barrier_lipid", "stress_damage"}

sig = edges.loc[edges["permutation_q"] < 0.05]
assert len(sig) == 4
assert {tuple(sorted(x)) for x in sig[["disease_1", "disease_2"]].itertuples(index=False, name=None)} == {
    tuple(sorted(x)) for x in [("ACD", "ACNE"), ("ROSACEA", "ICD"), ("HS", "ICD"), ("AD", "PSORIASIS")]
}

membership = {r.disease: int(r.cluster) for r in clusters.itertuples()}
assert membership["AD"] == membership["ACD"] == membership["PSORIASIS"] == membership["ACNE"]
assert membership["HS"] == membership["ROSACEA"] == membership["ICD"]
assert membership["AD"] != membership["ICD"]
assert (clusters["bootstrap_cluster_support"] >= 0.75).all()
assert int(models.iloc[0]["k"]) == 2

target = edges[((edges.disease_1 == "AD") & (edges.disease_2 == "ACD")) |
               ((edges.disease_1 == "ACD") & (edges.disease_2 == "AD"))].iloc[0]
assert target["permutation_q"] > 0.05
assert target["bootstrap_coclustering"] >= 0.75

for fn in ("snf_network.png", "snf_fused_similarity_heatmap.png"):
    p = out / "figures" / fn
    assert p.exists() and p.stat().st_size > 10_000

report = (root / "SELECTED_POSITIVE_SNF_REPORT.md").read_text()
for phrase in ("4 条融合边", "Cluster 1", "Cluster 2", "0.792", "置换 q=0.771"):
    assert phrase in report

print("SNF_VALIDATION_OK nodes=7 views=4 pathways=1444 significant_edges=4 selected_k=2")
