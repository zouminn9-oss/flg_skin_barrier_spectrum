#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(Matrix)
  library(edgeR)
  library(limma)
})

root <- normalizePath(getwd())
expr_dir <- file.path(root, "data/raw/expression/geo/GSE267929")
meta_file <- file.path(root, "data/raw/geo/GSE267929/GSE267929_meta.data.tsv.gz")
out_dir <- file.path(root, "results/tables/single_cell_validation")
proc_dir <- file.path(root, "data/processed/expression/GSE267929")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(proc_dir, recursive = TRUE, showWarnings = FALSE)

counts <- readMM(gzfile(file.path(expr_dir, "GSE267929_matrix.mtx.gz")))
genes <- read.delim(gzfile(file.path(expr_dir, "GSE267929_genes.tsv.gz")),
                    header = FALSE, stringsAsFactors = FALSE)
barcodes <- readLines(gzfile(file.path(expr_dir, "GSE267929_barcodes.tsv.gz")))
meta <- read.table(gzfile(meta_file), header = TRUE, row.names = 1,
                   check.names = FALSE, stringsAsFactors = FALSE)
if (nrow(counts) != nrow(genes) || ncol(counts) != length(barcodes)) stop("Matrix dimensions do not match genes/barcodes")
if (!identical(barcodes, rownames(meta))) stop("Barcode order does not match metadata")
rownames(counts) <- genes[[2]]
colnames(counts) <- barcodes

cell_counts <- as.data.frame(xtabs(~ Patient + Lesion + Basic_Celltype, data = meta))
names(cell_counts)[4] <- "cells"
write.table(cell_counts, file.path(out_dir, "GSE267929_cell_counts.tsv"),
            sep = "\t", quote = FALSE, row.names = FALSE)

read_gmt <- function(path) {
  x <- strsplit(readLines(path, warn = FALSE), "\t", fixed = TRUE)
  sets <- lapply(x, function(z) unique(z[-c(1, 2)]))
  names(sets) <- vapply(x, `[[`, character(1), 1)
  sets
}
reactome <- read_gmt(file.path(root, "data/raw/pathways/reactome_v97/ReactomePathways.gmt"))

aggregate_pseudobulk <- function(cell_index, label) {
  m <- meta[cell_index, , drop = FALSE]
  grouping <- interaction(m$Patient, m$Lesion, drop = TRUE, sep = "__")
  z <- sparse.model.matrix(~ 0 + grouping)
  colnames(z) <- sub("^grouping", "", colnames(z))
  pb <- counts[, cell_index, drop = FALSE] %*% z
  colnames(pb) <- colnames(z)
  attr(pb, "cell_counts") <- as.integer(table(grouping)[colnames(pb)])
  saveRDS(pb, file.path(proc_dir, paste0("pseudobulk_", label, ".rds")))
  pb
}

fit_pair <- function(pb, label, min_cells) {
  parts <- do.call(rbind, strsplit(colnames(pb), "__", fixed = TRUE))
  smeta <- data.frame(sample = colnames(pb), participant = parts[, 1], condition = parts[, 2],
                      cells = attr(pb, "cell_counts"), stringsAsFactors = FALSE)
  target <- smeta$condition %in% c("Day4_Allergy", "Irritant") & smeta$cells >= min_cells
  smeta <- smeta[target, , drop = FALSE]
  paired <- names(which(table(smeta$participant) == 2L))
  smeta <- smeta[smeta$participant %in% paired, , drop = FALSE]
  if (length(paired) < 4L) return(NULL)
  y <- pb[, smeta$sample, drop = FALSE]
  smeta$participant <- factor(smeta$participant)
  smeta$condition <- factor(smeta$condition, levels = c("Irritant", "Day4_Allergy"))
  design <- model.matrix(~ participant + condition, data = smeta)
  dge <- DGEList(counts = y)
  keep <- filterByExpr(dge, design = design, min.count = 5)
  dge <- calcNormFactors(dge[keep, , keep.lib.sizes = FALSE])
  dge <- estimateDisp(dge, design, robust = TRUE)
  fit <- glmQLFit(dge, design, robust = TRUE)
  coef_name <- "conditionDay4_Allergy"
  qlf <- glmQLFTest(fit, coef = coef_name)
  tt <- topTags(qlf, n = Inf, sort.by = "none")$table
  tt$gene_symbol <- rownames(tt)
  tt$contrast <- "Day4_Allergy_minus_Irritant"
  tt$analysis <- label
  tt$n_donors <- length(paired)
  tt <- tt[, c("gene_symbol", "analysis", "contrast", "logFC", "logCPM", "F", "PValue", "FDR", "n_donors")]
  write.table(tt, file.path(out_dir, paste0("GSE267929_", label, "_gene_effects.tsv")),
              sep = "\t", quote = FALSE, row.names = FALSE)

  stat <- sign(tt$logFC) * sqrt(tt$F)
  names(stat) <- tt$gene_symbol
  idx <- lapply(reactome, function(z) which(names(stat) %in% z))
  idx <- idx[vapply(idx, length, integer(1)) >= 10L & vapply(idx, length, integer(1)) <= 500L]
  cam <- cameraPR(stat, index = idx, use.ranks = TRUE, inter.gene.cor = 0.01, sort = FALSE)
  cam$pathway <- rownames(cam)
  cam$analysis <- label
  cam$contrast <- "Day4_Allergy_minus_Irritant"
  cam$FDR <- p.adjust(cam$PValue, method = "BH")
  cam <- cam[, c("pathway", "analysis", "contrast", "NGenes", "Direction", "PValue", "FDR")]
  cam <- cam[order(cam$PValue), ]
  write.table(cam, file.path(out_dir, paste0("GSE267929_", label, "_reactome.tsv")),
              sep = "\t", quote = FALSE, row.names = FALSE)

  write.table(smeta, file.path(out_dir, paste0("GSE267929_", label, "_pseudobulk_samples.tsv")),
              sep = "\t", quote = FALSE, row.names = FALSE)
  data.frame(
    analysis = label,
    minimum_cells_per_donor_condition = min_cells,
    paired_donors = length(paired),
    tested_genes = nrow(tt),
    gene_fdr_0_05 = sum(tt$FDR < 0.05, na.rm = TRUE),
    reactome_fdr_0_05 = sum(cam$FDR < 0.05, na.rm = TRUE),
    donors = paste(sort(paired), collapse = ";")
  )
}

summaries <- list()
pb_all <- aggregate_pseudobulk(seq_len(ncol(counts)), "all_cells")
summaries[["all_cells"]] <- fit_pair(pb_all, "all_cells", min_cells = 20L)

for (ct in c("APC", "KRT", "LYMPH", "MEL")) {
  idx <- which(meta$Basic_Celltype == ct)
  pb <- aggregate_pseudobulk(idx, ct)
  summaries[[ct]] <- fit_pair(pb, ct, min_cells = 10L)
}

summary_table <- do.call(rbind, summaries[!vapply(summaries, is.null, logical(1))])
write.table(summary_table, file.path(out_dir, "GSE267929_pseudobulk_summary.tsv"),
            sep = "\t", quote = FALSE, row.names = FALSE)
print(summary_table)
