#!/usr/bin/env python3
"""Score the frozen GSE201278 JNJ-7706621 skin-line contrast."""

from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
LOCAL_PACKAGES = ROOT / "environment/python_packages"
if LOCAL_PACKAGES.exists():
    sys.path.insert(0, str(LOCAL_PACKAGES))

import numpy as np
import pandas as pd
from scipy.stats import rankdata, spearmanr


SEED = 20260826
N_PERM = 10_000
RAW = ROOT / "data/raw/perturbations/GSE201278"
FPKM = RAW / "GSE201278_fpkm.txt.gz"
SERIES = RAW / "GSE201278_series.soft.txt"
SAMPLES = RAW / "GSE201278_samples.soft.txt"
MECH = ROOT / "results/exploratory_snf/selected_positive_reml_z_q05/optimized_AD_ACD_branch/mechanism"
DISEASE = MECH / "drug_signature_reversal/locked_disease_signatures.tsv"
TARGETED = MECH / "lincs_cross_resource_replication/covered_compound_aggregation.tsv"
FULL = MECH / "lincs_full_background_calibration/JNJ7706621_FULL_BACKGROUND_DISPOSITION.json"
FROZEN_GENES = MECH / "lincs_full_background_calibration/gctx_row_identifiers.tsv"
OUT = MECH / "gse201278_jnj_skin_line_validation"
OUT.mkdir(parents=True, exist_ok=True)

CTRL = ["SKMEL2.CTRL.1", "SKMEL2.CTRL.2"]
JNJ = ["SKMEL2.JNJ.1.75.1", "SKMEL2.JNJ.1.75.2"]
EXPECTED_COLUMNS = ["Gene_ID", *CTRL, *JNJ, "gene_name"]


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def weighted_corr(y, x, weights):
    y = np.asarray(y, dtype=float)
    x = np.asarray(x, dtype=float)
    w = np.asarray(weights, dtype=float)
    w = w / w.sum()
    mx = float(w @ x)
    my = float(w @ y)
    xc = x - mx
    yc = y - my
    denom = np.sqrt(float(w @ (xc * xc)) * float(w @ (yc * yc)))
    return float(-(w @ (xc * yc)) / denom) if denom > 0 else np.nan


def rank_corr(y, x):
    value = spearmanr(np.asarray(y, dtype=float), np.asarray(x, dtype=float)).statistic
    return float(-value)


def panel(effect: pd.Series, disease: pd.DataFrame, prefix: str = "apc"):
    aligned = disease.join(effect.rename("effect"), how="inner")
    if prefix == "apc":
        stat_col = "apc_signed_stat"
    elif prefix == "external":
        stat_col = "external_t"
    else:
        raise ValueError(prefix)
    base = aligned[aligned[stat_col].notna() & aligned["effect"].notna()].copy()
    x = base[stat_col].to_numpy(float)
    y = base["effect"].to_numpy(float)
    weights = np.minimum(np.abs(x), np.quantile(np.abs(x), 0.95))
    program = base["program_weight"].fillna(0).gt(0).to_numpy()
    program_weights = base["program_weight"].fillna(0).to_numpy(float)
    scores = {
        f"{prefix}_genome_rank_reversal": rank_corr(y, x),
        f"{prefix}_genome_weighted_reversal": weighted_corr(y, x, weights),
        f"{prefix}_program_rank_reversal": rank_corr(y[program], x[program]),
        f"{prefix}_program_weighted_reversal": weighted_corr(
            y[program], x[program], program_weights[program]
        ),
    }
    scores[f"{prefix}_composite_reversal"] = float(np.mean(list(scores.values())))
    scores[f"{prefix}_genes"] = int(len(base))
    scores[f"{prefix}_program_genes"] = int(program.sum())
    return scores


def toxicity(effect: pd.Series, disease: pd.DataFrame, primary_scores: dict):
    aligned = disease.join(effect.rename("effect"), how="inner")
    z = (aligned["effect"] - aligned["effect"].mean()) / aligned["effect"].std(ddof=1)
    axes = {
        "cell_death_induction": float(z[aligned["tox_cell_death"].fillna(False)].mean()),
        "translation_shutdown": float(-z[aligned["tox_translation_ribosome"].fillna(False)].mean()),
        "cellcycle_replication_arrest": float(-z[aligned["tox_cellcycle_replication"].fillna(False)].mean()),
    }
    tox_index = float(max(axes.values()))
    removed_effect = aligned.loc[~aligned["tox_any"].fillna(False), "effect"]
    removed = panel(removed_effect, disease, "apc")
    observed = float(primary_scores["apc_composite_reversal"])
    removed_value = float(removed["apc_composite_reversal"])
    attenuation = float((observed - removed_value) / abs(observed)) if abs(observed) > 1e-12 else np.nan
    dominated = bool(tox_index >= 0.5 and (removed_value <= 0 or attenuation >= 0.5))
    return {
        **{f"tox_{key}": value for key, value in axes.items()},
        "toxicity_index": tox_index,
        "tox_removed_apc_composite_reversal": removed_value,
        "tox_removal_attenuation_fraction": attenuation,
        "toxicity_dominated": dominated,
    }


raw = pd.read_csv(FPKM, sep="\t", compression="gzip")
if raw.columns.tolist() != EXPECTED_COLUMNS:
    raise RuntimeError(f"Unexpected expression columns: {raw.columns.tolist()}")
values = raw[CTRL + JNJ].apply(pd.to_numeric, errors="raise")
if values.isna().any().any() or not np.isfinite(values.to_numpy()).all() or (values < 0).any().any():
    raise RuntimeError("FPKM matrix contains missing, non-finite, or negative values")
if raw["Gene_ID"].duplicated().any():
    raise RuntimeError("Duplicate Ensembl identifiers")

series_text = SERIES.read_text()
samples_text = SAMPLES.read_text()
if series_text.count("!Series_sample_id") != 2 or samples_text.count("^SAMPLE") != 2:
    raise RuntimeError("GEO metadata does not contain exactly one registered sample per arm")

disease = pd.read_csv(DISEASE, sep="\t").set_index("gene")
if disease.index.duplicated().any():
    raise RuntimeError("Duplicate disease-signature gene symbols")
frozen_gene_table = pd.read_csv(FROZEN_GENES, sep="\t")
frozen_gene_column = "gene" if "gene" in frozen_gene_table else frozen_gene_table.columns[-1]
frozen_gene_set = set(frozen_gene_table[frozen_gene_column].astype(str))
disease = disease.loc[disease.index.astype(str).isin(frozen_gene_set)].copy()
if disease["apc_signed_stat"].notna().sum() != 3735 or (
    disease["apc_signed_stat"].notna() & disease["program_weight"].gt(0)
).sum() != 214:
    raise RuntimeError("Frozen LINCS gene panel does not reconcile to 3,735/214 genes")


def collapsed_effect(pseudocount=1.0, ctrl_col=None, jnj_col=None):
    if ctrl_col is None:
        ctrl = np.log2(values[CTRL] + pseudocount).mean(axis=1)
    else:
        ctrl = np.log2(values[ctrl_col] + pseudocount)
    if jnj_col is None:
        treated = np.log2(values[JNJ] + pseudocount).mean(axis=1)
    else:
        treated = np.log2(values[jnj_col] + pseudocount)
    frame = pd.DataFrame({"gene": raw["gene_name"].astype(str), "effect": treated - ctrl})
    frame = frame[frame["gene"].notna() & frame["gene"].ne("")]
    return frame.groupby("gene", sort=True)["effect"].median()


effect = collapsed_effect(1.0)
mean_fpkm = pd.DataFrame({
    "gene": raw["gene_name"].astype(str),
    "mean_fpkm": values.mean(axis=1),
}).groupby("gene", sort=True)["mean_fpkm"].median()

primary = panel(effect, disease, "apc")
external = panel(effect, disease, "external")
tox = toxicity(effect, disease, primary)

sensitivities = []
for label, sensitivity_effect in [
    ("pseudocount_0.5", collapsed_effect(0.5)),
    ("pseudocount_2", collapsed_effect(2.0)),
    ("mean_fpkm_ge_1", effect[mean_fpkm.reindex(effect.index).ge(1).fillna(False)]),
]:
    scores = panel(sensitivity_effect, disease, "apc")
    sensitivities.append({"analysis": label, **scores})
low, high = effect.quantile([0.01, 0.99])
scores = panel(effect.clip(low, high), disease, "apc")
sensitivities.append({"analysis": "winsorized_1_99", **scores})
sensitivity = pd.DataFrame(sensitivities)

pairwise_rows = []
for ctrl_col in CTRL:
    for jnj_col in JNJ:
        scores = panel(collapsed_effect(1.0, ctrl_col, jnj_col), disease, "apc")
        pairwise_rows.append({"control_column": ctrl_col, "jnj_column": jnj_col, **scores})
pairwise = pd.DataFrame(pairwise_rows)

# Gene-label permutation: preserve the observed contrast distribution and fixed disease labels.
perm_base = disease.join(effect.rename("effect"), how="inner")
perm_base = perm_base[perm_base["apc_signed_stat"].notna() & perm_base["effect"].notna()].copy()
x = perm_base["apc_signed_stat"].to_numpy(float)
y = perm_base["effect"].to_numpy(float)
w = np.minimum(np.abs(x), np.quantile(np.abs(x), 0.95))
program = perm_base["program_weight"].fillna(0).gt(0).to_numpy()
pw = perm_base["program_weight"].fillna(0).to_numpy(float)
rng = np.random.default_rng(SEED)
permuted = np.empty(N_PERM, dtype=float)
for index in range(N_PERM):
    yp = rng.permutation(y)
    permuted[index] = np.mean([
        rank_corr(yp, x), weighted_corr(yp, x, w),
        rank_corr(yp[program], x[program]),
        weighted_corr(yp[program], x[program], pw[program]),
    ])
observed = float(primary["apc_composite_reversal"])
alignment_fraction = float((1 + np.sum(permuted >= observed)) / (N_PERM + 1))
permutation_summary = {
    "seed": SEED,
    "permutations": N_PERM,
    "observed_apc_composite_reversal": observed,
    "gene_label_alignment_fraction": alignment_fraction,
    "quantity_is_treatment_effect_p": False,
    "quantity_is_fdr": False,
    "permuted_quantiles": {
        str(q): float(np.quantile(permuted, q)) for q in [0, 0.01, 0.05, 0.5, 0.95, 0.99, 1]
    },
}

targeted = pd.read_csv(TARGETED, sep="\t").set_index("target_key").loc["JNJ-7706621"]
full = json.loads(FULL.read_text())
four_keys = [
    "apc_genome_rank_reversal", "apc_genome_weighted_reversal",
    "apc_program_rank_reversal", "apc_program_weighted_reversal",
]
all_four_positive = bool(all(primary[key] > 0 for key in four_keys))
external_positive = bool(external["external_composite_reversal"] > 0)
transform_robust = bool(sensitivity["apc_composite_reversal"].gt(0).all())
pairwise_robust = bool(pairwise["apc_composite_reversal"].gt(0).all())
if observed <= 0:
    label = "independent_skin_line_not_supported"
elif (
    all_four_positive and external_positive and not tox["toxicity_dominated"]
    and transform_robust and pairwise_robust and alignment_fraction < 0.05
):
    label = "independent_skin_line_direction_supported"
else:
    label = "independent_skin_line_directional_but_fragile"

contrast = pd.DataFrame({
    "gene": effect.index,
    "jnj_minus_dmso_log2_fpkm_plus_1": effect.to_numpy(),
    "mean_fpkm": mean_fpkm.reindex(effect.index).to_numpy(),
}).sort_values("gene")
contrast.to_csv(OUT / "gene_level_jnj_contrast.tsv", sep="\t", index=False)
pd.DataFrame([{**primary, **external, **tox}]).to_csv(
    OUT / "frozen_score_panel.tsv", sep="\t", index=False
)
sensitivity.to_csv(OUT / "transformation_sensitivity.tsv", sep="\t", index=False)
pairwise.to_csv(OUT / "processed_column_pairwise_audit.tsv", sep="\t", index=False)
np.save(OUT / "gene_label_permuted_composites.npy", permuted)
(OUT / "GENE_LABEL_PERMUTATION_SUMMARY.json").write_text(json.dumps(permutation_summary, indent=2) + "\n")

registered_runs = ["SRR18885475", "SRR18885476"]
source_qc = {
    "checked_at_utc": datetime.now(timezone.utc).isoformat(),
    "series": "GSE201278",
    "bioproject": "PRJNA830706",
    "cell_line": "SK-MEL-2",
    "cell_type": "skin melanoma cells",
    "treatment": "JNJ-7706621 1.75 uM 48 h",
    "registered_geo_samples": 2,
    "registered_sra_runs": registered_runs,
    "registered_runs_per_arm": 1,
    "processed_expression_columns": CTRL + JNJ,
    "processed_columns_per_arm": 2,
    "processed_column_to_raw_run_mapping_available": False,
    "metadata_ambiguity_severity": "high",
    "metadata_ambiguity_impact": "processed columns cannot be treated as independent biological replicates",
    "fpkm_bytes": FPKM.stat().st_size,
    "fpkm_sha256": sha256(FPKM),
    "series_soft_sha256": sha256(SERIES),
    "samples_soft_sha256": sha256(SAMPLES),
    "expression_rows": int(len(raw)),
    "expression_gene_symbols": int(effect.index.nunique()),
    "duplicate_gene_symbols_collapsed": int(raw["gene_name"].duplicated(keep=False).sum()),
    "missing_expression_values": int(values.isna().sum().sum()),
    "negative_expression_values": int((values < 0).sum().sum()),
    "ctrl_column_spearman": float(values[CTRL[0]].corr(values[CTRL[1]], method="spearman")),
    "jnj_column_spearman": float(values[JNJ[0]].corr(values[JNJ[1]], method="spearman")),
    "apc_gene_coverage": int(primary["apc_genes"]),
    "apc_gene_coverage_fraction": float(primary["apc_genes"] / 3735),
    "program_gene_coverage": int(primary["apc_program_genes"]),
    "program_gene_coverage_fraction": float(primary["apc_program_genes"] / 214),
}
(OUT / "SOURCE_AND_SCHEMA_QC.json").write_text(json.dumps(source_qc, indent=2) + "\n")

disposition = {
    "candidate": "JNJ-7706621",
    "source": "GSE201278",
    "cell_context": "SK-MEL-2 skin melanoma cell line",
    "frozen_label": label,
    **primary,
    **external,
    **tox,
    "all_four_primary_positive": all_four_positive,
    "all_transform_sensitivities_positive": transform_robust,
    "all_processed_column_pairwise_composites_positive": pairwise_robust,
    "gene_label_alignment_fraction": alignment_fraction,
    "gene_label_alignment_fraction_is_treatment_effect_p": False,
    "registered_biological_samples_per_arm": 1,
    "processed_columns_per_arm": 2,
    "processed_columns_counted_as_independent_replicates": False,
    "metadata_ambiguity_severity": "high",
    "targeted_lincs_median_composite": float(targeted["median_apc_composite_reversal"]),
    "targeted_lincs_q_frozen": float(targeted["targeted_BH_q"]),
    "full_background_label_frozen": full["full_background_label"],
    "formal_replication": False,
    "clinical_evidence": False,
    "normal_keratinocyte_evidence": False,
    "cdk2_specificity_supported": False,
    "gate3_changed": False,
}
(OUT / "GSE201278_JNJ_DISPOSITION.json").write_text(json.dumps(disposition, indent=2) + "\n")
(OUT / "RUN_PARAMETERS.json").write_text(json.dumps({
    "completed_at_utc": datetime.now(timezone.utc).isoformat(),
    "seed": SEED,
    "gene_label_permutations": N_PERM,
    "primary_transform": "mean_arm_log2_fpkm_plus_1_difference",
    "status": "post_hoc_exploratory_computational_independent_skin_melanoma_line_direction_validation",
}, indent=2) + "\n")
print(json.dumps(disposition, indent=2))
