#!/usr/bin/env python3
"""Validate the complete LINCS background calibration and its evidence labels."""

from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
LOCAL_PACKAGES = ROOT / "environment/python_packages"
if LOCAL_PACKAGES.exists():
    sys.path.insert(0, str(LOCAL_PACKAGES))

import numpy as np
import pandas as pd


MECH = ROOT / "results/exploratory_snf/selected_positive_reml_z_q05/optimized_AD_ACD_branch/mechanism"
OUT = MECH / "lincs_full_background_calibration"
TARGETED = MECH / "lincs_cross_resource_replication"
PROTOCOL = ROOT / "LINCS_FULL_BACKGROUND_CALIBRATION_PROTOCOL.md"
EXPECTED_CONDITIONS = 718_157
EXPECTED_COMPOUNDS = 33_609
EXPECTED_BYTES = 36_084_518_760

checks = []


def check(name, condition, detail=""):
    passed = bool(condition)
    checks.append({"check": name, "passed": passed, "detail": str(detail)})
    if not passed:
        raise AssertionError(f"{name}: {detail}")


source = json.loads((OUT / "SOURCE_AND_SCHEMA_QC.json").read_text())
run = json.loads((OUT / "RUN_PARAMETERS.json").read_text())
disposition = json.loads((OUT / "JNJ7706621_FULL_BACKGROUND_DISPOSITION.json").read_text())
protocol = PROTOCOL.read_text()
ranking = pd.read_csv(OUT / "full_background_compound_ranking.tsv", sep="\t")
recon = pd.read_csv(OUT / "targeted_full_score_reconciliation.tsv", sep="\t")
recon_summary = pd.read_csv(OUT / "targeted_full_score_reconciliation_summary.tsv", sep="\t")
condition = pd.read_parquet(OUT / "condition_score_parts", columns=[
    "signature_id", "pert_name", "cell_line", "dose", "time",
    "apc_genome_rank_reversal", "apc_genome_weighted_reversal",
    "apc_program_rank_reversal", "apc_program_weighted_reversal",
    "apc_composite_reversal", "external_composite_reversal", "toxicity_index",
    "tox_removed_apc_composite_reversal", "condition_toxicity_dominated",
])
targeted = pd.read_csv(TARGETED / "covered_compound_aggregation.tsv", sep="\t").set_index("target_key")

check("protocol exists", PROTOCOL.exists())
check("protocol is explicitly post hoc", "post hoc" in protocol)
check("protocol is explicitly computational", "computational" in protocol)
check("protocol prohibits clinical inference", "establish efficacy or safety" in protocol)
check(
    "protocol preserves targeted q scope",
    "cannot become a library-wide q value" in protocol and "not an FDR" in protocol,
)
check("protocol records matrix version drift", "revised object under the 2021 library path" in protocol)
check("protocol records 2026 metadata amendment", "Pre-score metadata amendment" in protocol)
check("protocol freezes competitive quantity as non-P", "not a null-hypothesis P value" in protocol)
check("protocol freezes top-five-percent boundary", "top 5%" in protocol)

check("local matrix bytes exact", source["local_bytes"] == EXPECTED_BYTES, source["local_bytes"])
check("remote matrix bytes exact", source["remote_observed_bytes"] == EXPECTED_BYTES)
check("matrix SHA-256 recorded", len(source["local_sha256"]) == 64)
check("parallel assembly receipt verified", source["parallel_assembly_receipt_verified"])
check("multipart ETag not treated as MD5", source["multipart_etag_not_interpreted_as_md5"])
check("source drift status retained", source["version_drift"]["status"] == "revised_object_under_2021_library_path")
check("GCTX row identifiers unique", source["unique_rows"] == source["row_identifiers"])
check("GCTX column identifiers unique", source["unique_columns"] == source["column_identifiers"])
check("GCTX condition count", source["column_identifiers"] == EXPECTED_CONDITIONS)
check("Broad siginfo full record count", source["broad_siginfo"]["full_records"] == 1_201_944)
check("Broad siginfo GCTX record count", source["broad_siginfo"]["gctx_records"] == EXPECTED_CONDITIONS)
check("Broad siginfo covers every matrix sig_id", source["broad_siginfo"]["all_gctx_columns_covered"])
check("Broad siginfo SHA-256 frozen", source["broad_siginfo"]["local_sha256"] == "1a38d7ea2a804be79804af4a27aff9f2537af8f13d3c8af1fdc1fef780f40201")
check("Broad siginfo compound count", source["broad_siginfo"]["unique_gctx_compound_names"] == EXPECTED_COMPOUNDS)
check("current ranker metadata difference retained", source["current_ranker_metadata"]["record_difference_vs_gctx"] == 102)
check("current ranker covers targeted UUIDs", source["current_ranker_metadata"]["targeted_uuid_overlap"] == 2787)
check("all targeted cmap_ids overlap full matrix", source["targeted_identifier_overlap_counts"]["cmap_id"] == 2787)
check("targeted compound names agree", source["targeted_cmap_id_name_agreement_fraction"] == 1)

check("run condition count", run["conditions"] == EXPECTED_CONDITIONS)
check("run compound count", run["compounds"] == EXPECTED_COMPOUNDS)
check("run APC gene count frozen", run["common_complete_APC_genes"] == 3735)
check("run program gene count frozen", run["common_complete_program_genes"] == 214)
check("run does not reuse targeted BH as library FDR", not run["targeted_BH_reused_as_library_FDR"])
check("run does not claim library FDR", not run["library_wide_FDR_computed"])
check("run status remains exploratory", "exploratory" in run["status"])

check("condition rows complete", len(condition) == EXPECTED_CONDITIONS, len(condition))
check("condition UUIDs unique", condition["signature_id"].is_unique)
check("condition compound names complete", condition["pert_name"].notna().all())
check("condition cell lines complete", condition["cell_line"].notna().all())
score_columns = [column for column in condition if column.endswith("reversal") or column == "toxicity_index"]
check("condition scores finite", np.isfinite(condition[score_columns].to_numpy(float)).all())
check("condition toxicity flag complete", condition["condition_toxicity_dominated"].notna().all())

check("ranking rows complete", len(ranking) == EXPECTED_COMPOUNDS, len(ranking))
check("ranking compound names unique", ranking["pert_name"].is_unique)
check("ranking includes negative results", ranking["median_apc_composite_reversal"].le(0).any())
check("ranking includes positive results", ranking["median_apc_composite_reversal"].gt(0).any())
check("all ranks within background", ranking["all_compound_rank"].between(1, EXPECTED_COMPOUNDS).all())
check("competitive fractions bounded", ranking["all_compound_competitive_upper_tail_fraction"].between(0, 1).all())
check("competitive quantity labeled non-P/FDR", ranking["calibration_quantity_type"].eq("competitive_rank_fraction_not_null_p_not_fdr").all())
check("no fabricated library-wide q column", not any("BH_q" in column or "full_background_q" in column for column in ranking))

jnj = ranking.loc[ranking["pert_name"].eq("JNJ-7706621")]
check("one JNJ aggregate", len(jnj) == 1, len(jnj))
jnj = jnj.iloc[0]
check("JNJ retains all 297 conditions", jnj["n_conditions"] == 297)
check("JNJ retains 98 cell lines", jnj["n_cell_lines"] == 98)
check("JNJ disposition count matches ranking", disposition["full_background_conditions"] == jnj["n_conditions"])
check("JNJ all-background rank matches", disposition["all_compound_rank"] == jnj["all_compound_rank"])
check("JNJ eligible rank matches", disposition["stable_eligible_rank"] == jnj["stable_eligible_rank"])
check("JNJ all-background tail matches", np.isclose(disposition["all_compound_competitive_upper_tail_fraction"], jnj["all_compound_competitive_upper_tail_fraction"]))
check("JNJ targeted nominal P preserved", np.isclose(disposition["frozen_targeted_gene_label_empirical_p"], targeted.loc["JNJ-7706621", "gene_label_empirical_p"]))
check("JNJ targeted q preserved", np.isclose(disposition["frozen_targeted_BH_q"], targeted.loc["JNJ-7706621", "targeted_BH_q"]))
check("JNJ competitive fraction not called null P", not disposition["competitive_fraction_is_null_p"])
check("JNJ library FDR not claimed", not disposition["library_wide_fdr_computed"])
check("JNJ formal replication remains false", not disposition["formal_replication"])
check("JNJ clinical evidence remains false", not disposition["clinical_evidence"])
check("Gate 3 remains unchanged", not disposition["gate3_changed"])

check("targeted reconciliation has all 2787 rows", len(recon) == 2787, len(recon))
check("targeted reconciliation has no missing side", recon["_merge"].eq("both").all())
check("reconciliation covers five frozen scores", len(recon_summary) == 5)
status = run["targeted_source_reconciliation"]
check("reconciliation status allowed", status in {"compatible", "near_compatible", "version_divergent"}, status)
check("disposition reconciliation matches run", disposition["source_reconciliation"] == status)

direction = bool(jnj["primary_five_score_screen"])
top_all = bool(jnj["all_compound_competitive_upper_tail_fraction"] <= 0.05)
top_eligible = bool(jnj["stable_eligible_competitive_upper_tail_fraction"] <= 0.05)
robust = bool(jnj["multi_condition_stable"] and jnj["external_direction_supported"] and not jnj["toxicity_dominated"])
source_pass = status in {"compatible", "near_compatible"}
expected_label = (
    "full_background_competitive" if direction and top_all and top_eligible and robust and source_pass
    else "positive_not_top5" if direction and robust and source_pass
    else "full_background_not_supported"
)
check("frozen disposition rule applied exactly", disposition["full_background_label"] == expected_label, (disposition["full_background_label"], expected_label))

summary = {
    "status": "pass", "checks_passed": len(checks), "checks_failed": 0,
    "checks": checks,
}
(OUT / "VALIDATION_SUMMARY.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps({"status": "pass", "checks_passed": len(checks)}, indent=2))
