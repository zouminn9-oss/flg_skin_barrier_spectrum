#!/usr/bin/env python3
import csv
import hashlib
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "results/exploratory_snf/selected_positive_reml_z_q05/optimized_AD_ACD_branch/mechanism/apc_regulator_network"


def rows(path):
    with path.open(newline="") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


snapshot = ROOT / "data/raw/regulons/collectri/omnipath_collectri_human_2026-08-25.tsv"
digest = hashlib.sha256(snapshot.read_bytes()).hexdigest()
assert digest == "66645ed13dcabb0533f8e54600b0f7004b0a82ef0c07db55cd95306077cef632"

summary = rows(OUT / "apc_regulator_summary.tsv")[0]
assert int(summary["TFs_tested"]) == 306
assert int(summary["permutations"]) == 10000
assert int(summary["TFs_BH_q_lt_0_05"]) == 0
assert int(summary["TFs_max_stat_p_lt_0_05"]) == 0
assert int(summary["positive_nominal_core_connected_candidates"]) == 5
assert int(summary["candidate_network_edges"]) == 12
assert summary["lead_candidate"] == "YY1"

candidates = {r["TF"]: r for r in rows(OUT / "candidate_positive_regulators.tsv")}
assert set(candidates) == {"YY1", "IRF1", "E2F6", "E2F4", "HSF1"}
assert float(candidates["YY1"]["activity_score"]) > 2.9
assert float(candidates["YY1"]["empirical_p_two_sided"]) < 0.003
assert float(candidates["YY1"]["empirical_q_BH_306TF"]) > 0.05
assert int(candidates["E2F4"]["direct_core_targets"]) == 7

edges = rows(OUT / "candidate_regulator_core_edges.tsv")
yy1 = {(r["core_gene"], r["regulation"]) for r in edges if r["TF"] == "YY1"}
assert yy1 == {("BRCA1", "activation"), ("PCNA", "activation")}
assert len([r for r in edges if r["TF"] == "E2F4"]) == 7

loo = rows(OUT / "candidate_regulator_leave_one_target_out.tsv")
assert len(loo) == 250
assert all(r["positive_direction_preserved"] == "True" for r in loo)

cross = rows(OUT / "candidate_regulator_activity_across_celltypes.tsv")
assert len(cross) == 20
assert all(float(r["activity_score"]) > 0 for r in cross if r["TF"] == "YY1")

figure = OUT / "figures/candidate_APC_regulator_core_network.png"
assert figure.stat().st_size > 30_000
report = (ROOT / "AD_ACD_APC_REGULATOR_REPORT.md").read_text()
for phrase in ("YY1", "0.00260", "0 个达到", "250 次", "CollecTRI"):
    assert phrase in report

print("PASS: CollecTRI provenance, APC TF activities, candidate edges, LOO stability, figure, and report are consistent")
