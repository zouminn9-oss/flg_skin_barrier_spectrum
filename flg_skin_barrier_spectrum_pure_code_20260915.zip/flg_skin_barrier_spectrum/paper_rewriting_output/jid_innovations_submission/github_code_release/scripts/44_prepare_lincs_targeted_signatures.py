#!/usr/bin/env python3
"""Freeze coverage and prepare targeted SigCom LINCS Level-5 signatures.

This script performs no disease-signature scoring. It queries only identifiers
locked in LINCS_CROSS_RESOURCE_REPLICATION_PROTOCOL.md, retains every matched
condition, verifies each persistent file against the API SHA-256, and builds a
compact gene-by-condition coefficient matrix.
"""

from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from io import BytesIO
from pathlib import Path
from email.utils import parsedate_to_datetime
import hashlib
import json
import sys
import time
import urllib.error
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
LOCAL_PACKAGES = ROOT / "environment/python_packages"
if LOCAL_PACKAGES.exists():
    sys.path.insert(0, str(LOCAL_PACKAGES))

import numpy as np
import pandas as pd


LIBRARY_ID = "54198d6e-fe17-5ef8-91ac-02b425761653"
API = "https://maayanlab.cloud/sigcom-lincs/metadata-api"
MECH = ROOT / "results/exploratory_snf/selected_positive_reml_z_q05/optimized_AD_ACD_branch/mechanism"
OUT = MECH / "lincs_cross_resource_replication"
RAW = ROOT / "data/raw/perturbations/lincs_2021_targeted"
OUT.mkdir(parents=True, exist_ok=True)
RAW.mkdir(parents=True, exist_ok=True)

# The union of six Sci-Plex Tier-C and six provider-CDK2-token compounds.
SCIPLEX_TARGETS = [
    {"target_key": "AC480", "pubchem_ids": [10437018], "tier_c": True, "cdk2_token": False},
    {"target_key": "Andarine", "pubchem_ids": [9824562], "tier_c": True, "cdk2_token": False},
    {"target_key": "BMS-265246", "pubchem_ids": [135402864], "tier_c": True, "cdk2_token": True},
    {"target_key": "BMS-536924", "pubchem_ids": [135440466], "tier_c": False, "cdk2_token": True},
    {"target_key": "Bosutinib", "pubchem_ids": [5328940], "tier_c": False, "cdk2_token": True},
    {"target_key": "Droxinostat", "pubchem_ids": [568416], "tier_c": True, "cdk2_token": False},
    {"target_key": "G007-LK", "pubchem_ids": [67960134], "tier_c": True, "cdk2_token": False},
    {"target_key": "Iniparib", "pubchem_ids": [9796068], "tier_c": True, "cdk2_token": False},
    {"target_key": "JNJ-7706621", "pubchem_ids": [5330790], "tier_c": False, "cdk2_token": True},
    {"target_key": "PF-573228", "pubchem_ids": [11612883], "tier_c": False, "cdk2_token": True},
    {"target_key": "Roscovitine", "pubchem_ids": [160355], "tier_c": False, "cdk2_token": True},
]

# Previously named agents. Case variants are fixed here before any scoring
# because SigCom exact matching is case-sensitive.
LEAD_TARGETS = [
    {"target_key": "I-2", "target": "IRF1", "pubchem_ids": [], "aliases": ["I-2", "i-2"]},
    {"target_key": "I-19", "target": "IRF1", "pubchem_ids": [], "aliases": ["I-19", "i-19"]},
    {"target_key": "DTHIB/SISU-102", "target": "HSF1", "pubchem_ids": [108866909],
     "aliases": ["DTHIB", "dthib", "SISU-102", "sisu-102"]},
    {"target_key": "camonsertib", "target": "ATR", "pubchem_ids": [156487652],
     "aliases": ["camonsertib", "RP-3500", "rp-3500", "RP3500", "rp3500"]},
    {"target_key": "ceralasertib", "target": "ATR", "pubchem_ids": [54761306, 121596701],
     "aliases": ["ceralasertib", "AZD6738", "azd6738", "AZD-6738", "azd-6738"]},
    {"target_key": "elimusertib", "target": "ATR", "pubchem_ids": [118869362, 129893299],
     "aliases": ["elimusertib", "BAY-1895344", "bay-1895344", "BAY1895344", "bay1895344"]},
    {"target_key": "AOH1996", "target": "PCNA", "pubchem_ids": [126718388],
     "aliases": ["AOH1996", "aoh1996"]},
    {"target_key": "INX-315", "target": "CDK2", "pubchem_ids": [162360412],
     "aliases": ["INX-315", "inx-315"]},
    {"target_key": "AZD8421", "target": "CDK2", "pubchem_ids": [171364438],
     "aliases": ["AZD8421", "azd8421"]},
    {"target_key": "HLM006474", "target": "E2F4", "pubchem_ids": [2895500],
     "aliases": ["HLM006474", "hlm006474", "HLM-006474", "hlm-006474"]},
]


def post_json(endpoint, payload, timeout=240):
    request = urllib.request.Request(
        f"{API}/{endpoint}", data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json", "User-Agent": "FLG-LINCS-replication/1.0"},
    )
    with urllib.request.urlopen(request, timeout=timeout) as handle:
        return json.load(handle)


def signature_query(field, values):
    return {
        "filter": {"where": {"and": [
            {field: {"inq": values}}, {"library": {"eq": LIBRARY_ID}},
        ]}},
        "limit": 10000,
    }


def normalize_records(result):
    if isinstance(result, list):
        return result
    for key in ("data", "results", "items"):
        if isinstance(result.get(key), list):
            return result[key]
    raise TypeError(f"Unexpected API response: {type(result)}")


queried_at = datetime.now(timezone.utc).isoformat()
library_payload = {"filter": {"where": {"id": {"eq": LIBRARY_ID}}}, "limit": 10}
library_response = post_json("libraries/find", library_payload)

sciplex_cids = [cid for row in SCIPLEX_TARGETS for cid in row["pubchem_ids"]]
lead_cids = [cid for row in LEAD_TARGETS for cid in row["pubchem_ids"]]
lead_aliases = [alias for row in LEAD_TARGETS for alias in row["aliases"]]
payloads = {
    "sciplex_pubchem": signature_query("meta.pubchem_id", sciplex_cids),
    "lead_pubchem": signature_query("meta.pubchem_id", lead_cids),
    "lead_alias": signature_query("meta.pert_name", lead_aliases),
}
responses = {name: normalize_records(post_json("signatures/find", payload)) for name, payload in payloads.items()}

with (OUT / "api_queries.json").open("w") as handle:
    json.dump({"queried_at_utc": queried_at, "api": API, "library": LIBRARY_ID,
               "library_payload": library_payload, "signature_payloads": payloads}, handle, indent=2)
with (OUT / "library_response.json").open("w") as handle:
    json.dump(library_response, handle, indent=2)
with (OUT / "raw_signature_metadata.json").open("w") as handle:
    json.dump(responses, handle, indent=2)

# Deduplicate UUIDs while recording every prespecified route that matched.
records = {}
routes = {}
for query_name, response in responses.items():
    for record in response:
        signature_id = str(record["id"])
        records.setdefault(signature_id, record)
        routes.setdefault(signature_id, set()).add(query_name)

cid_to_target = {}
for row in SCIPLEX_TARGETS:
    for cid in row["pubchem_ids"]:
        cid_to_target[int(cid)] = row["target_key"]
for row in LEAD_TARGETS:
    for cid in row["pubchem_ids"]:
        cid_to_target[int(cid)] = row["target_key"]
alias_to_target = {alias: row["target_key"] for row in LEAD_TARGETS for alias in row["aliases"]}

metadata_rows = []
for signature_id, record in records.items():
    meta = record["meta"]
    pubchem = meta.get("pubchem_id")
    target_key = cid_to_target.get(int(pubchem)) if pubchem not in (None, "") else None
    if target_key is None:
        target_key = alias_to_target.get(str(meta.get("pert_name")))
    if target_key is None:
        raise AssertionError((signature_id, pubchem, meta.get("pert_name")))
    metadata_rows.append({
        "signature_id": signature_id,
        "target_key": target_key,
        "query_routes": ";".join(sorted(routes[signature_id])),
        "local_id": meta.get("local_id"),
        "cmap_id": meta.get("cmap_id"),
        "pert_name": meta.get("pert_name"),
        "pubchem_id": pubchem,
        "cell_line": meta.get("cell_line"),
        "tissue": meta.get("tissue"),
        "disease": meta.get("disease"),
        "dose": meta.get("pert_dose"),
        "time": meta.get("pert_time"),
        "data_level": meta.get("data_level"),
        "version": meta.get("version"),
        "creation_time": meta.get("creation_time"),
        "filename": meta.get("filename"),
        "persistent_id": meta.get("persistent_id"),
        "expected_sha256": meta.get("sha256"),
        "expected_md5": meta.get("md5"),
        "expected_bytes": meta.get("size_in_bytes"),
        "signature_strength_available": False,
    })
metadata = pd.DataFrame(metadata_rows).sort_values(["target_key", "signature_id"]).reset_index(drop=True)
assert metadata["signature_id"].is_unique
assert metadata["persistent_id"].notna().all() and metadata["expected_sha256"].notna().all()
metadata.to_csv(OUT / "condition_metadata.tsv", sep="\t", index=False)

inventory_rows = []
for row in SCIPLEX_TARGETS:
    n = int(metadata["target_key"].eq(row["target_key"]).sum())
    inventory_rows.append({
        "target_key": row["target_key"], "target": "CDK2" if row["cdk2_token"] else "",
        "target_group": "sciplex_audit", "sciplex_tier_c": row["tier_c"],
        "sciplex_cdk2_token": row["cdk2_token"], "pubchem_ids": ";".join(map(str, row["pubchem_ids"])),
        "aliases": "", "matched_signatures": n, "coverage": "covered" if n else "not_covered",
    })
for row in LEAD_TARGETS:
    n = int(metadata["target_key"].eq(row["target_key"]).sum())
    inventory_rows.append({
        "target_key": row["target_key"], "target": row["target"], "target_group": "named_prior_lead",
        "sciplex_tier_c": False, "sciplex_cdk2_token": False,
        "pubchem_ids": ";".join(map(str, row["pubchem_ids"])), "aliases": ";".join(row["aliases"]),
        "matched_signatures": n, "coverage": "covered" if n else "not_covered",
    })
inventory = pd.DataFrame(inventory_rows)
inventory.to_csv(OUT / "target_coverage_inventory.tsv", sep="\t", index=False)

if metadata.empty:
    raise RuntimeError("No locked target has LINCS coverage; no matrix can be prepared")


def fetch_bytes(row, attempts=5):
    error = None
    for attempt in range(attempts):
        try:
            request = urllib.request.Request(row.persistent_id, headers={"User-Agent": "FLG-LINCS-replication/1.0"})
            with urllib.request.urlopen(request, timeout=120) as handle:
                content = handle.read()
                etag = handle.headers.get("ETag", "").strip('"')
                last_modified = handle.headers.get("Last-Modified", "")
            observed_sha = hashlib.sha256(content).hexdigest()
            observed_md5 = hashlib.md5(content).hexdigest()
            # API hashes are systematically stale. The pre-score protocol
            # amendment instead requires a single-part S3 ETag/body-MD5 match.
            if len(etag) != 32 or "-" in etag or observed_md5 != etag:
                raise ValueError(f"S3 ETag/body-MD5 mismatch {row.signature_id}: {etag} != {observed_md5}")
            modified = parsedate_to_datetime(last_modified)
            if modified.year != 2021:
                raise ValueError(f"Unexpected object date {row.signature_id}: {last_modified}")
            frame = pd.read_csv(BytesIO(content), sep="\t")
            gene_column = str(frame.columns[0]) if len(frame.columns) else ""
            if len(frame.columns) != 2 or gene_column not in {"symbol", "Unnamed: 0"} or frame.columns[1] != "CD-coefficient":
                raise ValueError(f"Unexpected columns {row.signature_id}: {list(frame.columns)}")
            genes = frame.iloc[:, 0].astype(str).to_numpy()
            values = frame["CD-coefficient"].to_numpy(np.float32)
            return genes, values, gene_column, observed_sha, observed_md5, etag, last_modified, len(content), attempt + 1
        except (urllib.error.URLError, TimeoutError, ValueError) as exc:
            error = exc
            if attempt + 1 < attempts:
                time.sleep(1.5 * (attempt + 1))
    raise RuntimeError(f"Failed {row.signature_id}: {error}")


# Establish the gene order, then fill a preallocated condition-by-gene matrix.
first = metadata.iloc[0]
first_genes, first_values, first_gene_column, first_sha, first_md5, first_etag, first_modified, first_bytes, first_attempts = fetch_bytes(first)
assert len(first_genes) == len(set(first_genes))
effects = np.empty((len(metadata), len(first_genes)), dtype=np.float32)
effects[0] = first_values
download_rows = [{
    "signature_id": first.signature_id, "persistent_id": first.persistent_id,
    "source_gene_column": first_gene_column,
    "expected_sha256": first.expected_sha256, "observed_sha256": first_sha,
    "api_sha256_matches": first.expected_sha256 == first_sha,
    "expected_md5": first.expected_md5, "observed_md5": first_md5,
    "api_md5_matches": first.expected_md5 == first_md5, "s3_etag": first_etag,
    "etag_body_md5_verified": first_etag == first_md5, "s3_last_modified": first_modified,
    "expected_bytes": first.expected_bytes, "observed_bytes": first_bytes,
    "api_size_matches": first.expected_bytes == first_bytes,
    "attempts": first_attempts, "verified": True,
}]


def fetch_index(index):
    row = metadata.iloc[index]
    genes, values, gene_column, observed, observed_md5, etag, modified, nbytes, attempts = fetch_bytes(row)
    if not np.array_equal(genes, first_genes):
        raise ValueError(f"Gene order/content differs for {row.signature_id}")
    return index, values, gene_column, observed, observed_md5, etag, modified, nbytes, attempts


with ThreadPoolExecutor(max_workers=16) as pool:
    futures = {pool.submit(fetch_index, index): index for index in range(1, len(metadata))}
    completed = 1
    for future in as_completed(futures):
        index, values, gene_column, observed, observed_md5, etag, modified, nbytes, attempts = future.result()
        effects[index] = values
        row = metadata.iloc[index]
        download_rows.append({
            "signature_id": row.signature_id, "persistent_id": row.persistent_id,
            "source_gene_column": gene_column,
            "expected_sha256": row.expected_sha256, "observed_sha256": observed,
            "api_sha256_matches": row.expected_sha256 == observed,
            "expected_md5": row.expected_md5, "observed_md5": observed_md5,
            "api_md5_matches": row.expected_md5 == observed_md5, "s3_etag": etag,
            "etag_body_md5_verified": etag == observed_md5, "s3_last_modified": modified,
            "expected_bytes": row.expected_bytes, "observed_bytes": nbytes,
            "api_size_matches": row.expected_bytes == nbytes,
            "attempts": attempts, "verified": True,
        })
        completed += 1
        if completed % 250 == 0 or completed == len(metadata):
            print(f"verified {completed}/{len(metadata)} persistent signatures", flush=True)

downloads = pd.DataFrame(download_rows).sort_values("signature_id")
downloads.to_csv(OUT / "persistent_file_integrity.tsv", sep="\t", index=False)
assert downloads["verified"].all() and downloads["etag_body_md5_verified"].all() and len(downloads) == len(metadata)
assert np.isfinite(effects).all(), "Level-5 targeted files unexpectedly contain non-finite coefficients"

np.savez_compressed(
    OUT / "prepared_lincs_effects.npz",
    genes=np.asarray(first_genes, dtype=str),
    condition_ids=metadata["signature_id"].astype(str).to_numpy(dtype=str), effects=effects.T,
)

coverage_counts = inventory.groupby(["target_group", "coverage"]).size().rename("targets").reset_index()
coverage_counts.to_csv(OUT / "coverage_summary.tsv", sep="\t", index=False)

provenance = f"""# Provenance — targeted LINCS L1000 2021 signatures

- Accessed (UTC): {queried_at}
- Metadata API: {API}
- Library: l1000_cp, UUID `{LIBRARY_ID}`
- Release: 2021-06-10, Level 5 characteristic-direction coefficients, version 1
- Selection: identifiers frozen in `LINCS_CROSS_RESOURCE_REPLICATION_PROTOCOL.md`; no reversal score was computed by the preparation script
- Conditions: {len(metadata):,}; genes per condition: {len(first_genes):,}
- Persistent files: each URL, stale API digest, observed SHA-256, S3 ETag, and comparison result is retained in `persistent_file_integrity.tsv`; every computed body MD5 matched its single-part S3 ETag before matrix construction
- Integrity deviation: API SHA-256/MD5 values were systematically inconsistent with served bodies; the pre-score amendment in `LINCS_CROSS_RESOURCE_REPLICATION_PROTOCOL.md` records the replacement transport check
- Missing metadata: the API records do not expose CLUE signature-strength/quality metrics; this is retained as unavailable rather than imputed
- Raw storage policy: verified individual responses were parsed in memory; the compact matrix plus complete URLs and checksums is retained to make byte-identical refetching possible
"""
(RAW / "PROVENANCE.md").write_text(provenance)

print(inventory[["target_key", "target_group", "matched_signatures", "coverage"]].to_string(index=False))
print(f"prepared genes={len(first_genes)} conditions={len(metadata)} matrix={effects.shape}")
