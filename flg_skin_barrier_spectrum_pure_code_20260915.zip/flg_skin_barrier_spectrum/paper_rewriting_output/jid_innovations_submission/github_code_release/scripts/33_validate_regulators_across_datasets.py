#!/usr/bin/env python3
"""Cross-dataset validation of the five APC-derived TF candidates."""

from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.stats import binomtest


ROOT = Path(__file__).resolve().parents[1]
MECH = ROOT / "results/exploratory_snf/selected_positive_reml_z_q05/optimized_AD_ACD_branch/mechanism"
APC_NET = MECH / "apc_regulator_network"
OUT = MECH / "regulator_crossdataset_validation"
FIG = OUT / "figures"
OUT.mkdir(parents=True, exist_ok=True)
FIG.mkdir(parents=True, exist_ok=True)

PERMUTATIONS = 10_000
CANDIDATES = pd.read_csv(APC_NET / "candidate_positive_regulators.tsv", sep="\t")["TF"].tolist()
assert CANDIDATES == ["YY1", "IRF1", "E2F6", "E2F4", "HSF1"]


def bh_adjust(values):
    p = np.asarray(values, dtype=float)
    order = np.argsort(p)
    ranked = p[order]
    q = ranked * len(ranked) / np.arange(1, len(ranked) + 1)
    q = np.minimum.accumulate(q[::-1])[::-1]
    restored = np.empty_like(q)
    restored[order] = np.minimum(q, 1)
    return restored


raw = pd.read_csv(
    ROOT / "data/raw/regulons/collectri/omnipath_collectri_human_2026-08-25.tsv",
    sep="\t", low_memory=False,
)
raw = raw.loc[raw["consensus_stimulation"].ne(raw["consensus_inhibition"])].copy()
raw["mor"] = np.where(raw["consensus_stimulation"], 1.0, -1.0)
pairs = raw.groupby(["source_genesymbol", "target_genesymbol"])["mor"].mean().reset_index()
pairs = pairs.loc[pairs["mor"].abs().eq(1) & pairs["source_genesymbol"].isin(CANDIDATES)].copy()

datasets = [
    {
        "dataset": "GSE267929_APC_discovery",
        "role": "APC_discovery",
        "disease": "ACD_vs_ICD",
        "contrast": "Day4_Allergy_minus_Irritant",
        "path": ROOT / "results/tables/single_cell_validation/GSE267929_APC_gene_effects.tsv",
        "gene": "gene_symbol", "stat": None,
    },
    {
        "dataset": "E-MTAB-9501_direct",
        "role": "independent_direct_bulk_validation",
        "disease": "ACD_vs_ICD",
        "contrast": "ACD_minus_ICD",
        "path": ROOT / "results/tables/direct_comparison/E-MTAB-9501_ACD_vs_ICD_gene_effects.tsv",
        "gene": "gene_symbol", "stat": "t",
    },
    {
        "dataset": "AD_GSE121212_acute", "role": "internal_bulk_direction_audit", "disease": "AD",
        "contrast": "lesional_minus_nonlesional", "path": ROOT / "results/tables/cohort_effects/AD_GSE121212_acute.tsv",
        "gene": "gene", "stat": "t",
    },
    {
        "dataset": "AD_GSE32924", "role": "internal_bulk_direction_audit", "disease": "AD",
        "contrast": "lesional_minus_nonlesional", "path": ROOT / "results/tables/cohort_effects/AD_GSE32924.tsv",
        "gene": "gene", "stat": "t",
    },
    {
        "dataset": "AD_GSE36842_acute", "role": "internal_bulk_direction_audit", "disease": "AD",
        "contrast": "lesional_minus_nonlesional", "path": ROOT / "results/tables/cohort_effects/AD_GSE36842_acute.tsv",
        "gene": "gene", "stat": "t",
    },
    {
        "dataset": "ACD_GSE282562", "role": "internal_bulk_direction_audit", "disease": "ACD",
        "contrast": "ACD_minus_control", "path": ROOT / "results/tables/cohort_effects/ACD_GSE282562.tsv",
        "gene": "gene", "stat": "t",
    },
    {
        "dataset": "ACD_GSE6281_48h", "role": "internal_bulk_direction_audit", "disease": "ACD",
        "contrast": "48h_minus_0h", "path": ROOT / "results/tables/cohort_effects/ACD_GSE6281_48h.tsv",
        "gene": "gene", "stat": "t",
    },
]

rng = np.random.default_rng(20260825)
result_rows = []
for spec in datasets:
    data = pd.read_csv(spec["path"], sep="\t").set_index(spec["gene"])
    if spec["stat"] is None:
        statistic = np.sign(data["logFC"]) * np.sqrt(data["F"])
    else:
        statistic = data[spec["stat"]].astype(float)
    statistic = (statistic - statistic.mean()) / statistic.std(ddof=1)

    candidate_edges = {}
    scores = []
    for tf in CANDIDATES:
        edge = pairs.loc[
            pairs["source_genesymbol"].eq(tf) & pairs["target_genesymbol"].isin(statistic.index)
        ].copy()
        candidate_edges[tf] = edge
        value = (
            edge["mor"].to_numpy() * statistic.reindex(edge["target_genesymbol"]).to_numpy()
        ).sum() / np.sqrt(len(edge))
        scores.append(value)
    scores = np.asarray(scores)

    extreme = np.zeros(len(CANDIDATES), dtype=int)
    max_null = []
    y = statistic.to_numpy()
    for _ in range(PERMUTATIONS):
        permuted = pd.Series(rng.permutation(y), index=statistic.index)
        null_scores = []
        for tf in CANDIDATES:
            edge = candidate_edges[tf]
            null_scores.append((
                edge["mor"].to_numpy() * permuted.reindex(edge["target_genesymbol"]).to_numpy()
            ).sum() / np.sqrt(len(edge)))
        null_scores = np.asarray(null_scores)
        extreme += np.abs(null_scores) >= np.abs(scores)
        max_null.append(np.max(np.abs(null_scores)))
    p_values = (1 + extreme) / (PERMUTATIONS + 1)
    q_values = bh_adjust(p_values)
    max_null = np.asarray(max_null)

    for index, tf in enumerate(CANDIDATES):
        result_rows.append({
            "dataset": spec["dataset"],
            "role": spec["role"],
            "disease": spec["disease"],
            "contrast": spec["contrast"],
            "TF": tf,
            "measured_targets": len(candidate_edges[tf]),
            "activity_score": scores[index],
            "activity_direction": "positive" if scores[index] > 0 else "negative",
            "empirical_p_two_sided": p_values[index],
            "empirical_q_BH_5TF": q_values[index],
            "max_stat_selection_p_5TF": (1 + np.sum(max_null >= abs(scores[index]))) / (PERMUTATIONS + 1),
        })

results = pd.DataFrame(result_rows)
results.to_csv(OUT / "candidate_TF_crossdataset_activity.tsv", sep="\t", index=False)

# Candidate-level synthesis keeps the independent direct contrast separate from
# the five cohorts that contributed to the upstream bulk program.
discovery = results.loc[results["role"].eq("APC_discovery")].set_index("TF")
external = results.loc[results["role"].eq("independent_direct_bulk_validation")].set_index("TF")
internal = results.loc[results["role"].eq("internal_bulk_direction_audit")]
synthesis_rows = []
for tf in CANDIDATES:
    subset = internal.loc[internal["TF"].eq(tf)]
    positive_n = int(subset["activity_score"].gt(0).sum())
    sign_p = binomtest(positive_n, len(subset), 0.5, alternative="greater").pvalue
    synthesis_rows.append({
        "TF": tf,
        "APC_discovery_score": discovery.loc[tf, "activity_score"],
        "APC_discovery_p": discovery.loc[tf, "empirical_p_two_sided"],
        "external_E_MTAB_9501_score": external.loc[tf, "activity_score"],
        "external_E_MTAB_9501_p": external.loc[tf, "empirical_p_two_sided"],
        "external_E_MTAB_9501_q_5TF": external.loc[tf, "empirical_q_BH_5TF"],
        "external_direction_matches_APC": np.sign(external.loc[tf, "activity_score"]) == np.sign(discovery.loc[tf, "activity_score"]),
        "internal_bulk_positive_cohorts": positive_n,
        "internal_bulk_cohorts": len(subset),
        "internal_bulk_median_score": subset["activity_score"].median(),
        "internal_direction_sign_p": sign_p,
        "internal_BH_significant_positive_cohorts": int(
            (subset["activity_score"].gt(0) & subset["empirical_q_BH_5TF"].lt(0.05)).sum()
        ),
    })
synthesis = pd.DataFrame(synthesis_rows)
synthesis["internal_direction_sign_q_BH_5TF"] = bh_adjust(synthesis["internal_direction_sign_p"])
synthesis.to_csv(OUT / "candidate_TF_validation_synthesis.tsv", sep="\t", index=False)

# Direct branch readout for YY1 and E2F4 TF/core genes in the independent data.
direct = pd.read_csv(
    ROOT / "results/tables/direct_comparison/E-MTAB-9501_ACD_vs_ICD_gene_effects.tsv", sep="\t"
).set_index("gene_symbol")
branch_genes = ["YY1", "E2F4", "PCNA", "BRCA1", "CDK2", "POLD1", "POLE2", "RAD51", "RPA3"]
branch_rows = []
for gene in branch_genes:
    if gene in direct.index:
        row = direct.loc[gene]
        branch_rows.append({
            "gene": gene,
            "logFC_ACD_minus_ICD": row["logFC"],
            "p_value": row["P.Value"],
            "FDR": row["adj.P.Val"],
        })
pd.DataFrame(branch_rows).to_csv(OUT / "E_MTAB_9501_YY1_E2F4_branch_gene_effects.tsv", sep="\t", index=False)

summary = pd.DataFrame([{
    "locked_candidates": len(CANDIDATES),
    "permutations_per_dataset": PERMUTATIONS,
    "independent_validation_dataset": "E-MTAB-9501_ACD_minus_ICD",
    "independent_q_lt_0_05": int(external["empirical_q_BH_5TF"].lt(0.05).sum()),
    "YY1_external_direction_match": bool(synthesis.set_index("TF").loc["YY1", "external_direction_matches_APC"]),
    "YY1_external_score": synthesis.set_index("TF").loc["YY1", "external_E_MTAB_9501_score"],
    "E2F4_external_direction_match": bool(synthesis.set_index("TF").loc["E2F4", "external_direction_matches_APC"]),
    "E2F4_external_score": synthesis.set_index("TF").loc["E2F4", "external_E_MTAB_9501_score"],
    "internal_5of5_positive_TFs": ";".join(synthesis.loc[synthesis["internal_bulk_positive_cohorts"].eq(5), "TF"]),
}])
summary.to_csv(OUT / "regulator_crossdataset_validation_summary.tsv", sep="\t", index=False)

# Heatmap of standardized regulon activity across discovery, external direct,
# and internal bulk contrasts.
dataset_order = [x["dataset"] for x in datasets]
matrix = results.pivot(index="TF", columns="dataset", values="activity_score").reindex(
    index=CANDIDATES, columns=dataset_order
)
labels = ["APC\ndiscovery", "E-MTAB-9501\nACD−ICD", "AD\nGSE121212", "AD\nGSE32924",
          "AD\nGSE36842", "ACD\nGSE282562", "ACD\nGSE6281"]
vmax = max(3, float(np.nanmax(np.abs(matrix.to_numpy()))))
fig, ax = plt.subplots(figsize=(12, 6))
im = ax.imshow(matrix.to_numpy(), cmap="RdBu_r", vmin=-vmax, vmax=vmax, aspect="auto")
ax.set_xticks(range(len(labels)))
ax.set_xticklabels(labels, fontsize=9)
ax.set_yticks(range(len(CANDIDATES)))
ax.set_yticklabels(CANDIDATES, fontsize=10)
for i in range(matrix.shape[0]):
    for j in range(matrix.shape[1]):
        value = matrix.iat[i, j]
        ax.text(j, i, f"{value:.2f}", ha="center", va="center", fontsize=8,
                color="white" if abs(value) > vmax * 0.55 else "black")
ax.set_title("Locked APC candidate-TF activities across datasets")
fig.colorbar(im, ax=ax, label="standardized regulon activity", fraction=0.035, pad=0.02)
fig.tight_layout()
fig.savefig(FIG / "candidate_TF_crossdataset_activity_heatmap.png", dpi=180)
plt.close(fig)

print(summary.to_string(index=False))
print("\nValidation synthesis:")
print(synthesis.to_string(index=False))
print("\nIndependent E-MTAB-9501 results:")
print(results.loc[results["role"].eq("independent_direct_bulk_validation")].to_string(index=False))
