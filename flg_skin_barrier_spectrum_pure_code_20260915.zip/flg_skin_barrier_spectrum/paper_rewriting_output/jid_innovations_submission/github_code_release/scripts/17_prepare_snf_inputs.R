#!/usr/bin/env Rscript

# Load the frozen data loaders and the sample-level pathway-score model without
# executing the prior full cohort pipeline.
src <- readLines("scripts/13_pathway_effect_meta.R")
cut <- grep("^cohort_results <- list\\(\\)", src)[1]
eval(parse(text = src[seq_len(cut - 1L)]), envir = .GlobalEnv)

root <- normalizePath(getwd())
out_dir <- file.path(root, "results/exploratory_snf/selected_positive_reml_z_q05")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

# ICD: two explicit irritants, each modeled separately against 0 h within the
# incomplete repeated-measures design, then averaged for descriptive network use.
x <- load_matrix("GSE18206")
icd <- list()
for (agent in c("sodium lauryl sulfate", "nonanoic acid")) {
  idx <- which(x$map$exposure == agent & x$map$time %in% c("0h", "0.5h", "4h", "24h", "d11"))
  m <- data.frame(participant = factor(x$map$participant_id[idx]),
                  time = relevel(factor(x$map$time[idx], levels = c("0h", "0.5h", "4h", "24h", "d11")), "0h"))
  id <- if (agent == "sodium lauryl sulfate") "ICD_GSE18206_SLS_24h" else "ICD_GSE18206_NON_24h"
  icd[[id]] <- fit_pathways(id, x, idx, m, ~ participant + time, "time24h")
}
icd_combined <- merge(
  icd[["ICD_GSE18206_SLS_24h"]][, .(pathway, effect_SLS = effect, SE_SLS = SE, FDR_SLS = FDR)],
  icd[["ICD_GSE18206_NON_24h"]][, .(pathway, effect_NON = effect, SE_NON = SE, FDR_NON = FDR)],
  by = "pathway"
)
icd_combined[, `:=`(
  effect = (effect_SLS + effect_NON) / 2,
  same_direction = sign(effect_SLS) == sign(effect_NON),
  positive_feature = FDR_SLS < 0.05 & FDR_NON < 0.05 & sign(effect_SLS) == sign(effect_NON)
)]
fwrite(icd_combined, file.path(out_dir, "ICD_GSE18206_combined_pathway_effects.tsv"), sep = "\t")

# Selected positive REML-z q<0.05 branch for multi-cohort diseases.
grid <- fread(file.path(root, "results/exploratory_sensitivity/pathway_meta_complete_grid.tsv"))
grid <- grid[method_id == "reml_z_q05"]

features <- list(
  AD = grid[disease == "AD", .(pathway, effect)],
  ACD = grid[disease == "ACD", .(pathway, effect)],
  PSORIASIS = grid[disease == "PSORIASIS", .(pathway, effect)],
  HS = grid[disease == "HS", .(pathway, effect)],
  ACNE = fread(file.path(root, "results/tables/pathway_effects/ACNE_GSE53795.tsv"))[, .(pathway, effect)],
  ROSACEA = fread(file.path(root, "results/tables/pathway_effects/ROSACEA_GSE65914.tsv"))[, .(pathway, effect)],
  ICD = icd_combined[, .(pathway, effect)]
)

common <- sort(Reduce(intersect, lapply(features, function(z) z$pathway)))
feature_matrix <- sapply(features, function(z) z$effect[match(common, z$pathway)])
rownames(feature_matrix) <- common

# Keep pathways positive in at least one node under the selected branch. For
# single-cohort nodes use their own FDR; ICD requires both agents to pass.
positive <- unique(c(
  grid[significant == TRUE, pathway],
  fread(file.path(root, "results/tables/pathway_effects/ACNE_GSE53795.tsv"))[FDR < .05, pathway],
  fread(file.path(root, "results/tables/pathway_effects/ROSACEA_GSE65914.tsv"))[FDR < .05, pathway],
  icd_combined[positive_feature == TRUE, pathway]
))
feature_matrix <- feature_matrix[rownames(feature_matrix) %in% positive, , drop = FALSE]

fwrite(data.table(pathway = rownames(feature_matrix), feature_matrix),
       file.path(out_dir, "snf_positive_pathway_feature_matrix.tsv"), sep = "\t")

immune_pattern <- paste(c("interleukin", "interferon", "TCR", "B Cell", "immune", "immuno", "antigen",
                          "chemokine", "NF-kB", "TNF", "NOD", "TLR", "lymph", "FCER", "FCGR"), collapse = "|")
barrier_pattern <- paste(c("keratin", "cornified", "epiderm", "lipid", "fatty", "cholesterol", "sphingo",
                           "glycosphingo", "ceramide", "phospholipid"), collapse = "|")
damage_pattern <- paste(c("apopt", "cell cycle", "DNA", "mitotic", "stress", "unfolded", "death", "necro",
                          "oxidative", "respiration", "hypoxia", "damage"), collapse = "|")

assignments <- data.table(pathway = rownames(feature_matrix))
assignments[, immune_adaptive := grepl(immune_pattern, pathway, ignore.case = TRUE)]
assignments[, barrier_lipid := grepl(barrier_pattern, pathway, ignore.case = TRUE)]
assignments[, stress_damage := grepl(damage_pattern, pathway, ignore.case = TRUE)]
assignments[, all_positive := TRUE]
fwrite(assignments, file.path(out_dir, "snf_view_assignments.tsv"), sep = "\t")

view_summary <- data.table(
  view = c("all_positive", "immune_adaptive", "barrier_lipid", "stress_damage"),
  pathways = c(nrow(assignments), sum(assignments$immune_adaptive), sum(assignments$barrier_lipid), sum(assignments$stress_damage))
)
if (any(view_summary$pathways < 20L)) stop("A prespecified SNF view has fewer than 20 pathways")
fwrite(view_summary, file.path(out_dir, "snf_view_summary.tsv"), sep = "\t")
print(view_summary)
