#!/usr/bin/env python3

from pathlib import Path
import pandas as pd

root = Path(__file__).resolve().parents[1]
out = root / "results/exploratory_sensitivity"

summary = pd.read_csv(out / "method_grid_summary.tsv", sep="\t")
axis = pd.read_csv(out / "exploratory_axis_decisions.tsv", sep="\t")
best = pd.read_csv(out / "most_favorable_branch.tsv", sep="\t").iloc[0]

assert len(summary) == 24
assert set(axis["method_id"]) == {
    "reml_mkh_q05", "reml_z_q05", "reml_z_q10", "dl_z_q05", "fixed_z_q05", "fixed_z_q10"
}

ref = axis.loc[axis["method_id"] == "reml_mkh_q05"].iloc[0]
assert int(ref["shared_same_direction_significant"]) == 0
assert not bool(ref["candidate_project_positive_before_snf"])

recommended = axis.loc[axis["method_id"] == "reml_z_q05"].iloc[0]
assert int(recommended["shared_same_direction_significant"]) == 429
assert int(recommended["candidate_axes_passed"]) == 3
assert bool(recommended["candidate_project_positive_before_snf"])

assert best["method_id"] == "fixed_z_q10"
assert int(best["shared_same_direction_significant"]) == 1027

report = (root / "EXPLORATORY_SENSITIVITY_REPORT.md").read_text()
for phrase in ("确认性结论：保持不变", "REML + normal z", "429", "1,027", "事后探索"):
    assert phrase in report

print("EXPLORATORY_VALIDATION_OK methods=6 recommended=reml_z_q05 confirmatory_unchanged=TRUE")
