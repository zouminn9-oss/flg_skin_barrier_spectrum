#!/usr/bin/env Rscript

base_dir <- "results/exploratory_snf/selected_positive_reml_z_q05/optimized_AD_ACD_branch"
obs_df <- read.delim(file.path(base_dir, "optimized_fused_similarity.tsv"), check.names = FALSE)
diseases <- obs_df$disease
obs <- as.matrix(obs_df[, -1, drop = FALSE])
rownames(obs) <- diseases
edges <- read.delim(file.path(base_dir, "optimized_edge_statistics.tsv"))
clusters <- read.delim(file.path(base_dir, "optimized_cluster_support.tsv"))
cluster <- setNames(clusters$cluster, clusters$disease)[diseases]

dmat <- 1 - obs
dmat[dmat < 0] <- 0
coords <- cmdscale(as.dist(dmat), k = 2)
rownames(coords) <- diseases

png(file.path(base_dir, "figures/optimized_AD_ACD_network.png"), width = 1400, height = 1100, res = 170)
xpad <- diff(range(coords[, 1])) * .08
ypad <- diff(range(coords[, 2])) * .10
plot(coords, type = "n", xlab = "MDS1", ylab = "MDS2",
     xlim = range(coords[, 1]) + c(-xpad, xpad), ylim = range(coords[, 2]) + c(-ypad, ypad),
     main = "AD-ACD optimized selected-positive SNF\nsolid edges: nominal permutation BH q < 0.05")
sig <- edges[edges$nominal_permutation_q < .05, ]
for (i in seq_len(nrow(sig))) {
  a <- sig$disease_1[i]
  b <- sig$disease_2[i]
  segments(coords[a, 1], coords[a, 2], coords[b, 1], coords[b, 2],
           lwd = 2 + 10 * sig$fused_similarity[i], col = adjustcolor("#286DA8", .7))
}
palette <- c("#E45756", "#4C78A8", "#72B7B2", "#F2CF5B")
points(coords, pch = 21, bg = palette[cluster], col = "white", cex = 4.5, lwd = 1.5)
label_x <- coords[, 1]
label_y <- coords[, 2] + diff(range(coords[, 2])) * .035
label_x["HS"] <- label_x["HS"] - diff(range(coords[, 1])) * .065
label_y["HS"] <- label_y["HS"] + diff(range(coords[, 2])) * .040
label_x["ICD"] <- label_x["ICD"] + diff(range(coords[, 1])) * .065
label_y["ICD"] <- label_y["ICD"] - diff(range(coords[, 2])) * .025
text(label_x, label_y, labels = diseases, cex = .95, font = 2)
dev.off()
