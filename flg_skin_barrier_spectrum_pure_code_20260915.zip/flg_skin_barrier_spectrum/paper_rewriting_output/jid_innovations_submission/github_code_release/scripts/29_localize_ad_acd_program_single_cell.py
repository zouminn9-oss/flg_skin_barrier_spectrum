#!/usr/bin/env python3
"""Localize the AD–ACD damage-response program in GSE267929 cell groups."""

from pathlib import Path
import textwrap

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.stats import norm


ROOT = Path(__file__).resolve().parents[1]
MECH = ROOT / "results/exploratory_snf/selected_positive_reml_z_q05/optimized_AD_ACD_branch/mechanism"
OUT = MECH / "single_cell_localization"
FIG = OUT / "figures"
OUT.mkdir(parents=True, exist_ok=True)
FIG.mkdir(parents=True, exist_ok=True)

CELLTYPES = ["KRT", "APC", "LYMPH", "all_cells"]
PERMUTATIONS = 10_000


def bh_adjust(values):
    p = np.asarray(values, dtype=float)
    order = np.argsort(p)
    ranked = p[order]
    q = ranked * len(ranked) / np.arange(1, len(ranked) + 1)
    q = np.minimum.accumulate(q[::-1])[::-1]
    restored = np.empty_like(q)
    restored[order] = np.minimum(q, 1)
    return restored


def matched_null_means(frame, selected, value_column, bin_column, rng):
    total = np.zeros(PERMUTATIONS)
    n = 0
    for group, count in selected[bin_column].value_counts().items():
        pool = frame.loc[frame[bin_column].eq(group), value_column].to_numpy(dtype=float)
        total += rng.choice(pool, size=(PERMUTATIONS, count), replace=True).sum(axis=1)
        n += count
    return total / n


core = pd.read_csv(MECH / "core_genes/tier1_core_genes.tsv", sep="\t")["gene"].tolist()
top_pathways = pd.read_csv(MECH / "top_AD_ACD_pathway_drivers.tsv", sep="\t").head(20)["pathway"].tolist()

score_rows = []
gene_rows = []
pathway_rows = []
loo_rows = []
rng = np.random.default_rng(20260825)

for celltype in CELLTYPES:
    gene_file = ROOT / f"results/tables/single_cell_validation/GSE267929_{celltype}_gene_effects.tsv"
    genes = pd.read_csv(gene_file, sep="\t")
    genes["signed_statistic"] = np.sign(genes["logFC"]) * np.sqrt(genes["F"])
    genes["expression_bin"] = pd.qcut(genes["logCPM"], 10, labels=False, duplicates="drop")
    selected_genes = genes.loc[genes["gene_symbol"].isin(core)].copy()
    selected_genes["celltype"] = celltype
    gene_rows.append(selected_genes[[
        "celltype", "gene_symbol", "logFC", "logCPM", "F", "PValue", "FDR", "signed_statistic"
    ]])
    gene_score = float(selected_genes["signed_statistic"].mean())
    gene_null = matched_null_means(genes, selected_genes, "signed_statistic", "expression_bin", rng)
    gene_p_up = (1 + np.sum(gene_null >= gene_score)) / (PERMUTATIONS + 1)
    gene_p_down = (1 + np.sum(gene_null <= gene_score)) / (PERMUTATIONS + 1)

    pathway_file = ROOT / f"results/tables/single_cell_validation/GSE267929_{celltype}_reactome.tsv"
    pathways = pd.read_csv(pathway_file, sep="\t")
    pathways["signed_z"] = np.where(pathways["Direction"].eq("Up"), 1, -1) * norm.isf(
        np.clip(pathways["PValue"] / 2, 1e-300, 1)
    )
    pathways["size_bin"] = pd.qcut(pathways["NGenes"], 10, labels=False, duplicates="drop")
    selected_pathways = pathways.loc[pathways["pathway"].isin(top_pathways)].copy()
    selected_pathways["celltype"] = celltype
    pathway_rows.append(selected_pathways[[
        "celltype", "pathway", "NGenes", "Direction", "PValue", "FDR", "signed_z"
    ]])
    pathway_score = float(selected_pathways["signed_z"].mean())
    pathway_null = matched_null_means(pathways, selected_pathways, "signed_z", "size_bin", rng)
    pathway_p_up = (1 + np.sum(pathway_null >= pathway_score)) / (PERMUTATIONS + 1)
    pathway_p_down = (1 + np.sum(pathway_null <= pathway_score)) / (PERMUTATIONS + 1)

    for omitted in selected_pathways["pathway"]:
        reduced = selected_pathways.loc[selected_pathways["pathway"].ne(omitted), "signed_z"]
        loo_rows.append({
            "celltype": celltype,
            "omitted_pathway": omitted,
            "remaining_pathways": len(reduced),
            "leave_one_pathway_out_score": reduced.mean(),
            "same_direction_as_full_score": np.sign(reduced.mean()) == np.sign(pathway_score),
        })

    score_rows.append({
        "celltype": celltype,
        "contrast": "Day4_Allergy_minus_Irritant",
        "paired_donors": int(genes["n_donors"].iloc[0]),
        "core_genes_total": len(core),
        "core_genes_measured": len(selected_genes),
        "core_genes_positive": int(selected_genes["logFC"].gt(0).sum()),
        "core_gene_score": gene_score,
        "core_gene_empirical_p_up": gene_p_up,
        "core_gene_empirical_p_down": gene_p_down,
        "core_gene_empirical_p_two_sided": min(1, 2 * min(gene_p_up, gene_p_down)),
        "driver_pathways_total": len(top_pathways),
        "driver_pathways_measured": len(selected_pathways),
        "driver_pathways_up": int(selected_pathways["Direction"].eq("Up").sum()),
        "driver_pathway_score": pathway_score,
        "driver_pathway_empirical_p_up": pathway_p_up,
        "driver_pathway_empirical_p_down": pathway_p_down,
        "driver_pathway_empirical_p_two_sided": min(1, 2 * min(pathway_p_up, pathway_p_down)),
    })

scores = pd.DataFrame(score_rows)
scores["core_gene_q_BH_4celltypes"] = bh_adjust(scores["core_gene_empirical_p_two_sided"])
scores["driver_pathway_q_BH_4celltypes"] = bh_adjust(scores["driver_pathway_empirical_p_two_sided"])
scores["driver_program_direction"] = np.where(scores["driver_pathway_score"] > 0, "Allergy_higher", "Irritant_higher")
scores.to_csv(OUT / "celltype_program_scores.tsv", sep="\t", index=False)

gene_detail = pd.concat(gene_rows, ignore_index=True)
gene_detail.to_csv(OUT / "core_gene_single_cell_effects.tsv", sep="\t", index=False)
pathway_detail = pd.concat(pathway_rows, ignore_index=True)
pathway_detail.to_csv(OUT / "driver_pathway_single_cell_effects.tsv", sep="\t", index=False)
loo = pd.DataFrame(loo_rows)
loo.to_csv(OUT / "driver_pathway_leave_one_out.tsv", sep="\t", index=False)

loo_summary = loo.groupby("celltype").agg(
    leave_one_out_runs=("same_direction_as_full_score", "size"),
    direction_preserved=("same_direction_as_full_score", "sum"),
    minimum_score=("leave_one_pathway_out_score", "min"),
    maximum_score=("leave_one_pathway_out_score", "max"),
).reset_index()
loo_summary["direction_preserved_rate"] = loo_summary["direction_preserved"] / loo_summary["leave_one_out_runs"]
loo_summary.to_csv(OUT / "driver_pathway_leave_one_out_summary.tsv", sep="\t", index=False)

summary = pd.DataFrame([{
    "contrast": "Day4_Allergy_minus_Irritant",
    "paired_donors_per_analysis": int(scores["paired_donors"].min()),
    "positive_localization_celltype": scores.loc[scores["driver_pathway_score"].idxmax(), "celltype"],
    "positive_localization_score": scores["driver_pathway_score"].max(),
    "positive_localization_q": scores.loc[scores["driver_pathway_score"].idxmax(), "driver_pathway_q_BH_4celltypes"],
    "negative_localization_celltype": scores.loc[scores["driver_pathway_score"].idxmin(), "celltype"],
    "negative_localization_score": scores["driver_pathway_score"].min(),
    "negative_localization_q": scores.loc[scores["driver_pathway_score"].idxmin(), "driver_pathway_q_BH_4celltypes"],
    "core_gene_tests_significant_q_0_05": int(scores["core_gene_q_BH_4celltypes"].lt(0.05).sum()),
    "pathway_program_tests_significant_q_0_05": int(scores["driver_pathway_q_BH_4celltypes"].lt(0.05).sum()),
    "all_pathway_LOO_directions_preserved": bool(loo["same_direction_as_full_score"].all()),
}])
summary.to_csv(OUT / "single_cell_localization_summary.tsv", sep="\t", index=False)

# Figures: separate score and heatmap panels avoid collisions from long pathway labels.
order = ["KRT", "APC", "LYMPH", "all_cells"]
plot_scores = scores.set_index("celltype").loc[order]
matrix = pathway_detail.pivot(index="pathway", columns="celltype", values="signed_z").reindex(index=top_pathways, columns=order)

fig, ax = plt.subplots(figsize=(7, 4.8))
colors = ["#4C78A8" if x < 0 else "#E45756" for x in plot_scores["driver_pathway_score"]]
ax.barh(range(len(order)), plot_scores["driver_pathway_score"], color=colors)
ax.axvline(0, color="black", linewidth=0.8)
ax.set_yticks(range(len(order)))
ax.set_yticklabels(order)
ax.invert_yaxis()
ax.set_xlabel("Mean signed pathway z (Allergy − Irritant)")
ax.set_title("Cell-type localization of the AD–ACD driver program")
for i, celltype in enumerate(order):
    q = plot_scores.loc[celltype, "driver_pathway_q_BH_4celltypes"]
    x = plot_scores.loc[celltype, "driver_pathway_score"]
    if abs(x) >= 0.30:
        ax.text(x * 0.80, i, f"q={q:.3f}", va="center", ha="center", fontsize=9, color="white")
    else:
        ax.text(x + 0.025, i, f"q={q:.3f}", va="center", ha="left", fontsize=9)
ax.grid(axis="x", alpha=0.2)
fig.tight_layout()
fig.savefig(FIG / "celltype_driver_program_scores.png", dpi=180)
plt.close(fig)

fig, ax = plt.subplots(figsize=(12, 10))
vmax = max(2.5, float(np.nanmax(np.abs(matrix.to_numpy()))))
im = ax.imshow(matrix.to_numpy(), cmap="RdBu_r", vmin=-vmax, vmax=vmax, aspect="auto")
ax.set_xticks(range(len(order)))
ax.set_xticklabels(order)
ax.set_yticks(range(len(matrix)))
ax.set_yticklabels([textwrap.fill(x, 58) for x in matrix.index], fontsize=8)
ax.set_title("Top-20 AD–ACD driver pathways in GSE267929: Allergy − Irritant")
fig.colorbar(im, ax=ax, label="signed pathway z", fraction=0.03, pad=0.02)
fig.subplots_adjust(left=0.48, right=0.93, top=0.93, bottom=0.07)
fig.savefig(FIG / "driver_pathway_celltype_heatmap.png", dpi=180)
plt.close(fig)

print(summary.to_string(index=False))
print("\nCell-type scores:")
print(scores.to_string(index=False))
print("\nLeave-one-pathway-out direction stability:")
print(loo_summary.to_string(index=False))
