#!/usr/bin/env Rscript

suppressPackageStartupMessages(library(data.table))
root <- normalizePath(getwd())
out_dir <- file.path(root, "results/exploratory_snf/selected_positive_reml_z_q05")
fig_dir <- file.path(out_dir, "figures")

wtab <- fread(file.path(out_dir, "snf_fused_similarity.tsv"))
diseases <- wtab$disease
w <- as.matrix(wtab[, -"disease"])
dimnames(w) <- list(diseases, diseases)
edges <- fread(file.path(out_dir, "snf_edge_statistics.tsv"))
clusters <- fread(file.path(out_dir, "snf_cluster_assignments.tsv"))
cl <- clusters$cluster[match(diseases, clusters$disease)]
names(cl) <- diseases

dmat <- 1 - w
dmat[dmat < 0] <- 0
coords <- cmdscale(as.dist(dmat), k = 2)
rownames(coords) <- diseases

png(file.path(fig_dir, "snf_network.png"), width = 1400, height = 1100, res = 170)
xpad <- diff(range(coords[, 1])) * 0.08
ypad <- diff(range(coords[, 2])) * 0.10
plot(coords, type = "n", xlab = "MDS1", ylab = "MDS2",
     xlim = range(coords[, 1]) + c(-xpad, xpad), ylim = range(coords[, 2]) + c(-ypad, ypad),
     main = "Selected-positive REML-z multi-view SNF\nsolid edges: permutation BH q < 0.05; red = cluster 1; blue = cluster 2")
sig <- edges[permutation_q < .05]
for (i in seq_len(nrow(sig))) {
  a <- sig$disease_1[i]; b <- sig$disease_2[i]
  segments(coords[a, 1], coords[a, 2], coords[b, 1], coords[b, 2],
           lwd = 2 + 12 * sig$fused_similarity[i], col = adjustcolor("#286DA8", alpha.f = 0.70))
}
cols <- c("#E45756", "#4C78A8", "#72B7B2", "#F2CF5B")[cl]
points(coords, pch = 21, bg = cols, col = "white", cex = 4.5, lwd = 1.5)
text(coords, labels = diseases, pos = 3, cex = 0.95, font = 2)
dev.off()

png(file.path(fig_dir, "snf_fused_similarity_heatmap.png"), width = 1250, height = 1100, res = 160)
heatmap(w, symm = TRUE, margins = c(10, 10), main = "Selected-positive REML-z SNF similarity")
dev.off()

cat("SNF_RENDER_OK significant_edges=", nrow(sig), "\n", sep = "")
