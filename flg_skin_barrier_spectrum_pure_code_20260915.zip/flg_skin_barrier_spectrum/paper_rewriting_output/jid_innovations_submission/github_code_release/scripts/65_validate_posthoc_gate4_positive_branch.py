#!/usr/bin/env python3
"""Strictly validate the user-directed post-hoc exploratory Gate 4 package."""

from __future__ import annotations

from itertools import combinations, product
from pathlib import Path
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
LOCAL_PACKAGES = ROOT / "environment/python_packages"
if LOCAL_PACKAGES.exists():
    sys.path.insert(0, str(LOCAL_PACKAGES))

import numpy as np
import pandas as pd


BASE = ROOT / "results/exploratory_snf/selected_positive_reml_z_q05"
OPT = BASE / "optimized_AD_ACD_branch"
OUT = ROOT / "results/posthoc_exploratory_gate4_positive_branch"
EXPECTED_NODES = {"AD", "ACD", "ICD", "PSORIASIS", "ACNE", "ROSACEA", "HS"}
EXPECTED_LABEL = "exploratory_gate4_transcriptomic_positive_multilayer_incomplete"
checks = []


def check(name, condition, detail=""):
    checks.append({"check": name, "passed": bool(condition), "detail": str(detail)})


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


required = [
    "GATE4_DISPOSITION.json", "RUN_PARAMETERS.json", "SOURCE_MANIFEST.json",
    "positive_branch_entry_audit.tsv", "layer_coverage_audit.tsv",
    "downstream_candidate_annotation_audit.tsv", "REPORT_ARTIFACT.json",
]
for name in required:
    path = OUT / name
    check(f"required output exists: {name}", path.exists() and path.stat().st_size > 0)

disposition = json.loads((OUT / "GATE4_DISPOSITION.json").read_text())
run = json.loads((OUT / "RUN_PARAMETERS.json").read_text())
manifest = json.loads((OUT / "SOURCE_MANIFEST.json").read_text())
entry = pd.read_csv(OUT / "positive_branch_entry_audit.tsv", sep="\t")
coverage = pd.read_csv(OUT / "layer_coverage_audit.tsv", sep="\t")
candidate = pd.read_csv(OUT / "downstream_candidate_annotation_audit.tsv", sep="\t").iloc[0]
summary = pd.read_csv(OPT / "optimized_snf_summary.tsv", sep="\t").iloc[0]
edges = pd.read_csv(OPT / "optimized_edge_statistics.tsv", sep="\t")
support = pd.read_csv(OPT / "optimized_cluster_support.tsv", sep="\t").set_index("disease")
coclustering = pd.read_csv(OPT / "optimized_bootstrap_coclustering.tsv", sep="\t").set_index("disease")
fused = pd.read_csv(OPT / "optimized_fused_similarity.tsv", sep="\t").set_index("disease")
grid = pd.read_csv(BASE / "parameter_grid/snf_parameter_grid.tsv", sep="\t")
features = pd.read_csv(BASE / "snf_positive_pathway_feature_matrix.tsv", sep="\t")
jnj = json.loads((OPT / "mechanism/lincs_full_background_calibration/JNJ7706621_FULL_BACKGROUND_DISPOSITION.json").read_text())
protocol = (ROOT / "POSTHOC_EXPLORATORY_GATE4_POSITIVE_BRANCH_PROTOCOL.md").read_text()
plan = (ROOT / "gate12_snapshot/05_analysis_plan.md").read_text()
upstream = (ROOT / "scripts/22_run_optimized_ad_acd_snf.R").read_text()

for rel, recorded in manifest.items():
    path = ROOT / rel
    check(f"manifest source exists: {rel}", path.exists())
    if path.exists():
        check(f"manifest bytes match: {rel}", path.stat().st_size == recorded["bytes"], path.stat().st_size)
        check(f"manifest SHA-256 matches: {rel}", sha256(path) == recorded["sha256"])

gate3_manifest = pd.read_csv(ROOT / "records/gate3_output_manifest.tsv", sep="\t")
gate3_bad = []
for row in gate3_manifest.itertuples(index=False):
    path = ROOT / row.path
    if not path.exists() or path.stat().st_size != row.bytes or sha256(path) != row.sha256:
        gate3_bad.append(row.path)
check("all frozen Gate 3 manifest files remain byte-identical", not gate3_bad, gate3_bad[:10])
gate3_report = (ROOT / "GATE3_TRANSCRIPTOMIC_REPORT.md").read_text()
check("Gate 3 report remains negative 0/3", all(token in gate3_report for token in ["0 of 3 frozen axes pass", "NEGATIVE"]))

check("protocol explicitly post-hoc exploratory", all(token in protocol for token in ["Post-hoc exploratory", "post-hoc", "exploratory"]))
check("protocol keeps Gate 3 negative", "negative with 0/3 axes passing" in protocol)
check("protocol prohibits missing-layer fill", "Missing layers are not\nfilled with zero" in protocol)
check("protocol fixes incomplete multilayer label", EXPECTED_LABEL in protocol)
check("frozen plan defines four layers", all(token in plan for token in ["层 1", "层 2", "层 3", "层 4"]))
check("frozen plan prohibits zero fill", "不填零" in plan)
check("upstream uses 1,000 bootstraps", "bootstrap_n <- 1000L" in upstream)
check("upstream uses 10,000 nominal permutations", "perm_n <- 10000L" in upstream)
check("upstream uses 500 selection permutations", "selection_perm_n <- 500L" in upstream)

check("grid contains 396 rows", len(grid) == 396, len(grid))
check("grid branch IDs unique", grid["branch_id"].is_unique)
check("grid parameter tuples unique", not grid.duplicated(["views", "K", "alpha", "iterations"]).any())
views = {"all_positive", "immune_adaptive", "barrier_lipid", "stress_damage"}
expected_view_sets = {"+".join(v) for n in (2, 3, 4) for v in combinations(sorted(views), n)}
observed_view_sets = {"+".join(sorted(v.split("+"))) for v in grid["views"].unique()}
check("grid contains every 2-4 view subset", observed_view_sets == expected_view_sets, observed_view_sets ^ expected_view_sets)
expected_params = set(product((2, 3, 4, 5), (0.2, 0.5, 1.0), (10, 20, 50)))
for view in grid["views"].unique():
    sub = grid.loc[grid["views"] == view]
    observed = set(map(tuple, sub[["K", "alpha", "iterations"]].to_numpy()))
    check(f"complete tuning grid for {view}", observed == expected_params)

check("selected branch ID fixed", summary["branch_id"] == "B0073")
check("selected views fixed", summary["views"] == "all_positive+stress_damage")
check("selected K fixed", int(summary["K"]) == 2)
check("selected alpha fixed", np.isclose(summary["alpha"], 0.2))
check("selected iterations fixed", int(summary["iterations"]) == 10)
check("summary reports 396 screened branches", int(summary["branches_screened"]) == 396)
check("summary reports 500 selection permutations", int(summary["selection_adjustment_permutations"]) == 500)
selected_grid = grid.loc[grid["branch_id"] == summary["branch_id"]]
check("selected branch occurs once in grid", len(selected_grid) == 1)
if len(selected_grid) == 1:
    selected_grid = selected_grid.iloc[0]
    check("selected summary agrees with grid: views", summary["views"] == selected_grid["views"])
    for column in ["K", "alpha", "iterations", "AD_ACD_similarity", "AD_ACD_rank"]:
        check(f"selected summary agrees with grid: {column}", np.isclose(float(summary[column]), float(selected_grid[column])))

check("edge table has all 21 disease pairs", len(edges) == 21)
pairs = {frozenset((row.disease_1, row.disease_2)) for row in edges.itertuples(index=False)}
check("edge table pair set complete", pairs == {frozenset(x) for x in combinations(EXPECTED_NODES, 2)})
target = edges.loc[edges.apply(lambda r: {r["disease_1"], r["disease_2"]} == {"AD", "ACD"}, axis=1)]
check("exactly one AD-ACD edge", len(target) == 1)
target = target.iloc[0]

def bh(values):
    values = np.asarray(values, dtype=float)
    order = np.argsort(values)
    ranked = values[order]
    adjusted = np.minimum.accumulate((ranked * len(values) / np.arange(1, len(values) + 1))[::-1])[::-1]
    result = np.empty(len(values))
    result[order] = np.minimum(adjusted, 1)
    return result

check("nominal BH q values recompute exactly", np.allclose(edges["nominal_permutation_q"], bh(edges["nominal_permutation_p"]), atol=1e-12))
check("fused matrix node coverage", set(fused.index) == EXPECTED_NODES and set(fused.columns) == EXPECTED_NODES)
check("fused matrix symmetric", np.allclose(fused.to_numpy(float), fused.to_numpy(float).T))
check("AD-ACD edge equals fused matrix", np.isclose(target["fused_similarity"], fused.loc["AD", "ACD"]))
check("coclustering matrix node coverage", set(coclustering.index) == EXPECTED_NODES and set(coclustering.columns) == EXPECTED_NODES)
check("coclustering matrix symmetric", np.allclose(coclustering.to_numpy(float), coclustering.to_numpy(float).T))
check("AD-ACD coclustering equals matrix", np.isclose(target["bootstrap_coclustering"], coclustering.loc["AD", "ACD"]))
check("cluster support node coverage", set(support.index) == EXPECTED_NODES)
check("AD and ACD same observed cluster", support.loc["AD", "cluster"] == support.loc["ACD", "cluster"] and bool(target["same_cluster"]))
for disease in EXPECTED_NODES:
    mates = support.index[(support["cluster"] == support.loc[disease, "cluster"]) & (support.index != disease)]
    reconstructed = coclustering.loc[disease, mates].mean()
    check(f"cluster support reconstructs: {disease}", np.isclose(reconstructed, support.loc[disease, "bootstrap_cluster_support"]))

expected_entry = {
    "complete_branch_grid", "selection_adjusted_permutation", "nominal_permutation_BH",
    "same_observed_cluster", "AD_ACD_bootstrap_coclustering", "AD_cluster_support", "ACD_cluster_support",
}
check("entry audit contains seven frozen checks", set(entry["check"]) == expected_entry and len(entry) == 7)
check("all frozen transcriptomic entry checks pass", entry["passed"].astype(bool).all())
check("selection-adjusted P passes without relaxation", summary["AD_ACD_selection_adjusted_p_500"] < 0.05)
check("nominal permutation BH q passes without relaxation", target["nominal_permutation_q"] < 0.05)
check("AD-ACD coclustering meets 0.75", target["bootstrap_coclustering"] >= 0.75)
check("AD node support meets 0.75", support.loc["AD", "bootstrap_cluster_support"] >= 0.75)
check("ACD node support meets 0.75", support.loc["ACD", "bootstrap_cluster_support"] >= 0.75)

check("transcriptomic feature matrix has 1,444 pathways", len(features) == 1444)
check("transcriptomic matrix covers exactly seven nodes", set(features.columns) - {"pathway"} == EXPECTED_NODES)
check("transcriptomic matrix has no missing node features", features[list(EXPECTED_NODES)].notna().all().all())
check("coverage audit contains exactly four frozen layers", set(coverage["layer_id"]) == {1, 2, 3, 4} and len(coverage) == 4)
check("layer node-coverage counts are exact", coverage.sort_values("layer_id")["discovery_nodes_with_comparable_features"].tolist() == [7, 1, 1, 2])
check("planned layer weights preserved", np.allclose(coverage.sort_values("layer_id")["planned_weight"], [0.4, 0.3, 0.2, 0.1]))
check("planned weights sum to one", np.isclose(coverage["planned_weight"].sum(), 1.0))
check("only transcriptomic layer has seven-node coverage", coverage.loc[coverage["discovery_nodes_with_comparable_features"] == 7, "layer"].tolist() == ["transcriptomic_pathway"])
check("only transcriptomic layer eligible for complete fusion", coverage.loc[coverage["eligible_for_complete_fusion"], "layer"].tolist() == ["transcriptomic_pathway"])
check("incomplete layers explicitly not filled or imputed", coverage.loc[~coverage["eligible_for_complete_fusion"], "missing_value_handling"].eq("not_filled_not_imputed").all())
declared_coverage_sources = {item for cell in coverage["evidence_source_paths"] for item in cell.split(";")}
check("all declared layer evidence sources exist and are checksummed", all((ROOT / item).exists() and item in manifest for item in declared_coverage_sources), sorted(declared_coverage_sources - set(manifest)))
check("no multilayer fusion artifact was fabricated", not (OUT / "multilayer_fused_similarity.tsv").exists())

check("JNJ annotation remains positive_not_top5", candidate["annotation"] == "positive_not_top5" == jnj["full_background_label"])
check("JNJ is downstream annotation only", candidate["role"] == "downstream_computational_candidate_annotation_only")
check("JNJ not used as disease network layer", not bool(candidate["used_as_disease_network_layer"]) and not disposition["entry_drug_signal_used_as_network_layer"])
check("JNJ formal replication remains false", not bool(candidate["formal_replication"]) and not disposition["formal_replication"])
check("JNJ targeted q preserved", np.isclose(candidate["targeted_BH_q"], jnj["frozen_targeted_BH_q"]))
check("no clinical-efficacy claim", not bool(candidate["clinical_efficacy_evidence"]) and not disposition["clinical_efficacy_evidence"])
check("no safety claim", not bool(candidate["safety_evidence"]) and not disposition["safety_evidence"])

check("disposition label follows incomplete multilayer rule", disposition["label"] == EXPECTED_LABEL, disposition["label"])
check("transcriptomic sub-gate passes 7/7", disposition["transcriptomic_subgate_pass"] and disposition["transcriptomic_subgate_checks_passed"] == 7 == disposition["transcriptomic_subgate_checks_total"])
check("eligible complete-fusion layers equals one", disposition["eligible_complete_fusion_layers"] == 1)
check("full multilayer Gate 4 is not evaluable", not disposition["full_multilayer_gate4_evaluable"])
check("no missing layer imputation", not disposition["missing_layers_imputed"])
check("no Gate 4 threshold relaxation", not disposition["thresholds_relaxed_for_gate4"])
check("Gate 4 explicitly non-confirmatory", not disposition["confirmatory_gate4"])
check("no independent replication claim", not disposition["independent_biological_replication"])
check("Gate 3 frozen decision preserved", disposition["gate3_frozen_decision"] == "negative_0_of_3_axes" and not disposition["gate3_changed"])
check("run policy prohibits drug substitution", run["missing_layer_policy"] == "do_not_fill_zero_do_not_impute_do_not_substitute_drug_annotation")

report_path = ROOT / "POSTHOC_EXPLORATORY_GATE4_POSITIVE_BRANCH_REPORT.md"
check("durable Markdown report exists", report_path.exists() and report_path.stat().st_size > 0)
if report_path.exists():
    report = report_path.read_text()
    for token in [
        EXPECTED_LABEL, "post-hoc", "exploratory", "0/3", "positive_not_top5",
        "not a\ndisease-network layer", "not confirmatory", "not independent replication",
        "clinical efficacy", "safety", "No missing layer was filled with zero",
    ]:
        check(f"durable report retains required boundary: {token}", token in report)

failed = [row for row in checks if not row["passed"]]
validation = {
    "status": "pass" if not failed else "fail",
    "checks_passed": len(checks) - len(failed),
    "checks_failed": len(failed),
    "checks": checks,
}
(OUT / "VALIDATION_SUMMARY.json").write_text(json.dumps(validation, indent=2) + "\n")
print(json.dumps({key: validation[key] for key in ["status", "checks_passed", "checks_failed"]}, indent=2))
if failed:
    for row in failed:
        print(f"FAIL {row['check']}: {row['detail']}", file=sys.stderr)
    raise SystemExit(1)
