#!/usr/bin/env python3
"""Infer candidate APC regulators from a fixed CollecTRI regulon snapshot."""

from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch
import numpy as np
import pandas as pd
from scipy import sparse


ROOT = Path(__file__).resolve().parents[1]
MECH = ROOT / "results/exploratory_snf/selected_positive_reml_z_q05/optimized_AD_ACD_branch/mechanism"
OUT = MECH / "apc_regulator_network"
FIG = OUT / "figures"
OUT.mkdir(parents=True, exist_ok=True)
FIG.mkdir(parents=True, exist_ok=True)

REGULON = ROOT / "data/raw/regulons/collectri/omnipath_collectri_human_2026-08-25.tsv"
PERMUTATIONS = 10_000
MIN_TARGETS = 10
MAX_TARGETS = 500


def bh_adjust(values):
    p = np.asarray(values, dtype=float)
    order = np.argsort(p)
    ranked = p[order]
    q = ranked * len(ranked) / np.arange(1, len(ranked) + 1)
    q = np.minimum.accumulate(q[::-1])[::-1]
    restored = np.empty_like(q)
    restored[order] = np.minimum(q, 1)
    return restored


raw = pd.read_csv(REGULON, sep="\t", low_memory=False)
raw = raw.loc[raw["consensus_stimulation"].ne(raw["consensus_inhibition"])].copy()
raw["mor"] = np.where(raw["consensus_stimulation"], 1.0, -1.0)

# Collapse duplicated evidence rows and discard TF-target pairs with conflicting signs.
pair_sign = raw.groupby(["source_genesymbol", "target_genesymbol"])["mor"].mean().reset_index()
pair_sign = pair_sign.loc[pair_sign["mor"].abs().eq(1)].copy()

apc = pd.read_csv(
    ROOT / "results/tables/single_cell_validation/GSE267929_APC_gene_effects.tsv", sep="\t"
)
apc["raw_signed_statistic"] = np.sign(apc["logFC"]) * np.sqrt(apc["F"])
apc["standardized_signed_statistic"] = (
    apc["raw_signed_statistic"] - apc["raw_signed_statistic"].mean()
) / apc["raw_signed_statistic"].std(ddof=1)
genes = apc["gene_symbol"].tolist()
gene_index = {gene: i for i, gene in enumerate(genes)}

measured_edges = pair_sign.loc[pair_sign["target_genesymbol"].isin(gene_index)].copy()
target_counts = measured_edges.groupby("source_genesymbol").size()
tested_tfs = target_counts.loc[target_counts.between(MIN_TARGETS, MAX_TARGETS)].index.tolist()
tf_index = {tf: i for i, tf in enumerate(tested_tfs)}
measured_edges = measured_edges.loc[measured_edges["source_genesymbol"].isin(tf_index)].copy()

row_index = measured_edges["source_genesymbol"].map(tf_index).to_numpy()
column_index = measured_edges["target_genesymbol"].map(gene_index).to_numpy()
weights = measured_edges["mor"].to_numpy() / np.sqrt(
    measured_edges["source_genesymbol"].map(target_counts).to_numpy()
)
w = sparse.csr_matrix((weights, (row_index, column_index)), shape=(len(tested_tfs), len(genes)))
y = apc["standardized_signed_statistic"].to_numpy()
observed = np.asarray(w @ y).ravel()

# Global gene-label permutations preserve the APC statistic distribution and
# evaluate every TF in the same permutation. Max statistics audit TF selection.
rng = np.random.default_rng(20260825)
extreme = np.zeros(len(tested_tfs), dtype=int)
max_abs_null = []
chunk_size = 250
for start in range(0, PERMUTATIONS, chunk_size):
    n_chunk = min(chunk_size, PERMUTATIONS - start)
    permuted = np.column_stack([rng.permutation(y) for _ in range(n_chunk)])
    null_scores = np.asarray(w @ permuted)
    extreme += (np.abs(null_scores) >= np.abs(observed)[:, None]).sum(axis=1)
    max_abs_null.extend(np.max(np.abs(null_scores), axis=0))
empirical_p = (1 + extreme) / (PERMUTATIONS + 1)
max_abs_null = np.asarray(max_abs_null)
max_stat_p = np.array([
    (1 + np.sum(max_abs_null >= abs(value))) / (PERMUTATIONS + 1)
    for value in observed
])

core_genes = set(pd.read_csv(MECH / "core_genes/tier1_core_genes.tsv", sep="\t")["gene"])
core_pairs = pair_sign.loc[pair_sign["target_genesymbol"].isin(core_genes)].copy()
core_counts = core_pairs.groupby("source_genesymbol")["target_genesymbol"].nunique()
core_targets = core_pairs.groupby("source_genesymbol")["target_genesymbol"].agg(
    lambda values: ";".join(sorted(set(values)))
)

activity = pd.DataFrame({
    "TF": tested_tfs,
    "measured_regulon_targets": target_counts.reindex(tested_tfs).to_numpy(),
    "activity_score": observed,
    "empirical_p_two_sided": empirical_p,
    "empirical_q_BH_306TF": bh_adjust(empirical_p),
    "max_stat_selection_p_306TF": max_stat_p,
    "direct_core_targets": pd.Series(tested_tfs).map(core_counts).fillna(0).astype(int).to_numpy(),
    "core_target_genes": pd.Series(tested_tfs).map(core_targets).fillna("").to_numpy(),
})

# A restricted multiplicity audit is reported for regulators with at least two
# direct core-gene links, but it does not replace the all-TF correction.
activity["empirical_q_BH_core_connected"] = np.nan
restricted = activity["direct_core_targets"].ge(2)
activity.loc[restricted, "empirical_q_BH_core_connected"] = bh_adjust(
    activity.loc[restricted, "empirical_p_two_sided"]
)

apc_lookup = apc.set_index("gene_symbol")
activity["TF_APC_logFC"] = activity["TF"].map(apc_lookup["logFC"])
activity["TF_APC_PValue"] = activity["TF"].map(apc_lookup["PValue"])
activity["TF_APC_FDR"] = activity["TF"].map(apc_lookup["FDR"])
activity = activity.sort_values("activity_score", ascending=False)
activity.to_csv(OUT / "TF_activity_all.tsv", sep="\t", index=False)
activity.loc[restricted].to_csv(OUT / "core_connected_TF_activity.tsv", sep="\t", index=False)

# Positive candidate network: nominal activity p<0.10 plus at least one curated
# direct edge to the 16-gene program. This is explicitly a candidate rule.
candidates = activity.loc[
    activity["activity_score"].gt(0)
    & activity["empirical_p_two_sided"].lt(0.10)
    & activity["direct_core_targets"].ge(1)
].copy()
candidates.to_csv(OUT / "candidate_positive_regulators.tsv", sep="\t", index=False)

# Collapse evidence metadata for the candidate-to-core network.
candidate_pairs = core_pairs.loc[core_pairs["source_genesymbol"].isin(candidates["TF"])].copy()
evidence_rows = []
for pair in candidate_pairs.itertuples(index=False):
    rows = raw.loc[
        raw["source_genesymbol"].eq(pair.source_genesymbol)
        & raw["target_genesymbol"].eq(pair.target_genesymbol)
        & raw["mor"].eq(pair.mor)
    ]
    sources = sorted({x for value in rows["sources"].dropna() for x in str(value).split(";") if x})
    refs = sorted({x for value in rows["references"].dropna() for x in str(value).split(";") if x})
    evidence_rows.append({
        "TF": pair.source_genesymbol,
        "core_gene": pair.target_genesymbol,
        "regulation_sign": int(pair.mor),
        "regulation": "activation" if pair.mor > 0 else "inhibition",
        "source_databases_n": len(sources),
        "reference_records_n": len(refs),
        "sources": ";".join(sources),
        "references": ";".join(refs),
    })
network_edges = pd.DataFrame(evidence_rows).sort_values(["TF", "core_gene"])
network_edges.to_csv(OUT / "candidate_regulator_core_edges.tsv", sep="\t", index=False)

# Exact leave-one-regulon-target influence checks candidate activity direction.
loo_rows = []
for candidate in candidates.itertuples(index=False):
    tf_edges = measured_edges.loc[measured_edges["source_genesymbol"].eq(candidate.TF)]
    signed_values = tf_edges["mor"].to_numpy() * apc_lookup.reindex(tf_edges["target_genesymbol"])[
        "standardized_signed_statistic"
    ].to_numpy()
    full_sum = signed_values.sum()
    n_targets = len(signed_values)
    for omitted_gene, omitted_value in zip(tf_edges["target_genesymbol"], signed_values):
        reduced_score = (full_sum - omitted_value) / np.sqrt(n_targets - 1)
        loo_rows.append({
            "TF": candidate.TF,
            "omitted_regulon_target": omitted_gene,
            "remaining_targets": n_targets - 1,
            "leave_one_target_out_activity": reduced_score,
            "positive_direction_preserved": reduced_score > 0,
        })
loo = pd.DataFrame(loo_rows)
loo.to_csv(OUT / "candidate_regulator_leave_one_target_out.tsv", sep="\t", index=False)
loo_summary = loo.groupby("TF").agg(
    leave_one_target_out_runs=("positive_direction_preserved", "size"),
    positive_direction_preserved=("positive_direction_preserved", "sum"),
    minimum_activity=("leave_one_target_out_activity", "min"),
    maximum_activity=("leave_one_target_out_activity", "max"),
).reset_index()
loo_summary["direction_preserved_rate"] = (
    loo_summary["positive_direction_preserved"] / loo_summary["leave_one_target_out_runs"]
)
loo_summary.to_csv(OUT / "candidate_regulator_leave_one_target_out_summary.tsv", sep="\t", index=False)

# Cross-cell diagnostic scores use each cell group's standardized gene statistic
# and its available targets; APC remains the discovery contrast.
cross_rows = []
for celltype in ("KRT", "APC", "LYMPH", "all_cells"):
    data = pd.read_csv(
        ROOT / f"results/tables/single_cell_validation/GSE267929_{celltype}_gene_effects.tsv", sep="\t"
    ).set_index("gene_symbol")
    data["stat"] = np.sign(data["logFC"]) * np.sqrt(data["F"])
    data["stat"] = (data["stat"] - data["stat"].mean()) / data["stat"].std(ddof=1)
    for candidate in candidates.itertuples(index=False):
        tf_edges = pair_sign.loc[
            pair_sign["source_genesymbol"].eq(candidate.TF)
            & pair_sign["target_genesymbol"].isin(data.index)
        ]
        score = (
            tf_edges["mor"].to_numpy() * data.reindex(tf_edges["target_genesymbol"])["stat"].to_numpy()
        ).sum() / np.sqrt(len(tf_edges))
        cross_rows.append({
            "TF": candidate.TF,
            "celltype": celltype,
            "measured_targets": len(tf_edges),
            "activity_score": score,
        })
cross = pd.DataFrame(cross_rows)
cross.to_csv(OUT / "candidate_regulator_activity_across_celltypes.tsv", sep="\t", index=False)

summary = pd.DataFrame([{
    "regulon_resource": "OmniPath_CollecTRI_snapshot_2026-08-25",
    "raw_interaction_rows": len(raw),
    "TFs_tested": len(activity),
    "permutations": PERMUTATIONS,
    "TFs_BH_q_lt_0_05": int(activity["empirical_q_BH_306TF"].lt(0.05).sum()),
    "TFs_max_stat_p_lt_0_05": int(activity["max_stat_selection_p_306TF"].lt(0.05).sum()),
    "positive_nominal_core_connected_candidates": len(candidates),
    "candidate_network_edges": len(network_edges),
    "candidate_LOO_all_positive": bool(loo["positive_direction_preserved"].all()),
    "lead_candidate": candidates.iloc[0]["TF"] if len(candidates) else "",
}])
summary.to_csv(OUT / "apc_regulator_summary.tsv", sep="\t", index=False)

# Bipartite candidate network.
tf_nodes = candidates["TF"].tolist()
gene_nodes = sorted(network_edges["core_gene"].unique())
tf_x = np.linspace(0.08, 0.92, len(tf_nodes))
gene_x = np.linspace(0.05, 0.95, len(gene_nodes))
positions = {tf: (x, 0.82) for tf, x in zip(tf_nodes, tf_x)}
positions.update({gene: (x, 0.18) for gene, x in zip(gene_nodes, gene_x)})

fig, ax = plt.subplots(figsize=(14, 8))
ax.set_xlim(0, 1)
ax.set_ylim(0, 1)
ax.axis("off")
for edge in network_edges.itertuples(index=False):
    start, end = positions[edge.TF], positions[edge.core_gene]
    color = "#E45756" if edge.regulation_sign > 0 else "#4C78A8"
    arrow = FancyArrowPatch(start, end, arrowstyle="-|>", mutation_scale=12,
                            linewidth=1.8, color=color, alpha=0.72,
                            connectionstyle="arc3,rad=0.05")
    ax.add_patch(arrow)
for tf in tf_nodes:
    x_pos, y_pos = positions[tf]
    row = candidates.loc[candidates["TF"].eq(tf)].iloc[0]
    ax.scatter(x_pos, y_pos, s=1500, c="#F2CF5B", edgecolors="white", linewidths=1.5, zorder=3)
    ax.text(x_pos, y_pos + 0.005, tf, ha="center", va="center", fontweight="bold", fontsize=11)
    ax.text(x_pos, y_pos - 0.11, f"activity={row.activity_score:.2f}\np={row.empirical_p_two_sided:.3f}",
            ha="center", va="center", fontsize=8)
for gene in gene_nodes:
    x_pos, y_pos = positions[gene]
    ax.scatter(x_pos, y_pos, s=1050, c="#72B7B2", edgecolors="white", linewidths=1.5, zorder=3)
    ax.text(x_pos, y_pos, gene, ha="center", va="center", fontweight="bold", fontsize=9)
ax.text(0.5, 0.96, "Candidate APC regulators of the AD–ACD core program", ha="center", fontsize=16, fontweight="bold")
ax.text(0.5, 0.05, "red: curated activation   blue: curated inhibition", ha="center", fontsize=10)
fig.tight_layout()
fig.savefig(FIG / "candidate_APC_regulator_core_network.png", dpi=180)
plt.close(fig)

print(summary.to_string(index=False))
print("\nCandidate positive regulators:")
print(candidates.to_string(index=False))
print("\nLOO stability:")
print(loo_summary.to_string(index=False))
