#!/usr/bin/env python3
"""Verify and inventory the complete LINCS chemical-perturbation GCTX.

This script performs no disease-signature scoring.  It records the exact local
object, HDF5 layout, row/column identifiers, and the degree to which GCTX column
identifiers can be parsed or reconciled to the frozen targeted metadata.
"""

from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
LOCAL_PACKAGES = ROOT / "environment/python_packages"
if LOCAL_PACKAGES.exists():
    sys.path.insert(0, str(LOCAL_PACKAGES))

import h5py
import numpy as np
import pandas as pd


URL = "https://lincs-dcic.s3.amazonaws.com/LINCS-sigs-2021/gctx/cd-coefficient/cp_coeff_mat.gctx"
EXPECTED_DOCUMENTED_BYTES = 35_565_630_496
OBSERVED_REMOTE_BYTES = 36_084_518_760
REMOTE_LAST_MODIFIED = "Tue, 10 Oct 2023 18:32:10 GMT"
REMOTE_ETAG = "23b8c0e7d2cdafc12c0f76c38904ab9b-4302"
GCTX = ROOT / "data/raw/perturbations/lincs_2021_full/cp_coeff_mat.gctx"
RANKER_METADATA = ROOT / "data/raw/perturbations/lincs_2021_full/signatures_meta_2026-06-30.json"
SIGINFO = ROOT / "data/raw/perturbations/lincs_2021_full/siginfo_beta.txt"
COMPOUNDINFO = ROOT / "data/raw/perturbations/lincs_2021_full/compoundinfo_beta.txt"
MECH = ROOT / "results/exploratory_snf/selected_positive_reml_z_q05/optimized_AD_ACD_branch/mechanism"
TARGETED = MECH / "lincs_cross_resource_replication"
OUT = MECH / "lincs_full_background_calibration"
OUT.mkdir(parents=True, exist_ok=True)


def decode(values: np.ndarray) -> np.ndarray:
    values = np.asarray(values)
    if values.dtype.kind == "S":
        return np.char.decode(values, "utf-8")
    if values.dtype.kind == "O":
        return np.asarray([
            value.decode("utf-8") if isinstance(value, (bytes, np.bytes_)) else str(value)
            for value in values
        ])
    return values.astype(str)


def sha256_file(path: Path, block_size: int = 16 * 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(block_size), b""):
            digest.update(block)
    return digest.hexdigest()


started = time.perf_counter()
if not GCTX.exists():
    raise FileNotFoundError(GCTX)
local_bytes = GCTX.stat().st_size
if local_bytes != OBSERVED_REMOTE_BYTES:
    raise RuntimeError(f"Incomplete or changed download: {local_bytes} != {OBSERVED_REMOTE_BYTES}")

local_sha256 = sha256_file(GCTX)
assembly_receipt_path = GCTX.parent / "download_segments/assembled_sha256.json"
assembly_receipt = json.loads(assembly_receipt_path.read_text()) if assembly_receipt_path.exists() else None
if assembly_receipt is not None and (
    assembly_receipt.get("bytes") != local_bytes or assembly_receipt.get("sha256") != local_sha256
):
    raise RuntimeError("Parallel assembly receipt does not match the final GCTX")
objects = []
with h5py.File(GCTX, "r") as handle:
    def collect(name, obj):
        row = {"path": "/" + name, "object_type": "group" if isinstance(obj, h5py.Group) else "dataset"}
        if isinstance(obj, h5py.Dataset):
            row.update({
                "shape": list(obj.shape), "dtype": str(obj.dtype),
                "chunks": list(obj.chunks) if obj.chunks else None,
                "compression": obj.compression,
            })
        objects.append(row)
    handle.visititems(collect)

    required = ["/0/DATA/0/matrix", "/0/META/ROW/id", "/0/META/COL/id"]
    missing = [path for path in required if path not in handle]
    if missing:
        raise RuntimeError(f"Missing required GCTX objects: {missing}")
    matrix = handle["/0/DATA/0/matrix"]
    row_ids = decode(handle["/0/META/ROW/id"][:])
    column_ids = decode(handle["/0/META/COL/id"][:])
    if matrix.shape == (len(row_ids), len(column_ids)):
        matrix_orientation = "gene_by_condition"
    elif matrix.shape == (len(column_ids), len(row_ids)):
        matrix_orientation = "condition_by_gene_gctx_transposed"
    else:
        raise RuntimeError((matrix.shape, len(row_ids), len(column_ids)))

if len(set(row_ids)) != len(row_ids):
    raise RuntimeError("Duplicate row identifiers")
if len(set(column_ids)) != len(column_ids):
    raise RuntimeError("Duplicate column identifiers")

for path in (RANKER_METADATA, SIGINFO, COMPOUNDINFO):
    if not path.exists():
        raise FileNotFoundError(path)
ranker_sha256 = sha256_file(RANKER_METADATA)
siginfo_sha256 = sha256_file(SIGINFO)
compoundinfo_sha256 = sha256_file(COMPOUNDINFO)
expected_hashes = {
    "ranker": "a1179dc7a9e730869d020fee576b0b20d75d7e92ead4f8fdfd5fed0d800f921b",
    "siginfo": "1a38d7ea2a804be79804af4a27aff9f2537af8f13d3c8af1fdc1fef780f40201",
    "compoundinfo": "a71fca6de41dcc46a5063858be7e04155f3c09832c8b3fb35814f03db8d9fdff",
}
if (ranker_sha256, siginfo_sha256, compoundinfo_sha256) != (
    expected_hashes["ranker"], expected_hashes["siginfo"], expected_hashes["compoundinfo"]
):
    raise RuntimeError("One or more frozen metadata SHA-256 values changed")

siginfo_columns = [
    "sig_id", "pert_id", "pert_dose", "pert_dose_unit", "pert_idose",
    "pert_time", "pert_time_unit", "pert_itime", "pert_type", "cell_iname",
    "cmap_name", "is_hiq", "qc_pass", "tas", "cc_q75", "ss_ngene",
]
siginfo = pd.read_csv(SIGINFO, sep="\t", usecols=siginfo_columns, low_memory=False)
if len(siginfo) != 1_201_944 or not siginfo["sig_id"].is_unique:
    raise RuntimeError((len(siginfo), siginfo["sig_id"].nunique()))
siginfo_indexed = siginfo.set_index("sig_id")
missing_siginfo = [value for value in column_ids if value not in siginfo_indexed.index]
if missing_siginfo:
    raise RuntimeError(f"GCTX sig_id absent from Broad siginfo: {len(missing_siginfo)}")
column_metadata = siginfo_indexed.reindex(column_ids).reset_index().rename(columns={"sig_id": "gctx_sig_id"})
column_metadata.insert(0, "column_index", np.arange(len(column_ids), dtype=np.int64))
if not column_metadata["gctx_sig_id"].astype(str).equals(pd.Series(column_ids)):
    raise RuntimeError("Broad siginfo order reconciliation failed")
if column_metadata["cmap_name"].isna().any() or column_metadata["cell_iname"].isna().any():
    raise RuntimeError("Missing compound or cell-line identity in GCTX subset")

compoundinfo = pd.read_csv(COMPOUNDINFO, sep="\t", low_memory=False)
with RANKER_METADATA.open() as handle:
    current_ranker_metadata = json.load(handle)
if len(current_ranker_metadata) != 718_055:
    raise RuntimeError(f"Unexpected current ranker metadata count: {len(current_ranker_metadata)}")

targeted = pd.read_csv(TARGETED / "condition_metadata.tsv", sep="\t")
identifier_routes = {
    "signature_id": set(targeted["signature_id"].dropna().astype(str)),
    "local_id": set(targeted["local_id"].dropna().astype(str)),
    "cmap_id": set(targeted["cmap_id"].dropna().astype(str)),
}
route_counts = {
    route: int(np.isin(column_ids, np.asarray(sorted(values), dtype=str)).sum())
    for route, values in identifier_routes.items()
}
targeted_name_check = targeted[["cmap_id", "pert_name"]].merge(
    column_metadata[["gctx_sig_id", "cmap_name"]], left_on="cmap_id", right_on="gctx_sig_id", how="left"
)
targeted_name_agreement = float(
    targeted_name_check["pert_name"].str.lower().eq(targeted_name_check["cmap_name"].str.lower()).mean()
)
targeted_uuid_ranker_overlap = int(targeted["signature_id"].astype(str).isin(current_ranker_metadata).sum())

pd.DataFrame(objects).to_json(OUT / "gctx_hdf5_inventory.json", orient="records", indent=2)
pd.DataFrame({"row_index": np.arange(len(row_ids)), "gene": row_ids}).to_csv(
    OUT / "gctx_row_identifiers.tsv", sep="\t", index=False
)
column_metadata.to_parquet(OUT / "gctx_column_metadata.parquet", index=False)

matrix_record = next(row for row in objects if row["path"] == "/0/DATA/0/matrix")
summary = {
    "inspected_at_utc": datetime.now(timezone.utc).isoformat(),
    "url": URL,
    "documented_bytes": EXPECTED_DOCUMENTED_BYTES,
    "remote_observed_bytes": OBSERVED_REMOTE_BYTES,
    "local_bytes": local_bytes,
    "remote_last_modified": REMOTE_LAST_MODIFIED,
    "remote_multipart_etag": REMOTE_ETAG,
    "multipart_etag_not_interpreted_as_md5": True,
    "local_sha256": local_sha256,
    "parallel_assembly_receipt_verified": assembly_receipt is not None,
    "matrix": matrix_record,
    "matrix_orientation": matrix_orientation,
    "row_identifiers": len(row_ids),
    "column_identifiers": len(column_ids),
    "unique_rows": len(set(row_ids)),
    "unique_columns": len(set(column_ids)),
    "broad_siginfo": {
        "url": "https://s3.amazonaws.com/macchiato.clue.io/builds/LINCS2020/siginfo_beta.txt",
        "observed_bytes": SIGINFO.stat().st_size,
        "last_modified": "Tue, 07 Dec 2021 13:24:26 GMT",
        "etag": "f1f854d7675f5dfd0a3ae3664640f70e-28",
        "version_id": "IdjZYad8vgq4Fste7egTLfio9nCf9bkI",
        "local_sha256": siginfo_sha256,
        "full_records": len(siginfo),
        "gctx_records": len(column_metadata),
        "all_gctx_columns_covered": not missing_siginfo,
        "unique_gctx_compound_names": int(column_metadata["cmap_name"].nunique()),
        "unique_gctx_pert_ids": int(column_metadata["pert_id"].nunique()),
        "missing_critical_fields": {
            key: int(column_metadata[key].isna().sum())
            for key in ["cell_iname", "cmap_name", "pert_dose", "pert_time"]
        },
        "status": "authoritative_exact_gctx_sig_id_crosswalk",
    },
    "broad_compoundinfo": {
        "url": "https://s3.amazonaws.com/macchiato.clue.io/builds/LINCS2020/compoundinfo_beta.txt",
        "observed_bytes": COMPOUNDINFO.stat().st_size,
        "last_modified": "Thu, 28 Jan 2021 22:46:50 GMT",
        "etag": "bf8e3a15ad026b47903c98d625195d24",
        "version_id": "TnqtvNk2u_hkNd5GcYY7QjMPZqL2FrpM",
        "local_sha256": compoundinfo_sha256,
        "records": len(compoundinfo),
        "status": "perturbagen_identity_provenance",
    },
    "current_ranker_metadata": {
        "url": "https://s3.dev.maayanlab.cloud/sigcom-lincs/ranker/signatures_meta.json",
        "observed_bytes": RANKER_METADATA.stat().st_size,
        "last_modified": "Tue, 30 Jun 2026 14:08:34 GMT",
        "etag": "12ec763ccc466ed3f3f94b0797e622f4",
        "local_sha256": ranker_sha256,
        "records": len(current_ranker_metadata),
        "record_difference_vs_gctx": len(column_ids) - len(current_ranker_metadata),
        "targeted_uuid_overlap": targeted_uuid_ranker_overlap,
        "status": "secondary_current_uuid_metadata_not_gctx_primary_key",
    },
    "targeted_identifier_overlap_counts": route_counts,
    "targeted_cmap_id_name_agreement_fraction": targeted_name_agreement,
    "version_drift": {
        "difference_bytes": OBSERVED_REMOTE_BYTES - EXPECTED_DOCUMENTED_BYTES,
        "difference_percent": 100 * (OBSERVED_REMOTE_BYTES / EXPECTED_DOCUMENTED_BYTES - 1),
        "status": "revised_object_under_2021_library_path",
    },
    "elapsed_seconds": time.perf_counter() - started,
    "scoring_performed": False,
}
(OUT / "SOURCE_AND_SCHEMA_QC.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps(summary, indent=2))
