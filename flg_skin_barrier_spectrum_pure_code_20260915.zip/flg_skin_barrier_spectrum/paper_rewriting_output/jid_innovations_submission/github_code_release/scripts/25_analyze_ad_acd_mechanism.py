#!/usr/bin/env python3
"""Explain and stress-test the optimized AD–ACD SNF edge."""

from pathlib import Path
import re
import textwrap

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.stats import fisher_exact


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "results/exploratory_snf/selected_positive_reml_z_q05"
OPT = BASE / "optimized_AD_ACD_branch"
OUT = OPT / "mechanism"
FIG = OUT / "figures"
OUT.mkdir(parents=True, exist_ok=True)
FIG.mkdir(parents=True, exist_ok=True)

K = 2
ALPHA = 0.2
ITERATIONS = 10
DISEASES = ["AD", "ACD", "PSORIASIS", "HS", "ACNE", "ROSACEA", "ICD"]
AD_I, ACD_I = DISEASES.index("AD"), DISEASES.index("ACD")


def scale_features(pathway_by_disease: pd.DataFrame) -> np.ndarray:
    z = pathway_by_disease[DISEASES].to_numpy(dtype=float).T
    sd = z.std(axis=0, ddof=1)
    z = z[:, np.isfinite(sd) & (sd > 0)]
    return (z - z.mean(axis=0)) / z.std(axis=0, ddof=1)


def affinity(z: np.ndarray) -> np.ndarray:
    sq = np.sum(z * z, axis=1)
    d2 = np.maximum(sq[:, None] + sq[None, :] - 2 * z @ z.T, 0)
    local = np.array([
        np.sort(np.delete(d2[i], i))[: min(K, len(d2) - 1)].mean()
        for i in range(len(d2))
    ])
    mu = (local[:, None] + local[None, :] + d2) / 3
    w = np.exp(-d2 / np.maximum(ALPHA * mu, 1e-12))
    np.fill_diagonal(w, 1)
    return w


def normalize_w(w: np.ndarray) -> np.ndarray:
    w = (w + w.T) / 2
    np.fill_diagonal(w, 0)
    p = w / np.maximum(w.sum(axis=1)[:, None], 1e-12)
    p = (p + p.T) / 2
    np.fill_diagonal(p, 0.5)
    return p / p.sum(axis=1)[:, None]


def dominant(w: np.ndarray) -> np.ndarray:
    s = np.zeros_like(w)
    for i in range(len(w)):
        ix = np.argsort(-w[i])[:K]
        s[i, ix] = w[i, ix]
    return s / np.maximum(s.sum(axis=1)[:, None], 1e-12)


def fuse(view_frames: list[pd.DataFrame]) -> np.ndarray:
    ws = [affinity(scale_features(frame)) for frame in view_frames]
    p = [normalize_w(w) for w in ws]
    s = [dominant(w) for w in ws]
    for _ in range(ITERATIONS):
        updated = []
        for i in range(len(p)):
            others = sum(p[j] for j in range(len(p)) if j != i) / (len(p) - 1)
            updated.append(normalize_w(s[i] @ others @ s[i].T))
        p = updated
    out = sum(p) / len(p)
    out = (out + out.T) / 2
    np.fill_diagonal(out, 1)
    return out


def target_metrics(w: np.ndarray) -> tuple[float, int]:
    target = float(w[AD_I, ACD_I])
    edges = w[np.triu_indices_from(w, 1)]
    return target, int(1 + np.sum(edges > target + 1e-14))


def pathway_theme(name: str, immune: bool, barrier: bool) -> str:
    if immune:
        return "immune_inflammatory"
    if barrier:
        return "barrier_lipid"
    if re.search(r"cell cycle|mitot|chromosom|spindle|centrosom|g1/s|g2/m|apc/c|meiotic", name, re.I):
        return "cell_cycle_mitotic"
    if re.search(r"dna|repair|replication|telomere|mismatch|nucleotide excision|homologous", name, re.I):
        return "DNA_damage_repair"
    if re.search(r"apopt|death|necro|caspase|stress|unfolded", name, re.I):
        return "cell_stress_death"
    if re.search(r"oxidative|respiration|mitochond|hypoxia|reactive oxygen|ROS", name, re.I):
        return "oxidative_mitochondrial"
    if re.search(r"metabol|glycol|amino acid|glucose|insulin|translation|ribosom", name, re.I):
        return "metabolism_translation"
    return "other_signaling_processes"


features = pd.read_csv(BASE / "snf_positive_pathway_feature_matrix.tsv", sep="\t").set_index("pathway")
assign = pd.read_csv(BASE / "snf_view_assignments.tsv", sep="\t").set_index("pathway").astype(bool)
features = features.loc[assign.index, DISEASES]
stress_names = assign.index[assign["stress_damage"]]
stress = features.loc[stress_names]

baseline = fuse([features, stress])
baseline_similarity, baseline_rank = target_metrics(baseline)
recorded = pd.read_csv(OPT / "optimized_fused_similarity.tsv", sep="\t").set_index("disease").to_numpy()
if not np.allclose(baseline, recorded, atol=1e-12):
    raise RuntimeError("Python SNF reproduction does not match the recorded optimized network")

# Exact leave-one-pathway-out influence. Stress pathways are removed from both
# selected views so the deletion represents removal from the complete model.
loo_rows = []
for pathway in features.index:
    all_minus = features.drop(index=pathway)
    stress_minus = stress.drop(index=pathway) if pathway in stress.index else stress
    similarity, rank = target_metrics(fuse([all_minus, stress_minus]))
    loo_rows.append((pathway, similarity, baseline_similarity - similarity, rank))

loo = pd.DataFrame(loo_rows, columns=[
    "pathway", "AD_ACD_similarity_without_pathway", "support_influence", "AD_ACD_rank_without_pathway"
]).set_index("pathway")
loo = loo.join(features[["AD", "ACD"]].rename(columns={"AD": "effect_AD", "ACD": "effect_ACD"}))
loo = loo.join(assign[["immune_adaptive", "barrier_lipid", "stress_damage"]])
shared = pd.read_csv(ROOT / "results/exploratory_sensitivity/axis_b_shared_pathways_grid.tsv", sep="\t")
shared = shared.loc[shared["method_id"].eq("reml_z_q05")].set_index("pathway")
loo["shared_significant_same_direction"] = loo.index.isin(shared.index)
loo["effect_same_direction"] = np.sign(loo["effect_AD"]) == np.sign(loo["effect_ACD"])
loo["minimum_absolute_effect"] = np.minimum(loo["effect_AD"].abs(), loo["effect_ACD"].abs())
loo["absolute_effect_gap"] = (loo["effect_AD"] - loo["effect_ACD"]).abs()
loo["theme"] = [
    pathway_theme(p, bool(r.immune_adaptive), bool(r.barrier_lipid))
    for p, r in loo.iterrows()
]
loo = loo.sort_values("support_influence", ascending=False)
loo.to_csv(OUT / "pathway_loo_influence.tsv", sep="\t")
loo.head(50).to_csv(OUT / "top_AD_ACD_pathway_drivers.tsv", sep="\t")

# Theme-level summaries preserve both net influence and the strictly positive
# support component, because nonlinear leave-one-out effects may have either sign.
theme = loo.groupby("theme").agg(
    pathways=("support_influence", "size"),
    supportive_pathways=("support_influence", lambda x: int((x > 0).sum())),
    positive_support_sum=("support_influence", lambda x: float(x[x > 0].sum())),
    net_influence=("support_influence", "sum"),
    median_influence=("support_influence", "median"),
    shared_AD_ACD_significant=("shared_significant_same_direction", "sum"),
).sort_values("positive_support_sum", ascending=False)
theme.to_csv(OUT / "pathway_theme_summary.tsv", sep="\t")

# Top-decile enrichment audits whether the influential set is dominated by the
# selected stress view or by independently shared AD/ACD-positive pathways.
top_n = int(np.ceil(len(loo) * 0.10))
is_top = pd.Series(False, index=loo.index)
is_top.iloc[:top_n] = True


def enrichment(flag: pd.Series, label: str) -> dict:
    table = np.array([
        [int((is_top & flag).sum()), int((is_top & ~flag).sum())],
        [int((~is_top & flag).sum()), int((~is_top & ~flag).sum())],
    ])
    odds, p = fisher_exact(table, alternative="greater")
    return {
        "feature": label,
        "top_decile_with_feature": table[0, 0],
        "top_decile_without_feature": table[0, 1],
        "remainder_with_feature": table[1, 0],
        "remainder_without_feature": table[1, 1],
        "odds_ratio": odds,
        "fisher_one_sided_p": p,
    }


enrich = pd.DataFrame([
    enrichment(loo["stress_damage"], "stress_damage_view"),
    enrichment(loo["shared_significant_same_direction"], "shared_AD_ACD_significant_same_direction"),
])
enrich.to_csv(OUT / "top_decile_driver_enrichment.tsv", sep="\t", index=False)

# Diagnostic variants test whether the edge depends entirely on duplicated
# stress pathways (stress pathways also occur within all_positive).
nonstress = features.drop(index=stress.index)
variants = {
    "optimized_all_plus_stress": [features, stress],
    "nonoverlap_nonstress_plus_stress": [nonstress, stress],
    "all_only_duplicated_diagnostic": [features, features],
    "stress_only_duplicated_diagnostic": [stress, stress],
}
variant_rows = []
for name, frames in variants.items():
    similarity, rank = target_metrics(fuse(frames))
    variant_rows.append({
        "network_variant": name,
        "AD_ACD_similarity": similarity,
        "AD_ACD_rank": rank,
        "pathways_view_1": len(frames[0]),
        "pathways_view_2": len(frames[1]),
    })
pd.DataFrame(variant_rows).to_csv(OUT / "view_overlap_diagnostics.tsv", sep="\t", index=False)

# Ten-percent global pathway deletion quantifies stability to broad feature loss.
rng = np.random.default_rng(20260825)
deletion_rows = []
drop_n = int(round(len(features) * 0.10))
for replicate in range(1, 1001):
    dropped = rng.choice(features.index.to_numpy(), size=drop_n, replace=False)
    all_reduced = features.drop(index=dropped)
    stress_reduced = stress.drop(index=stress.index.intersection(dropped))
    similarity, rank = target_metrics(fuse([all_reduced, stress_reduced]))
    deletion_rows.append((replicate, similarity, rank))
deletion = pd.DataFrame(deletion_rows, columns=["replicate", "AD_ACD_similarity", "AD_ACD_rank"])
deletion.to_csv(OUT / "random_10pct_pathway_deletion.tsv", sep="\t", index=False)
deletion_summary = pd.DataFrame([{
    "replicates": len(deletion),
    "pathways_removed_per_replicate": drop_n,
    "similarity_median": deletion["AD_ACD_similarity"].median(),
    "similarity_ci_low": deletion["AD_ACD_similarity"].quantile(0.025),
    "similarity_ci_high": deletion["AD_ACD_similarity"].quantile(0.975),
    "rank_median": deletion["AD_ACD_rank"].median(),
    "proportion_rank_le_3": (deletion["AD_ACD_rank"] <= 3).mean(),
    "proportion_similarity_above_initial_network": (deletion["AD_ACD_similarity"] > 0.125721205622182).mean(),
}])
deletion_summary.to_csv(OUT / "random_10pct_pathway_deletion_summary.tsv", sep="\t", index=False)

# Keep the same-parameter view comparison visible without re-running the grid.
grid = pd.read_csv(BASE / "parameter_grid/snf_parameter_grid.tsv", sep="\t")
same_parameter = grid.loc[
    grid["K"].eq(K) & grid["alpha"].eq(ALPHA) & grid["iterations"].eq(ITERATIONS)
].sort_values("AD_ACD_similarity", ascending=False)
same_parameter.to_csv(OUT / "same_parameter_view_comparison.tsv", sep="\t", index=False)

summary = pd.DataFrame([{
    "baseline_similarity": baseline_similarity,
    "baseline_rank": baseline_rank,
    "pathways": len(features),
    "stress_damage_pathways": len(stress),
    "shared_AD_ACD_significant_same_direction": int(loo["shared_significant_same_direction"].sum()),
    "positive_LOO_supporters": int((loo["support_influence"] > 0).sum()),
    "top_decile_size": top_n,
    "random_deletion_replicates": len(deletion),
    "random_deletion_rank_le_3": float((deletion["AD_ACD_rank"] <= 3).mean()),
    "random_deletion_similarity_median": float(deletion["AD_ACD_similarity"].median()),
}])
summary.to_csv(OUT / "mechanism_summary.tsv", sep="\t", index=False)

# Compact positive-driver figure; exact values remain in the TSV.
plot_data = loo.head(20).sort_values("support_influence")
colors = np.where(plot_data["stress_damage"], "#E45756", "#4C78A8")
fig, ax = plt.subplots(figsize=(12, 9))
plot_values = plot_data["support_influence"] * 1000
ax.barh(range(len(plot_data)), plot_values, color=colors)
ax.set_yticks(range(len(plot_data)))
ax.set_yticklabels([textwrap.fill(x, 52) for x in plot_data.index], fontsize=8)
ax.set_xlabel("AD–ACD support influence (×10⁻³)")
ax.set_title("Top pathway drivers of the optimized AD–ACD SNF edge")
ax.grid(axis="x", alpha=0.2)
fig.subplots_adjust(left=0.47, right=0.98, top=0.94, bottom=0.09)
fig.savefig(FIG / "top_AD_ACD_pathway_drivers.png", dpi=180)
plt.close(fig)

print(summary.to_string(index=False))
print("\nTop 15 drivers:")
print(loo.head(15)[["support_influence", "effect_AD", "effect_ACD", "stress_damage", "shared_significant_same_direction", "theme"]].to_string())
print("\nDeletion stability:")
print(deletion_summary.to_string(index=False))
print("\nView overlap diagnostics:")
print(pd.DataFrame(variant_rows).to_string(index=False))
