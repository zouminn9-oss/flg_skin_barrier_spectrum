#!/usr/bin/env Rscript

# Reuse the validated SNF implementation up to, but not including, the original
# observed-network execution.
src <- readLines("scripts/18_run_exploratory_snf.R")
cut <- grep("^obs_views <- make_views", src)[1]
eval(parse(text = src[seq_len(cut - 1L)]), envir = .GlobalEnv)

grid_dir <- file.path(root, "results/exploratory_snf/selected_positive_reml_z_q05/parameter_grid")
dir.create(grid_dir, recursive = TRUE, showWarnings = FALSE)

all_views <- make_views(x)
names(all_views) <- view_names
view_sets <- unlist(lapply(2:4, function(k) combn(view_names, k, simplify = FALSE)), recursive = FALSE)

rows <- list()
counter <- 0L
for (vs in view_sets) {
  for (k_nn in c(2L, 3L, 4L, 5L)) {
    for (a in c(0.2, 0.5, 1.0)) {
      for (it in c(10L, 20L, 50L)) {
        counter <- counter + 1L
        K <- k_nn; alpha <- a; iterations <- it
        wf <- fuse(all_views[vs])
        vals <- sort(wf[upper.tri(wf)], decreasing = TRUE)
        target <- wf["AD", "ACD"]
        models <- rbindlist(lapply(2:4, function(kc) {
          cl <- spectral_cluster(wf, kc)
          data.table(k = kc, silhouette = mean_silhouette(cl$cluster, wf),
                     target_same_cluster = cl$cluster[match("AD", diseases)] == cl$cluster[match("ACD", diseases)])
        }))
        setorder(models, -silhouette, k)
        rows[[counter]] <- data.table(
          branch_id = sprintf("B%04d", counter),
          views = paste(vs, collapse = "+"), n_views = length(vs),
          K = K, alpha = alpha, iterations = iterations,
          AD_ACD_similarity = target,
          AD_ACD_rank = match(target, vals),
          selected_k = models$k[1],
          selected_silhouette = models$silhouette[1],
          AD_ACD_same_cluster = models$target_same_cluster[1]
        )
      }
    }
  }
}

grid <- rbindlist(rows)
setorder(grid, -AD_ACD_similarity, AD_ACD_rank, -selected_silhouette)
fwrite(grid, file.path(grid_dir, "snf_parameter_grid.tsv"), sep = "\t")
fwrite(grid[1], file.path(grid_dir, "snf_most_favorable_AD_ACD_branch.tsv"), sep = "\t")
print(grid[1:20])
