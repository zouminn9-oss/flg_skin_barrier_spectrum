#!/bin/sh
set -eu

project_root=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
out_file="$project_root/logs/environment_session.txt"

{
  date -u '+captured_utc=%Y-%m-%dT%H:%M:%SZ'
  uname -a
  python3 --version
  R --version | sed -n '1,3p'
  git --version
  curl --version | sed -n '1,2p'
  shasum -a 256 "$project_root"/gate12_snapshot/*.md "$project_root"/gate12_snapshot/*.csv
} > "$out_file"

