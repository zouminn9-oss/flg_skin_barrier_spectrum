#!/usr/bin/env python3
"""Verify and inventory the immutable Broad CMap2020 MODZ compound GCTX."""

from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
LOCAL_PACKAGES = ROOT / "environment/python_packages"
if LOCAL_PACKAGES.exists():
    sys.path.insert(0, str(LOCAL_PACKAGES))

import h5py
import numpy as np
import pandas as pd

BASE_URL = "https://s3.amazonaws.com/macchiato.clue.io/builds/LINCS2020/level5/level5_beta_trt_cp_n720216x12328.gctx"
VERSION_ID = "ljLz1nWDJ4co.kG6bSrfEs7mrklxiVS4"
EXPECTED_BYTES = 35_518_405_386
EXPECTED_ETAG = "d342ab7f3fa6ece699099bc2d8fc94b8-2118"
GCTX = ROOT / "data/raw/perturbations/cmap2020_modz/level5_beta_trt_cp_n720216x12328.gctx"
GENEINFO = ROOT / "data/raw/perturbations/cmap2020_modz/geneinfo_beta.txt"
RECEIPT = GCTX.parent / "download_receipt.json"
SIGINFO = ROOT / "data/raw/perturbations/lincs_2021_full/siginfo_beta.txt"
COMPOUNDINFO = ROOT / "data/raw/perturbations/lincs_2021_full/compoundinfo_beta.txt"
MECH = ROOT / "results/exploratory_snf/selected_positive_reml_z_q05/optimized_AD_ACD_branch/mechanism"
TARGETED = MECH / "lincs_cross_resource_replication"
OUT = MECH / "cmap2020_modz_full_background_sensitivity"
OUT.mkdir(parents=True, exist_ok=True)

EXPECTED_HASHES = {
    "geneinfo": "e739d06bad42ff9285c00b778e65d8999425062a3375cc7e7cdab0e7154490b5",
    "siginfo": "1a38d7ea2a804be79804af4a27aff9f2537af8f13d3c8af1fdc1fef780f40201",
    "compoundinfo": "a71fca6de41dcc46a5063858be7e04155f3c09832c8b3fb35814f03db8d9fdff",
}


def decode(values):
    values = np.asarray(values)
    if values.dtype.kind == "S":
        return np.char.decode(values, "utf-8")
    if values.dtype.kind == "O":
        return np.asarray([value.decode() if isinstance(value, (bytes, np.bytes_)) else str(value) for value in values])
    return values.astype(str)


def sha256_file(path, block_size=16 * 1024 * 1024):
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(block_size), b""):
            digest.update(block)
    return digest.hexdigest()


started = time.perf_counter()
for path in (GCTX, GENEINFO, RECEIPT, SIGINFO, COMPOUNDINFO):
    if not path.exists():
        raise FileNotFoundError(path)
if GCTX.stat().st_size != EXPECTED_BYTES:
    raise RuntimeError(f"Matrix bytes changed: {GCTX.stat().st_size} != {EXPECTED_BYTES}")

receipt = json.loads(RECEIPT.read_text())
matrix_sha256 = sha256_file(GCTX)
if receipt["matrix_bytes"] != EXPECTED_BYTES or receipt["matrix_sha256"] != matrix_sha256:
    raise RuntimeError("Download receipt does not match matrix")
if receipt["remote"]["version_id"] != VERSION_ID or receipt["remote"]["etag"] != EXPECTED_ETAG:
    raise RuntimeError("Download receipt does not match frozen S3 object")

geneinfo_sha256 = sha256_file(GENEINFO)
siginfo_sha256 = sha256_file(SIGINFO)
compoundinfo_sha256 = sha256_file(COMPOUNDINFO)
if (geneinfo_sha256, siginfo_sha256, compoundinfo_sha256) != tuple(EXPECTED_HASHES.values()):
    raise RuntimeError("Frozen metadata SHA-256 mismatch")

objects = []
with h5py.File(GCTX, "r") as handle:
    def collect(name, obj):
        row = {"path": "/" + name, "object_type": "group" if isinstance(obj, h5py.Group) else "dataset"}
        if isinstance(obj, h5py.Dataset):
            row.update({"shape": list(obj.shape), "dtype": str(obj.dtype), "chunks": list(obj.chunks) if obj.chunks else None, "compression": obj.compression})
        objects.append(row)
    handle.visititems(collect)
    required = ["/0/DATA/0/matrix", "/0/META/ROW/id", "/0/META/COL/id"]
    missing = [path for path in required if path not in handle]
    if missing:
        raise RuntimeError(f"Missing GCTX objects: {missing}")
    matrix = handle["/0/DATA/0/matrix"]
    row_ids = decode(handle["/0/META/ROW/id"][:])
    column_ids = decode(handle["/0/META/COL/id"][:])
    if matrix.shape == (len(row_ids), len(column_ids)):
        orientation = "gene_by_condition"
    elif matrix.shape == (len(column_ids), len(row_ids)):
        orientation = "condition_by_gene_gctx_transposed"
    else:
        raise RuntimeError((matrix.shape, len(row_ids), len(column_ids)))

if len(row_ids) != 12_328 or len(set(row_ids)) != len(row_ids):
    raise RuntimeError("Unexpected or duplicate row identifiers")
if len(column_ids) != 720_216 or len(set(column_ids)) != len(column_ids):
    raise RuntimeError("Unexpected or duplicate column identifiers")

geneinfo = pd.read_csv(GENEINFO, sep="\t", low_memory=False)
if len(geneinfo) != 12_328 or not geneinfo["gene_id"].is_unique:
    raise RuntimeError("Unexpected geneinfo grain")
geneinfo["gene_id_string"] = geneinfo["gene_id"].astype(str)
row_metadata = geneinfo.set_index("gene_id_string").reindex(row_ids).reset_index()
if row_metadata["gene_symbol"].isna().any():
    raise RuntimeError("A GCTX row lacks a geneinfo crosswalk")
row_metadata.insert(0, "row_index", np.arange(len(row_ids), dtype=np.int64))
row_metadata["canonical_for_symbol"] = ~row_metadata["gene_symbol"].duplicated(keep=False)
row_metadata.loc[row_metadata["gene_id"].eq(4253), "canonical_for_symbol"] = True
row_metadata.loc[row_metadata["gene_id"].eq(117153), "canonical_for_symbol"] = False
if row_metadata.loc[row_metadata["gene_symbol"].eq("MIA2"), "canonical_for_symbol"].sum() != 1:
    raise RuntimeError("MIA2 canonical mapping was not resolved")
canonical_symbols = row_metadata.loc[row_metadata["canonical_for_symbol"], "gene_symbol"]
if len(canonical_symbols) != 12_327 or not canonical_symbols.is_unique:
    raise RuntimeError("Canonical symbol mapping must contain 12,327 unique symbols")

siginfo_columns = ["sig_id", "pert_id", "pert_dose", "pert_dose_unit", "pert_idose", "pert_time", "pert_time_unit", "pert_itime", "pert_type", "cell_iname", "cmap_name", "is_hiq", "qc_pass", "tas", "cc_q75", "ss_ngene"]
siginfo = pd.read_csv(SIGINFO, sep="\t", usecols=siginfo_columns, low_memory=False)
if len(siginfo) != 1_201_944 or not siginfo["sig_id"].is_unique:
    raise RuntimeError("Unexpected siginfo grain")
trt_cp = siginfo.loc[siginfo["pert_type"].eq("trt_cp")]
if len(trt_cp) != 720_216:
    raise RuntimeError(f"Unexpected trt_cp count: {len(trt_cp)}")
indexed = trt_cp.set_index("sig_id")
missing_columns = [value for value in column_ids if value not in indexed.index]
if missing_columns:
    raise RuntimeError(f"MODZ columns absent from siginfo: {len(missing_columns)}")
column_metadata = indexed.reindex(column_ids).reset_index().rename(columns={"sig_id": "gctx_sig_id"})
column_metadata.insert(0, "column_index", np.arange(len(column_ids), dtype=np.int64))
if column_metadata["cmap_name"].isna().any() or column_metadata["cell_iname"].isna().any():
    raise RuntimeError("Missing compound or cell-line identity")

targeted = pd.read_csv(TARGETED / "condition_metadata.tsv", sep="\t")
targeted_overlap = int(targeted["cmap_id"].astype(str).isin(set(column_ids)).sum())
jnj = column_metadata.loc[column_metadata["cmap_name"].eq("JNJ-7706621")]
if len(jnj) != 297:
    raise RuntimeError(f"Expected 297 JNJ conditions, found {len(jnj)}")

pd.DataFrame(objects).to_json(OUT / "gctx_hdf5_inventory.json", orient="records", indent=2)
row_metadata.to_csv(OUT / "gctx_row_metadata.tsv", sep="\t", index=False)
column_metadata.to_parquet(OUT / "gctx_column_metadata.parquet", index=False)
matrix_record = next(row for row in objects if row["path"] == "/0/DATA/0/matrix")
summary = {
    "inspected_at_utc": datetime.now(timezone.utc).isoformat(), "url": BASE_URL,
    "version_id": VERSION_ID, "remote_observed_bytes": EXPECTED_BYTES, "local_bytes": GCTX.stat().st_size,
    "remote_last_modified": receipt["remote"]["last_modified"], "remote_multipart_etag": EXPECTED_ETAG,
    "multipart_etag_not_interpreted_as_md5": True, "local_sha256": matrix_sha256,
    "download_receipt_verified": True, "matrix": matrix_record, "matrix_orientation": orientation,
    "row_identifiers": len(row_ids), "column_identifiers": len(column_ids), "canonical_gene_symbols": len(canonical_symbols),
    "duplicate_symbol_resolution": {"symbol": "MIA2", "included_gene_id": 4253, "excluded_gene_id": 117153},
    "geneinfo": {"bytes": GENEINFO.stat().st_size, "local_sha256": geneinfo_sha256, "records": len(geneinfo)},
    "broad_siginfo": {"local_sha256": siginfo_sha256, "full_records": len(siginfo), "trt_cp_records": len(trt_cp), "all_gctx_columns_covered": not missing_columns, "unique_gctx_compound_names": int(column_metadata["cmap_name"].nunique()), "unique_gctx_pert_ids": int(column_metadata["pert_id"].nunique()), "missing_critical_fields": {key: int(column_metadata[key].isna().sum()) for key in ["cell_iname", "cmap_name", "pert_dose", "pert_time"]}},
    "broad_compoundinfo": {"local_sha256": compoundinfo_sha256, "records": len(pd.read_csv(COMPOUNDINFO, sep="\t", low_memory=False))},
    "targeted_cmap_id_overlap": targeted_overlap, "jnj_conditions": len(jnj),
    "elapsed_seconds": time.perf_counter() - started, "scoring_performed": False,
}
(OUT / "SOURCE_AND_SCHEMA_QC.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps(summary, indent=2))
