#!/usr/bin/env python3
"""Independently validate drug-signature reversal outputs and tier boundaries."""

from pathlib import Path
import hashlib
import json

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
MECH = ROOT / "results/exploratory_snf/selected_positive_reml_z_q05/optimized_AD_ACD_branch/mechanism"
OUT = MECH / "drug_signature_reversal"
RAW = ROOT / "data/raw/perturbations/sciplex_perturbseqr"
EXPECTED = {
    "sciplex-full.txt.gz": "bde6c2e27a6505137f64d10f41eaf8d92354be86a920de0eb80d4ab9e76d0a19",
    "sciplex-cell_line_metadata.parquet": "80cd7467b1363ebf93c440e7f7fb5bbe7276c1dc8042d05f70e9c6d1e9de06c3",
    "sciplex-drug_metadata.parquet": "de46525a4fec469751f5b68e3eacb000e82a5a7691b70867f17abd70dd974f06",
}
REQUIRED = [
    "condition_level_reversal.tsv", "compound_level_ranking.tsv",
    "candidate_vs_background.tsv", "candidate_matched_compounds.tsv",
    "independent_validation.tsv", "internal_five_cohort_direction_audit.tsv",
    "toxicity_cell_cycle_sensitivity.tsv", "locked_disease_signatures.tsv",
    "condition_metadata.tsv", "resource_qc_summary.tsv", "raw_file_integrity.tsv",
    "prepared_sciplex_effects.npz", "RUN_PARAMETERS.json",
]


def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def bh(pvalues):
    p = np.asarray(pvalues, dtype=float)
    order = np.argsort(p)
    ranked = p[order]
    adjusted = np.minimum.accumulate((ranked * len(p) / np.arange(1, len(p) + 1))[::-1])[::-1]
    out = np.empty_like(adjusted)
    out[order] = np.minimum(adjusted, 1.0)
    return out


for name in REQUIRED:
    path = OUT / name
    assert path.exists() and path.stat().st_size > 0, path
for name, expected in EXPECTED.items():
    assert sha256(RAW / name) == expected, name
assert (ROOT / "DRUG_SIGNATURE_REVERSAL_PROTOCOL.md").exists()
assert (ROOT / "AD_ACD_DRUG_SIGNATURE_REVERSAL_REPORT.md").exists()

run = json.loads((OUT / "RUN_PARAMETERS.json").read_text())
assert run["seed"] == 20260825
assert run["gene_label_permutations"] == run["compound_label_permutations"] == 1000
assert run["common_complete_APC_genes"] == 3692
assert run["common_complete_program_genes"] == 213

condition = pd.read_csv(OUT / "condition_level_reversal.tsv", sep="\t")
compound = pd.read_csv(OUT / "compound_level_ranking.tsv", sep="\t")
independent = pd.read_csv(OUT / "independent_validation.tsv", sep="\t")
internal = pd.read_csv(OUT / "internal_five_cohort_direction_audit.tsv", sep="\t")
toxicity = pd.read_csv(OUT / "toxicity_cell_cycle_sensitivity.tsv", sep="\t")
candidate = pd.read_csv(OUT / "candidate_vs_background.tsv", sep="\t")
matched = pd.read_csv(OUT / "candidate_matched_compounds.tsv", sep="\t")
qc = pd.read_csv(OUT / "resource_qc_summary.tsv", sep="\t").iloc[0]

assert len(condition) == condition["condition_id"].nunique() == 2302
assert condition["compound_normalized"].nunique() == 188
assert set(condition["cell_line"]) == {"A549", "K562", "MCF7"}
assert set(condition["dose"]) == {"10nM", "100nM", "1µM", "10µM"}
assert set(condition["time"]) == {"24h", "72h"}
assert (condition["common_complete_APC_genes"] == 3692).all()
assert (condition["common_complete_program_genes"] == 213).all()
assert condition["pairwise_APC_genes"].min() >= 100
assert condition["pairwise_program_genes"].min() >= 20

components = [
    "apc_genome_rank_reversal", "apc_genome_weighted_reversal",
    "apc_program_rank_reversal", "apc_program_weighted_reversal",
]
assert np.allclose(condition[components].mean(axis=1), condition["apc_composite_reversal"])
assert np.allclose(
    condition[[x.replace("apc_", "external_") for x in components]].mean(axis=1),
    condition["external_composite_reversal"],
)
psteps = condition["apc_gene_label_empirical_p"] * 1001
assert np.allclose(psteps, np.round(psteps))
assert condition["apc_gene_label_empirical_p"].ge(1 / 1001 - 1e-12).all()
assert condition["apc_gene_label_empirical_p"].le(1 + 1e-12).all()
assert np.corrcoef(
    condition["apc_composite_reversal"], condition["pairwise_apc_composite_reversal"]
)[0, 1] > 0.99

assert len(compound) == compound["compound_normalized"].nunique() == 188
assert compound["rank"].tolist() == list(range(1, 189))
assert set(compound["evidence_tier"]) <= {"Tier A", "Tier B", "Tier C", "Reject"}
assert compound["posthoc_status"].eq("exploratory_computational_hypothesis_generation").all()
assert np.allclose(compound["compound_label_BH_q"], bh(compound["compound_label_empirical_p"]))
assert np.allclose(compound["compound_label_empirical_p"] * 1001, np.round(compound["compound_label_empirical_p"] * 1001))

# Recompute every compound aggregation, stability flag, screen, toxicity rule,
# and tier without trusting the scoring script.
lookup = compound.set_index("compound_normalized")
for name, group in condition.groupby("compound_normalized"):
    row = lookup.loc[name]
    assert int(row["n_conditions"]) == len(group)
    assert int(row["n_cell_lines"]) == group["cell_line"].nunique()
    assert np.isclose(row["median_apc_composite_reversal"], group["apc_composite_reversal"].median())
    for column in components:
        assert np.isclose(row[f"median_{column}"], group[column].median())
    values = group["apc_composite_reversal"].to_numpy()
    min_cond = min(np.median(np.delete(values, i)) for i in range(len(values))) if len(values) >= 2 else np.nan
    cell_loo = [
        group.loc[group["cell_line"].ne(cell), "apc_composite_reversal"].median()
        for cell in group["cell_line"].unique()
        if group["cell_line"].ne(cell).any()
    ]
    min_cell = min(cell_loo) if group["cell_line"].nunique() >= 2 else np.nan
    stable = bool(
        len(group) >= 2 and group["cell_line"].nunique() >= 2
        and np.mean(values > 0) >= 2 / 3 and min_cond > 0 and min_cell > 0
    )
    assert bool(row["multi_condition_stable"]) == stable
    screen = bool(all(group[column].median() > 0 for column in components) and np.median(values) > 0)
    assert bool(row["primary_five_score_screen"]) == screen
    removed = group["tox_removed_apc_composite_reversal"].median()
    frac = group["condition_toxicity_dominated"].mean()
    tox = bool(frac >= 0.5 or removed <= 0 or (np.median(values) > 0 and removed < 0.5 * np.median(values)))
    assert bool(row["toxicity_dominated"]) == tox

expected_tier = np.full(len(compound), "Reject", dtype=object)
tier_a = (
    compound["primary_five_score_screen"] & compound["compound_label_BH_q"].lt(0.05)
    & compound["multi_condition_stable"] & compound["external_direction_supported"]
    & ~compound["toxicity_dominated"]
)
tier_b = (
    compound["primary_five_score_screen"] & compound["compound_label_BH_q"].lt(0.05)
    & compound["multi_condition_stable"] & ~compound["external_direction_supported"]
    & ~compound["toxicity_dominated"]
)
tier_c = (
    compound["median_apc_composite_reversal"].gt(0)
    & compound["compound_label_empirical_p"].lt(0.05)
    & ~compound["toxicity_dominated"] & ~tier_a & ~tier_b
)
expected_tier[tier_a] = "Tier A"
expected_tier[tier_b] = "Tier B"
expected_tier[tier_c] = "Tier C"
assert np.array_equal(expected_tier, compound["evidence_tier"].to_numpy())
assert int(tier_a.sum()) == int(tier_b.sum()) == 0
assert int(tier_c.sum()) == 6
assert int((compound["evidence_tier"] == "Reject").sum()) == 182
assert int((compound["compound_label_BH_q"] < 0.05).sum()) == 0
assert np.isclose(compound["compound_label_BH_q"].min(), 0.3756243756243756)

assert len(independent) == len(internal) == len(toxicity) == 188
assert set(independent["compound_normalized"]) == set(compound["compound_normalized"])
assert set(internal["compound_normalized"]) == set(compound["compound_normalized"])
assert set(toxicity["compound_normalized"]) == set(compound["compound_normalized"])
assert np.allclose(
    independent["external_compound_label_BH_q"], bh(independent["external_compound_label_empirical_p"])
)
assert int((independent["external_compound_label_BH_q"] < 0.05).sum()) == 0
assert internal["validation_status"].eq("not_independent_upstream_contributors").all()
assert internal["positive_internal_cohorts"].between(0, 5).all()
assert int(toxicity["toxicity_dominated"].sum()) == 102

assert len(candidate) == 8
assert set(candidate["candidate_target"]) == {"IRF1", "HSF1", "ATR", "PCNA", "CDK2", "E2F4", "YY1", "E2F6"}
assert candidate["exact_lead_agents_screened"].sum() == 0
assert (candidate["unique_candidate_group_compounds"] + candidate["full_background_compounds"] == 188).all()
assert set(matched["candidate_target"]) == {"CDK2"}
assert len(matched) == 6
assert (matched["exact_lead_agent_alias"] == False).all()  # noqa: E712

assert int(qc["conditions"]) == 2302 and int(qc["compounds"]) == 188
assert int(qc["APC_overlap"]) == 4267 and int(qc["locked_program_overlap"]) == 219
assert qc["excluded_CMap_reason"] == "drug_cell_aggregated_no_dose_time_batch"

report = (ROOT / "AD_ACD_DRUG_SIGNATURE_REVERSAL_REPORT.md").read_text()
for required_text in [
    "事后、探索性、纯计算分析", "没有任何药物达到 Tier A 或 Tier B",
    "0/5 在 BH q<0.05 确认", "不是独立验证", "不是因果生物学敲除",
    "不是临床疗效或安全性证据", "182 个被拒绝", "完整比较网格均保留",
]:
    assert required_text in report, required_text

print(
    "PASS: 2,302 conditions and all 188 compounds retained; four-score, "
    "permutation/BH, stability, toxicity, external/internal, candidate-background, "
    "and tier rules independently validated. Tier A=0, Tier B=0, Tier C=6, Reject=182."
)
