#!/usr/bin/env python3
"""Validate completeness and labeling of post-hoc virtual-KO sensitivity."""

from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "results/exploratory_snf/selected_positive_reml_z_q05/optimized_AD_ACD_branch/mechanism/virtual_knockout_sensitivity"

for name in [
    "model_scope_comparison.tsv", "program_restricted_virtual_knockout.tsv",
    "complete_threshold_sensitivity_grid.tsv", "experiment_matrix.tsv",
    "resource_estimate.tsv", "figures/complete_threshold_sensitivity.png",
]:
    path = OUT / name
    assert path.exists() and path.stat().st_size > 0, path

scope = pd.read_csv(OUT / "model_scope_comparison.tsv", sep="\t")
result = pd.read_csv(OUT / "program_restricted_virtual_knockout.tsv", sep="\t")
grid = pd.read_csv(OUT / "complete_threshold_sensitivity_grid.tsv", sep="\t")
matrix = pd.read_csv(OUT / "experiment_matrix.tsv", sep="\t")
resource = pd.read_csv(OUT / "resource_estimate.tsv", sep="\t").iloc[0]

assert len(scope) == 4
assert set(scope["model_id"]) == {
    "full_genome_5TF", "full_genome_306TF", "program_only_5TF", "program_only_306TF"
}
assert scope["posthoc_status"].eq("exploratory_sensitivity_only").all()
assert len(result) == 5 and set(result["TF"]) == {"YY1", "IRF1", "E2F6", "E2F4", "HSF1"}
assert result["posthoc_status"].eq("exploratory_program_restricted_model").all()
assert result[["driver_program_reduction", "bootstrap_CI025", "bootstrap_CI975",
               "bootstrap_probability_reduction_gt_0", "max5_network_null_p"]].notna().all().all()
assert result["bootstrap_probability_reduction_gt_0"].between(0, 1).all()
assert result["max5_network_null_p"].between(0, 1).all()
expected_strict = (
    result["driver_program_reduction"].gt(0)
    & result["bootstrap_probability_reduction_gt_0"].ge(0.95)
    & result["max5_network_null_p"].lt(0.05)
)
assert (result["strict_095_005_pass"] == expected_strict).all()

assert len(grid) == 2 * 4 * 3
assert grid.groupby("model_id").size().eq(12).all()
assert grid["bootstrap_probability_threshold"].nunique() == 4
assert grid["max5_network_null_p_threshold"].nunique() == 3
assert grid.loc[grid["threshold_role"].eq("original_strict")].shape[0] == 2
assert matrix.loc[matrix["run_id"].str.startswith("S")].shape[0] == 4
assert matrix["status"].eq("completed").all() and matrix["seed"].eq(20260825).all()
assert resource["GPU_hours"] == 0 and resource["external_API_cost_USD"] == 0
assert resource["gene_bootstraps"] == 2000 and resource["network_rewires"] == 5000
assert np.isfinite(scope[["in_sample_R2", "tenfold_CV_R2"]].to_numpy()).all()

print("PASS: full 2x2 scope comparison and all 24 threshold cells are present and labeled post hoc.")

