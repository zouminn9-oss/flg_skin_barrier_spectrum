#!/usr/bin/env python3
"""Structural and numerical validation for the APC virtual-knockout outputs."""

from pathlib import Path

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "results/exploratory_snf/selected_positive_reml_z_q05/optimized_AD_ACD_branch/mechanism/virtual_knockout"
CANDIDATES = ["YY1", "IRF1", "E2F6", "E2F4", "HSF1"]

required = [
    "experiment_matrix.tsv",
    "single_tf_virtual_knockout.tsv",
    "pair_virtual_knockout.tsv",
    "pathway_virtual_knockout_effects.tsv",
    "bootstrap_virtual_knockout.tsv.gz",
    "random_network_null.tsv.gz",
    "virtual_knockout_model_summary.tsv",
    "virtual_knockout_summary.tsv",
    "figures/single_TF_virtual_knockout_effects.png",
]
for relative in required:
    path = OUT / relative
    assert path.exists() and path.stat().st_size > 0, f"missing or empty: {path}"

matrix = pd.read_csv(OUT / "experiment_matrix.tsv", sep="\t")
single = pd.read_csv(OUT / "single_tf_virtual_knockout.tsv", sep="\t")
pair = pd.read_csv(OUT / "pair_virtual_knockout.tsv", sep="\t")
pathways = pd.read_csv(OUT / "pathway_virtual_knockout_effects.tsv", sep="\t")
boot = pd.read_csv(OUT / "bootstrap_virtual_knockout.tsv.gz", sep="\t")
null = pd.read_csv(OUT / "random_network_null.tsv.gz", sep="\t")
model = pd.read_csv(OUT / "virtual_knockout_model_summary.tsv", sep="\t").iloc[0]
summary = pd.read_csv(OUT / "virtual_knockout_summary.tsv", sep="\t").iloc[0]

assert set(single["TF"]) == set(CANDIDATES) and len(single) == 5
assert single["intervention"].eq("KO_" + single["TF"]).all()
assert np.allclose(
    single["driver_program_reduction"],
    single["baseline_predicted_driver_score"] - single["KO_predicted_driver_score"],
)
assert np.allclose(
    single["core_program_reduction"],
    single["baseline_predicted_core_score"] - single["KO_predicted_core_score"],
)
assert single[[
    "ridge_coefficient", "driver_program_reduction", "bootstrap_CI025",
    "bootstrap_CI975", "bootstrap_probability_reduction_gt_0",
    "network_null_p_one_sided", "max5_network_null_p",
]].notna().all().all()
assert single["bootstrap_probability_reduction_gt_0"].between(0, 1).all()
assert single["network_null_p_one_sided"].between(0, 1).all()
assert single["max5_network_null_p"].between(0, 1).all()
assert (single["bootstrap_CI025"] <= single["bootstrap_CI975"]).all()

expected_pass = (
    single["driver_program_reduction"].gt(0)
    & single["bootstrap_probability_reduction_gt_0"].ge(
        model["strict_bootstrap_probability_threshold"]
    )
    & single["max5_network_null_p"].lt(model["strict_max5_network_null_p_threshold"])
)
assert (single["strict_screen_pass"] == expected_pass).all()
assert int(model["strict_single_KO_passes"]) == int(expected_pass.sum())
assert int(summary["strict_screen_pass_count"]) == int(expected_pass.sum())

assert int(model["genes_modeled"]) == 4621
assert int(model["candidate_TFs"]) == 5
assert int(model["gene_bootstraps"]) == 2000
assert int(model["degree_sign_preserving_network_rewires"]) == 5000
assert len(boot) == 2000 * 5 and set(boot["TF"]) == set(CANDIDATES)
assert len(null) == 5000 * 5 and set(null["TF"]) == set(CANDIDATES)
assert pathways.groupby("pathway")["TF"].nunique().eq(5).all()

single_matrix = matrix.loc[matrix["run_id"].str.startswith("single_KO_")]
assert len(single_matrix) == 5 and single_matrix["variables_changed"].eq(1).all()
pair_triggered = bool(model["pair_stage_triggered"])
assert pair_triggered == (len(pair) == 1)
pair_status = matrix.loc[matrix["run_id"].eq("pair_KO_contingent"), "status"].iloc[0]
assert pair_status == ("completed" if pair_triggered else "not_triggered")
if pair_triggered:
    assert int(expected_pass.sum()) >= 2
else:
    assert int(expected_pass.sum()) < 2

assert summary["analysis_scope"] == "exploratory_computational_virtual_knockout"
assert bool(summary["biological_validation_required"])

print(
    "PASS: virtual-knockout outputs are complete, numerical identities hold, "
    "single-variable isolation is encoded, and staged pair logic is consistent."
)

