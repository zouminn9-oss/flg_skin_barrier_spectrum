#!/usr/bin/env python3
import csv
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "results/exploratory_snf/selected_positive_reml_z_q05/optimized_AD_ACD_branch/mechanism"


def rows(path):
    with path.open(newline="") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


summary = rows(OUT / "mechanism_summary.tsv")[0]
assert int(summary["pathways"]) == 1444
assert int(summary["stress_damage_pathways"]) == 114
assert int(summary["shared_AD_ACD_significant_same_direction"]) == 417
assert abs(float(summary["baseline_similarity"]) - 0.259194425241384) < 1e-12
assert int(summary["baseline_rank"]) == 3

loo = rows(OUT / "pathway_loo_influence.tsv")
assert len(loo) == 1444
assert loo[0]["pathway"] == "Recognition of DNA damage by PCNA-containing replication complex"
assert float(loo[0]["support_influence"]) > 0.0037
assert all(r["stress_damage"] == "True" for r in loo[:20])
assert sum(r["theme"] in {"DNA_damage_repair", "cell_cycle_mitotic", "cell_stress_death"} for r in loo[:20]) >= 18

deletion = rows(OUT / "random_10pct_pathway_deletion.tsv")
assert len(deletion) == 1000
assert all(int(r["AD_ACD_rank"]) <= 3 for r in deletion)
assert all(float(r["AD_ACD_similarity"]) > 0.125721205622182 for r in deletion)

variants = {r["network_variant"]: r for r in rows(OUT / "view_overlap_diagnostics.tsv")}
assert int(variants["nonoverlap_nonstress_plus_stress"]["AD_ACD_rank"]) == 3
assert float(variants["nonoverlap_nonstress_plus_stress"]["AD_ACD_similarity"]) > 0.24
assert int(variants["all_only_duplicated_diagnostic"]["AD_ACD_rank"]) == 6

enrichment = {r["feature"]: r for r in rows(OUT / "top_decile_driver_enrichment.tsv")}
assert float(enrichment["stress_damage_view"]["odds_ratio"]) > 10
assert float(enrichment["stress_damage_view"]["fisher_one_sided_p"]) < 1e-20
assert float(enrichment["shared_AD_ACD_significant_same_direction"]["fisher_one_sided_p"]) < 0.01

figure = OUT / "figures/top_AD_ACD_pathway_drivers.png"
assert figure.stat().st_size > 20_000
report = (ROOT / "AD_ACD_MECHANISM_REPORT.md").read_text()
for phrase in ("DNA 损伤", "1,000/1,000", "OR=17.91", "非重叠分区"):
    assert phrase in report

print("PASS: AD–ACD pathway mechanism, deletion stability, overlap audit, figure, and report are consistent")
