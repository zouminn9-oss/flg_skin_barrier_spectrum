#!/usr/bin/env python3
"""Validate drug-target ranking calculations and evidence boundaries."""

from pathlib import Path
import json
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "results/exploratory_snf/selected_positive_reml_z_q05/optimized_AD_ACD_branch/mechanism/drug_target_ranking"
for name in [
    "drug_target_ranking.tsv", "direct_TF_target_ranking.tsv",
    "core_mechanism_target_ranking.tsv", "independent_bulk_confirmation_summary.tsv",
    "SCORING_RULES.json",
]:
    path = OUT / name
    assert path.exists() and path.stat().st_size > 0, path

ranking = pd.read_csv(OUT / "drug_target_ranking.tsv", sep="\t")
tf = pd.read_csv(OUT / "direct_TF_target_ranking.tsv", sep="\t")
mechanism = pd.read_csv(OUT / "core_mechanism_target_ranking.tsv", sep="\t")
summary = pd.read_csv(OUT / "independent_bulk_confirmation_summary.tsv", sep="\t").iloc[0]
rules = json.loads((OUT / "SCORING_RULES.json").read_text())

assert len(ranking) == 8 and len(tf) == 5 and len(mechanism) == 3
assert set(tf["target"]) == {"YY1", "IRF1", "E2F6", "E2F4", "HSF1"}
assert set(mechanism["target"]) == {"ATR", "PCNA", "CDK2"}
assert ranking["overall_rank"].tolist() == list(range(1, 9))
components = [
    "independent_bulk_score_0_20", "local_program_score_0_15",
    "development_stage_score_0_20", "specificity_score_0_10",
    "skin_relevance_score_0_10", "direction_safety_score_0_10",
]
assert np.allclose(ranking[components].sum(axis=1), ranking["total_score_0_85"])
assert ranking["total_score_0_85"].is_monotonic_decreasing
assert int(summary["independent_bulk_confirmed_q_lt_0_05"]) == 0
assert set(summary["direction_supported_not_significant"].split(";")) == {"IRF1", "E2F6", "HSF1"}
assert set(summary["direction_mismatch"].split(";")) == {"YY1", "E2F4"}
assert mechanism["recommendation"].eq("mechanism_probe_only_not_therapy").all()
assert ranking["source_url"].str.startswith("https://").all()
assert ranking["as_of_date"].eq("2026-08-25").all()
assert len(rules) == 6

print("PASS: ranking scores sum correctly; no independent bulk TF is mislabeled confirmed.")

