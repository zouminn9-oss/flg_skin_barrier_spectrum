#!/usr/bin/env python3
"""Prepare the locked disease signatures and Sci-Plex condition matrix.

This post-hoc exploratory script performs no drug scoring. It verifies the raw
snapshot, parses all condition labels, filters the matrix only by prespecified
gene universes, and retains the excluded CMap resource QC result.
"""

from pathlib import Path
import gzip
import hashlib
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
LOCAL_PACKAGES = ROOT / "environment/python_packages"
if LOCAL_PACKAGES.exists():
    sys.path.insert(0, str(LOCAL_PACKAGES))

import numpy as np
import pandas as pd


MECH = ROOT / "results/exploratory_snf/selected_positive_reml_z_q05/optimized_AD_ACD_branch/mechanism"
RAW = ROOT / "data/raw/perturbations/sciplex_perturbseqr"
OUT = MECH / "drug_signature_reversal"
OUT.mkdir(parents=True, exist_ok=True)

EXPECTED = {
    "sciplex-full.txt.gz": "bde6c2e27a6505137f64d10f41eaf8d92354be86a920de0eb80d4ab9e76d0a19",
    "sciplex-cell_line_metadata.parquet": "80cd7467b1363ebf93c440e7f7fb5bbe7276c1dc8042d05f70e9c6d1e9de06c3",
    "sciplex-drug_metadata.parquet": "de46525a4fec469751f5b68e3eacb000e82a5a7691b70867f17abd70dd974f06",
}
COHORTS = [
    "AD_GSE121212_acute", "AD_GSE32924", "AD_GSE36842_acute",
    "ACD_GSE282562", "ACD_GSE6281_48h",
]
COND_RE = re.compile(r"^(A549|K562|MCF7)_(.*)_([^_]+)_([^_]+)$")


def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def read_stat(path, gene_col, stat_col, output_col):
    frame = pd.read_csv(path, sep="\t", usecols=[gene_col, stat_col])
    frame = frame.rename(columns={gene_col: "gene", stat_col: output_col})
    frame["gene"] = frame["gene"].astype(str)
    frame = frame.groupby("gene", as_index=False)[output_col].mean()
    return frame


# Byte-level input verification.
manifest_rows = []
for name, expected in EXPECTED.items():
    path = RAW / name
    assert path.exists() and path.stat().st_size > 0, path
    observed = sha256(path)
    assert observed == expected, (name, observed, expected)
    manifest_rows.append({"file": name, "bytes": path.stat().st_size, "sha256": observed, "verified": True})
pd.DataFrame(manifest_rows).to_csv(OUT / "raw_file_integrity.tsv", sep="\t", index=False)

# Locked disease statistics.
apc_raw = pd.read_csv(
    ROOT / "results/tables/single_cell_validation/GSE267929_APC_gene_effects.tsv", sep="\t"
)
apc = pd.DataFrame({
    "gene": apc_raw["gene_symbol"].astype(str),
    "apc_logFC": apc_raw["logFC"],
    "apc_signed_stat": np.sign(apc_raw["logFC"]) * np.sqrt(apc_raw["F"].clip(lower=0)),
})
apc = apc.groupby("gene", as_index=False).mean(numeric_only=True)

external = read_stat(
    ROOT / "results/tables/direct_comparison/E-MTAB-9501_ACD_vs_ICD_gene_effects.tsv",
    "gene_symbol", "t", "external_t",
)
disease = apc.merge(external, on="gene", how="outer")

for cohort in COHORTS:
    one = read_stat(ROOT / f"results/tables/cohort_effects/{cohort}.tsv", "gene", "t", f"t__{cohort}")
    disease = disease.merge(one, on="gene", how="outer")

membership = pd.read_csv(MECH / "core_genes/top20_pathway_gene_membership.tsv", sep="\t")
support = membership.groupby("gene", as_index=False)["pathway_support_influence"].sum()
support = support.rename(columns={"gene": "gene", "pathway_support_influence": "program_support_raw"})
support["gene"] = support["gene"].astype(str)
disease = disease.merge(support, on="gene", how="outer")
disease["program_support_raw"] = disease["program_support_raw"].fillna(0.0)
measured_program = disease["apc_signed_stat"].notna() & disease["program_support_raw"].gt(0)
disease["program_weight"] = 0.0
disease.loc[measured_program, "program_weight"] = (
    disease.loc[measured_program, "program_support_raw"]
    / disease.loc[measured_program, "program_support_raw"].sum()
)

tier1 = set(pd.read_csv(MECH / "core_genes/tier1_core_genes.tsv", sep="\t")["gene"].astype(str))
disease["tier1_core"] = disease["gene"].isin(tier1)

# Prespecified Reactome v97 toxicity-control universes.
tox_sets = {"cell_death": set(), "translation_ribosome": set(), "cellcycle_replication": set()}
with (ROOT / "data/raw/pathways/reactome_v97/ReactomePathways.gmt").open() as handle:
    for line in handle:
        fields = line.rstrip("\n").split("\t")
        name, genes = fields[0], set(fields[2:])
        lower = name.lower()
        if re.search(r"apoptosis|programmed cell death", lower):
            tox_sets["cell_death"].update(genes)
        if re.search(r"translation|ribosom", lower):
            tox_sets["translation_ribosome"].update(genes)
        if re.search(r"cell cycle|mitotic|g1/s|s phase|dna replication|dna strand elongation|synthesis of dna", lower):
            tox_sets["cellcycle_replication"].update(genes)
for name, genes in tox_sets.items():
    disease[f"tox_{name}"] = disease["gene"].isin(genes)
disease["tox_any"] = disease[[f"tox_{x}" for x in tox_sets]].any(axis=1)

# Condition metadata is parsed from the full source labels, then joined to the
# provider's drug and cell-line annotations without changing compound identity.
with gzip.open(RAW / "sciplex-full.txt.gz", "rt") as handle:
    header = handle.readline().rstrip("\n").split("\t")
assert header[0] == "Gene"
condition_ids = header[1:]
assert len(condition_ids) == len(set(condition_ids)) == 2302
condition_rows = []
for condition_id in condition_ids:
    match = COND_RE.match(condition_id)
    assert match is not None, condition_id
    cell, drug, dose, time = match.groups()
    condition_rows.append({
        "condition_id": condition_id, "cell_line": cell, "compound": drug,
        "compound_normalized": " ".join(drug.lower().split()), "dose": dose, "time": time,
    })
conditions = pd.DataFrame(condition_rows)

drug_meta = pd.read_parquet(RAW / "sciplex-drug_metadata.parquet")
conditions = conditions.merge(
    drug_meta, left_on="compound", right_on="sciplex_drug_name", how="left", validate="many_to_one"
)
cell_meta = pd.read_parquet(RAW / "sciplex-cell_line_metadata.parquet")
conditions = conditions.merge(cell_meta, left_on="cell_line", right_on="cell_name", how="left", validate="many_to_one")
assert conditions["sciplex_drug_name"].notna().all()
assert conditions["cell_name"].notna().all()
conditions.to_csv(OUT / "condition_metadata.tsv", sep="\t", index=False)

# Only prespecified disease/toxicity genes are materialized; every condition is
# retained and selection never sees a reversal score.
needed = set(disease.loc[
    disease["apc_signed_stat"].notna()
    | disease["external_t"].notna()
    | disease[[f"t__{x}" for x in COHORTS]].notna().any(axis=1)
    | disease["program_support_raw"].gt(0)
    | disease["tox_any"],
    "gene",
].astype(str))

matrix_genes, matrix_rows = [], []
source_gene_count = 0
with gzip.open(RAW / "sciplex-full.txt.gz", "rt") as handle:
    next(handle)
    for line in handle:
        source_gene_count += 1
        gene, values = line.rstrip("\n").split("\t", 1)
        if gene not in needed:
            continue
        # Empty fields are genuine missing coefficients. np.fromstring drops
        # them and shifts later columns, so preserve their exact positions.
        tokens = values.split("\t")
        row = np.fromiter(
            (float(value) if value else np.nan for value in tokens),
            dtype=np.float32,
            count=len(tokens),
        )
        assert row.size == len(condition_ids), (gene, row.size)
        matrix_genes.append(gene)
        matrix_rows.append(row)
assert source_gene_count == 18124
assert len(matrix_genes) == len(set(matrix_genes)), "duplicate source gene symbols require explicit collapse"
effects = np.vstack(matrix_rows).astype(np.float32, copy=False)
np.savez_compressed(
    OUT / "prepared_sciplex_effects.npz",
    genes=np.asarray(matrix_genes), condition_ids=np.asarray(condition_ids), effects=effects,
)

source_genes = set(matrix_genes)
disease["in_prepared_matrix"] = disease["gene"].isin(source_genes)
disease = disease.sort_values("gene").reset_index(drop=True)
disease.to_csv(OUT / "locked_disease_signatures.tsv", sep="\t", index=False)

qc = pd.DataFrame([{
    "analysis_resource": "Sci-Plex_Perturb-Seqr_full_CD",
    "source_genes": source_gene_count,
    "prepared_genes": len(matrix_genes),
    "conditions": len(condition_ids),
    "compounds": conditions["compound"].nunique(),
    "cell_lines": conditions["cell_line"].nunique(),
    "doses": conditions["dose"].nunique(),
    "times": conditions["time"].nunique(),
    "APC_genes": int(disease["apc_signed_stat"].notna().sum()),
    "APC_overlap": int((disease["apc_signed_stat"].notna() & disease["in_prepared_matrix"]).sum()),
    "locked_program_genes_APC_measured": int(measured_program.sum()),
    "locked_program_overlap": int((measured_program & disease["in_prepared_matrix"]).sum()),
    "tier1_overlap": int((disease["tier1_core"] & disease["in_prepared_matrix"]).sum()),
    "all_condition_labels_parse": True,
    "excluded_CMap_reason": "drug_cell_aggregated_no_dose_time_batch",
    "posthoc_status": "exploratory_computational",
}])
qc.to_csv(OUT / "resource_qc_summary.tsv", sep="\t", index=False)
print(qc.to_string(index=False))
