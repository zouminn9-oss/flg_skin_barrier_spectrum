#!/usr/bin/env python3
"""Fetch primary metadata only and write an auditable SHA-256 manifest."""

import csv
import datetime as dt
import hashlib
import json
import pathlib
import shutil
import time
import urllib.request


ROOT = pathlib.Path(__file__).resolve().parents[1]
CONFIG = ROOT / "config" / "datasets.tsv"
RAW = ROOT / "data" / "raw"
MANIFEST = ROOT / "records" / "metadata_download_manifest.tsv"


def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def download(url, destination):
    destination.parent.mkdir(parents=True, exist_ok=True)
    if not destination.exists() or destination.stat().st_size == 0:
        temporary = destination.with_suffix(destination.suffix + ".part")
        last_error = None
        for attempt in range(1, 6):
            request = urllib.request.Request(url, headers={"User-Agent": "flg-gate3-metadata-audit/1.0"})
            try:
                with urllib.request.urlopen(request, timeout=180) as response, temporary.open("wb") as output:
                    shutil.copyfileobj(response, output)
                temporary.replace(destination)
                last_error = None
                break
            except Exception as error:
                last_error = error
                if temporary.exists():
                    temporary.unlink()
                if attempt < 5:
                    time.sleep(2 ** (attempt - 1))
        if last_error is not None:
            raise last_error
    return {
        "url": url,
        "path": str(destination.relative_to(ROOT)),
        "bytes": destination.stat().st_size,
        "sha256": sha256(destination),
        "downloaded_utc": dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat(),
    }


def geo_prefix(accession):
    return accession[:-3] + "nnn"


def collect_files(node):
    found = []
    if isinstance(node, dict):
        if node.get("type") == "file" and node.get("path"):
            found.append(node["path"])
        for value in node.values():
            found.extend(collect_files(value))
    elif isinstance(node, list):
        for value in node:
            found.extend(collect_files(value))
    return found


def biostudies_fire_path(accession, filename):
    number = accession.rsplit("-", 1)[1]
    shard = number[-3:].lstrip("0") or "0"
    return f"https://ftp.ebi.ac.uk/biostudies/fire/E-MTAB-/{shard}/{accession}/Files/{filename}"


def main():
    rows = []
    with CONFIG.open(newline="") as handle:
        datasets = list(csv.DictReader(handle, delimiter="\t"))

    for dataset in datasets:
        accession = dataset["accession"]
        source = dataset["source"]
        if source == "GEO":
            base = f"https://ftp.ncbi.nlm.nih.gov/geo/series/{geo_prefix(accession)}/{accession}"
            targets = [
                (f"{base}/soft/{accession}_family.soft.gz", RAW / "geo" / accession / f"{accession}_family.soft.gz"),
                (f"{base}/matrix/", RAW / "geo" / accession / "matrix_index.html"),
                (f"{base}/suppl/", RAW / "geo" / accession / "supplementary_index.html"),
            ]
            for url, path in targets:
                rows.append(download(url, path))
        else:
            api_url = f"https://www.ebi.ac.uk/biostudies/api/v1/studies/{accession}"
            api_path = RAW / "arrayexpress" / accession / f"{accession}_api.json"
            record = download(api_url, api_path)
            rows.append(record)
            study = json.loads(api_path.read_text())
            for filename in sorted(set(collect_files(study))):
                if filename.lower().endswith((".idf.txt", ".sdrf.txt", ".adf.txt")):
                    url = biostudies_fire_path(accession, filename)
                    rows.append(download(url, RAW / "arrayexpress" / accession / filename))

    MANIFEST.parent.mkdir(parents=True, exist_ok=True)
    with MANIFEST.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, delimiter="\t", fieldnames=["url", "path", "bytes", "sha256", "downloaded_utc"])
        writer.writeheader()
        writer.writerows(rows)
    print(f"METADATA_FETCH_OK files={len(rows)} manifest={MANIFEST}")


if __name__ == "__main__":
    main()
