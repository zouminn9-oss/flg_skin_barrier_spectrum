#!/usr/bin/env python3
"""Validate the JNJ-7706621 candidate-specific computational audit."""

from pathlib import Path
import json
import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
MECH = ROOT / "results/exploratory_snf/selected_positive_reml_z_q05/optimized_AD_ACD_branch/mechanism"
LINCS = MECH / "lincs_cross_resource_replication"
OUT = MECH / "jnj7706621_candidate_audit"

protocol = (ROOT / "JNJ7706621_CANDIDATE_AUDIT_PROTOCOL.md").read_text()
assert "before inspecting JNJ-7706621 stratum-level reversal scores" in protocol
assert "Single factor" in protocol and "GPU hours 0" in protocol

condition = pd.read_csv(LINCS / "condition_level_lincs_reversal.tsv", sep="\t")
jnj = condition.loc[condition["target_key"].eq("JNJ-7706621")]
assert len(jnj) == 297 and jnj["cell_line"].nunique() == 98
assert jnj["dose"].nunique() == 3 and jnj["time"].nunique() == 3 and jnj["tissue"].nunique() == 23

strata = pd.read_csv(OUT / "context_stratum_summary.tsv", sep="\t")
assert len(strata) == 32
assert strata.groupby("dimension").size().to_dict() == {
    "dose": 3, "overall": 1, "skin_context": 2, "time": 3, "tissue": 23,
}
overall = strata.loc[strata["dimension"].eq("overall")].iloc[0]
assert overall["n_conditions"] == 297 and overall["n_cell_lines"] == 98
assert np.isclose(overall["median_composite"], jnj["apc_composite_reversal"].median())
assert np.isclose(overall["median_composite"], 0.0177586709707972)
assert overall["cluster_bootstrap_ci_low"] > 0

skin = strata.loc[(strata["dimension"] == "skin_context") & (strata["level"] == "skin")].iloc[0]
assert skin["n_conditions"] == 16 and skin["n_cell_lines"] == 5
assert np.isclose(skin["median_composite"], 0.043657254633468)
assert skin["cluster_bootstrap_ci_low"] > 0
skin_conditions = pd.read_csv(OUT / "skin_condition_scores.tsv", sep="\t")
assert len(skin_conditions) == 16
assert set(skin_conditions["cell_line"]) == {"A375", "IGR37", "MELHO", "SH4", "SKMEL3"}

dose = strata.loc[strata["dimension"].eq("dose")]
time = strata.loc[strata["dimension"].eq("time")]
assert dose["median_composite"].gt(0).all() and time["median_composite"].gt(0).all()
assert strata.loc[(strata["dimension"] == "dose") & (strata["level"] == "10 uM"), "median_tox_removed_composite"].iloc[0] < 0
assert strata.loc[(strata["dimension"] == "time") & (strata["level"] == "6 h"), "median_tox_removed_composite"].iloc[0] < 0
assert strata.loc[(strata["dimension"] == "time") & (strata["level"] == "48 h"), "median_external_composite"].iloc[0] < 0
negative_tissues = set(strata.loc[strata["dimension"].eq("tissue") & strata["median_composite"].le(0), "level"])
assert negative_tissues == {"blastocyst", "central nervous system", "colon", "connective tissue", "endometrium", "pancreas", "stomach"}

deletions = pd.read_csv(OUT / "leave_one_context_robustness.tsv", sep="\t")
assert len(deletions) == 29 and deletions["remaining_median_composite"].gt(0).all()
assert np.isclose(deletions.groupby("dimension")["remaining_median_composite"].min()["tissue"], 0.0164797349385635)

dose_trends = pd.read_csv(OUT / "matched_dose_trends.tsv", sep="\t")
time_trends = pd.read_csv(OUT / "matched_time_trends.tsv", sep="\t")
assert len(dose_trends) == 91 and len(time_trends) == 12
assert np.isclose(dose_trends["spearman_dose_composite"].median(), 0.5)
assert np.isclose(time_trends["spearman_time_composite"].median(), 0.5)

comparisons = pd.read_csv(OUT / "matched_cdk2_token_comparison.tsv", sep="\t")
assert len(comparisons) == 5
assert comparisons["median_paired_difference_jnj_minus_comparator"].gt(0).all()
assert comparisons["paired_wilcoxon_BH_q"].lt(0.05).sum() == 3
assert set(comparisons.loc[comparisons["paired_wilcoxon_BH_q"].lt(0.05), "comparator"]) == {
    "Bosutinib", "PF-573228", "Roscovitine",
}
ranking = pd.read_csv(OUT / "cdk2_token_class_ranking.tsv", sep="\t")
assert len(ranking) == 6 and ranking.iloc[0]["target_key"] == "JNJ-7706621"

pharmacology = pd.read_csv(OUT / "pharmacology_evidence_matrix.tsv", sep="\t")
assert len(pharmacology) == 3
assert pharmacology["supported_claim"].str.contains("identity|CDK|G1", regex=True).all()

disposition = json.loads((OUT / "CANDIDATE_DISPOSITION.json").read_text())
assert disposition["candidate"] == "JNJ-7706621"
assert disposition["transportability"] == "broad_transportable"
assert disposition["class_leading_descriptive"] is True
assert disposition["class_leading_inferential"] is True
assert disposition["cdk2_specificity_supported"] is False
assert len(disposition["negative_tissue_median_levels"]) == 7
assert disposition["nonpositive_tox_removed_primary_levels"] == ["dose=10 uM", "time=6 h"]
assert disposition["nonpositive_external_primary_levels"] == ["time=48 h"]
assert disposition["formal_replication"] is False and disposition["clinical_evidence"] is False

original = pd.read_csv(LINCS / "all_target_classification.tsv", sep="\t")
row = original.loc[original["target_key"].eq("JNJ-7706621")].iloc[0]
assert row["cross_resource_classification"] == "direction_only"
assert np.isclose(row["targeted_BH_q"], 0.4145854145854146)

report = (ROOT / "AD_ACD_JNJ7706621_CANDIDATE_AUDIT_REPORT.md").read_text()
for phrase in [
    "broad_transportable", "class_leading_inferential", "seven of 23",
    "10 µM", "6 h", "48 h", "melanoma", "multi-CDK/Aurora", "not formally replicated",
]:
    assert phrase.lower() in report.lower(), phrase

summary = {
    "validation": "PASS", "candidate": "JNJ-7706621", "conditions": len(jnj),
    "cell_lines": jnj["cell_line"].nunique(), "skin_conditions": len(skin_conditions),
    "transportability": disposition["transportability"],
    "class_leading_inferential": disposition["class_leading_inferential"],
    "cdk2_specificity_supported": False, "formal_replication": False,
}
(OUT / "VALIDATION_SUMMARY.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps(summary, indent=2))
