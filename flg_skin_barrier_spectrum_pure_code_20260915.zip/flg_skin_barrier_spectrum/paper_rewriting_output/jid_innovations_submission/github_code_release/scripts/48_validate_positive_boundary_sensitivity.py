#!/usr/bin/env python3
"""Validate the post-hoc positive-boundary grid and selected candidate."""

from pathlib import Path
import json
import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
MECH = ROOT / "results/exploratory_snf/selected_positive_reml_z_q05/optimized_AD_ACD_branch/mechanism"
OUT = MECH / "positive_boundary_sensitivity"

protocol = (ROOT / "LINCS_POSITIVE_BOUNDARY_SENSITIVITY_PROTOCOL.md").read_text()
assert "after** the negative Sci-Plex and targeted" in protocol.replace("\n", " ")
assert "cannot relabel" in protocol and "Only the statistical-evidence rule is varied" in protocol

resource = pd.read_csv(OUT / "resource_level_boundary_gates.tsv", sep="\t")
assert len(resource) == 20
assert resource.groupby("resource")["target_key"].nunique().to_dict() == {"LINCS": 10, "Sci-Plex": 10}
recomputed_structural = (
    resource["all_four_positive"] & resource["stable"] & resource["external_positive"]
    & ~resource["toxicity_dominated"]
)
assert (recomputed_structural == resource["structural_pass"]).all()
assert (resource["original_full_pass"] == (resource["structural_pass"] & resource["bh_q"].lt(0.05))).all()
assert (resource["nominal_p05_pass"] == (resource["structural_pass"] & resource["empirical_p"].lt(0.05))).all()
assert resource["original_full_pass"].sum() == 0
assert set(resource.loc[resource["nominal_p05_pass"], "target_key"]) == {"Andarine", "JNJ-7706621"}

grid = pd.read_csv(OUT / "complete_threshold_grid.tsv", sep="\t")
assert len(grid) == 22
assert set(grid["resource"]) == {"Sci-Plex", "LINCS"}
assert set(grid["evidence_mode"]) == {"BH_q", "nominal_p"}
for row in grid.itertuples(index=False):
    group = resource.loc[resource["resource"].eq(row.resource)]
    column = "bh_q" if row.evidence_mode == "BH_q" else "empirical_p"
    positive = group["structural_pass"] & group[column].lt(row.threshold)
    observed_targets = "" if pd.isna(row.positive_target_keys) else row.positive_target_keys
    assert int(positive.sum()) == row.positive_compounds
    assert ";".join(sorted(group.loc[positive, "target_key"])) == observed_targets
    assert row.fdr_control_claimed == (row.evidence_mode == "BH_q")

cross = pd.read_csv(OUT / "cross_resource_balanced_sensitivity.tsv", sep="\t")
assert len(cross) == 10 and cross["target_key"].is_unique
for row in cross.itertuples(index=False):
    balanced = bool(
        row.both_resource_composites_positive and row.both_external_directions_positive
        and row.neither_resource_toxicity_dominated and row.robust_nominal_resources >= 1
    )
    assert balanced == row.balanced_posthoc_nominal_candidate
assert cross["balanced_posthoc_nominal_candidate"].sum() == 1
selected_row = cross.loc[cross["balanced_posthoc_nominal_candidate"]].iloc[0]
assert selected_row["target_key"] == "JNJ-7706621"
assert np.isclose(selected_row["lincs_empirical_p"], 0.0469530469530469)
assert np.isclose(selected_row["lincs_targeted_bh_q"], 0.4145854145854146)
assert selected_row["sciplex_composite"] > 0 and selected_row["lincs_composite"] > 0

selection = json.loads((OUT / "SELECTED_EXPLORATORY_POSITIVE.json").read_text())
assert selection["selected_target"] == "JNJ-7706621"
assert selection["selected_label"] == "balanced_posthoc_nominal_candidate"
assert selection["multiplicity_control"] == "none_for_nominal_positive_label"
assert selection["original_replication_status"] == "not_replicated"
assert selection["clinical_evidence"] is False and selection["gate3_changed"] is False

# Confirm the source result files retain the original negative labels.
original = pd.read_csv(MECH / "lincs_cross_resource_replication/all_target_classification.tsv", sep="\t")
jnj = original.loc[original["target_key"].eq("JNJ-7706621")].iloc[0]
assert jnj["cross_resource_classification"] == "direction_only"
assert not (original["cross_resource_classification"] == "replicated").any()

report = (ROOT / "AD_ACD_POSITIVE_BOUNDARY_SENSITIVITY_REPORT.md").read_text()
for phrase in [
    "JNJ-7706621", "post hoc", "nominal", "not replicated", "Andarine",
    "0.4146", "0.5259", "Gate 3", "not clinical",
]:
    assert phrase.lower() in report.lower(), phrase

summary = {
    "validation": "PASS", "resource_rows": len(resource), "grid_cells": len(grid),
    "balanced_positive_candidates": ["JNJ-7706621"],
    "original_replicated_compounds": 0, "original_gate3_changed": False,
}
(OUT / "VALIDATION_SUMMARY.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps(summary, indent=2))
