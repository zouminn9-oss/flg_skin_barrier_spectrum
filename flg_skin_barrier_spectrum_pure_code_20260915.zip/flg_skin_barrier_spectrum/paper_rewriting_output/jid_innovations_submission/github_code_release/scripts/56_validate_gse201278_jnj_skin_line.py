#!/usr/bin/env python3
"""Independent validation for the frozen GSE201278 JNJ skin-line analysis."""

from pathlib import Path
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
LOCAL_PACKAGES = ROOT / "environment/python_packages"
if LOCAL_PACKAGES.exists():
    sys.path.insert(0, str(LOCAL_PACKAGES))

import numpy as np
import pandas as pd
from scipy.stats import spearmanr

RAW = ROOT / "data/raw/perturbations/GSE201278"
MECH = ROOT / "results/exploratory_snf/selected_positive_reml_z_q05/optimized_AD_ACD_branch/mechanism"
OUT = MECH / "gse201278_jnj_skin_line_validation"
PROTOCOL = ROOT / "GSE201278_JNJ_SKIN_LINE_VALIDATION_PROTOCOL.md"
DISEASE = MECH / "drug_signature_reversal/locked_disease_signatures.tsv"
FROZEN_GENES = MECH / "lincs_full_background_calibration/gctx_row_identifiers.tsv"

checks = []


def check(name, condition, detail=""):
    if not bool(condition):
        raise AssertionError(f"{name}: {detail}")
    checks.append(name)


def sha256(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def weighted_corr(y, x, weights):
    y, x, w = map(lambda v: np.asarray(v, dtype=float), (y, x, weights))
    w = w / w.sum()
    xc, yc = x - w @ x, y - w @ y
    denom = np.sqrt((w @ (xc * xc)) * (w @ (yc * yc)))
    return float(-(w @ (xc * yc)) / denom)


protocol = PROTOCOL.read_text()
source = json.loads((OUT / "SOURCE_AND_SCHEMA_QC.json").read_text())
disposition = json.loads((OUT / "GSE201278_JNJ_DISPOSITION.json").read_text())
permutation = json.loads((OUT / "GENE_LABEL_PERMUTATION_SUMMARY.json").read_text())
score = pd.read_csv(OUT / "frozen_score_panel.tsv", sep="\t").iloc[0]
sensitivity = pd.read_csv(OUT / "transformation_sensitivity.tsv", sep="\t")
pairwise = pd.read_csv(OUT / "processed_column_pairwise_audit.tsv", sep="\t")
contrast = pd.read_csv(OUT / "gene_level_jnj_contrast.tsv", sep="\t").set_index("gene")
permuted = np.load(OUT / "gene_label_permuted_composites.npy")

check("protocol frozen before values", "before expression values or reversal scores were inspected" in protocol)
check(
    "protocol records metadata ambiguity",
    "cannot be counted" in protocol and "independent biological libraries" in protocol,
)
check("protocol forbids formal replication", "cannot establish formal replication" in protocol)
check("protocol preserves Gate 3", "Gate 3" in protocol and "formal replication=false" in protocol)
check("FPKM byte count", (RAW / "GSE201278_fpkm.txt.gz").stat().st_size == 1_383_358)
check("FPKM hash", sha256(RAW / "GSE201278_fpkm.txt.gz") == source["fpkm_sha256"])
check("series hash", sha256(RAW / "GSE201278_series.soft.txt") == source["series_soft_sha256"])
check("samples hash", sha256(RAW / "GSE201278_samples.soft.txt") == source["samples_soft_sha256"])
check("registered samples", source["registered_geo_samples"] == 2)
check("registered runs", source["registered_sra_runs"] == ["SRR18885475", "SRR18885476"])
check("one registered run per arm", source["registered_runs_per_arm"] == 1)
check("two processed columns per arm", source["processed_columns_per_arm"] == 2)
check("no processed-to-raw mapping", not source["processed_column_to_raw_run_mapping_available"])
check("metadata ambiguity high", source["metadata_ambiguity_severity"] == "high")
check("no missing expression", source["missing_expression_values"] == 0)
check("no negative expression", source["negative_expression_values"] == 0)
check("within-arm correlations finite", np.isfinite([source["ctrl_column_spearman"], source["jnj_column_spearman"]]).all())
check("APC coverage exact", disposition["apc_genes"] == 3735)
check("program coverage exact", disposition["apc_program_genes"] == 214)
check("external coverage high", disposition["external_genes"] >= 11800)

four = [
    "apc_genome_rank_reversal", "apc_genome_weighted_reversal",
    "apc_program_rank_reversal", "apc_program_weighted_reversal",
]
check("score columns finite", np.isfinite(score[[*four, "apc_composite_reversal"]].astype(float)).all())
check("composite arithmetic", np.isclose(score["apc_composite_reversal"], score[four].astype(float).mean()))
check("score/disposition agreement", all(np.isclose(score[key], disposition[key]) for key in [*four, "apc_composite_reversal"]))

# Independently recompute the four primary scores from the saved contrast.
disease = pd.read_csv(DISEASE, sep="\t").set_index("gene")
frozen = set(pd.read_csv(FROZEN_GENES, sep="\t")["gene"].astype(str))
disease = disease.loc[disease.index.astype(str).isin(frozen)]
aligned = disease.join(contrast[["jnj_minus_dmso_log2_fpkm_plus_1"]].rename(
    columns={"jnj_minus_dmso_log2_fpkm_plus_1": "effect"}), how="inner")
base = aligned[aligned["apc_signed_stat"].notna()].copy()
x, y = base["apc_signed_stat"].to_numpy(float), base["effect"].to_numpy(float)
w = np.minimum(np.abs(x), np.quantile(np.abs(x), 0.95))
program_mask = base["program_weight"].gt(0).to_numpy()
pw = base["program_weight"].to_numpy(float)
recomputed = {
    "apc_genome_rank_reversal": -spearmanr(y, x).statistic,
    "apc_genome_weighted_reversal": weighted_corr(y, x, w),
    "apc_program_rank_reversal": -spearmanr(y[program_mask], x[program_mask]).statistic,
    "apc_program_weighted_reversal": weighted_corr(y[program_mask], x[program_mask], pw[program_mask]),
}
check("independent score recomputation", all(np.isclose(recomputed[key], disposition[key]) for key in four))
check("two genome scores positive", disposition["apc_genome_rank_reversal"] > 0 and disposition["apc_genome_weighted_reversal"] > 0)
check("two program scores negative", disposition["apc_program_rank_reversal"] < 0 and disposition["apc_program_weighted_reversal"] < 0)
check("primary composite negative", disposition["apc_composite_reversal"] < 0)
check("external composite positive", disposition["external_composite_reversal"] > 0)
check("not toxicity dominated", not disposition["toxicity_dominated"])

check("four transform sensitivities", len(sensitivity) == 4 and sensitivity["analysis"].nunique() == 4)
check("transform flag exact", disposition["all_transform_sensitivities_positive"] == bool(sensitivity["apc_composite_reversal"].gt(0).all()))
check("four processed-column comparisons", len(pairwise) == 4)
check("pairwise combinations unique", pairwise[["control_column", "jnj_column"]].drop_duplicates().shape[0] == 4)
check("pairwise flag exact", disposition["all_processed_column_pairwise_composites_positive"] == bool(pairwise["apc_composite_reversal"].gt(0).all()))
check("10k permutations", len(permuted) == 10_000 and permutation["permutations"] == 10_000)
expected_fraction = (1 + int(np.sum(permuted >= disposition["apc_composite_reversal"]))) / 10_001
check("alignment fraction exact", np.isclose(expected_fraction, disposition["gene_label_alignment_fraction"]))
check("alignment is not treatment P", not permutation["quantity_is_treatment_effect_p"] and not disposition["gene_label_alignment_fraction_is_treatment_effect_p"])
check("alignment is not FDR", not permutation["quantity_is_fdr"])

if disposition["apc_composite_reversal"] <= 0:
    expected_label = "independent_skin_line_not_supported"
elif (
    disposition["all_four_primary_positive"]
    and disposition["external_composite_reversal"] > 0
    and not disposition["toxicity_dominated"]
    and disposition["all_transform_sensitivities_positive"]
    and disposition["all_processed_column_pairwise_composites_positive"]
    and disposition["gene_label_alignment_fraction"] < 0.05
):
    expected_label = "independent_skin_line_direction_supported"
else:
    expected_label = "independent_skin_line_directional_but_fragile"
check("frozen label exact", disposition["frozen_label"] == expected_label)
check("full-background label preserved", disposition["full_background_label_frozen"] == "positive_not_top5")
check("targeted q preserved", np.isclose(disposition["targeted_lincs_q_frozen"], 0.4145854145854145))
check("processed columns not promoted", not disposition["processed_columns_counted_as_independent_replicates"])
check("normal keratinocyte evidence false", not disposition["normal_keratinocyte_evidence"])
check("CDK2 specificity false", not disposition["cdk2_specificity_supported"])
check("formal replication false", not disposition["formal_replication"])
check("clinical evidence false", not disposition["clinical_evidence"])
check("Gate 3 unchanged", not disposition["gate3_changed"])

summary = {"status": "pass", "checks_passed": len(checks), "checks": checks}
(OUT / "VALIDATION_SUMMARY.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps({"status": "pass", "checks_passed": len(checks)}, indent=2))
