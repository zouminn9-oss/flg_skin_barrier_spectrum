#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(limma)
  library(AnnotationDbi)
  library(org.Hs.eg.db)
})

root <- normalizePath(getwd())
sdrf_file <- file.path(root, "data/raw/arrayexpress/E-MTAB-9501/E-MTAB-9501.sdrf.txt")
raw_dir <- file.path(root, "data/interim/E-MTAB-9501_raw")
out_dir <- file.path(root, "results/tables/direct_comparison")
fig_dir <- file.path(root, "results/figures/qc")
proc_dir <- file.path(root, "data/processed/expression/E-MTAB-9501")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(fig_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(proc_dir, recursive = TRUE, showWarnings = FALSE)

sdrf <- read.delim(sdrf_file, check.names = FALSE, stringsAsFactors = FALSE)
sdrf <- sdrf[sdrf[["Characteristics[post analysis well quality]"]] == "good", ]
sdrf$array_file <- basename(sdrf[["Array Data File"]])
sdrf$sample_id <- sdrf[["Source Name"]]
sdrf$participant <- as.character(sdrf[["Characteristics[individual]"]])
sdrf$stimulus <- sdrf[["Characteristics[stimulus]"]]
sdrf$age <- as.numeric(sdrf[["Characteristics[age]"]])
sdrf$sex <- factor(sdrf[["Characteristics[sex]"]])
sdrf$dye <- factor(sdrf[["Label"]], levels = c("Cy3", "Cy5"))
sdrf$array_id <- factor(sdrf$array_file)

files <- sort(list.files(raw_dir, pattern = "^[^.].*\\.txt$", full.names = TRUE))
if (length(files) != 48L) stop("Expected 48 non-resource-fork Agilent files; found ", length(files))
rg <- read.maimages(files, source = "agilent", green.only = FALSE)
colnames(rg$G) <- basename(files)
colnames(rg$R) <- basename(files)

if (!all(sdrf$array_file %in% colnames(rg$G))) stop("SDRF/raw file mismatch")
expr <- vapply(seq_len(nrow(sdrf)), function(i) {
  f <- sdrf$array_file[i]
  if (sdrf$dye[i] == "Cy3") rg$G[, f] else rg$R[, f]
}, numeric(nrow(rg$G)))
colnames(expr) <- sdrf$sample_id
expr <- log2(pmax(expr, 1))
expr <- normalizeBetweenArrays(expr, method = "quantile")

genes <- rg$genes
keep_noncontrol <- genes$ControlType == 0
acc <- as.character(genes$SystematicName)
acc_clean <- sub("\\..*$", "", acc)
symbol <- rep(NA_character_, length(acc_clean))

ref_idx <- which(keep_noncontrol & grepl("^(NM_|NR_|XM_|XR_)", acc_clean))
ref_keys <- unique(acc_clean[ref_idx])
ref_map <- select(org.Hs.eg.db, keys = ref_keys, keytype = "REFSEQ", columns = "SYMBOL")
ref_map <- ref_map[!is.na(ref_map$SYMBOL), ]
ref_tab <- split(ref_map$SYMBOL, ref_map$REFSEQ)
ref_unambiguous <- vapply(ref_tab, function(z) {
  z <- unique(z)
  if (length(z) == 1L) z else NA_character_
}, character(1))
symbol[ref_idx] <- unname(ref_unambiguous[acc_clean[ref_idx]])

ens_idx <- which(keep_noncontrol & grepl("^ENST", acc_clean))
ens_keys <- unique(acc_clean[ens_idx])
ens_map <- select(org.Hs.eg.db, keys = ens_keys, keytype = "ENSEMBLTRANS", columns = "SYMBOL")
ens_map <- ens_map[!is.na(ens_map$SYMBOL), ]
ens_tab <- split(ens_map$SYMBOL, ens_map$ENSEMBLTRANS)
ens_unambiguous <- vapply(ens_tab, function(z) {
  z <- unique(z)
  if (length(z) == 1L) z else NA_character_
}, character(1))
symbol[ens_idx] <- unname(ens_unambiguous[acc_clean[ens_idx]])

mapped <- keep_noncontrol & !is.na(symbol) & nzchar(symbol)
expr <- expr[mapped, , drop = FALSE]
symbol <- symbol[mapped]
probe_iqr <- apply(expr, 1, IQR, na.rm = TRUE)
ord <- order(symbol, -probe_iqr)
expr <- expr[ord, , drop = FALSE]
symbol <- symbol[ord]
expr <- expr[!duplicated(symbol), , drop = FALSE]
rownames(expr) <- symbol[!duplicated(symbol)]

stimulus_group <- c(
  "PPD" = "ACD", "epoxy resin" = "ACD",
  "methylchloroisothiazolinone" = "ACD", "nickel" = "ACD",
  "nonanoic acid" = "ICD", "sodium lauryl sulfate" = "ICD",
  "baseline" = "BASELINE"
)
sdrf$group <- unname(stimulus_group[sdrf$stimulus])
if (anyNA(sdrf$group)) stop("Unclassified stimulus in SDRF")

saveRDS(list(expression = expr, metadata = sdrf), file.path(proc_dir, "normalized_gene_expression.rds"))
write.table(sdrf, file.path(proc_dir, "sample_metadata.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)

analysis_keep <- sdrf$group %in% c("ACD", "ICD")
meta <- droplevels(sdrf[analysis_keep, ])
y <- expr[, analysis_keep, drop = FALSE]
meta$group <- factor(meta$group, levels = c("ICD", "ACD"))
design <- model.matrix(~ group + scale(age) + sex + dye, data = meta)
corfit <- duplicateCorrelation(y, design, block = meta$array_id)
fit <- lmFit(y, design, block = meta$array_id, correlation = corfit$consensus)
fit <- eBayes(fit, trend = TRUE, robust = TRUE)
coef_name <- "groupACD"
tt <- topTable(fit, coef = coef_name, number = Inf, sort.by = "none")
tt$gene_symbol <- rownames(tt)
tt$contrast <- "ACD_minus_ICD"
tt$n_ACD <- sum(meta$group == "ACD")
tt$n_ICD <- sum(meta$group == "ICD")
tt$within_array_correlation <- corfit$consensus
tt <- tt[, c("gene_symbol", "contrast", "logFC", "AveExpr", "t", "P.Value", "adj.P.Val", "B",
             "n_ACD", "n_ICD", "within_array_correlation")]
write.table(tt, file.path(out_dir, "E-MTAB-9501_ACD_vs_ICD_gene_effects.tsv"),
            sep = "\t", quote = FALSE, row.names = FALSE)

read_gmt <- function(path) {
  x <- strsplit(readLines(path, warn = FALSE), "\t", fixed = TRUE)
  sets <- lapply(x, function(z) unique(z[-c(1, 2)]))
  names(sets) <- vapply(x, `[[`, character(1), 1)
  sets
}
gmt <- file.path(root, "data/raw/pathways/reactome_v97/ReactomePathways.gmt")
sets <- read_gmt(gmt)
idx <- lapply(sets, function(z) which(rownames(y) %in% z))
idx <- idx[vapply(idx, length, integer(1)) >= 10L & vapply(idx, length, integer(1)) <= 500L]
cam <- cameraPR(fit$t[, coef_name], index = idx, use.ranks = TRUE, inter.gene.cor = 0.01, sort = FALSE)
cam$pathway <- rownames(cam)
cam$contrast <- "E-MTAB-9501_ACD_minus_ICD"
cam$FDR <- p.adjust(cam$PValue, method = "BH")
cam <- cam[, c("pathway", "contrast", "NGenes", "Direction", "PValue", "FDR")]
cam <- cam[order(cam$PValue), ]
write.table(cam, file.path(out_dir, "E-MTAB-9501_ACD_vs_ICD_reactome.tsv"),
            sep = "\t", quote = FALSE, row.names = FALSE)

pca <- prcomp(t(expr[order(apply(expr, 1, IQR), decreasing = TRUE)[seq_len(min(1000, nrow(expr)))], ]), scale. = TRUE)
pc <- data.frame(PC1 = pca$x[, 1], PC2 = pca$x[, 2], group = sdrf$group, dye = sdrf$dye)
png(file.path(fig_dir, "E-MTAB-9501_pca.png"), width = 1200, height = 900, res = 150)
cols <- c(ACD = "#D55E00", ICD = "#0072B2", BASELINE = "#777777")
plot(pc$PC1, pc$PC2, col = cols[pc$group], pch = ifelse(pc$dye == "Cy3", 16, 1),
     xlab = "PC1", ylab = "PC2", main = "E-MTAB-9501: normalized gene expression")
legend("topright", legend = names(cols), col = cols, pch = 16, bty = "n")
dev.off()

summary <- data.frame(
  dataset = "E-MTAB-9501",
  raw_files = length(files),
  qc_pass_channels = nrow(sdrf),
  mapped_gene_symbols = nrow(expr),
  n_ACD = sum(meta$group == "ACD"),
  n_ICD = sum(meta$group == "ICD"),
  de_fdr_0_05 = sum(tt$adj.P.Val < 0.05, na.rm = TRUE),
  reactome_fdr_0_05 = sum(cam$FDR < 0.05, na.rm = TRUE),
  within_array_correlation = corfit$consensus
)
write.table(summary, file.path(out_dir, "E-MTAB-9501_direct_summary.tsv"),
            sep = "\t", quote = FALSE, row.names = FALSE)
print(summary)
