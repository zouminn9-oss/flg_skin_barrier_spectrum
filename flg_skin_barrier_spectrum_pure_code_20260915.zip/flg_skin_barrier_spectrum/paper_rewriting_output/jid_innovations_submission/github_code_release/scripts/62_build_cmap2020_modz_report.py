#!/usr/bin/env python3
"""Build the durable CMap2020 MODZ processing-method sensitivity report."""

from pathlib import Path
import json
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
MECH = ROOT / "results/exploratory_snf/selected_positive_reml_z_q05/optimized_AD_ACD_branch/mechanism"
OUT = MECH / "cmap2020_modz_full_background_sensitivity"
REPORT = ROOT / "AD_ACD_CMAP2020_MODZ_SENSITIVITY_REPORT.md"

source = json.loads((OUT / "SOURCE_AND_SCHEMA_QC.json").read_text())
run = json.loads((OUT / "RUN_PARAMETERS.json").read_text())
disposition = json.loads((OUT / "JNJ7706621_MODZ_DISPOSITION.json").read_text())
validation = json.loads((OUT / "VALIDATION_SUMMARY.json").read_text())
ranking = pd.read_csv(OUT / "full_background_compound_ranking.tsv", sep="\t")
comparison = pd.read_csv(OUT / "cd_modz_score_reconciliation_summary.tsv", sep="\t")
jnj = ranking.loc[ranking["pert_name"].eq("JNJ-7706621")].iloc[0]


def f(value, digits=5):
    return f"{float(value):.{digits}f}"


score_labels = {
    "apc_genome_rank_reversal": "APC genome rank",
    "apc_genome_weighted_reversal": "APC genome weighted",
    "apc_program_rank_reversal": "Program rank",
    "apc_program_weighted_reversal": "Program weighted",
    "apc_composite_reversal": "Composite",
}

method_rows = []
for row in comparison.itertuples(index=False):
    method_rows.append(
        f"| {score_labels.get(row.score, row.score)} | {int(row.overlap):,} | "
        f"{f(row.spearman_correlation, 4)} | {f(row.sign_agreement_fraction, 4)} | "
        f"{f(row.median_modz_minus_cd, 6)} |"
    )

component_rows = []
for column, label in score_labels.items():
    if column == "apc_composite_reversal":
        value = jnj["median_apc_composite_reversal"]
    else:
        value = jnj[f"median_{column}"]
    component_rows.append(f"| {label} | {f(value, 6)} | {'positive' if value > 0 else 'non-positive'} |")

text = f"""# AD–ACD CMap2020 MODZ full-background sensitivity report

## Executive conclusion

This post hoc, exploratory, computational analysis evaluates JNJ-7706621 with
Broad CMap2020 Level-5 MODZ signatures as a processing-method sensitivity check.
The frozen MODZ disposition is **`{disposition['modz_full_background_label']}`**.

This is not an independent biological replication. It does not alter the CD
label `positive_not_top5`, the independent GSE201278 label
`independent_skin_line_not_supported`, the targeted LINCS q=0.4146, or the
negative Gate 3 result.

## Source and scope

- Version-pinned Broad object:
  `level5_beta_trt_cp_n720216x12328.gctx`, S3 version
  `{source['version_id']}`.
- Exact bytes: {source['local_bytes']:,}.
- Local SHA-256: `{source['local_sha256']}`.
- Matrix: {source['column_identifiers']:,} compound-treatment conditions by
  {source['row_identifiers']:,} Entrez rows.
- Canonical scoring universe: {source['canonical_gene_symbols']:,} unique gene
  symbols; duplicated MIA2 was resolved before scoring by retaining Entrez 4253
  and excluding legacy Entrez 117153.
- Complete provider-name background: {run['compounds']:,} compounds; stable-
  eligible background: {run['stable_eligible_compounds']:,} compounds.
- The audit retains all {run['conditions']:,} conditions. Exactly
  {run['unscorable_all_zero_conditions']:,} source signatures were constant
  all-zero vectors and therefore mathematically unscorable; they were retained
  with missing scores and transparently excluded from compound aggregation.
  The remaining {run['scorable_conditions']:,} conditions were scored before
  aggregation. None of the all-zero signatures was JNJ-7706621 or part of the
  frozen 2,787-condition CD/MODZ comparison.

## JNJ-7706621 MODZ result

| Score | Compound median | Direction |
|---|---:|---|
{chr(10).join(component_rows)}

- Conditions: {int(jnj['n_conditions'])}; cell lines: {int(jnj['n_cell_lines'])}.
- All-compound rank: {int(jnj['all_compound_rank']):,}/{run['compounds']:,};
  competitive upper-tail fraction:
  {f(jnj['all_compound_competitive_upper_tail_fraction'], 5)}.
- Stable-eligible rank: {int(jnj['stable_eligible_rank']):,}/
  {run['stable_eligible_compounds']:,}; competitive upper-tail fraction:
  {f(jnj['stable_eligible_competitive_upper_tail_fraction'], 5)}.
- Multi-condition stable: {bool(jnj['multi_condition_stable'])}.
- External direction supported: {bool(jnj['external_direction_supported'])}.
- Toxicity dominated: {bool(jnj['toxicity_dominated'])}.

Competitive fractions are descriptive ranks, not null P values and not FDR.

## Complete CD/MODZ method comparison

| Score | Overlap | Spearman | Sign agreement | Median MODZ − CD |
|---|---:|---:|---:|---:|
{chr(10).join(method_rows)}

The comparison retains all 2,787 prespecified targeted conditions. Correlation
is diagnostic because CD and MODZ estimate different processed signatures; no
post-score compatibility threshold was introduced.

## Interpretation and limits

- A favorable MODZ result supports processing-method robustness only.
- A non-favorable MODZ result indicates that the earlier CD signal is sensitive
  to signature-estimation method.
- Neither outcome is an independent JNJ experiment.
- The analysis does not establish skin efficacy, safety, CDK2 selectivity, or
  clinical utility.
- Formal replication remains false and no library-wide FDR was computed.
- Validation: `{validation['status']}` with
  {validation['checks_passed']} checks passed.

Primary machine-readable outputs are in:
`results/exploratory_snf/selected_positive_reml_z_q05/optimized_AD_ACD_branch/mechanism/cmap2020_modz_full_background_sensitivity/`.
"""

REPORT.write_text(text)
artifact = {
    "report": str(REPORT),
    "title": "AD–ACD CMap2020 MODZ full-background sensitivity report",
    "disposition": disposition["modz_full_background_label"],
    "conditions": run["conditions"],
    "compounds": run["compounds"],
    "validation_status": validation["status"],
}
(OUT / "report_artifact.json").write_text(json.dumps(artifact, indent=2) + "\n")
print(json.dumps(artifact, indent=2))
