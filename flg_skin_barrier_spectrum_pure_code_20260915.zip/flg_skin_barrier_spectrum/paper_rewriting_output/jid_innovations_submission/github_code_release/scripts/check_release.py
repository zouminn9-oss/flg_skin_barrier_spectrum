#!/usr/bin/env python3
"""Perform dependency-free static checks on the GitHub release bundle."""

from __future__ import annotations

import json
import re
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SCAN_DIRS = ("scripts", "config", "environment", "notebooks")
REQUIRED = (
    "README.md",
    "LICENSE",
    ".gitignore",
    "requirements.txt",
    "config/datasets.tsv",
    "environment/install_r_packages.R",
    "environment/r-packages.tsv",
    "docs/PIPELINE_MAP.md",
    "docs/DATA.md",
    "docs/RELEASE_AUDIT.md",
    "docs/REPRODUCIBILITY_CHECKLIST.md",
)
ABSOLUTE_PATH = re.compile("/" + "Users/|/" + "Volumes/|/" + "home/")
SECRET = re.compile(
    r"(?i)(api[_-]?key|access[_-]?token|client[_-]?secret|password|passwd)\s*[:=]\s*['\"][^'\"]+"
)


def text_files() -> list[Path]:
    allowed = {".py", ".R", ".sh", ".tsv", ".txt", ".md", ".ipynb"}
    return sorted(
        path
        for directory in SCAN_DIRS
        for path in (ROOT / directory).rglob("*")
        if path.is_file() and path.suffix in allowed and not path.name.startswith("._")
    )


def main() -> None:
    problems: list[str] = []

    for relative in REQUIRED:
        if not (ROOT / relative).is_file():
            problems.append(f"missing required file: {relative}")

    forbidden = [
        path.relative_to(ROOT)
        for path in ROOT.rglob("*")
        if path.name.startswith("._") or path.name == "__pycache__" or path.suffix == ".pyc"
    ]
    if forbidden:
        problems.append("forbidden generated artifacts: " + ", ".join(map(str, forbidden)))

    for path in text_files():
        relative = path.relative_to(ROOT)
        content = path.read_text(encoding="utf-8")
        if ABSOLUTE_PATH.search(content):
            problems.append(f"author-machine absolute path: {relative}")
        if SECRET.search(content):
            problems.append(f"possible embedded secret: {relative}")
        if path.suffix == ".py":
            try:
                compile(content, str(relative), "exec")
            except SyntaxError as error:
                problems.append(f"Python syntax error in {relative}: {error}")
        elif path.suffix == ".ipynb":
            try:
                json.loads(content)
            except json.JSONDecodeError as error:
                problems.append(f"invalid notebook JSON in {relative}: {error}")

    scripts = [path for path in (ROOT / "scripts").iterdir() if path.is_file()]
    expected = {".py": 52, ".R": 15, ".sh": 3}
    observed = {suffix: sum(path.suffix == suffix for path in scripts) for suffix in expected}
    if observed != expected:
        problems.append(f"unexpected script inventory: expected {expected}, observed {observed}")

    if problems:
        raise SystemExit("RELEASE_CHECK_FAILED\n- " + "\n- ".join(problems))

    print(
        "RELEASE_CHECK_OK "
        f"python={observed['.py']} R={observed['.R']} shell={observed['.sh']} "
        f"scanned_files={len(text_files())}"
    )


if __name__ == "__main__":
    main()
