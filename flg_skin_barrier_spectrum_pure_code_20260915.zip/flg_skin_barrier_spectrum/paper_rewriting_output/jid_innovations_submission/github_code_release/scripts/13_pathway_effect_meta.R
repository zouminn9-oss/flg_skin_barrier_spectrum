#!/usr/bin/env Rscript

# Reuse only the data-loading and mapping functions from the cohort-effect script.
src <- readLines("scripts/07_fit_cohort_effects.R")
cut <- grep("^summaries <- list\\(\\)", src)[1]
eval(parse(text = src[seq_len(cut - 1L)]), envir = .GlobalEnv)
suppressPackageStartupMessages({ library(Matrix); library(metafor) })

set.seed(20260825)
dir.create("results/tables/pathway_effects", recursive = TRUE, showWarnings = FALSE)
dir.create("results/tables/pathway_meta", recursive = TRUE, showWarnings = FALSE)

gmt_lines <- readLines("data/raw/pathways/reactome_v97/ReactomePathways.gmt")
gmt_split <- strsplit(gmt_lines, "\t", fixed = TRUE)
gmt <- lapply(gmt_split, function(x) unique(x[-c(1, 2)]))
names(gmt) <- vapply(gmt_split, `[`, character(1), 1)

fit_pathways <- function(cohort_id, loaded, keep, meta, formula, coefficient, group_for_filter = NULL) {
  mat <- loaded$mat[, keep, drop = FALSE]
  design <- model.matrix(formula, data = meta)
  if (qr(design)$rank < ncol(design)) stop(cohort_id, ": rank-deficient design")
  if (loaded$counts) {
    dge <- DGEList(mat)
    keep_gene <- filterByExpr(dge, design = design, group = group_for_filter)
    dge <- normLibSizes(dge[keep_gene, , keep.lib.sizes = FALSE])
    mat <- voom(dge, design = design, plot = FALSE)$E
  }
  mu <- rowMeans(mat, na.rm = TRUE)
  s <- matrixStats::rowSds(mat, na.rm = TRUE)
  valid <- is.finite(s) & s > 0
  mat <- mat[valid, , drop = FALSE]
  zmat <- (mat - mu[valid]) / s[valid]
  gene_names <- rownames(zmat)
  indices <- lapply(gmt, function(gs) match(intersect(gs, gene_names), gene_names))
  keep_set <- lengths(indices) >= 10L & lengths(indices) <= 500L
  indices <- indices[keep_set]
  ii <- rep(seq_along(indices), lengths(indices))
  jj <- unlist(indices, use.names = FALSE)
  xx <- rep(1 / lengths(indices), lengths(indices))
  w <- sparseMatrix(i = ii, j = jj, x = xx, dims = c(length(indices), nrow(zmat)))
  score <- as.matrix(w %*% zmat)
  rownames(score) <- names(indices)
  colnames(score) <- colnames(zmat)
  fit <- eBayes(lmFit(score, design), robust = TRUE, trend = TRUE)
  j <- match(coefficient, colnames(fit$coefficients))
  se <- fit$stdev.unscaled[, j] * sqrt(fit$s2.post)
  out <- data.table(
    pathway = rownames(score), effect = fit$coefficients[, j], SE = se,
    t = fit$t[, j], p_value = fit$p.value[, j], FDR = p.adjust(fit$p.value[, j], "BH"),
    genes_in_score = lengths(indices), n_samples = ncol(score),
    n_participants = uniqueN(meta$participant), cohort = cohort_id
  )
  setorder(out, p_value)
  fwrite(out, file.path("results/tables/pathway_effects", paste0(cohort_id, ".tsv")), sep = "\t")
  out
}

cohort_results <- list()

# AD
x <- load_matrix("GSE121212"); keep <- x$map$disease == "AD" & x$map$condition %in% c("lesional", "non-lesional")
complete <- paired_complete(x$map[keep], "lesional", "non-lesional"); idx <- which(keep)[complete]
m <- data.frame(participant = factor(x$map$participant_id[idx]), state = relevel(factor(x$map$condition[idx]), "non-lesional"))
cohort_results[["AD_GSE121212_acute"]] <- fit_pathways("AD_GSE121212_acute", x, idx, m, ~ participant + state, "statelesional", m$state)

x <- load_matrix("GSE32924"); keep <- x$map$disease == "AD" & x$map$condition %in% c("AL", "ANL")
complete <- paired_complete(x$map[keep], "AL", "ANL"); idx <- which(keep)[complete]
m <- data.frame(participant = factor(x$map$participant_id[idx]), state = relevel(factor(x$map$condition[idx]), "ANL"))
cohort_results[["AD_GSE32924"]] <- fit_pathways("AD_GSE32924", x, idx, m, ~ participant + state, "stateAL")

x <- load_matrix("GSE36842"); keep <- x$map$disease == "AD" & x$map$condition %in% c("ALS", "NL")
complete <- paired_complete(x$map[keep], "ALS", "NL"); idx <- which(keep)[complete]
m <- data.frame(participant = factor(x$map$participant_id[idx]), state = relevel(factor(x$map$condition[idx]), "NL"))
cohort_results[["AD_GSE36842_acute"]] <- fit_pathways("AD_GSE36842_acute", x, idx, m, ~ participant + state, "stateALS")

# ACD
x <- load_matrix("GSE282562"); idx <- seq_len(ncol(x$mat)); raw <- geo_meta[series == "GSE282562"][match(x$map$gsm, gsm)]
json_text <- sub('^"(.*)"$', '\\1', raw$characteristics_json); json_text <- gsub('""', '"', json_text, fixed = TRUE)
chars <- lapply(json_text, fromJSON)
extract <- function(key) vapply(chars, function(z) if (!is.null(z[[key]])) as.character(z[[key]][1]) else NA_character_, character(1))
m <- data.frame(participant = factor(x$map$participant_id), state = relevel(factor(ifelse(x$map$disease == "ACD", "ACD", "CTRL")), "CTRL"),
                age = as.numeric(extract("age")), sex = factor(extract("sex")), batch = factor(extract("batch")), technician = factor(extract("technician")))
cohort_results[["ACD_GSE282562"]] <- fit_pathways("ACD_GSE282562", x, idx, m, ~ state + age + sex + batch + technician, "stateACD")

x <- load_matrix("GSE6281"); idx <- which(x$map$disease == "ACD" & x$map$time %in% c("0h", "7h", "48h", "96h"))
m <- data.frame(participant = factor(x$map$participant_id[idx]), time = relevel(factor(x$map$time[idx], levels = c("0h", "7h", "48h", "96h")), "0h"))
cohort_results[["ACD_GSE6281_48h"]] <- fit_pathways("ACD_GSE6281_48h", x, idx, m, ~ participant + time, "time48h")

# Backgrounds
x <- load_matrix("GSE13355"); keep <- x$map$condition %in% c("psoriasis_lesional", "psoriasis_nonlesional")
complete <- paired_complete(x$map[keep], "psoriasis_lesional", "psoriasis_nonlesional"); idx <- which(keep)[complete]
m <- data.frame(participant = factor(x$map$participant_id[idx]), state = relevel(factor(x$map$condition[idx]), "psoriasis_nonlesional"))
cohort_results[["PSO_GSE13355"]] <- fit_pathways("PSO_GSE13355", x, idx, m, ~ participant + state, "statepsoriasis_lesional")

x <- load_matrix("GSE121212"); keep <- x$map$disease == "PSO" & x$map$condition %in% c("lesional", "non-lesional")
complete <- paired_complete(x$map[keep], "lesional", "non-lesional"); idx <- which(keep)[complete]
m <- data.frame(participant = factor(x$map$participant_id[idx]), state = relevel(factor(x$map$condition[idx]), "non-lesional"))
cohort_results[["PSO_GSE121212"]] <- fit_pathways("PSO_GSE121212", x, idx, m, ~ participant + state, "statelesional", m$state)

x <- load_matrix("GSE53795"); idx <- seq_len(ncol(x$mat)); m <- data.frame(participant = factor(x$map$participant_id), state = relevel(factor(x$map$condition), "non-lesional skin"))
cohort_results[["ACNE_GSE53795"]] <- fit_pathways("ACNE_GSE53795", x, idx, m, ~ participant + state, "statelesional skin")

x <- load_matrix("GSE65914"); participants <- unique(x$map$participant_id)
collapsed <- sapply(participants, function(p) rowMeans(x$mat[, x$map$participant_id == p, drop = FALSE])); if (is.vector(collapsed)) collapsed <- matrix(collapsed, ncol = 1)
colnames(collapsed) <- participants; map_collapsed <- x$map[match(participants, x$map$participant_id)]
x2 <- list(mat = collapsed, map = map_collapsed, counts = FALSE)
m <- data.frame(participant = factor(participants), state = relevel(factor(ifelse(map_collapsed$disease == "rosacea", "rosacea", "CTRL")), "CTRL"))
cohort_results[["ROSACEA_GSE65914"]] <- fit_pathways("ROSACEA_GSE65914", x2, seq_along(participants), m, ~ state, "staterosacea")

for (accession in c("GSE137141", "GSE72702")) {
  x <- load_matrix(accession); states <- if (accession == "GSE137141") c("lesional site (LS)", "non-lesional site (NL)") else c("lesion", "non-lesion")
  keep <- x$map$condition %in% states; complete <- paired_complete(x$map[keep], states[1], states[2]); idx <- which(keep)[complete]
  m <- data.frame(participant = factor(x$map$participant_id[idx]), state = relevel(factor(x$map$condition[idx]), states[2]))
  id <- paste0("HS_", accession); cohort_results[[id]] <- fit_pathways(id, x, idx, m, ~ participant + state, paste0("state", states[1]))
}

groups <- list(AD = c("AD_GSE121212_acute", "AD_GSE32924", "AD_GSE36842_acute"),
               ACD = c("ACD_GSE282562", "ACD_GSE6281_48h"),
               PSORIASIS = c("PSO_GSE13355", "PSO_GSE121212"),
               HS = c("HS_GSE137141", "HS_GSE72702"))

fit_meta <- function(disease, ids) {
  merged <- Reduce(function(a, b) merge(a, b, by = "pathway", all = FALSE),
                   lapply(ids, function(id) {
                     x <- copy(cohort_results[[id]])[, .(pathway, effect, SE, FDR)]
                     setnames(x, c("effect", "SE", "FDR"), paste0(c("effect__", "SE__", "FDR__"), id)); x
                   }))
  rows <- lapply(seq_len(nrow(merged)), function(i) {
    yi <- as.numeric(merged[i, paste0("effect__", ids), with = FALSE]); sei <- as.numeric(merged[i, paste0("SE__", ids), with = FALSE])
    ok <- is.finite(yi) & is.finite(sei) & sei > 0; yi <- yi[ok]; sei <- sei[ok]
    model <- suppressWarnings(rma.uni(yi = yi, sei = sei, method = "REML", test = "adhoc"))
    loo <- vapply(seq_along(yi), function(j) { w <- 1 / sei[-j]^2; sum(w * yi[-j]) / sum(w) }, numeric(1))
    c(effect = as.numeric(model$b), SE = model$se, CI_low = model$ci.lb, CI_high = model$ci.ub,
      p_value = model$pval, tau2 = model$tau2, I2 = model$I2,
      direction_agree_n = sum(sign(yi) == sign(as.numeric(model$b))),
      LODO_direction_stable = all(sign(loo[loo != 0]) == sign(as.numeric(model$b))))
  })
  vals <- as.data.table(do.call(rbind, rows))
  out <- cbind(merged[, .(pathway)], vals)
  out[, `:=`(FDR = p.adjust(p_value, "BH"), cohorts = length(ids), disease = disease,
             signed_z = qnorm(pmax(p_value / 2, .Machine$double.xmin), lower.tail = FALSE) * sign(effect))]
  setorder(out, p_value); fwrite(out, file.path("results/tables/pathway_meta", paste0(disease, "_pathway_meta.tsv")), sep = "\t")
  out
}
meta <- lapply(names(groups), function(d) fit_meta(d, groups[[d]])); names(meta) <- names(groups)
summary <- rbindlist(lapply(names(meta), function(d) data.table(
  disease = d, pathways = nrow(meta[[d]]), FDR_005 = sum(meta[[d]]$FDR < .05),
  direction_complete = sum(meta[[d]]$direction_agree_n == meta[[d]]$cohorts),
  LODO_direction_stable = sum(meta[[d]]$LODO_direction_stable)
)))
fwrite(summary, "results/tables/pathway_meta/pathway_meta_summary.tsv", sep = "\t")
print(summary)
