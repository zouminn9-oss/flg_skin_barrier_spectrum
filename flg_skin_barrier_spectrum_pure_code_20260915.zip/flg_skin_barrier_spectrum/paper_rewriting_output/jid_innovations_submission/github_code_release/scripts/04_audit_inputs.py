#!/usr/bin/env python3
"""Create the canonical raw-input integrity manifest."""

import csv
import gzip
import hashlib
import pathlib


ROOT = pathlib.Path(__file__).resolve().parents[1]
RAW = ROOT / "data" / "raw"
OUT = ROOT / "records" / "raw_input_manifest.tsv"


def digest(path):
    value = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def main():
    rows = []
    for path in sorted(RAW.rglob("*")):
        if not path.is_file() or path.name.startswith("._") or "quarantine" in path.parts or path.name.endswith(".part"):
            continue
        status = "not_applicable"
        if path.name.endswith(".gz"):
            try:
                with gzip.open(path, "rb") as handle:
                    while handle.read(1024 * 1024):
                        pass
                status = "gzip_ok"
            except Exception as error:
                status = f"gzip_failed:{type(error).__name__}"
        rows.append({"path": str(path.relative_to(ROOT)), "bytes": path.stat().st_size,
                     "sha256": digest(path), "integrity": status})
    if any(row["integrity"].startswith("gzip_failed") for row in rows):
        raise RuntimeError("At least one canonical gzip input failed integrity testing")
    with OUT.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, delimiter="\t", fieldnames=list(rows[0]))
        writer.writeheader(); writer.writerows(rows)
    print(f"RAW_INPUT_AUDIT_OK files={len(rows)}")


if __name__ == "__main__":
    main()

