#!/usr/bin/env python3
"""Download the immutable Broad CMap2020 MODZ compound matrix by byte ranges."""

from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
import hashlib
import json
import os
import subprocess
import urllib.request


ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data/raw/perturbations/cmap2020_modz"
TARGET = RAW / "level5_beta_trt_cp_n720216x12328.gctx"
SEGMENTS = RAW / "download_segments"
MANIFEST = SEGMENTS / "manifest.json"
ASSEMBLED = RAW / "level5_beta_trt_cp_n720216x12328.gctx.assembled"

BASE_URL = "https://s3.amazonaws.com/macchiato.clue.io/builds/LINCS2020/level5/level5_beta_trt_cp_n720216x12328.gctx"
VERSION_ID = "ljLz1nWDJ4co.kG6bSrfEs7mrklxiVS4"
URL = f"{BASE_URL}?versionId={VERSION_ID}"
TOTAL_BYTES = 35_518_405_386
EXPECTED_ETAG = "d342ab7f3fa6ece699099bc2d8fc94b8-2118"
EXPECTED_LAST_MODIFIED = "Wed, 16 Dec 2020 23:54:09 GMT"
N_SEGMENTS = 8
COPY_BLOCK = 16 * 1024 * 1024

GENEINFO_BASE_URL = "https://s3.amazonaws.com/macchiato.clue.io/builds/LINCS2020/geneinfo_beta.txt"
GENEINFO_VERSION_ID = "zMQVoz8KI8QHbXRa2UHS.ta3VQhg3lgq"
GENEINFO_URL = f"{GENEINFO_BASE_URL}?versionId={GENEINFO_VERSION_ID}"
GENEINFO = RAW / "geneinfo_beta.txt"
GENEINFO_BYTES = 1_141_389
GENEINFO_MD5 = "45c725d17ce6c377f1e7de07b821a5f0"


def head(url):
    request = urllib.request.Request(url, method="HEAD", headers={"User-Agent": "FLG-CMap2020-MODZ/1.0"})
    with urllib.request.urlopen(request, timeout=120) as handle:
        return {key.lower(): value for key, value in handle.headers.items()}


def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while block := handle.read(COPY_BLOCK):
            digest.update(block)
    return digest.hexdigest()


RAW.mkdir(parents=True, exist_ok=True)
SEGMENTS.mkdir(parents=True, exist_ok=True)

headers = head(URL)
observed = {
    "url": BASE_URL,
    "version_pinned_url": URL,
    "version_id": headers.get("x-amz-version-id"),
    "content_length": int(headers.get("content-length", "0")),
    "last_modified": headers.get("last-modified"),
    "etag": headers.get("etag", "").strip('"'),
    "accept_ranges": headers.get("accept-ranges"),
}
if observed["version_id"] != VERSION_ID:
    raise RuntimeError(f"Unexpected matrix version ID: {observed}")
if observed["content_length"] != TOTAL_BYTES or observed["etag"] != EXPECTED_ETAG:
    raise RuntimeError(f"Unexpected matrix object: {observed}")
if observed["last_modified"] != EXPECTED_LAST_MODIFIED:
    raise RuntimeError(f"Unexpected matrix modification time: {observed}")
(RAW / "remote_headers.json").write_text(json.dumps(observed, indent=2) + "\n")

gene_headers = head(GENEINFO_URL)
if gene_headers.get("x-amz-version-id") != GENEINFO_VERSION_ID:
    raise RuntimeError(f"Unexpected geneinfo version: {gene_headers}")
if int(gene_headers.get("content-length", "0")) != GENEINFO_BYTES:
    raise RuntimeError(f"Unexpected geneinfo bytes: {gene_headers}")
if not GENEINFO.exists() or GENEINFO.stat().st_size != GENEINFO_BYTES:
    subprocess.run([
        "curl", "-sS", "-L", "--fail", "--retry", "10", "--retry-all-errors",
        "--output", str(GENEINFO), GENEINFO_URL,
    ], check=True)
gene_md5 = hashlib.md5(GENEINFO.read_bytes()).hexdigest()
if GENEINFO.stat().st_size != GENEINFO_BYTES or gene_md5 != GENEINFO_MD5:
    raise RuntimeError("geneinfo size or ETag/body-MD5 check failed")

if TARGET.exists() and TARGET.stat().st_size == TOTAL_BYTES:
    receipt = {
        "matrix_bytes": TARGET.stat().st_size,
        "matrix_sha256": sha256(TARGET),
        "geneinfo_bytes": GENEINFO.stat().st_size,
        "geneinfo_sha256": sha256(GENEINFO),
        "remote": observed,
    }
    (RAW / "download_receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps(receipt, indent=2))
    raise SystemExit(0)

if MANIFEST.exists():
    manifest = json.loads(MANIFEST.read_text())
    if manifest["total_bytes"] != TOTAL_BYTES or manifest["version_pinned_url"] != URL:
        raise RuntimeError("Existing download manifest does not match the frozen object")
else:
    base, extra = divmod(TOTAL_BYTES, N_SEGMENTS)
    ranges = []
    start = 0
    for index in range(N_SEGMENTS):
        size = base + (1 if index < extra else 0)
        end = start + size - 1
        ranges.append({
            "index": index,
            "start": start,
            "end": end,
            "expected_bytes": size,
            "path": str(SEGMENTS / f"segment_{index:02d}_{start}_{end}.part"),
        })
        start = end + 1
    if start != TOTAL_BYTES:
        raise RuntimeError((start, TOTAL_BYTES))
    manifest = {"version_pinned_url": URL, "total_bytes": TOTAL_BYTES, "segments": ranges}
    MANIFEST.write_text(json.dumps(manifest, indent=2) + "\n")


def download(row):
    path = Path(row["path"])
    if path.exists() and path.stat().st_size == row["expected_bytes"]:
        return row["index"], "checkpoint"
    if path.exists():
        os.replace(path, path.with_suffix(path.suffix + ".incomplete"))
    subprocess.run([
        "curl", "-sS", "-L", "--fail", "--retry", "20", "--retry-all-errors",
        "--speed-limit", "1024", "--speed-time", "120",
        "--range", f"{row['start']}-{row['end']}", "--output", str(path), URL,
    ], check=True)
    if path.stat().st_size != row["expected_bytes"]:
        raise RuntimeError(f"Segment {row['index']} size mismatch")
    return row["index"], "downloaded"


print(json.dumps({"total_bytes": TOTAL_BYTES, "parallel_segments": N_SEGMENTS}, indent=2), flush=True)
with ThreadPoolExecutor(max_workers=N_SEGMENTS) as pool:
    futures = [pool.submit(download, row) for row in manifest["segments"]]
    for future in as_completed(futures):
        index, status = future.result()
        print(f"segment {index}: {status}", flush=True)

digest = hashlib.sha256()
with ASSEMBLED.open("wb") as destination:
    for row in manifest["segments"]:
        path = Path(row["path"])
        with path.open("rb") as source:
            while block := source.read(COPY_BLOCK):
                destination.write(block)
                digest.update(block)
        print(f"assembled {path.name}", flush=True)

if ASSEMBLED.stat().st_size != TOTAL_BYTES:
    raise RuntimeError("Assembled matrix size mismatch")
os.replace(ASSEMBLED, TARGET)
receipt = {
    "matrix_bytes": TARGET.stat().st_size,
    "matrix_sha256": digest.hexdigest(),
    "geneinfo_bytes": GENEINFO.stat().st_size,
    "geneinfo_sha256": sha256(GENEINFO),
    "remote": observed,
}
(RAW / "download_receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps(receipt, indent=2))
