#!/usr/bin/env Rscript

root <- normalizePath(getwd())
meta_dir <- file.path(root, "results/tables/pathway_meta")
effect_dir <- file.path(root, "results/tables/pathway_effects")
out_dir <- file.path(root, "results/tables/similarity")
fig_dir <- file.path(root, "results/figures/similarity")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(fig_dir, recursive = TRUE, showWarnings = FALSE)

meta_files <- c(AD = "AD_pathway_meta.tsv", ACD = "ACD_pathway_meta.tsv",
                PSORIASIS = "PSORIASIS_pathway_meta.tsv", HS = "HS_pathway_meta.tsv")
tabs <- lapply(meta_files, function(f) read.delim(file.path(meta_dir, f), stringsAsFactors = FALSE))
background_files <- c(ACNE = "ACNE_GSE53795.tsv", ROSACEA = "ROSACEA_GSE65914.tsv")
for (nm in names(background_files)) {
  d <- read.delim(file.path(effect_dir, background_files[[nm]]), stringsAsFactors = FALSE)
  d$signed_z <- d$t
  tabs[[nm]] <- d
}
all_pathways <- sort(Reduce(intersect, lapply(tabs, function(x) x$pathway)))
z <- sapply(tabs, function(x) x$signed_z[match(all_pathways, x$pathway)])
rownames(z) <- all_pathways

cormat <- cor(z, method = "spearman", use = "pairwise.complete.obs")
write.table(cbind(disease = rownames(cormat), as.data.frame(cormat)),
            file.path(out_dir, "reactome_spearman_similarity.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)

set.seed(20260825)
pairs <- combn(colnames(z), 2, simplify = FALSE)
perm_n <- 10000L
pair_results <- lapply(pairs, function(p) {
  x <- z[, p[1]]
  y <- z[, p[2]]
  obs <- cor(x, y, method = "spearman")
  null <- replicate(perm_n, cor(x, sample(y), method = "spearman"))
  data.frame(disease_1 = p[1], disease_2 = p[2], spearman_rho = obs,
             permutation_p = (1 + sum(abs(null) >= abs(obs))) / (perm_n + 1),
             pathways = length(x))
})
pair_results <- do.call(rbind, pair_results)
pair_results$permutation_q <- p.adjust(pair_results$permutation_p, method = "BH")
write.table(pair_results, file.path(out_dir, "reactome_similarity_permutation.tsv"),
            sep = "\t", quote = FALSE, row.names = FALSE)

backgrounds <- c("PSORIASIS", "ACNE", "ROSACEA", "HS")
background_values <- c(cormat["AD", backgrounds], cormat["ACD", backgrounds])
target <- cormat["AD", "ACD"]
threshold <- median(background_values) + 0.5 * sd(background_values)
target_row <- pair_results[(pair_results$disease_1 == "AD" & pair_results$disease_2 == "ACD") |
                           (pair_results$disease_1 == "ACD" & pair_results$disease_2 == "AD"), ]
specificity <- data.frame(
  target_pair = "AD--ACD",
  target_spearman_rho = target,
  background_median = median(background_values),
  background_sd = sd(background_values),
  frozen_threshold_median_plus_0_5sd = threshold,
  exceeds_threshold = target > threshold,
  permutation_p = target_row$permutation_p,
  permutation_q = target_row$permutation_q,
  background_correlations = paste(sprintf("%s=%.4f", c(paste0("AD--", backgrounds), paste0("ACD--", backgrounds)), background_values), collapse = ";")
)
write.table(specificity, file.path(out_dir, "AD_ACD_background_specificity.tsv"),
            sep = "\t", quote = FALSE, row.names = FALSE)

ad <- tabs$AD
acd <- tabs$ACD
ad$Direction <- ifelse(ad$effect > 0, "Up", "Down")
acd$Direction <- ifelse(acd$effect > 0, "Up", "Down")
shared <- merge(ad[, c("pathway", "Direction", "FDR", "signed_z")],
                acd[, c("pathway", "Direction", "FDR", "signed_z")],
                by = "pathway", suffixes = c("_AD", "_ACD"))
shared <- shared[shared$FDR_AD < 0.05 & shared$FDR_ACD < 0.05 & shared$Direction_AD == shared$Direction_ACD, ]
shared <- shared[order(pmax(shared$FDR_AD, shared$FDR_ACD), decreasing = FALSE), ]
write.table(shared, file.path(out_dir, "AD_ACD_shared_meta_pathways.tsv"),
            sep = "\t", quote = FALSE, row.names = FALSE)

png(file.path(fig_dir, "reactome_spearman_similarity_heatmap.png"), width = 1200, height = 1050, res = 150)
heatmap(cormat, symm = TRUE, margins = c(10, 10), main = "Reactome signed-effect similarity")
dev.off()

print(specificity)
cat("Shared AD/ACD pathways at meta FDR < 0.05 and same direction:", nrow(shared), "\n")
