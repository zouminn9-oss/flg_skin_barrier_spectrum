#!/bin/zsh
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
RESULT_DIR="$PROJECT_DIR/results/posthoc_exploratory_gate4_positive_branch"
LOG="$RESULT_DIR/pipeline.log"

mkdir -p "$RESULT_DIR"
cd "$PROJECT_DIR"

{
  print -- "[$(date -u +%Y-%m-%dT%H:%M:%SZ)] build_posthoc_gate4_package"
  PYTHONPATH=environment/python_packages python3 scripts/64_build_posthoc_gate4_positive_branch.py

  print -- "[$(date -u +%Y-%m-%dT%H:%M:%SZ)] build_durable_report"
  PYTHONPATH=environment/python_packages python3 scripts/66_build_posthoc_gate4_positive_branch_report.py

  print -- "[$(date -u +%Y-%m-%dT%H:%M:%SZ)] strict_validation"
  PYTHONPATH=environment/python_packages python3 scripts/65_validate_posthoc_gate4_positive_branch.py

  print -- "[$(date -u +%Y-%m-%dT%H:%M:%SZ)] pipeline_complete"
} 2>&1 | tee -a "$LOG"
