#!/usr/bin/env Rscript

src <- readLines("scripts/18_run_exploratory_snf.R")
cut <- grep("^obs_views <- make_views", src)[1]
eval(parse(text = src[seq_len(cut - 1L)]), envir = .GlobalEnv)

base_dir <- file.path(root, "results/exploratory_snf/selected_positive_reml_z_q05")
out_dir <- file.path(base_dir, "optimized_AD_ACD_branch")
fig_dir <- file.path(out_dir, "figures")
dir.create(fig_dir, recursive = TRUE, showWarnings = FALSE)

best <- fread(file.path(base_dir, "parameter_grid/snf_most_favorable_AD_ACD_branch.tsv"))[1]
selected_views <- strsplit(best$views, "+", fixed = TRUE)[[1]]
K <- best$K; alpha <- best$alpha; iterations <- best$iterations

all_views <- make_views(x); names(all_views) <- view_names
obs <- fuse(all_views[selected_views])
fwrite(data.table(disease = diseases, as.data.frame(obs)), file.path(out_dir, "optimized_fused_similarity.tsv"), sep = "\t")

models <- rbindlist(lapply(2:4, function(k) {
  z <- spectral_cluster(obs, k)
  data.table(k = k, silhouette = mean_silhouette(z$cluster, obs),
             eigengap = z$eigenvalues[k] - z$eigenvalues[k + 1L],
             clusters = paste(sprintf("%s:%s", diseases, z$cluster), collapse = ";"))
}))
setorder(models, -silhouette, -eigengap, k)
chosen_k <- models$k[1]
cluster <- spectral_cluster(obs, chosen_k)$cluster
names(cluster) <- diseases
fwrite(models, file.path(out_dir, "optimized_cluster_model_selection.tsv"), sep = "\t")

edge_index <- which(upper.tri(obs), arr.ind = TRUE)
obs_edges <- obs[edge_index]
target_j <- which((diseases[edge_index[, 1]] == "AD" & diseases[edge_index[, 2]] == "ACD") |
                  (diseases[edge_index[, 1]] == "ACD" & diseases[edge_index[, 2]] == "AD"))

# Selected-branch bootstrap.
bootstrap_n <- 1000L
boot_worker <- function(seed) {
  set.seed(seed)
  v <- make_views(x, bootstrap = TRUE); names(v) <- view_names
  wf <- fuse(v[selected_views])
  cl <- spectral_cluster(wf, chosen_k)$cluster
  c(wf[edge_index], as.numeric(outer(cl, cl, "==")))
}
boot <- mclapply(20260825 + seq_len(bootstrap_n), boot_worker, mc.cores = worker_cores, mc.preschedule = TRUE)
boot <- do.call(rbind, boot)
boot_edges <- boot[, seq_len(nrow(edge_index)), drop = FALSE]
boot_co <- matrix(colMeans(boot[, nrow(edge_index) + seq_len(n * n), drop = FALSE]), nrow = n,
                  dimnames = list(diseases, diseases))

# Nominal selected-branch label permutation.
perm_n <- 10000L
perm_worker <- function(seed) {
  set.seed(seed)
  v <- make_views(x, permute_rows = TRUE); names(v) <- view_names
  fuse(v[selected_views])[edge_index]
}
perm <- mclapply(20260825 + 100000L + seq_len(perm_n), perm_worker, mc.cores = worker_cores, mc.preschedule = TRUE)
perm <- do.call(rbind, perm)
perm_p <- vapply(seq_along(obs_edges), function(j) (1 + sum(perm[, j] >= obs_edges[j])) / (perm_n + 1), numeric(1))

# Max-statistic adjustment across all 396 inspected branches. Five hundred
# permutations provide a resolution of 1/501 for this selection audit.
view_sets <- unlist(lapply(2:4, function(k) combn(view_names, k, simplify = FALSE)), recursive = FALSE)
selection_perm_n <- 500L
selection_worker <- function(seed) {
  set.seed(seed)
  v <- make_views(x, permute_rows = TRUE); names(v) <- view_names
  max_target <- -Inf
  for (vs in view_sets) {
    for (k_nn in c(2L, 3L, 4L, 5L)) {
      for (a in c(0.2, 0.5, 1.0)) {
        for (it in c(10L, 20L, 50L)) {
          assign("K", k_nn, envir = .GlobalEnv)
          assign("alpha", a, envir = .GlobalEnv)
          assign("iterations", it, envir = .GlobalEnv)
          z <- fuse(v[vs])["AD", "ACD"]
          if (z > max_target) max_target <- z
        }
      }
    }
  }
  max_target
}
selection_null <- unlist(mclapply(20260825 + 200000L + seq_len(selection_perm_n), selection_worker,
                                   mc.cores = worker_cores, mc.preschedule = TRUE))
selection_adjusted_p <- (1 + sum(selection_null >= obs_edges[target_j])) / (selection_perm_n + 1)

# The single-worker fallback evaluates the grid in the global environment and
# leaves these tuning variables set to the last scanned branch. Restore the
# selected branch before recording provenance.
K <- best$K
alpha <- best$alpha
iterations <- best$iterations

edge_table <- data.table(
  disease_1 = diseases[edge_index[, 1]], disease_2 = diseases[edge_index[, 2]],
  fused_similarity = obs_edges,
  bootstrap_mean = colMeans(boot_edges),
  bootstrap_ci_low = apply(boot_edges, 2, quantile, 0.025),
  bootstrap_ci_high = apply(boot_edges, 2, quantile, 0.975),
  bootstrap_coclustering = boot_co[edge_index],
  nominal_permutation_p = perm_p,
  nominal_permutation_q = p.adjust(perm_p, "BH"),
  same_cluster = cluster[diseases[edge_index[, 1]]] == cluster[diseases[edge_index[, 2]]]
)
setorder(edge_table, -fused_similarity)
fwrite(edge_table, file.path(out_dir, "optimized_edge_statistics.tsv"), sep = "\t")

cluster_support <- vapply(diseases, function(d) {
  mates <- diseases[cluster == cluster[d] & diseases != d]
  if (!length(mates)) return(NA_real_)
  mean(boot_co[d, mates])
}, numeric(1))
cluster_table <- data.table(disease = diseases, cluster = cluster, bootstrap_cluster_support = cluster_support)
fwrite(cluster_table, file.path(out_dir, "optimized_cluster_support.tsv"), sep = "\t")
fwrite(data.table(disease = diseases, as.data.frame(boot_co)), file.path(out_dir, "optimized_bootstrap_coclustering.tsv"), sep = "\t")

target <- edge_table[(disease_1 == "AD" & disease_2 == "ACD") | (disease_1 == "ACD" & disease_2 == "AD")]
summary <- data.table(
  branch_id = best$branch_id,
  views = best$views,
  K = best$K,
  alpha = best$alpha,
  iterations = best$iterations,
  branches_screened = 396L,
  selected_k = chosen_k,
  selected_silhouette = models$silhouette[1],
  AD_ACD_similarity = target$fused_similarity,
  AD_ACD_rank = which(edge_table$disease_1 == target$disease_1 & edge_table$disease_2 == target$disease_2),
  AD_ACD_nominal_p = target$nominal_permutation_p,
  AD_ACD_nominal_q = target$nominal_permutation_q,
  AD_ACD_selection_adjusted_p_500 = selection_adjusted_p,
  AD_ACD_bootstrap_coclustering = target$bootstrap_coclustering,
  AD_ACD_same_cluster = target$same_cluster,
  selection_adjustment_permutations = selection_perm_n
)
fwrite(summary, file.path(out_dir, "optimized_snf_summary.tsv"), sep = "\t")

dmat <- 1 - obs; dmat[dmat < 0] <- 0
coords <- cmdscale(as.dist(dmat), k = 2); rownames(coords) <- diseases
png(file.path(fig_dir, "optimized_AD_ACD_network.png"), width = 1400, height = 1100, res = 170)
xpad <- diff(range(coords[, 1])) * .08; ypad <- diff(range(coords[, 2])) * .10
plot(coords, type = "n", xlab = "MDS1", ylab = "MDS2",
     xlim = range(coords[, 1]) + c(-xpad, xpad), ylim = range(coords[, 2]) + c(-ypad, ypad),
     main = "AD-ACD optimized selected-positive SNF\nsolid edges: nominal permutation BH q < 0.05")
sig <- edge_table[nominal_permutation_q < .05]
for (i in seq_len(nrow(sig))) {
  a <- sig$disease_1[i]; b <- sig$disease_2[i]
  segments(coords[a, 1], coords[a, 2], coords[b, 1], coords[b, 2],
           lwd = 2 + 10 * sig$fused_similarity[i], col = adjustcolor("#286DA8", .7))
}
palette <- c("#E45756", "#4C78A8", "#72B7B2", "#F2CF5B")
points(coords, pch = 21, bg = palette[cluster], col = "white", cex = 4.5, lwd = 1.5)
label_x <- coords[, 1]
label_y <- coords[, 2] + diff(range(coords[, 2])) * .035
label_x["HS"] <- label_x["HS"] - diff(range(coords[, 1])) * .065
label_y["HS"] <- label_y["HS"] + diff(range(coords[, 2])) * .040
label_x["ICD"] <- label_x["ICD"] + diff(range(coords[, 1])) * .065
label_y["ICD"] <- label_y["ICD"] - diff(range(coords[, 2])) * .025
text(label_x, label_y, labels = diseases, cex = .95, font = 2)
dev.off()

print(summary)
print(cluster_table)
print(edge_table[1:min(10, .N)])
