#!/usr/bin/env python3
"""Exploratory network-intervention simulation for five locked APC TF candidates.

This is a computational virtual knockout, not a biological knockout.  A joint
ridge model attributes the observed APC signed gene statistic to signed
CollecTRI target memberships.  A TF knockout sets exactly one fitted TF
coefficient to zero while holding the intercept and all other coefficients
fixed.  Gene bootstrap and degree/sign-preserving target rewiring quantify
uncertainty and a network null, respectively.
"""

from pathlib import Path
import os
import time

os.environ.setdefault("MPLCONFIGDIR", "/tmp/flg_skin_barrier_mplconfig")
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.linear_model import Ridge, RidgeCV
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.model_selection import KFold, cross_val_predict


ROOT = Path(__file__).resolve().parents[1]
MECH = ROOT / "results/exploratory_snf/selected_positive_reml_z_q05/optimized_AD_ACD_branch/mechanism"
APC_NET = MECH / "apc_regulator_network"
OUT = MECH / "virtual_knockout"
FIG = OUT / "figures"
OUT.mkdir(parents=True, exist_ok=True)
FIG.mkdir(parents=True, exist_ok=True)

SEED = 20260825
BOOTSTRAPS = 2_000
NULL_REWIRES = 5_000
ALPHAS = np.logspace(-4, 4, 81)
STRICT_BOOTSTRAP_PROBABILITY = 0.95
STRICT_MAX_NULL_P = 0.05


def weighted_score(values, weights):
    return float(np.dot(values, weights))


started = time.perf_counter()
rng = np.random.default_rng(SEED)

# Candidate order is frozen by the preceding APC regulator analysis.
candidates = pd.read_csv(APC_NET / "candidate_positive_regulators.tsv", sep="\t")
CANDIDATES = candidates["TF"].tolist()
assert CANDIDATES == ["YY1", "IRF1", "E2F6", "E2F4", "HSF1"]

# Collapse the fixed CollecTRI snapshot to unambiguous signed TF-target pairs.
raw = pd.read_csv(
    ROOT / "data/raw/regulons/collectri/omnipath_collectri_human_2026-08-25.tsv",
    sep="\t", low_memory=False,
)
raw = raw.loc[raw["consensus_stimulation"].ne(raw["consensus_inhibition"])].copy()
raw["mor"] = np.where(raw["consensus_stimulation"], 1.0, -1.0)
pairs = raw.groupby(["source_genesymbol", "target_genesymbol"])["mor"].mean().reset_index()
pairs = pairs.loc[
    pairs["mor"].abs().eq(1) & pairs["source_genesymbol"].isin(CANDIDATES)
].copy()

# APC allergy-minus-irritant response used in the regulator discovery step.
apc = pd.read_csv(
    ROOT / "results/tables/single_cell_validation/GSE267929_APC_gene_effects.tsv",
    sep="\t",
)
apc["raw_signed_statistic"] = np.sign(apc["logFC"]) * np.sqrt(apc["F"])
apc["y"] = (
    apc["raw_signed_statistic"] - apc["raw_signed_statistic"].mean()
) / apc["raw_signed_statistic"].std(ddof=1)
genes = apc["gene_symbol"].tolist()
gene_index = {gene: i for i, gene in enumerate(genes)}
y = apc["y"].to_numpy(dtype=float)

# Each candidate column has L2 norm one, matching the earlier activity-score
# normalization and making coefficient magnitudes comparable across TF degrees.
X = np.zeros((len(genes), len(CANDIDATES)), dtype=float)
target_counts = {}
for j, tf in enumerate(CANDIDATES):
    edge = pairs.loc[
        pairs["source_genesymbol"].eq(tf)
        & pairs["target_genesymbol"].isin(gene_index)
    ]
    target_counts[tf] = len(edge)
    X[[gene_index[g] for g in edge["target_genesymbol"]], j] = (
        edge["mor"].to_numpy() / np.sqrt(len(edge))
    )
assert np.allclose(np.sqrt((X ** 2).sum(axis=0)), 1.0)

# Locked top-20 pathway membership yields a gene-level readout weighted by the
# previously estimated pathway support influence; no KO result enters weights.
membership = pd.read_csv(MECH / "core_genes/top20_pathway_gene_membership.tsv", sep="\t")
gene_support = membership.groupby("gene")["pathway_support_influence"].sum()
program_weights = np.array([gene_support.get(gene, 0.0) for gene in genes], dtype=float)
program_weights /= program_weights.sum()
program_gene_mask = program_weights > 0

core = pd.read_csv(MECH / "core_genes/tier1_core_genes.tsv", sep="\t")["gene"].tolist()
core_weights = np.array([1.0 if gene in core else 0.0 for gene in genes])
core_weights /= core_weights.sum()
core_gene_mask = core_weights > 0

# Select ridge penalty by fixed 10-fold CV, then freeze it for all interventions,
# bootstraps, and network-null rewirings.
cv = KFold(n_splits=10, shuffle=True, random_state=SEED)
ridge_cv = RidgeCV(alphas=ALPHAS, cv=cv, scoring="neg_mean_squared_error", fit_intercept=True)
ridge_cv.fit(X, y)
alpha = float(ridge_cv.alpha_)
model = Ridge(alpha=alpha, fit_intercept=True).fit(X, y)
predicted = model.predict(X)
cv_predicted = cross_val_predict(Ridge(alpha=alpha), X, y, cv=cv)

observed_program = weighted_score(y, program_weights)
baseline_program = weighted_score(predicted, program_weights)
observed_core = weighted_score(y, core_weights)
baseline_core = weighted_score(predicted, core_weights)

# Single-variable intervention: remove only the selected TF contribution.
single_rows = []
single_effects = []
core_effects = []
for j, tf in enumerate(CANDIDATES):
    ko_prediction = predicted - X[:, j] * model.coef_[j]
    ko_program = weighted_score(ko_prediction, program_weights)
    ko_core = weighted_score(ko_prediction, core_weights)
    reduction = baseline_program - ko_program
    core_reduction = baseline_core - ko_core
    single_effects.append(reduction)
    core_effects.append(core_reduction)
    single_rows.append({
        "TF": tf,
        "intervention": f"KO_{tf}",
        "measured_regulon_targets": target_counts[tf],
        "ridge_coefficient": model.coef_[j],
        "baseline_predicted_driver_score": baseline_program,
        "KO_predicted_driver_score": ko_program,
        "driver_program_reduction": reduction,
        "KO_minus_baseline_percent_change_vs_abs_baseline": -100 * reduction / abs(baseline_program),
        "baseline_predicted_core_score": baseline_core,
        "KO_predicted_core_score": ko_core,
        "core_program_reduction": core_reduction,
    })
single_effects = np.asarray(single_effects)

# Gene-row bootstrap refits the frozen-alpha model, then evaluates effects on the
# original fixed network/readout.  This measures sampling/attribution stability.
bootstrap_effects = np.empty((BOOTSTRAPS, len(CANDIDATES)), dtype=float)
bootstrap_core_effects = np.empty_like(bootstrap_effects)
for b in range(BOOTSTRAPS):
    sample = rng.integers(0, len(genes), len(genes))
    boot_model = Ridge(alpha=alpha, fit_intercept=True).fit(X[sample], y[sample])
    for j in range(len(CANDIDATES)):
        bootstrap_effects[b, j] = weighted_score(
            X[:, j] * boot_model.coef_[j], program_weights
        )
        bootstrap_core_effects[b, j] = weighted_score(
            X[:, j] * boot_model.coef_[j], core_weights
        )

# Degree- and sign-preserving null: permute the gene positions of each full TF
# column independently, refit the same model, and retain the largest positive KO
# effect across all five candidates for selection-aware inference.
null_effects = np.empty((NULL_REWIRES, len(CANDIDATES)), dtype=float)
for b in range(NULL_REWIRES):
    X_null = np.column_stack([rng.permutation(X[:, j]) for j in range(len(CANDIDATES))])
    null_model = Ridge(alpha=alpha, fit_intercept=True).fit(X_null, y)
    null_effects[b] = np.array([
        weighted_score(X_null[:, j] * null_model.coef_[j], program_weights)
        for j in range(len(CANDIDATES))
    ])
max_positive_null = np.maximum(null_effects.max(axis=1), 0.0)

single = pd.DataFrame(single_rows)
single["bootstrap_CI025"] = np.quantile(bootstrap_effects, 0.025, axis=0)
single["bootstrap_CI975"] = np.quantile(bootstrap_effects, 0.975, axis=0)
single["bootstrap_probability_reduction_gt_0"] = (bootstrap_effects > 0).mean(axis=0)
single["core_bootstrap_CI025"] = np.quantile(bootstrap_core_effects, 0.025, axis=0)
single["core_bootstrap_CI975"] = np.quantile(bootstrap_core_effects, 0.975, axis=0)
single["network_null_p_one_sided"] = [
    (1 + np.sum(null_effects[:, j] >= effect)) / (NULL_REWIRES + 1)
    for j, effect in enumerate(single_effects)
]
single["max5_network_null_p"] = [
    (1 + np.sum(max_positive_null >= effect)) / (NULL_REWIRES + 1)
    for effect in single_effects
]
single["strict_screen_pass"] = (
    single["driver_program_reduction"].gt(0)
    & single["bootstrap_probability_reduction_gt_0"].ge(STRICT_BOOTSTRAP_PROBABILITY)
    & single["max5_network_null_p"].lt(STRICT_MAX_NULL_P)
)
single["result_scope"] = "exploratory_computational_intervention"
single = single.sort_values("driver_program_reduction", ascending=False).reset_index(drop=True)
single.to_csv(OUT / "single_tf_virtual_knockout.tsv", sep="\t", index=False)

bootstrap_long = pd.DataFrame({
    "bootstrap": np.repeat(np.arange(1, BOOTSTRAPS + 1), len(CANDIDATES)),
    "TF": np.tile(CANDIDATES, BOOTSTRAPS),
    "driver_program_reduction": bootstrap_effects.ravel(),
    "core_program_reduction": bootstrap_core_effects.ravel(),
})
bootstrap_long.to_csv(OUT / "bootstrap_virtual_knockout.tsv.gz", sep="\t", index=False)
null_long = pd.DataFrame({
    "rewire": np.repeat(np.arange(1, NULL_REWIRES + 1), len(CANDIDATES)),
    "TF": np.tile(CANDIDATES, NULL_REWIRES),
    "null_driver_program_reduction": null_effects.ravel(),
})
null_long.to_csv(OUT / "random_network_null.tsv.gz", sep="\t", index=False)

# Predeclared staged rule: a pair is evaluated only if at least two single KOs
# pass the strict screen.  The linear fixed-coefficient model is additive, so the
# pair is a combination estimate, not a synergy test.
passing = single.loc[single["strict_screen_pass"], "TF"].tolist()
pair_rows = []
if len(passing) >= 2:
    top_pair = passing[:2]
    indices = [CANDIDATES.index(tf) for tf in top_pair]
    pair_reduction = float(single_effects[indices].sum())
    pair_boot = bootstrap_effects[:, indices].sum(axis=1)
    pair_rows.append({
        "intervention": "KO_" + "_KO_".join(top_pair),
        "TFs": ";".join(top_pair),
        "selection_rule": "top_two_strict_single_KO_passes",
        "driver_program_reduction": pair_reduction,
        "bootstrap_CI025": np.quantile(pair_boot, 0.025),
        "bootstrap_CI975": np.quantile(pair_boot, 0.975),
        "bootstrap_probability_reduction_gt_0": (pair_boot > 0).mean(),
        "synergy_estimable": False,
    })
pd.DataFrame(pair_rows, columns=[
    "intervention", "TFs", "selection_rule", "driver_program_reduction",
    "bootstrap_CI025", "bootstrap_CI975", "bootstrap_probability_reduction_gt_0",
    "synergy_estimable",
]).to_csv(OUT / "pair_virtual_knockout.tsv", sep="\t", index=False)

# Pathway-resolved effects for interpretation, not extra hypothesis tests.
pathway_rows = []
for pathway, group in membership.groupby("pathway", sort=False):
    indices = np.array([gene_index[g] for g in group["gene"].unique() if g in gene_index])
    if not len(indices):
        continue
    baseline = float(predicted[indices].mean())
    for j, tf in enumerate(CANDIDATES):
        effect = float((X[indices, j] * model.coef_[j]).mean())
        pathway_rows.append({
            "pathway": pathway,
            "TF": tf,
            "measured_pathway_genes": len(indices),
            "baseline_predicted_pathway_score": baseline,
            "KO_predicted_pathway_score": baseline - effect,
            "pathway_score_reduction": effect,
        })
pd.DataFrame(pathway_rows).to_csv(
    OUT / "pathway_virtual_knockout_effects.tsv", sep="\t", index=False
)

# Required execution matrix and resource estimate.
matrix_rows = [{
    "stage": 1, "run_id": "baseline", "intervention": "none",
    "variables_changed": 0, "status": "completed",
    "primary_readout": "predicted_top20_driver_program_score",
}]
for tf in CANDIDATES:
    matrix_rows.append({
        "stage": 1, "run_id": f"single_KO_{tf}", "intervention": f"KO_{tf}",
        "variables_changed": 1, "status": "completed",
        "primary_readout": "baseline_minus_KO_driver_program_score",
    })
matrix_rows.append({
    "stage": 2, "run_id": "pair_KO_contingent", "intervention": "top_two_strict_passes",
    "variables_changed": 2, "status": "completed" if len(pair_rows) else "not_triggered",
    "primary_readout": "additive_combination_reduction_no_synergy_claim",
})
pd.DataFrame(matrix_rows).to_csv(OUT / "experiment_matrix.tsv", sep="\t", index=False)

elapsed = time.perf_counter() - started
model_summary = pd.DataFrame([{
    "genes_modeled": len(genes),
    "program_genes_measured": int(program_gene_mask.sum()),
    "tier1_core_genes_measured": int(core_gene_mask.sum()),
    "candidate_TFs": len(CANDIDATES),
    "selected_ridge_alpha": alpha,
    "in_sample_R2": r2_score(y, predicted),
    "tenfold_CV_R2": r2_score(y, cv_predicted),
    "in_sample_RMSE": mean_squared_error(y, predicted) ** 0.5,
    "observed_driver_program_score": observed_program,
    "baseline_predicted_driver_program_score": baseline_program,
    "observed_core_program_score": observed_core,
    "baseline_predicted_core_program_score": baseline_core,
    "gene_bootstraps": BOOTSTRAPS,
    "degree_sign_preserving_network_rewires": NULL_REWIRES,
    "strict_bootstrap_probability_threshold": STRICT_BOOTSTRAP_PROBABILITY,
    "strict_max5_network_null_p_threshold": STRICT_MAX_NULL_P,
    "strict_single_KO_passes": int(single["strict_screen_pass"].sum()),
    "pair_stage_triggered": bool(pair_rows),
    "runtime_seconds": elapsed,
    "estimated_peak_memory_MB": 80,
    "hardware_requirement": "CPU_only",
}])
model_summary.to_csv(OUT / "virtual_knockout_model_summary.tsv", sep="\t", index=False)

summary = pd.DataFrame([{
    "analysis_scope": "exploratory_computational_virtual_knockout",
    "lead_reduction_TF": single.iloc[0]["TF"],
    "lead_driver_program_reduction": single.iloc[0]["driver_program_reduction"],
    "lead_bootstrap_probability_positive": single.iloc[0]["bootstrap_probability_reduction_gt_0"],
    "lead_max5_network_null_p": single.iloc[0]["max5_network_null_p"],
    "strict_screen_pass_TFs": ";".join(single.loc[single["strict_screen_pass"], "TF"]),
    "strict_screen_pass_count": int(single["strict_screen_pass"].sum()),
    "pair_stage_triggered": bool(pair_rows),
    "biological_validation_required": True,
}])
summary.to_csv(OUT / "virtual_knockout_summary.tsv", sep="\t", index=False)

# Compact effect plot with bootstrap intervals and strict-screen status.
plot = single.sort_values("driver_program_reduction")
fig, ax = plt.subplots(figsize=(9, 5.5))
colors = ["#2A9D8F" if flag else "#9AA0A6" for flag in plot["strict_screen_pass"]]
ax.barh(plot["TF"], plot["driver_program_reduction"], color=colors)
ax.errorbar(
    plot["driver_program_reduction"], plot["TF"],
    xerr=np.vstack([
        plot["driver_program_reduction"] - plot["bootstrap_CI025"],
        plot["bootstrap_CI975"] - plot["driver_program_reduction"],
    ]),
    fmt="none", ecolor="#333333", capsize=3, linewidth=1.2,
)
ax.axvline(0, color="black", linewidth=0.8)
ax.set_xlabel("Predicted driver-program reduction after virtual KO")
ax.set_title("APC candidate TF virtual knockouts\nfixed-coefficient signed-network ridge model")
ax.grid(axis="x", alpha=0.2)
fig.tight_layout()
fig.savefig(FIG / "single_TF_virtual_knockout_effects.png", dpi=180)
plt.close(fig)

print(model_summary.to_string(index=False))
print(single[[
    "TF", "driver_program_reduction", "bootstrap_CI025", "bootstrap_CI975",
    "bootstrap_probability_reduction_gt_0", "max5_network_null_p", "strict_screen_pass",
]].to_string(index=False))
