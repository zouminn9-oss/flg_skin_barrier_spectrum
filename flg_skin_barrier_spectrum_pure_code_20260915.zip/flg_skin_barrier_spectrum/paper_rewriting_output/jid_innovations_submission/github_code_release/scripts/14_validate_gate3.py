#!/usr/bin/env python3

from pathlib import Path
import hashlib
import pandas as pd

root = Path(__file__).resolve().parents[1]

def read(rel):
    p = root / rel
    if not p.exists() or p.stat().st_size == 0:
        raise AssertionError(f"Missing or empty: {rel}")
    return pd.read_csv(p, sep="\t")

meta = read("results/tables/pathway_meta/pathway_meta_summary.tsv")
assert set(meta["disease"]) == {"AD", "ACD", "PSORIASIS", "HS"}
assert (meta["FDR_005"] == 0).all()

emt = read("results/tables/direct_comparison/E-MTAB-9501_direct_summary.tsv").iloc[0]
assert int(emt["raw_files"]) == 48
assert int(emt["qc_pass_channels"]) == 88
assert int(emt["n_ACD"]) == 34 and int(emt["n_ICD"]) == 41

sc = read("results/tables/single_cell_validation/GSE267929_pseudobulk_summary.tsv")
main = sc.loc[sc["analysis"] == "all_cells"].iloc[0]
assert int(main["paired_donors"]) == 5

sim = read("results/tables/similarity/AD_ACD_background_specificity.tsv").iloc[0]
assert bool(sim["exceeds_threshold"])
shared = read("results/tables/similarity/AD_ACD_shared_meta_pathways.tsv")
assert shared.empty

axis_c = read("results/tables/axis_tests/axis_c_adaptive_module_sensitivity.tsv")
emt_main = axis_c[(axis_c["dataset"] == "E-MTAB-9501") & (axis_c["sensitivity"] == "main")].iloc[0]
assert not bool(emt_main["passes_direction_and_fdr"])
gse_lodo = axis_c[(axis_c["dataset"] == "GSE267929") & axis_c["sensitivity"].str.contains("leave_out")]
assert (~gse_lodo["passes_direction_and_fdr"]).any()

report = (root / "GATE3_TRANSCRIPTOMIC_REPORT.md").read_text()
for phrase in ("0 of 3 frozen axes pass", "A — AD–IV barrier", "B — AD–ACD shared axis",
               "C — ACD–ICD distinction", "NEGATIVE"):
    assert phrase in report

assert not (root / "data/raw/platforms/GPL21185/GPL21185.soft").exists()

manifest_rows = []
for base in (root / "results", root / "scripts"):
    for p in sorted(base.rglob("*")):
        if p.is_file() and not p.name.startswith("._"):
            manifest_rows.append({
                "path": str(p.relative_to(root)),
                "bytes": p.stat().st_size,
                "sha256": hashlib.sha256(p.read_bytes()).hexdigest(),
            })
pd.DataFrame(manifest_rows).to_csv(root / "records/gate3_output_manifest.tsv", sep="\t", index=False)
print(f"GATE3_VALIDATION_OK files={len(manifest_rows)} decision=NEGATIVE axes_passed=0")
