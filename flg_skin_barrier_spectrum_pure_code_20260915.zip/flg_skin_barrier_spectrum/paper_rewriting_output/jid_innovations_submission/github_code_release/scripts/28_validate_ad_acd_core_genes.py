#!/usr/bin/env python3
import csv
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "results/exploratory_snf/selected_positive_reml_z_q05/optimized_AD_ACD_branch/mechanism/core_genes"


def rows(path):
    with path.open(newline="") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


summary = rows(OUT / "core_gene_summary.tsv")[0]
assert int(summary["top_driver_pathways"]) == 20
assert int(summary["unique_pathway_genes"]) == 525
assert int(summary["genes_in_at_least_5_pathways"]) == 58
assert int(summary["recurrent_genes_available_all5"]) == 56
assert int(summary["tier1_all5_positive_genes"]) == 16
assert int(summary["tier1_positive_in_both_disease_meta"]) == 16
assert int(summary["tier1_significant_in_both_disease_meta"]) == 0

tier1 = rows(OUT / "tier1_core_genes.tsv")
expected = {"RPA1", "RPA3", "PCNA", "UBA52", "UBB", "POLD1", "POLD3", "POLD4",
            "POLE2", "BRCA1", "ATR", "ATRIP", "BLM", "EXO1", "RAD51", "CDK2"}
assert {r["gene"] for r in tier1} == expected
assert all(int(r["positive_cohorts"]) == 5 for r in tier1)
assert all(float(r["AD_meta_logFC"]) > 0 and float(r["ACD_meta_logFC"]) > 0 for r in tier1)

ranking = rows(OUT / "core_gene_ranking.tsv")
assert len(ranking) == 525
assert ranking[0]["gene"] == "RPA1"
assert int(ranking[0]["top20_pathway_count"]) == 15

loo = rows(OUT / "leave_one_cohort_out_direction_validation.tsv")
assert len(loo) == 5
assert all(float(r["held_out_positive_rate"]) >= 0.80 for r in loo)
assert all(float(r["binomial_q_BH_5cohorts"]) < 0.01 for r in loo)

figure = OUT / "figures/tier1_core_gene_cohort_heatmap.png"
assert figure.stat().st_size > 30_000
report = (ROOT / "AD_ACD_CORE_GENE_REPORT.md").read_text()
for phrase in ("RPA1", "16/16", "80%", "没有任何基因", "程序级探索性复现"):
    assert phrase in report

print("PASS: AD–ACD core-gene ranking, cohort directions, LOCO audit, heatmap, and report are consistent")
