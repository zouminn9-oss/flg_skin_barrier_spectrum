#!/usr/bin/env python3
"""Package the user-directed post-hoc exploratory Gate 4 positive branch."""

from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
LOCAL_PACKAGES = ROOT / "environment/python_packages"
if LOCAL_PACKAGES.exists():
    sys.path.insert(0, str(LOCAL_PACKAGES))

import pandas as pd


BASE = ROOT / "results/exploratory_snf/selected_positive_reml_z_q05"
OPT = BASE / "optimized_AD_ACD_branch"
MECH = OPT / "mechanism"
CD = MECH / "lincs_full_background_calibration/JNJ7706621_FULL_BACKGROUND_DISPOSITION.json"
OUT = ROOT / "results/posthoc_exploratory_gate4_positive_branch"
OUT.mkdir(parents=True, exist_ok=True)

DISCOVERY_NODES = ["AD", "ACD", "ICD", "PSORIASIS", "ACNE", "ROSACEA", "HS"]


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


summary_path = OPT / "optimized_snf_summary.tsv"
edge_path = OPT / "optimized_edge_statistics.tsv"
support_path = OPT / "optimized_cluster_support.tsv"
coclustering_path = OPT / "optimized_bootstrap_coclustering.tsv"
fused_path = OPT / "optimized_fused_similarity.tsv"
grid_path = BASE / "parameter_grid/snf_parameter_grid.tsv"
feature_path = BASE / "snf_positive_pathway_feature_matrix.tsv"
upstream_script = ROOT / "scripts/22_run_optimized_ad_acd_snf.R"
protocol_path = ROOT / "POSTHOC_EXPLORATORY_GATE4_POSITIVE_BRANCH_PROTOCOL.md"
plan_path = ROOT / "gate12_snapshot/05_analysis_plan.md"
gate3_manifest_path = ROOT / "records/gate3_output_manifest.tsv"

summary_table = pd.read_csv(summary_path, sep="\t")
if len(summary_table) != 1:
    raise ValueError("optimized_snf_summary.tsv must contain exactly one selected branch")
summary = summary_table.iloc[0]
edges = pd.read_csv(edge_path, sep="\t")
support = pd.read_csv(support_path, sep="\t").set_index("disease")
grid = pd.read_csv(grid_path, sep="\t")
features = pd.read_csv(feature_path, sep="\t")
jnj = json.loads(CD.read_text())

target_rows = edges.loc[
    ((edges["disease_1"] == "AD") & (edges["disease_2"] == "ACD"))
    | ((edges["disease_1"] == "ACD") & (edges["disease_2"] == "AD"))
]
if len(target_rows) != 1:
    raise ValueError("optimized edge table must contain exactly one AD-ACD edge")
target = target_rows.iloc[0]

entry = pd.DataFrame([
    {"check": "complete_branch_grid", "observed": len(grid), "threshold": "=396", "passed": len(grid) == 396},
    {"check": "selection_adjusted_permutation", "observed": summary["AD_ACD_selection_adjusted_p_500"], "threshold": "<0.05", "passed": summary["AD_ACD_selection_adjusted_p_500"] < 0.05},
    {"check": "nominal_permutation_BH", "observed": target["nominal_permutation_q"], "threshold": "<0.05", "passed": target["nominal_permutation_q"] < 0.05},
    {"check": "same_observed_cluster", "observed": bool(target["same_cluster"]), "threshold": "=true", "passed": bool(target["same_cluster"])},
    {"check": "AD_ACD_bootstrap_coclustering", "observed": target["bootstrap_coclustering"], "threshold": ">=0.75", "passed": target["bootstrap_coclustering"] >= 0.75},
    {"check": "AD_cluster_support", "observed": support.loc["AD", "bootstrap_cluster_support"], "threshold": ">=0.75", "passed": support.loc["AD", "bootstrap_cluster_support"] >= 0.75},
    {"check": "ACD_cluster_support", "observed": support.loc["ACD", "bootstrap_cluster_support"], "threshold": ">=0.75", "passed": support.loc["ACD", "bootstrap_cluster_support"] >= 0.75},
])
entry.to_csv(OUT / "positive_branch_entry_audit.tsv", sep="\t", index=False)

feature_nodes = [column for column in features.columns if column != "pathway"]
transcriptomic_complete = set(feature_nodes) == set(DISCOVERY_NODES)
coverage = pd.DataFrame([
    {
        "layer_id": 1,
        "layer": "transcriptomic_pathway",
        "planned_weight": 0.40,
        "discovery_nodes_with_comparable_features": len(feature_nodes),
        "covered_discovery_nodes": ";".join(feature_nodes),
        "total_discovery_nodes": len(DISCOVERY_NODES),
        "coverage_fraction": len(feature_nodes) / len(DISCOVERY_NODES),
        "complete_7_node_comparable_feature_matrix_available": transcriptomic_complete,
        "eligible_for_complete_fusion": transcriptomic_complete,
        "evidence": f"selected-positive REML-z pathway feature matrix; {len(features):,} pathways; four transcriptomic views",
        "evidence_source_paths": str(feature_path.relative_to(ROOT)),
        "limitation": "outcome-selected post-hoc transcriptomic branch",
        "missing_value_handling": "none_required_for_node_coverage",
    },
    {
        "layer_id": 2,
        "layer": "GWAS_QTL_colocalization",
        "planned_weight": 0.30,
        "discovery_nodes_with_comparable_features": 1,
        "covered_discovery_nodes": "AD",
        "total_discovery_nodes": len(DISCOVERY_NODES),
        "coverage_fraction": 1 / len(DISCOVERY_NODES),
        "complete_7_node_comparable_feature_matrix_available": False,
        "eligible_for_complete_fusion": False,
        "evidence": "AD-only GWAS metadata and a frozen harmonization protocol; no executed seven-node QTL/colocalization matrix",
        "evidence_source_paths": "data/raw/gwas_metadata/GCST90503108.tsv.gz-meta.yaml;data/raw/gwas_metadata/GCST90503109.tsv.gz-meta.yaml;data/raw/gwas_metadata/GCST90503110.tsv.gz-meta.yaml;data/raw/gwas_metadata/GCST90503111.tsv.gz-meta.yaml;records/gwas_harmonization_protocol.md",
        "limitation": "no harmonized comparable GWAS/QTL/colocalization features across all seven discovery diseases",
        "missing_value_handling": "not_filled_not_imputed",
    },
    {
        "layer_id": 3,
        "layer": "direct_genetic_functional",
        "planned_weight": 0.20,
        "discovery_nodes_with_comparable_features": 1,
        "covered_discovery_nodes": "AD",
        "total_discovery_nodes": len(DISCOVERY_NODES),
        "coverage_fraction": 1 / len(DISCOVERY_NODES),
        "complete_7_node_comparable_feature_matrix_available": False,
        "eligible_for_complete_fusion": False,
        "evidence": "direct FLG family/functional anchor is specific to the IV/AD framing",
        "evidence_source_paths": "gate12_snapshot/05_analysis_plan.md;GATE3_TRANSCRIPTOMIC_REPORT.md",
        "limitation": "IV is an anchor outside the seven discovery disease nodes; no comparable seven-node feature matrix exists",
        "missing_value_handling": "not_filled_not_imputed",
    },
    {
        "layer_id": 4,
        "layer": "network_cell_spatial",
        "planned_weight": 0.10,
        "discovery_nodes_with_comparable_features": 2,
        "covered_discovery_nodes": "AD;ACD",
        "total_discovery_nodes": len(DISCOVERY_NODES),
        "coverage_fraction": 2 / len(DISCOVERY_NODES),
        "complete_7_node_comparable_feature_matrix_available": False,
        "eligible_for_complete_fusion": False,
        "evidence": "AD-ACD selected-core regulatory network and APC cell-compartment localization follow-up",
        "evidence_source_paths": "results/exploratory_snf/selected_positive_reml_z_q05/optimized_AD_ACD_branch/mechanism/apc_regulator_network/candidate_regulator_core_edges.tsv;results/exploratory_snf/selected_positive_reml_z_q05/optimized_AD_ACD_branch/mechanism/single_cell_localization/single_cell_localization_summary.tsv",
        "limitation": "mechanistic follow-up is not a comparable network/cell/spatial feature layer across all seven diseases",
        "missing_value_handling": "not_filled_not_imputed",
    },
])
coverage.to_csv(OUT / "layer_coverage_audit.tsv", sep="\t", index=False)

candidate = pd.DataFrame([{
    "candidate": "JNJ-7706621",
    "annotation": jnj["full_background_label"],
    "role": "downstream_computational_candidate_annotation_only",
    "used_as_disease_network_layer": False,
    "formal_replication": bool(jnj["formal_replication"]),
    "independent_biological_replication": False,
    "clinical_efficacy_evidence": False,
    "safety_evidence": False,
    "targeted_BH_q": jnj["frozen_targeted_BH_q"],
    "limitation": "may annotate downstream prioritization but cannot supply missing disease-layer coverage or determine Gate 4",
}])
candidate.to_csv(OUT / "downstream_candidate_annotation_audit.tsv", sep="\t", index=False)

transcriptomic_pass = bool(entry["passed"].all())
eligible_layers = int(coverage["eligible_for_complete_fusion"].sum())
multilayer_evaluable = eligible_layers >= 2
if transcriptomic_pass and multilayer_evaluable:
    label = "exploratory_gate4_multilayer_positive"
elif transcriptomic_pass:
    label = "exploratory_gate4_transcriptomic_positive_multilayer_incomplete"
else:
    label = "exploratory_gate4_not_supported"

disposition = {
    "gate": "Gate 4",
    "execution_role": "user_directed_posthoc_exploratory_positive_branch",
    "label": label,
    "entry_disease_network_signal": "optimized_AD_ACD_selected_positive_SNF",
    "entry_drug_signal": jnj["full_background_label"],
    "entry_drug_signal_role": "downstream_computational_candidate_annotation_only",
    "entry_drug_signal_used_as_network_layer": False,
    "branches_screened": int(summary["branches_screened"]),
    "selected_branch_id": str(summary["branch_id"]),
    "selected_branch": str(summary["views"]),
    "selected_K": int(summary["K"]),
    "selected_alpha": float(summary["alpha"]),
    "selected_iterations": int(summary["iterations"]),
    "nominal_permutations": 10_000,
    "bootstrap_replicates": 1_000,
    "selection_adjustment_permutations": int(summary["selection_adjustment_permutations"]),
    "AD_ACD_similarity": float(target["fused_similarity"]),
    "AD_ACD_edge_rank": int(summary["AD_ACD_rank"]),
    "AD_ACD_nominal_permutation_p": float(target["nominal_permutation_p"]),
    "AD_ACD_nominal_permutation_q": float(target["nominal_permutation_q"]),
    "AD_ACD_selection_adjusted_p_500": float(summary["AD_ACD_selection_adjusted_p_500"]),
    "AD_ACD_bootstrap_coclustering": float(target["bootstrap_coclustering"]),
    "AD_cluster_support": float(support.loc["AD", "bootstrap_cluster_support"]),
    "ACD_cluster_support": float(support.loc["ACD", "bootstrap_cluster_support"]),
    "transcriptomic_subgate_checks_passed": int(entry["passed"].sum()),
    "transcriptomic_subgate_checks_total": len(entry),
    "transcriptomic_subgate_pass": transcriptomic_pass,
    "eligible_complete_fusion_layers": eligible_layers,
    "eligible_complete_fusion_layer_names": coverage.loc[coverage["eligible_for_complete_fusion"], "layer"].tolist(),
    "full_multilayer_gate4_evaluable": multilayer_evaluable,
    "missing_layers_imputed": False,
    "thresholds_relaxed_for_gate4": False,
    "confirmatory_gate4": False,
    "formal_replication": False,
    "independent_biological_replication": False,
    "clinical_efficacy_evidence": False,
    "safety_evidence": False,
    "gate3_frozen_decision": "negative_0_of_3_axes",
    "gate3_changed": False,
    "completed_at_utc": datetime.now(timezone.utc).isoformat(),
}
(OUT / "GATE4_DISPOSITION.json").write_text(json.dumps(disposition, indent=2) + "\n")

run_parameters = {
    "protocol": str(protocol_path.relative_to(ROOT)),
    "analysis_plan": str(plan_path.relative_to(ROOT)),
    "discovery_nodes": DISCOVERY_NODES,
    "required_complete_fusion_layers": 2,
    "planned_layer_weights": dict(zip(coverage["layer"], coverage["planned_weight"])),
    "missing_layer_policy": "do_not_fill_zero_do_not_impute_do_not_substitute_drug_annotation",
    "entry_thresholds": {
        "branches": 396,
        "selection_adjusted_p": "<0.05",
        "nominal_permutation_BH_q": "<0.05",
        "same_cluster": True,
        "bootstrap_coclustering": ">=0.75",
        "node_cluster_support": ">=0.75",
    },
    "upstream_resampling": {"nominal_permutations": 10_000, "bootstraps": 1_000, "selection_adjustment_permutations": 500},
}
(OUT / "RUN_PARAMETERS.json").write_text(json.dumps(run_parameters, indent=2) + "\n")

source_paths = [
    summary_path, edge_path, support_path, coclustering_path, fused_path, grid_path,
    feature_path, CD, upstream_script, protocol_path, plan_path, gate3_manifest_path,
    ROOT / "GATE3_TRANSCRIPTOMIC_REPORT.md",
    ROOT / "data/raw/gwas_metadata/GCST90503108.tsv.gz-meta.yaml",
    ROOT / "data/raw/gwas_metadata/GCST90503109.tsv.gz-meta.yaml",
    ROOT / "data/raw/gwas_metadata/GCST90503110.tsv.gz-meta.yaml",
    ROOT / "data/raw/gwas_metadata/GCST90503111.tsv.gz-meta.yaml",
    ROOT / "records/gwas_harmonization_protocol.md",
    ROOT / "results/exploratory_snf/selected_positive_reml_z_q05/optimized_AD_ACD_branch/mechanism/apc_regulator_network/candidate_regulator_core_edges.tsv",
    ROOT / "results/exploratory_snf/selected_positive_reml_z_q05/optimized_AD_ACD_branch/mechanism/single_cell_localization/single_cell_localization_summary.tsv",
]
sources = {
    str(path.relative_to(ROOT)): {"sha256": sha256(path), "bytes": path.stat().st_size}
    for path in source_paths
}
(OUT / "SOURCE_MANIFEST.json").write_text(json.dumps(sources, indent=2) + "\n")
print(json.dumps(disposition, indent=2))
