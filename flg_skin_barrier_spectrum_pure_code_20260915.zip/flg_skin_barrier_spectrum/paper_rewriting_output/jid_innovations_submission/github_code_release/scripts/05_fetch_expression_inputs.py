#!/usr/bin/env python3
"""Fetch author-provided GEO expression inputs with atomic writes and checksums."""

import csv
import datetime as dt
import hashlib
import pathlib
import shutil
import time
import urllib.request


ROOT = pathlib.Path(__file__).resolve().parents[1]
DEST = ROOT / "data" / "raw" / "expression" / "geo"
MANIFEST = ROOT / "records" / "expression_download_manifest.tsv"

ACCESSIONS = [
    "GSE121212", "GSE32924", "GSE36842", "GSE6281", "GSE282562", "GSE18206",
    "GSE13355", "GSE53795", "GSE65914", "GSE137141", "GSE72702",
]
SUPPLEMENTARY = {
    "GSE121212": ["GSE121212_readcount.txt.gz"],
    "GSE282562": ["GSE282562_CountsTable.csv.gz"],
}


def prefix(accession):
    return accession[:-3] + "nnn"


def digest(path):
    value = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def fetch(url, path):
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists() or path.stat().st_size == 0:
        temporary = path.with_suffix(path.suffix + ".part")
        error = None
        for attempt in range(1, 7):
            request = urllib.request.Request(url, headers={"User-Agent": "flg-gate3-expression/1.0"})
            try:
                with urllib.request.urlopen(request, timeout=300) as response, temporary.open("wb") as output:
                    shutil.copyfileobj(response, output)
                temporary.replace(path)
                error = None
                break
            except Exception as current:
                error = current
                if temporary.exists(): temporary.unlink()
                if attempt < 6: time.sleep(2 ** (attempt - 1))
        if error is not None: raise error
    return {"url": url, "path": str(path.relative_to(ROOT)), "bytes": path.stat().st_size,
            "sha256": digest(path), "downloaded_utc": dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat()}


def main():
    rows = []
    for accession in ACCESSIONS:
        base = f"https://ftp.ncbi.nlm.nih.gov/geo/series/{prefix(accession)}/{accession}"
        filename = f"{accession}_series_matrix.txt.gz"
        rows.append(fetch(f"{base}/matrix/{filename}", DEST / accession / filename))
        for filename in SUPPLEMENTARY.get(accession, []):
            rows.append(fetch(f"{base}/suppl/{filename}", DEST / accession / filename))
    with MANIFEST.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, delimiter="\t", fieldnames=list(rows[0]))
        writer.writeheader(); writer.writerows(rows)
    print(f"EXPRESSION_FETCH_OK files={len(rows)} bytes={sum(row['bytes'] for row in rows)}")


if __name__ == "__main__":
    main()

