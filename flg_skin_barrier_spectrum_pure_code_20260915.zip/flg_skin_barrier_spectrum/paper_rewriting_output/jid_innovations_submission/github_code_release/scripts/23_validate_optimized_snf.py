#!/usr/bin/env python3
import csv
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "results/exploratory_snf/selected_positive_reml_z_q05"
OUT = BASE / "optimized_AD_ACD_branch"


def rows(path):
    with path.open(newline="") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


summary = rows(OUT / "optimized_snf_summary.tsv")[0]
assert summary["branch_id"] == "B0073"
assert summary["views"] == "all_positive+stress_damage"
assert int(float(summary["K"])) == 2
assert abs(float(summary["alpha"]) - 0.2) < 1e-12
assert int(float(summary["iterations"])) == 10
assert int(summary["branches_screened"]) == 396
assert int(summary["selected_k"]) == 3
assert int(summary["AD_ACD_rank"]) == 3
assert float(summary["AD_ACD_nominal_q"]) < 0.001
assert float(summary["AD_ACD_selection_adjusted_p_500"]) < 0.05
assert float(summary["AD_ACD_bootstrap_coclustering"]) == 1.0
assert summary["AD_ACD_same_cluster"] == "TRUE"

edges = rows(OUT / "optimized_edge_statistics.tsv")
significant = [r for r in edges if float(r["nominal_permutation_q"]) < 0.05]
assert len(significant) == 7
target = next(r for r in edges if {r["disease_1"], r["disease_2"]} == {"AD", "ACD"})
assert 0.216 < float(target["bootstrap_ci_low"]) < float(target["fused_similarity"])
assert float(target["bootstrap_ci_high"]) > float(target["fused_similarity"])

clusters = {r["disease"]: int(r["cluster"]) for r in rows(OUT / "optimized_cluster_support.tsv")}
assert clusters["AD"] == clusters["ACD"]
assert clusters["PSORIASIS"] == clusters["ACNE"]
assert clusters["HS"] == clusters["ROSACEA"] == clusters["ICD"]
assert len(set(clusters.values())) == 3

grid_best = rows(BASE / "parameter_grid/snf_most_favorable_AD_ACD_branch.tsv")[0]
for key in ("branch_id", "views", "K", "alpha", "iterations"):
    assert grid_best[key] == summary[key], (key, grid_best[key], summary[key])

figure = OUT / "figures/optimized_AD_ACD_network.png"
assert figure.stat().st_size > 10_000
report = (ROOT / "OPTIMIZED_AD_ACD_SNF_REPORT.md").read_text()
for phrase in ("选择校正 p=0.00998", "AD–ACD", "396", "1.000"):
    assert phrase in report

print("PASS: optimized AD–ACD SNF outputs, provenance, figure, and report are internally consistent")
