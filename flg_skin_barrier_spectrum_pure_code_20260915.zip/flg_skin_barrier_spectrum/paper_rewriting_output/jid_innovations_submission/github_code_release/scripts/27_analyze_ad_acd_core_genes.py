#!/usr/bin/env python3
"""Map the top AD–ACD pathway drivers to recurrent genes and audit directions."""

from collections import Counter, defaultdict
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.stats import binomtest


ROOT = Path(__file__).resolve().parents[1]
MECH = ROOT / "results/exploratory_snf/selected_positive_reml_z_q05/optimized_AD_ACD_branch/mechanism"
OUT = MECH / "core_genes"
FIG = OUT / "figures"
OUT.mkdir(parents=True, exist_ok=True)
FIG.mkdir(parents=True, exist_ok=True)

COHORTS = [
    "AD_GSE121212_acute",
    "AD_GSE32924",
    "AD_GSE36842_acute",
    "ACD_GSE282562",
    "ACD_GSE6281_48h",
]


def bh_adjust(values):
    p = np.asarray(values, dtype=float)
    out = np.full(len(p), np.nan)
    ok = np.isfinite(p)
    x = p[ok]
    order = np.argsort(x)
    ranked = x[order]
    q = ranked * len(ranked) / np.arange(1, len(ranked) + 1)
    q = np.minimum.accumulate(q[::-1])[::-1]
    restored = np.empty_like(q)
    restored[order] = np.minimum(q, 1)
    out[np.where(ok)[0]] = restored
    return out


# The top 20 is fixed by the preceding exact leave-one-pathway-out ranking.
top = pd.read_csv(MECH / "top_AD_ACD_pathway_drivers.tsv", sep="\t").head(20)
gmt = {}
with (ROOT / "data/raw/pathways/reactome_v97/ReactomePathways.gmt").open() as handle:
    for line in handle:
        fields = line.rstrip("\n").split("\t")
        gmt[fields[0]] = sorted(set(fields[2:]))
missing = sorted(set(top["pathway"]) - set(gmt))
if missing:
    raise RuntimeError(f"Top pathways missing from Reactome v97 GMT: {missing}")

membership_rows = []
pathway_count = Counter()
weighted_support = defaultdict(float)
gene_pathways = defaultdict(list)
for row in top.itertuples(index=False):
    for gene in gmt[row.pathway]:
        membership_rows.append({
            "pathway": row.pathway,
            "gene": gene,
            "pathway_support_influence": row.support_influence,
        })
        pathway_count[gene] += 1
        weighted_support[gene] += row.support_influence
        gene_pathways[gene].append(row.pathway)
membership = pd.DataFrame(membership_rows)
membership.to_csv(OUT / "top20_pathway_gene_membership.tsv", sep="\t", index=False)

cohort_data = {
    cohort: pd.read_csv(ROOT / f"results/tables/cohort_effects/{cohort}.tsv", sep="\t").set_index("gene")
    for cohort in COHORTS
}
meta_data = {
    disease: pd.read_csv(ROOT / f"results/tables/meta/{disease}_gene_meta.tsv", sep="\t").set_index("gene")
    for disease in ("AD", "ACD")
}

long_rows = []
ranking_rows = []
for gene in sorted(pathway_count):
    effects = []
    fdrs = []
    record = {
        "gene": gene,
        "top20_pathway_count": pathway_count[gene],
        "weighted_pathway_support": weighted_support[gene],
        "member_pathways": ";".join(gene_pathways[gene]),
    }
    for cohort in COHORTS:
        if gene in cohort_data[cohort].index:
            row = cohort_data[cohort].loc[gene]
            effect, fdr, p_value = float(row.logFC), float(row.FDR), float(row.p_value)
            effects.append(effect)
            fdrs.append(fdr)
            long_rows.append({
                "gene": gene,
                "cohort": cohort,
                "disease": "AD" if cohort.startswith("AD_") else "ACD",
                "logFC": effect,
                "p_value": p_value,
                "FDR": fdr,
                "positive": effect > 0,
                "significant_positive": effect > 0 and fdr < 0.05,
            })
            record[f"logFC__{cohort}"] = effect
            record[f"FDR__{cohort}"] = fdr
        else:
            effects.append(np.nan)
            fdrs.append(np.nan)
            record[f"logFC__{cohort}"] = np.nan
            record[f"FDR__{cohort}"] = np.nan

    finite = np.isfinite(effects)
    available = int(finite.sum())
    positive = int(np.sum(np.asarray(effects)[finite] > 0))
    record.update({
        "cohorts_available": available,
        "positive_cohorts": positive,
        "AD_positive_cohorts": int(sum(x > 0 for x in effects[:3] if np.isfinite(x))),
        "ACD_positive_cohorts": int(sum(x > 0 for x in effects[3:] if np.isfinite(x))),
        "significant_positive_cohorts": int(sum(x > 0 and q < 0.05 for x, q in zip(effects, fdrs) if np.isfinite(x))),
        "minimum_logFC": float(np.nanmin(effects)) if available else np.nan,
        "median_logFC": float(np.nanmedian(effects)) if available else np.nan,
        "all_five_positive": available == 5 and positive == 5,
        "direction_sign_test_p_one_sided": (
            float(binomtest(positive, available, 0.5, alternative="greater").pvalue)
            if available else np.nan
        ),
    })
    for disease in ("AD", "ACD"):
        if gene in meta_data[disease].index:
            m = meta_data[disease].loc[gene]
            record[f"{disease}_meta_logFC"] = float(m.meta_logFC)
            record[f"{disease}_meta_FDR"] = float(m.FDR)
        else:
            record[f"{disease}_meta_logFC"] = np.nan
            record[f"{disease}_meta_FDR"] = np.nan

    if record["top20_pathway_count"] >= 5 and record["all_five_positive"]:
        record["evidence_tier"] = "Tier1_recurrent_all5_positive"
    elif record["top20_pathway_count"] >= 5 and available == 5 and positive >= 4:
        record["evidence_tier"] = "Tier2_recurrent_4of5_positive"
    else:
        record["evidence_tier"] = "Other_pathway_member"
    ranking_rows.append(record)

long = pd.DataFrame(long_rows)
long.to_csv(OUT / "core_gene_cohort_effects_long.tsv", sep="\t", index=False)
ranking = pd.DataFrame(ranking_rows)
ranking["direction_sign_test_q_BH"] = bh_adjust(ranking["direction_sign_test_p_one_sided"])
tier_order = {
    "Tier1_recurrent_all5_positive": 0,
    "Tier2_recurrent_4of5_positive": 1,
    "Other_pathway_member": 2,
}
ranking["_tier_order"] = ranking["evidence_tier"].map(tier_order)
ranking = ranking.sort_values(
    ["_tier_order", "top20_pathway_count", "weighted_pathway_support", "positive_cohorts"],
    ascending=[True, False, False, False],
).drop(columns="_tier_order")
ranking.to_csv(OUT / "core_gene_ranking.tsv", sep="\t", index=False)
tier1 = ranking.loc[ranking["evidence_tier"].eq("Tier1_recurrent_all5_positive")].copy()
tier1.to_csv(OUT / "tier1_core_genes.tsv", sep="\t", index=False)

# Leave-one-cohort-out directional replication: select recurrent genes positive
# in all other four cohorts, then inspect the held-out direction.
recurrent = ranking.loc[
    ranking["top20_pathway_count"].ge(5) & ranking["cohorts_available"].eq(5)
].copy()
loo_rows = []
for held_out in COHORTS:
    other = [c for c in COHORTS if c != held_out]
    eligible = recurrent.loc[
        np.logical_and.reduce([recurrent[f"logFC__{c}"].gt(0) for c in other])
    ]
    positive_n = int(eligible[f"logFC__{held_out}"].gt(0).sum())
    tested_n = len(eligible)
    loo_rows.append({
        "held_out_cohort": held_out,
        "disease": "AD" if held_out.startswith("AD_") else "ACD",
        "genes_selected_from_other_four": tested_n,
        "held_out_positive_genes": positive_n,
        "held_out_positive_rate": positive_n / tested_n,
        "binomial_one_sided_p": binomtest(positive_n, tested_n, 0.5, alternative="greater").pvalue,
        "held_out_negative_genes": ";".join(eligible.loc[eligible[f"logFC__{held_out}"].le(0), "gene"]),
    })
loo_validation = pd.DataFrame(loo_rows)
loo_validation["binomial_q_BH_5cohorts"] = bh_adjust(loo_validation["binomial_one_sided_p"])
loo_validation.to_csv(OUT / "leave_one_cohort_out_direction_validation.tsv", sep="\t", index=False)

summary = pd.DataFrame([{
    "top_driver_pathways": len(top),
    "unique_pathway_genes": len(ranking),
    "genes_in_at_least_5_pathways": int(ranking["top20_pathway_count"].ge(5).sum()),
    "recurrent_genes_available_all5": len(recurrent),
    "tier1_all5_positive_genes": len(tier1),
    "tier1_positive_in_both_disease_meta": int(((tier1["AD_meta_logFC"] > 0) & (tier1["ACD_meta_logFC"] > 0)).sum()),
    "tier1_significant_in_both_disease_meta": int(((tier1["AD_meta_FDR"] < 0.05) & (tier1["ACD_meta_FDR"] < 0.05)).sum()),
    "LOCO_min_positive_rate": loo_validation["held_out_positive_rate"].min(),
    "LOCO_max_positive_rate": loo_validation["held_out_positive_rate"].max(),
    "LOCO_all_q_lt_0_05": bool((loo_validation["binomial_q_BH_5cohorts"] < 0.05).all()),
}])
summary.to_csv(OUT / "core_gene_summary.tsv", sep="\t", index=False)

# Heatmap of the Tier 1 genes across the five cohorts.
effect_columns = [f"logFC__{c}" for c in COHORTS]
heat = tier1.set_index("gene")[effect_columns]
heat.columns = [c.replace("_", "\n", 1) for c in COHORTS]
vmax = max(0.5, float(np.nanmax(np.abs(heat.to_numpy()))))
fig, ax = plt.subplots(figsize=(9, 9))
im = ax.imshow(heat.to_numpy(), cmap="RdBu_r", vmin=-vmax, vmax=vmax, aspect="auto")
ax.set_xticks(range(len(heat.columns)))
ax.set_xticklabels(heat.columns, rotation=25, ha="right", fontsize=9)
ax.set_yticks(range(len(heat)))
ax.set_yticklabels([
    f"{gene}  ({int(tier1.set_index('gene').loc[gene, 'top20_pathway_count'])}/20)"
    for gene in heat.index
], fontsize=9)
for i in range(heat.shape[0]):
    for j in range(heat.shape[1]):
        value = heat.iat[i, j]
        ax.text(j, i, f"{value:.2f}", ha="center", va="center", fontsize=7,
                color="white" if abs(value) > vmax * 0.55 else "black")
ax.set_title("Tier 1 recurrent genes: positive direction across all AD/ACD cohorts")
fig.colorbar(im, ax=ax, label="gene logFC", fraction=0.04, pad=0.03)
fig.tight_layout()
fig.savefig(FIG / "tier1_core_gene_cohort_heatmap.png", dpi=180)
plt.close(fig)

print(summary.to_string(index=False))
print("\nTier 1 core genes:")
print(tier1[["gene", "top20_pathway_count", "positive_cohorts", "significant_positive_cohorts", "AD_meta_logFC", "ACD_meta_logFC"]].to_string(index=False))
print("\nLeave-one-cohort-out validation:")
print(loo_validation.to_string(index=False))
