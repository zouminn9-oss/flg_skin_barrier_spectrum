#!/usr/bin/env python3
"""Resume the large official LINCS object with verified parallel byte ranges."""

from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess


ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data/raw/perturbations/lincs_2021_full"
TARGET = RAW / "cp_coeff_mat.gctx"
PREFIX = RAW / "cp_coeff_mat.prefix.part"
SEGMENTS = RAW / "download_segments"
MANIFEST = SEGMENTS / "manifest.json"
ASSEMBLED = RAW / "cp_coeff_mat.gctx.assembled"
URL = "https://lincs-dcic.s3.amazonaws.com/LINCS-sigs-2021/gctx/cd-coefficient/cp_coeff_mat.gctx"
TOTAL_BYTES = 36_084_518_760
N_SEGMENTS = 5
COPY_BLOCK = 16 * 1024 * 1024


RAW.mkdir(parents=True, exist_ok=True)
SEGMENTS.mkdir(parents=True, exist_ok=True)

if TARGET.exists() and TARGET.stat().st_size == TOTAL_BYTES:
    print(f"complete {TARGET} {TOTAL_BYTES}")
    raise SystemExit(0)

if MANIFEST.exists():
    manifest = json.loads(MANIFEST.read_text())
    if manifest["total_bytes"] != TOTAL_BYTES or manifest["url"] != URL:
        raise RuntimeError("Existing download manifest does not match the frozen object")
    if not PREFIX.exists() or PREFIX.stat().st_size != manifest["prefix_bytes"]:
        raise RuntimeError("Saved download prefix does not match its manifest")
else:
    if not TARGET.exists() or not 0 < TARGET.stat().st_size < TOTAL_BYTES:
        raise RuntimeError(f"Expected a partial prefix at {TARGET}")
    os.replace(TARGET, PREFIX)
    prefix_bytes = PREFIX.stat().st_size
    remaining = TOTAL_BYTES - prefix_bytes
    base, extra = divmod(remaining, N_SEGMENTS)
    ranges = []
    start = prefix_bytes
    for index in range(N_SEGMENTS):
        size = base + (1 if index < extra else 0)
        end = start + size - 1
        ranges.append({
            "index": index, "start": start, "end": end, "expected_bytes": size,
            "path": str(SEGMENTS / f"segment_{index:02d}_{start}_{end}.part"),
        })
        start = end + 1
    if start != TOTAL_BYTES:
        raise RuntimeError((start, TOTAL_BYTES))
    manifest = {
        "url": URL, "total_bytes": TOTAL_BYTES, "prefix_bytes": prefix_bytes,
        "segments": ranges,
    }
    MANIFEST.write_text(json.dumps(manifest, indent=2) + "\n")


def download(row):
    path = Path(row["path"])
    if path.exists() and path.stat().st_size == row["expected_bytes"]:
        return row["index"], "checkpoint"
    if path.exists():
        failed = path.with_suffix(path.suffix + ".incomplete")
        os.replace(path, failed)
    command = [
        "curl", "-sS", "-L", "--fail", "--retry", "10", "--retry-all-errors",
        "--speed-limit", "1024", "--speed-time", "60",
        "--range", f"{row['start']}-{row['end']}", "--output", str(path), URL,
    ]
    subprocess.run(command, check=True)
    observed = path.stat().st_size
    if observed != row["expected_bytes"]:
        raise RuntimeError(f"Segment {row['index']} bytes {observed} != {row['expected_bytes']}")
    return row["index"], "downloaded"


print(json.dumps({
    "prefix_bytes": manifest["prefix_bytes"],
    "remaining_bytes": TOTAL_BYTES - manifest["prefix_bytes"],
    "parallel_segments": len(manifest["segments"]),
}, indent=2), flush=True)
with ThreadPoolExecutor(max_workers=N_SEGMENTS) as pool:
    futures = [pool.submit(download, row) for row in manifest["segments"]]
    for future in as_completed(futures):
        index, status = future.result()
        print(f"segment {index}: {status}", flush=True)

digest = hashlib.sha256()
with ASSEMBLED.open("wb") as destination:
    for path in [PREFIX, *[Path(row["path"]) for row in manifest["segments"]]]:
        with path.open("rb") as source:
            while True:
                block = source.read(COPY_BLOCK)
                if not block:
                    break
                destination.write(block)
                digest.update(block)
        print(f"assembled {path.name}", flush=True)

if ASSEMBLED.stat().st_size != TOTAL_BYTES:
    raise RuntimeError(f"Assembled bytes {ASSEMBLED.stat().st_size} != {TOTAL_BYTES}")
os.replace(ASSEMBLED, TARGET)
(SEGMENTS / "assembled_sha256.json").write_text(json.dumps({
    "bytes": TARGET.stat().st_size, "sha256": digest.hexdigest(),
}, indent=2) + "\n")
print(json.dumps({"complete_bytes": TARGET.stat().st_size, "sha256": digest.hexdigest()}, indent=2))

