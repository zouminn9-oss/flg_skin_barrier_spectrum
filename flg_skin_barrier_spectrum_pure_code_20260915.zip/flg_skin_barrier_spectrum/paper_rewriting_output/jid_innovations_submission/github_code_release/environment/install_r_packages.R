project_root <- normalizePath(".")
lib <- file.path(project_root, "environment", "R_libs")
log_dir <- file.path(project_root, "logs")
dir.create(lib, recursive = TRUE, showWarnings = FALSE)
dir.create(log_dir, recursive = TRUE, showWarnings = FALSE)
.libPaths(c(lib, .libPaths()))

options(
  repos = c(CRAN = "https://cloud.r-project.org"),
  Ncpus = max(1L, parallel::detectCores(logical = FALSE) - 1L)
)

if (!requireNamespace("BiocManager", quietly = TRUE)) {
  install.packages("BiocManager", lib = lib)
}

cran <- c("data.table", "ggplot2", "jsonlite", "matrixStats", "metafor")
bioc <- c(
  "AnnotationDbi", "Biobase", "GEOquery", "edgeR", "hgu133plus2.db",
  "limma", "org.Hs.eg.db"
)

missing_cran <- cran[!vapply(cran, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing_cran)) install.packages(missing_cran, lib = lib)

missing_bioc <- bioc[!vapply(bioc, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing_bioc)) {
  BiocManager::install(missing_bioc, lib = lib, ask = FALSE, update = FALSE)
}

required <- c("Matrix", cran, bioc)
missing_after_install <- required[
  !vapply(required, requireNamespace, logical(1), quietly = TRUE)
]
if (length(missing_after_install)) {
  stop("Missing R packages after installation: ", paste(missing_after_install, collapse = ", "))
}

versions <- data.frame(
  package = required,
  version = vapply(required, function(x) as.character(packageVersion(x)), character(1))
)
write.table(
  versions,
  file.path(log_dir, "R_package_versions.tsv"),
  sep = "\t",
  row.names = FALSE,
  quote = FALSE
)
writeLines(capture.output(sessionInfo()), file.path(log_dir, "R_session_after_install.txt"))
