#!/usr/bin/env python3
"""Synchronize manuscript, review copy and file manifest from the current sources."""
from __future__ import annotations

from datetime import datetime, timezone
from hashlib import sha256
from pathlib import Path
import re
import shutil
import subprocess
import tempfile

from docx import Document
from docx.shared import Inches, Pt


HERE = Path(__file__).resolve().parent
MANUSCRIPT = HERE / "manuscript" / "jid_manuscript_anonymized.md"
REVIEW_MD = HERE / "manuscript" / "review_copy.md"
SUPP_MD = HERE / "manuscript" / "supplementary_information.md"
SUPP_DOCX = HERE / "supplementary_information.docx"
AUTHOR_MD = HERE / "manuscript" / "author_details.md"
COVER_MD = HERE / "manuscript" / "cover_letter.md"
REFERENCE = HERE / "archive" / "pre_reconstruction_20260829" / "jid_manuscript_anonymized.docx"
YAML = HERE / "manuscript" / "ref.docx.yaml"
MAIN_DOCX = HERE / "jid_manuscript_anonymized.docx"
REVIEW_DOCX = HERE / "jid_manuscript_review_copy.docx"
REVIEW_PDF = HERE / "jid_manuscript_review_copy.pdf"
AUTHOR_DOCX = HERE / "author_details.docx"
COVER_DOCX = HERE / "cover_letter.docx"
UPLOAD = HERE / "upload_ready"


def run(*args: str):
    subprocess.run(args, check=True)


def scrub_docx(path: Path, title: str, subject: str):
    doc = Document(path)
    props = doc.core_properties
    props.title = title
    props.subject = subject
    props.author = ""
    props.last_modified_by = ""
    props.comments = ""
    props.keywords = ""
    doc.save(path)


def format_cover_letter(path: Path):
    """Keep the journal cover letter within its required one-page format."""
    doc = Document(path)
    for section in doc.sections:
        section.top_margin = Inches(0.65)
        section.bottom_margin = Inches(0.65)
        section.left_margin = Inches(0.75)
        section.right_margin = Inches(0.75)
    normal = doc.styles["Normal"]
    normal.font.size = Pt(10.5)
    normal.paragraph_format.space_after = Pt(4)
    normal.paragraph_format.line_spacing = 1.0
    for paragraph in doc.paragraphs:
        paragraph.paragraph_format.space_after = Pt(4)
        paragraph.paragraph_format.line_spacing = 1.0
        for run in paragraph.runs:
            run.font.size = Pt(10.5)
    doc.save(path)


def make_review_markdown():
    lines = MANUSCRIPT.read_text(encoding="utf-8").splitlines()
    out = []
    in_legends = False
    for line in lines:
        if line == "# Figure Legends":
            in_legends = True
        elif line.startswith("# ") and line != "# Figure Legends":
            in_legends = False
        out.append(line)
        if in_legends:
            m = re.match(r"\*\*Figure ([1-5])\.", line)
            if m:
                out.extend(["", f"![](../figures/figure{m.group(1)}.png)", ""])
    REVIEW_MD.write_text("\n".join(out) + "\n", encoding="utf-8")


def pandoc(source: Path, output: Path):
    run("pandoc", str(source), "--from=gfm", "--to=docx",
        f"--reference-doc={REFERENCE}", f"--metadata-file={YAML}",
        f"--resource-path={HERE / 'manuscript'}:{HERE / 'figures'}",
        "--output", str(output))


def make_manifest():
    files = [
        MAIN_DOCX, AUTHOR_DOCX, COVER_DOCX,
        HERE / "supplementary_information.docx", REVIEW_PDF,
    ]
    for i in list(range(1, 6)) + ["S1"]:
        files.extend([HERE / "figures" / f"figure{i}.{ext}" for ext in ("png", "tif", "pdf")])
    files.extend(sorted(
        p for p in UPLOAD.rglob("*")
        if p.is_file() and not p.name.startswith("._") and "__MACOSX" not in p.parts
    ))
    rows = ["file\tbytes\tsha256"]
    for path in files:
        if path.exists():
            digest = sha256(path.read_bytes()).hexdigest()
            rows.append(f"{path.relative_to(HERE)}\t{path.stat().st_size}\t{digest}")
    rows.append(f"# generated_utc\t{datetime.now(timezone.utc).isoformat()}\t")
    (HERE / "SUBMISSION_FILE_MANIFEST.tsv").write_text("\n".join(rows) + "\n", encoding="utf-8")


def sync_upload_ready():
    (UPLOAD / "figures").mkdir(parents=True, exist_ok=True)
    for path in (MAIN_DOCX, AUTHOR_DOCX, COVER_DOCX,
                 HERE / "supplementary_information.docx"):
        shutil.copy2(path, UPLOAD / path.name)
    for i in list(range(1, 6)) + ["S1"]:
        src = HERE / "figures" / f"figure{i}.tif"
        shutil.copy2(src, UPLOAD / "figures" / src.name)
    (UPLOAD / "README.txt").write_text(
        "JID Innovations upload-ready files.\n"
        "Complete all remaining bracketed metadata/reference/archive placeholders before submission.\n"
        "The review-copy PDF and editable/build sources remain one directory above and are not upload files.\n",
        encoding="utf-8")


def main():
    if not REFERENCE.exists():
        raise FileNotFoundError(f"Reference DOCX missing: {REFERENCE}")
    pandoc(AUTHOR_MD, AUTHOR_DOCX)
    scrub_docx(AUTHOR_DOCX, "Author details — AD–ACD transcriptomic network", "Author details")
    pandoc(COVER_MD, COVER_DOCX)
    format_cover_letter(COVER_DOCX)
    scrub_docx(COVER_DOCX, "Cover letter — AD–ACD transcriptomic network", "Cover letter")
    make_review_markdown()
    pandoc(SUPP_MD, SUPP_DOCX)
    pandoc(MANUSCRIPT, MAIN_DOCX)
    scrub_docx(MAIN_DOCX, "A replication-surveillance transcriptomic network links AD and ACD", "Anonymized manuscript")
    pandoc(REVIEW_MD, REVIEW_DOCX)
    scrub_docx(REVIEW_DOCX, "Review copy — AD–ACD transcriptomic network", "Anonymized review copy")
    with tempfile.TemporaryDirectory(prefix="jid_review_pdf_") as td:
        run("soffice", "--headless", "--convert-to", "pdf", "--outdir", td, str(REVIEW_DOCX))
        made = Path(td) / (REVIEW_DOCX.stem + ".pdf")
        if not made.exists():
            raise RuntimeError("LibreOffice did not create the review PDF")
        shutil.copy2(made, REVIEW_PDF)
    sync_upload_ready()
    make_manifest()
    print("Synchronized main DOCX, review DOCX/PDF, upload-ready folder and submission manifest")


if __name__ == "__main__":
    main()
