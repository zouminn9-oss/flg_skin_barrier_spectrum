#!/usr/bin/env python3
"""Rewrite a PDF while removing its document Info and XMP metadata objects."""

from __future__ import annotations

import argparse
from pathlib import Path

from pypdf import PdfReader, PdfWriter
from pypdf.generic import NameObject


def strip_metadata(source: Path, destination: Path) -> None:
    reader = PdfReader(source)
    writer = PdfWriter()
    writer.clone_document_from_reader(reader)
    writer._info = None
    writer.root_object.pop(NameObject("/Metadata"), None)
    destination.parent.mkdir(parents=True, exist_ok=True)
    with destination.open("wb") as stream:
        writer.write(stream)

    check = PdfReader(destination)
    if check.metadata:
        raise RuntimeError(f"document Info metadata remains in {destination}")
    if check.xmp_metadata:
        raise RuntimeError(f"XMP metadata remains in {destination}")
    if len(check.pages) != len(reader.pages):
        raise RuntimeError(f"page count changed while rewriting {destination}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("destination", type=Path)
    args = parser.parse_args()
    strip_metadata(args.source, args.destination)


if __name__ == "__main__":
    main()
