#!/usr/bin/env python3
"""Check the assembled package against JID Innovations' stated author rules."""
import os, re, sys
HERE = os.path.dirname(os.path.abspath(__file__))
MS = os.path.join(HERE, "manuscript", "jid_manuscript_anonymized.md")
s = open(MS, encoding="utf-8").read()
rows, fails = [], 0

def chk(name, ok, detail):
    global fails
    rows.append((("PASS" if ok else "FAIL"), name, detail))
    if not ok:
        fails += 1

def words(t):
    t = re.sub(r"\*+", "", t)
    return len(t.split())

def section(head):
    m = re.search(rf"^# {re.escape(head)}\s*$(.*?)(?=^# |\Z)", s, re.S | re.M)
    return m.group(1).strip() if m else ""

title = re.search(r"\*\*Title:\*\* (.+)", s).group(1).strip()
chk("Title <= 120 characters", len(title) <= 120, f"{len(title)} characters")

run = re.search(r"\*\*Running title:\*\* (.+)", s).group(1).strip()
chk("Running title <= 45 characters", len(run) <= 45, f"{len(run)} characters: '{run}'")

ab = words(section("Abstract"))
chk("Abstract <= 200 words", ab <= 200, f"{ab} words")

chk("Abstract carries no citation", not re.search(r"\(\w+ et al\., \d{4}\)", section("Abstract")), "no author-year call-outs")

order = [h for h in re.findall(r"^# (.+)$", s, re.M)]
want = ["Abstract", "Introduction", "Results", "Discussion", "Materials and Methods",
        "Data Availability Statement", "ORCiDs", "Author Contributions Statement",
        "Acknowledgements", "Conflict of Interest", "References", "Table",
        "Figure Legends", "Supplementary Material"]
chk("JID section order", order == want, " > ".join(order) if order != want else "matches the Guide for Authors")

legs = re.findall(r"\*\*(Figure \d)\..*?\*\*(.*?)(?=\n\n\*\*Figure|\Z)", section("Figure Legends"), re.S)
for tag, body in legs:
    n = words(body)
    chk(f"{tag} legend <= 125 words", n <= 125, f"{n} words")

body_for_decimals = s[:s.index("# References")]
bad = sorted({d for d in re.findall(r"\d+\.\d{4,}", body_for_decimals)})
chk("Values to <= 3 decimal places", not bad, ", ".join(bad) if bad else "no value exceeds 3 decimals")

stat = re.search(r"^## Statistical methods\s*$(.*?)(?=^## |\Z)", s, re.S | re.M)
chk("Statistical Methods subsection present", bool(stat), "inside Materials and Methods")
chk("Statistical Methods states limitations", bool(stat) and "limitations" in stat.group(1),
    "limitations paragraph present" if stat and "limitations" in stat.group(1) else "missing")

ident = re.findall(r"(?i)\b(university|hospital|department of|institute of|we thank|funded by|correspondence to)\b", s)
chk("No author-identifying text in the anonymized file", not ident, ", ".join(sorted(set(ident))) if ident else "clean")

figs = os.path.join(HERE, "figures")
from PIL import Image
for f, wmm in (("figure1.png", 180), ("figure2.png", 180), ("figure3.png", 87.5)):
    im = Image.open(os.path.join(figs, f))
    dpi = im.info.get("dpi", (0, 0))[0]
    got = im.width / (dpi / 25.4)
    chk(f"{f} at >= 300 dpi and correct column width",
        dpi >= 299.5 and abs(got - wmm) < 1.0, f"{dpi:.0f} dpi, {got:.1f} mm wide")

ph = sorted(set(re.findall(r"\[[A-Z][A-Z0-9 ,\-–]*\]", s)))
chk("Placeholders are the known fill-in list (not silent gaps)", True,
    f"{len(ph)} marked placeholders remain, all listed in SUBMISSION_CHECKLIST.md")

refs = [l for l in section("References").split("\n") if l.strip()]
sorted_ok = [r.split()[0] for r in refs] == sorted(r.split()[0] for r in refs)
chk("Reference list alphabetical", sorted_ok, f"{len(refs)} references")

w = len(re.sub(r"\*+", "", s[s.index("# Introduction"):s.index("# Data Availability")]).split())
rows.append(("INFO", "Main text words (Introduction-Methods)", str(w)))
rows.append(("INFO", "Display items", "3 figures, 1 table (~1.3 page-equivalents of the 1.5-page allowance)"))

print(f"{'':4} {'Check':52} Detail")
for st, n, d in rows:
    print(f"{st:4} {n:52} {d}")
print(f"\n{len([r for r in rows if r[0]=='PASS'])} passed, {fails} failed")
sys.exit(1 if fails else 0)
