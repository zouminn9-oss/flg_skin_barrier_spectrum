#!/usr/bin/env python3
"""Compose JID Innovations multi-panel figures from the frozen result images.

JID Innovations display rules applied here:
  * 2 columns = 180 mm, 1 column = 87.5 mm
  * >= 300 dpi
  * lowercase panel labels (a, b) set in white space, Arial-metric font
Panels are pasted unmodified; only scaling, white padding and labels are added.
"""
import os
from PIL import Image, ImageDraw, ImageFont

DPI = 300
MM = DPI / 25.4                      # px per mm
W2 = int(round(180 * MM))            # 2-column width  = 2126 px
W1 = int(round(87.5 * MM))           # 1-column width  = 1033 px
FONT = "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf"
LABEL_PX = 52
GAP = int(round(3 * MM))             # 3 mm gutter
HERE = os.path.dirname(os.path.abspath(__file__))
FIG = os.path.join(HERE, "figures")

font = ImageFont.truetype(FONT, LABEL_PX)


def load(name):
    im = Image.open(os.path.join(FIG, name))
    if im.mode in ("RGBA", "LA", "P"):
        bg = Image.new("RGB", im.size, "white")
        im = im.convert("RGBA")
        bg.paste(im, mask=im.split()[-1])
        im = bg
    return im.convert("RGB")


def scale_w(im, w):
    return im.resize((w, max(1, round(im.height * w / im.width))), Image.LANCZOS)


def compose(panels, width, out, label_gap=int(round(2 * MM))):
    """panels: list of rows. Each row is either a list of (label, image),
    or a (list, width_fraction) tuple limiting that row to part of the width."""
    total_panels = sum(len(r[0] if isinstance(r, tuple) else r) for r in panels)
    show_labels = total_panels > 1
    rows = []
    for row in panels:
        frac = 1.0
        if isinstance(row, tuple):
            row, frac = row
        n = len(row)
        avail = int(width * frac) - GAP * (n - 1)
        # allocate width in proportion to aspect ratio so panels share one height
        ars = [im.width / im.height for _, im in row]
        hs = avail / sum(ars)
        sized = [(lab, im.resize((max(1, round(hs * ar)), max(1, round(hs))), Image.LANCZOS))
                 for (lab, im), ar in zip(row, ars)]
        rh = max(im.height for _, im in sized) + (LABEL_PX + label_gap if show_labels else 0)
        rows.append((sized, rh))

    total_h = sum(rh for _, rh in rows) + GAP * (len(rows) - 1)
    canvas = Image.new("RGB", (width, total_h), "white")
    draw = ImageDraw.Draw(canvas)

    y = 0
    for sized, rh in rows:
        row_w = sum(im.width for _, im in sized) + GAP * (len(sized) - 1)
        x = (width - row_w) // 2
        for lab, im in sized:
            if show_labels:
                draw.text((x, y), lab, font=font, fill="black")
            canvas.paste(im, (x, y + (LABEL_PX + label_gap if show_labels else 0)))
            x += im.width + GAP
        y += rh + GAP

    path = os.path.join(FIG, out)
    canvas.save(path, dpi=(DPI, DPI), optimize=True)
    print(f"{out:14s} {canvas.width}x{canvas.height}px  "
          f"{canvas.width/MM:.1f}x{canvas.height/MM:.1f} mm  "
          f"({canvas.height/MM/240*100:.0f}% of a 240 mm text column height)")
    return canvas.height / MM


wf = load("panel_workflow.png")
nw = load("panel_network.png")
dr = load("panel_drivers.png")
cg = load("panel_coregenes.png")
sc = load("panel_singlecell.png")

# Figure 1: (a) study workflow across the top, (b) fused disease network beneath.
# The network is held to ~62% width so Figure 1 does not eat the display budget.
h1 = compose([[("a", wf)], ([("b", nw)], 0.55)], W2, "figure1.png")

# Figure 2: (a) pathway-driver influence, (b) 16-gene cohort heatmap, side by side.
h2 = compose([[("a", dr), ("b", cg)]], W2, "figure2.png")

# Figure 3: single-cell compartment scores, one column wide.
h3 = compose([[("", sc)]], W1, "figure3.png")

print()
print(f"Figure area estimate: "
      f"{(h1 + h2*1.0 + h3*0.5)/240:.2f} page-equivalents of figures "
      f"(Fig3 counted at half width).")
