#!/usr/bin/env python3
"""Build six data-grounded, journal-scale figures for the JID Innovations paper.

Each Results subsection has one claim-centred multi-panel figure.  The script
reads only frozen tabular outputs, uses a color-blind-safe visual system, and
exports PNG, TIFF and vector PDF at the journal's 180-mm two-column width.
"""
from __future__ import annotations

from pathlib import Path
import math
import textwrap

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import patches
from matplotlib.colors import TwoSlopeNorm
import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
OUT = HERE / "figures"
OUT.mkdir(parents=True, exist_ok=True)

BRANCH = ROOT / "results/exploratory_snf/selected_positive_reml_z_q05/optimized_AD_ACD_branch"
MECH = BRANCH / "mechanism"
CORE = MECH / "core_genes"
CELL = MECH / "single_cell_localization"
CCI  = MECH / "cell_cycle_independence"

DPI = 300
WIDTH = 180 / 25.4
INK = "#17212B"
MUTED = "#677381"
GRID = "#DCE2E8"
BLUE = "#3B6FB6"
ORANGE = "#D97732"
TEAL = "#2A8C82"
PURPLE = "#7656A7"
RED = "#B64B4B"
GOLD = "#C59B2A"
LIGHT = "#EEF2F5"

plt.rcParams.update({
    "font.family": "DejaVu Sans",
    "font.size": 7.4,
    "axes.titlesize": 8.2,
    "axes.titleweight": "bold",
    "axes.labelsize": 7.2,
    "xtick.labelsize": 6.6,
    "ytick.labelsize": 6.6,
    "axes.edgecolor": "#8A949E",
    "axes.linewidth": 0.65,
    "figure.facecolor": "white",
    "savefig.facecolor": "white",
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
})


def read(path: Path) -> pd.DataFrame:
    return pd.read_csv(path, sep="\t")


def clean_axes(ax, grid="y"):
    ax.spines[["top", "right"]].set_visible(False)
    if grid:
        ax.grid(axis=grid, color=GRID, linewidth=0.55, zorder=0)
    ax.tick_params(length=2.5, color="#7B8791")


def panel(ax, letter: str, title: str):
    ax.text(-0.12, 1.07, letter, transform=ax.transAxes, fontsize=10.5,
            fontweight="bold", va="bottom", ha="left", color=INK)
    ax.set_title(textwrap.fill(title, width=38, break_long_words=False),
                 loc="left", pad=6, color=INK, fontsize=7.25, linespacing=1.05)


def short(text: str, width: int = 34) -> str:
    replacements = {
        "Recognition of DNA damage by PCNA-containing replication complex": "PCNA-complex damage recognition",
        "Gap-filling DNA repair synthesis and ligation in GG-NER": "GG-NER gap filling and ligation",
        "Gap-filling DNA repair synthesis and ligation in TC-NER": "TC-NER gap filling and ligation",
        "Recruitment and ATM-mediated phosphorylation of repair and signaling proteins at DNA double strand breaks": "ATM-mediated DSB signalling",
        "TP53 Regulates Transcription of Genes Involved in G2 Cell Cycle Arrest": "TP53-regulated G2 arrest",
        "Translesion synthesis by Y family DNA polymerases bypasses lesions on DNA template": "Y-family translesion synthesis",
        "Presynaptic phase of homologous DNA pairing and strand exchange": "Presynaptic homologous pairing",
        "Activation of ATR in response to replication stress": "ATR activation in replication stress",
    }
    text = replacements.get(text, text)
    return "\n".join(textwrap.wrap(text, width=width, break_long_words=False))


def compact_pathway(text: str) -> str:
    """Single-line labels for dense pathway heatmaps."""
    labels = {
        "TP53 Regulates Transcription of Genes Involved in G2 Cell Cycle Arrest": "TP53-regulated G2 arrest",
        "E2F mediated regulation of DNA replication": "E2F-regulated DNA replication",
        "Activation of ATR in response to replication stress": "ATR activation",
        "Synthesis of DNA": "DNA synthesis",
        "DNA strand elongation": "DNA elongation",
        "Gap-filling DNA repair synthesis and ligation in TC-NER": "TC-NER gap filling",
        "Diseases of DNA Double-Strand Break Repair": "Double-strand-break repair",
        "Diseases of DNA repair": "DNA-repair disorders",
        "TP53 Regulates Transcription of Cell Cycle Genes": "TP53 cell-cycle targets",
        "Presynaptic phase of homologous DNA pairing and strand exchange": "Presynaptic homologous pairing",
        "Homologous DNA Pairing and Strand Exchange": "Homologous pairing/exchange",
        "Mitotic G1 phase and G1/S transition": "Mitotic G1/S transition",
        "Gap-filling DNA repair synthesis and ligation in GG-NER": "GG-NER gap filling",
        "Translesion synthesis by Y family DNA polymerases bypasses lesions on DNA template": "Y-family translesion synthesis",
        "Termination of translesion DNA synthesis": "Translesion synthesis termination",
        "Recognition of DNA damage by PCNA-containing replication complex": "PCNA-complex damage recognition",
        "Recruitment and ATM-mediated phosphorylation of repair and signaling proteins at DNA double strand breaks": "ATM-mediated DSB signalling",
        "Apoptotic cleavage of cellular proteins": "Apoptotic protein cleavage",
    }
    out = labels.get(text, text)
    return out if len(out) <= 34 else out[:31] + "…"


def save(fig, number):
    for suffix in ("png", "tif", "pdf"):
        kwargs = {"dpi": DPI} if suffix != "pdf" else {}
        if suffix == "tif":
            kwargs["pil_kwargs"] = {"compression": "tiff_lzw"}
        fig.savefig(OUT / f"figure{number}.{suffix}", **kwargs)
    plt.close(fig)


def heatmap(ax, values, row_labels, col_labels, vmin=None, vmax=None,
            center=None, cmap="RdBu_r", fmt=None, cbar_label=None):
    arr = np.asarray(values, dtype=float)
    norm = TwoSlopeNorm(vmin=vmin, vcenter=center, vmax=vmax) if center is not None else None
    im = ax.imshow(arr, aspect="auto", cmap=cmap, vmin=None if norm else vmin,
                   vmax=None if norm else vmax, norm=norm, interpolation="nearest")
    ax.set_xticks(range(len(col_labels)), col_labels)
    ax.set_yticks(range(len(row_labels)), row_labels)
    ax.tick_params(length=0)
    for spine in ax.spines.values():
        spine.set_visible(False)
    if fmt:
        for i in range(arr.shape[0]):
            for j in range(arr.shape[1]):
                if np.isfinite(arr[i, j]):
                    ax.text(j, i, fmt.format(arr[i, j]), ha="center", va="center",
                            fontsize=5.9, color="white" if abs(arr[i, j]) > 0.58 * np.nanmax(np.abs(arr)) else INK)
    cb = plt.colorbar(im, ax=ax, fraction=0.038, pad=0.025)
    cb.outline.set_linewidth(0.5)
    cb.ax.tick_params(labelsize=5.8, length=2)
    if cbar_label:
        cb.set_label(cbar_label, fontsize=6.2)
    return im


def figure1():
    # Explicit margins keep panel a on the same left/right anchors as the
    # two-column row beneath it; constrained_layout previously shifted them.
    fig = plt.figure(figsize=(WIDTH, 6.30))
    gs = fig.add_gridspec(3, 2, height_ratios=[0.72, 1.55, 1.55],
                          left=0.105, right=0.94, bottom=0.075, top=0.915,
                          hspace=0.54, wspace=0.28)

    ax = fig.add_subplot(gs[0, :]); ax.axis("off"); ax.set_xlim(0, 1); ax.set_ylim(0, 1)
    panel(ax, "a", "Cohort-aware construction of the cross-disease pathway atlas")
    stages = [
        ("13 contrasts", "7 diseases\npublic bulk data", BLUE),
        ("Within cohort", "paired/covariate-\naware effects", TEAL),
        ("Reactome", "cohort-level\npathway statistics", PURPLE),
        ("Meta-analysis", "six-cell\ninference grid", ORANGE),
        ("Operating state", "429 concordant\nAD–ACD pathways", RED),
    ]
    gap = 0.014
    box_w = (1 - gap * (len(stages) - 1)) / len(stages)
    for i, (head, body, color) in enumerate(stages):
        x = i * (box_w + gap)
        box = patches.FancyBboxPatch((x, 0.15), box_w, 0.57,
                                     boxstyle="round,pad=0,rounding_size=0.018",
                                     transform=ax.transAxes, facecolor="white",
                                     edgecolor=color, linewidth=1.25, clip_on=False)
        ax.add_patch(box)
        ax.text(x + box_w / 2, 0.55, head, transform=ax.transAxes, ha="center",
                va="center", fontsize=7.2, fontweight="bold", color=color)
        ax.text(x + box_w / 2, 0.31, body, transform=ax.transAxes, ha="center",
                va="center", fontsize=6.4, color=INK, linespacing=1.15)
        if i < len(stages) - 1:
            next_x = (i + 1) * (box_w + gap)
            ax.annotate("", xy=(next_x - 0.001, 0.435), xytext=(x + box_w + 0.001, 0.435),
                        xycoords=ax.transAxes,
                        arrowprops=dict(arrowstyle="-|>", mutation_scale=8, lw=1, color=MUTED))

    ax = fig.add_subplot(gs[1, 0])
    panel(ax, "b", "Inference choice changes pathway yield")
    d = read(ROOT / "results/exploratory_sensitivity/method_grid_summary.tsv")
    d = d[d.disease.isin(["AD", "ACD"])].copy()
    labels = ["mKH\n.05", "REML-z\n.05", "REML-z\n.10",
              "DL-z\n.05", "FE-z\n.05", "FE-z\n.10"]
    order = ["reml_mkh_q05", "reml_z_q05", "reml_z_q10", "dl_z_q05", "fixed_z_q05", "fixed_z_q10"]
    x = np.arange(len(order)); w = 0.36
    for j, (disease, color) in enumerate([("AD", BLUE), ("ACD", ORANGE)]):
        vals = d[d.disease.eq(disease)].set_index("method_id").loc[order, "significant"].to_numpy()
        bars = ax.bar(x + (j - 0.5) * w, vals, width=w, color=color, label=disease, zorder=3)
        for k, b in enumerate(bars):
            if order[k] == "reml_z_q05":
                b.set_edgecolor(INK); b.set_linewidth(1.2)
    ax.axvspan(0.5, 1.5, color="#F7E9DC", zorder=0)
    ax.text(1, 1105, "operating\nbranch", ha="center", va="top", fontsize=6.1, color=ORANGE)
    ax.set_xticks(x, labels, fontsize=5.8); ax.set_ylabel("BH-significant pathways")
    ax.set_ylim(0, 1400); ax.legend(frameon=False, ncol=2, loc="upper right", bbox_to_anchor=(1.0, 1.02))
    clean_axes(ax)

    ax = fig.add_subplot(gs[1, 1])
    panel(ax, "c", "A broad concordant AD–ACD state emerges")
    d = read(ROOT / "results/exploratory_sensitivity/axis_b_shared_pathways_grid.tsv")
    d = d[d.method_id.eq("reml_z_q05")]
    shared = d[d.shared_significant.astype(bool)]
    rest = d[~d.shared_significant.astype(bool)]
    ax.scatter(rest.effect_AD, rest.effect_ACD, s=5, color="#CDD4DA", alpha=0.45, linewidth=0, rasterized=True)
    ax.scatter(shared.effect_AD, shared.effect_ACD, s=8, color=TEAL, alpha=0.7, linewidth=0, rasterized=True)
    lim = np.nanmax(np.abs(d[["effect_AD", "effect_ACD"]].to_numpy())) * 1.03
    ax.axhline(0, color="#9099A2", lw=0.6); ax.axvline(0, color="#9099A2", lw=0.6)
    ax.plot([-lim, lim], [-lim, lim], ls="--", color=MUTED, lw=0.7)
    ax.set(xlim=(-lim, lim), ylim=(-lim, lim), xlabel="AD pathway effect", ylabel="ACD pathway effect")
    ax.text(0.04, 0.94, f"429 shared, concordant\nBH-selected pathways", transform=ax.transAxes,
            va="top", fontsize=6.7, color=TEAL, fontweight="bold")
    clean_axes(ax, None)

    ax = fig.add_subplot(gs[2, :])
    panel(ax, "d", "The shared state sits within a correlated inflammatory-skin background")
    sim = read(ROOT / "results/tables/similarity/reactome_spearman_similarity.tsv").set_index("disease")
    labels = ["AD", "ACD", "PSO", "HS", "ACNE", "ROS"]
    heatmap(ax, sim.to_numpy(), labels, labels, vmin=0.3, vmax=1.0, cmap="Blues", fmt="{:.2f}",
            cbar_label="Spearman ρ")
    ax.text(0.995, -0.19, "Cohort-synthesized states; ICD enters the seven-node fused network as a single-study node.",
            transform=ax.transAxes, ha="right", va="top", color=MUTED, fontsize=6.1)
    save(fig, 1)


def figure2():
    fig, axes = plt.subplots(2, 2, figsize=(WIDTH, 5.55), layout="constrained")
    edge = read(BRANCH / "optimized_edge_statistics.tsv")
    sim = read(BRANCH / "optimized_fused_similarity.tsv").set_index("disease")
    support = read(BRANCH / "optimized_cluster_support.tsv").set_index("disease")

    ax = axes[0, 0]; panel(ax, "a", "Selected fused network retains three stable clusters")
    ax.axis("off")
    pos = {"AD":(-0.85,0.42), "ACD":(-0.75,-0.38), "PSORIASIS":(0.45,0.75),
           "ACNE":(0.92,0.25), "HS":(0.32,-0.55), "ROSACEA":(1.0,-0.55), "ICD":(0.62,-1.03)}
    cluster_color = {1:BLUE, 2:PURPLE, 3:ORANGE}
    for _, r in edge.iterrows():
        a, b = r.disease_1, r.disease_2
        x1,y1=pos[a]; x2,y2=pos[b]
        sig = float(r.nominal_permutation_q) < .05
        is_target = {a,b} == {"AD","ACD"}
        ax.plot([x1,x2],[y1,y2], color=ORANGE if is_target else ("#74808B" if sig else "#DDE2E6"),
                lw=2.8 if is_target else (0.6+3.2*float(r.fused_similarity) if sig else 0.35),
                alpha=1 if sig else .65, zorder=1)
    for n,(x,y) in pos.items():
        c=int(support.loc[n,"cluster"]); s=float(support.loc[n,"bootstrap_cluster_support"])
        ax.scatter(x,y,s=380,color=cluster_color[c],edgecolor="white",linewidth=1.4,zorder=3)
        ax.text(x,y,n.replace("PSORIASIS","PSO").replace("ROSACEA","ROS"),ha="center",va="center",
                color="white",fontsize=6.5,fontweight="bold",zorder=4)
        ax.text(x,y-.26,f"support {s:.3f}",ha="center",va="top",fontsize=5.7,color=MUTED)
    ax.text(-0.78,0.03,"0.259\nrank 3/21",ha="center",va="center",fontsize=6.2,color=ORANGE,fontweight="bold")
    ax.set_xlim(-1.22,1.35); ax.set_ylim(-1.3,1.05)

    ax = axes[0, 1]; panel(ax, "b", "The AD–ACD signal is calibrated over 396 specifications")
    grid = read(ROOT / "results/exploratory_snf/selected_positive_reml_z_q05/parameter_grid/snf_parameter_grid.tsv")
    rng=np.random.default_rng(18)
    for n,c in [(2,BLUE),(3,TEAL),(4,PURPLE)]:
        q=grid[grid.n_views.eq(n)]
        ax.scatter(n+rng.normal(0,.065,len(q)),q.AD_ACD_similarity,s=7,color=c,alpha=.32,linewidth=0,rasterized=True)
        ax.plot([n-.18,n+.18],[q.AD_ACD_similarity.median()]*2,color=INK,lw=1.1)
    sel=grid.iloc[grid.AD_ACD_similarity.argmax()]
    ax.scatter(sel.n_views,sel.AD_ACD_similarity,marker="*",s=90,color=ORANGE,edgecolor=INK,lw=.6,zorder=5)
    ax.annotate("selected: K=2, α=0.2, 10 iterations",(sel.n_views,sel.AD_ACD_similarity),
                xytext=(2.25,sel.AD_ACD_similarity-.055),arrowprops=dict(arrowstyle="-",color=MUTED,lw=.7),fontsize=6.1)
    ax.set_xticks([2,3,4],["2 views","3 views","4 views"]); ax.set_ylabel("AD–ACD fused similarity")
    ax.text(.98,.04,"grid-level max-statistic P = 0.010",transform=ax.transAxes,ha="right",fontsize=6.4,color=ORANGE)
    clean_axes(ax)

    ax = axes[1, 0]; panel(ax, "c", "Edge-level inference separates rank from cluster membership")
    d=edge.sort_values("fused_similarity",ascending=True).reset_index(drop=True)
    y=np.arange(len(d)); target=(d.disease_1.eq("AD")&d.disease_2.eq("ACD"))|(d.disease_1.eq("ACD")&d.disease_2.eq("AD"))
    colors=np.where(target,ORANGE,np.where(d.nominal_permutation_q.lt(.05),BLUE,"#BFC7CE"))
    ax.hlines(y,d.bootstrap_ci_low,d.bootstrap_ci_high,color=colors,lw=1.2)
    ax.scatter(d.fused_similarity,y,c=colors,s=np.where(target,34,16),edgecolor="white",lw=.35,zorder=3)
    pair=(d.disease_1+"–"+d.disease_2).str.replace("PSORIASIS","PSO").str.replace("ROSACEA","ROS")
    ax.set_yticks(y,pair); ax.set_xlabel("Fused similarity (pathway-bootstrap 95% interval)")
    ax.set_ylim(-.8,len(d)-.2); clean_axes(ax,"x")
    ax.text(.98,.04,"filled: edge-level BH q<0.05",transform=ax.transAxes,ha="right",fontsize=5.9,color=MUTED)

    ax = axes[1, 1]; panel(ax, "d", "Pathway resampling preserves conditional co-clustering")
    co=read(BRANCH / "optimized_bootstrap_coclustering.tsv").set_index("disease")
    labs=["AD","ACD","PSO","HS","ACNE","ROS","ICD"]
    heatmap(ax,co.to_numpy(),labs,labs,vmin=0,vmax=1,cmap="Blues",fmt="{:.2f}",cbar_label="co-clustering")
    save(fig,2)


def figure3():
    fig = plt.figure(figsize=(WIDTH, 6.05), layout="constrained")
    gs=fig.add_gridspec(2,3,height_ratios=[1.3,1])
    loo=read(MECH/"pathway_loo_influence.tsv")
    top=loo.nlargest(15,"support_influence").sort_values("support_influence")
    theme_colors={"DNA_damage_repair":ORANGE,"cell_cycle_mitotic":PURPLE,"immune_inflammatory":BLUE,
                  "barrier_extracellular":TEAL,"other_signaling_processes":"#8B97A3"}

    ax=fig.add_subplot(gs[0,:2]); panel(ax,"a","Exact pathway deletion resolves a repair/replication program")
    y=np.arange(len(top)); colors=[theme_colors.get(t,"#8B97A3") for t in top.theme]
    ax.barh(y,top.support_influence,color=colors,zorder=3)
    ax.set_yticks(y,[short(x,42) for x in top.pathway]); ax.set_xlabel("Support influence: Δ AD–ACD similarity")
    ax.set_xticks(np.arange(0, 0.0041, 0.001))
    ax.xaxis.set_major_formatter(matplotlib.ticker.FormatStrFormatter("%.3f"))
    clean_axes(ax,"x")

    ax=fig.add_subplot(gs[0,2]); panel(ax,"b","Driver concordance")
    top20=loo.nlargest(20,"support_influence")
    ax.scatter(top20.effect_AD,top20.effect_ACD,c=[theme_colors.get(t,"#8B97A3") for t in top20.theme],s=23,edgecolor="white",lw=.4)
    lo=min(top20.effect_AD.min(),top20.effect_ACD.min())-.04; hi=max(top20.effect_AD.max(),top20.effect_ACD.max())+.04
    ax.plot([lo,hi],[lo,hi],ls="--",lw=.7,color=MUTED)
    ax.axhline(0,color=GRID,lw=.7);ax.axvline(0,color=GRID,lw=.7)
    ax.set(xlim=(lo,hi),ylim=(lo,hi),xlabel="AD effect",ylabel="ACD effect")
    clean_axes(ax,None)

    ax=fig.add_subplot(gs[1,0]); panel(ax,"c","Theme support")
    d=read(MECH/"pathway_theme_summary.tsv").sort_values("net_influence")
    lab=[x.replace("_"," ") for x in d.theme]
    col=[theme_colors.get(x,"#AEB6BD") if v>0 else "#C7CDD2" for x,v in zip(d.theme,d.net_influence)]
    ax.barh(np.arange(len(d)),d.net_influence,color=col,zorder=3)
    ax.set_yticks(np.arange(len(d)),[short(x,24) for x in lab]); ax.axvline(0,color=MUTED,lw=.7)
    ax.set_xlabel("Net influence"); clean_axes(ax,"x")

    ax=fig.add_subplot(gs[1,1]); panel(ax,"d","Random deletions")
    rnd=read(MECH/"random_10pct_pathway_deletion.tsv")
    ax.hist(rnd.AD_ACD_similarity,bins=28,color=TEAL,alpha=.85,edgecolor="white",lw=.35)
    ax.axvline(.259194,color=ORANGE,lw=1.6,label="original 0.259")
    ax.axvline(.126,color=MUTED,lw=1.1,ls="--",label="initial four-view 0.126")
    ax.set_xlabel("AD–ACD similarity after deletion"); ax.set_ylabel("Runs (n=1,000)")
    ax.legend(frameon=False,fontsize=5.5,loc="upper center",bbox_to_anchor=(.5,.88)); clean_axes(ax)
    ax.text(.98,.72,"rank 3/21 in 1,000/1,000",transform=ax.transAxes,ha="right",fontsize=5.8,fontweight="bold",color=TEAL)

    ax=fig.add_subplot(gs[1,2]); panel(ax,"e","View diagnostics")
    d=read(MECH/"view_overlap_diagnostics.tsv")
    names={"optimized_all_plus_stress":"all + stress",
           "nonoverlap_nonstress_plus_stress":"non-overlap + stress",
           "all_only_duplicated_diagnostic":"all only (duplicated)",
           "stress_only_duplicated_diagnostic":"stress only (duplicated)"}
    d["label"]=d.network_variant.map(names).fillna(d.network_variant)
    d=d.sort_values("AD_ACD_similarity")
    ax.barh(np.arange(len(d)),d.AD_ACD_similarity,color=[ORANGE if "optimized" in x else BLUE for x in d.network_variant])
    ax.set_yticks(np.arange(len(d)),d.label)
    for y,(v,r) in enumerate(zip(d.AD_ACD_similarity,d.AD_ACD_rank)):
        ax.text(v+.005,y,f"rank {int(r)}/21",va="center",fontsize=5.8)
    ax.set_xlim(0,max(d.AD_ACD_similarity)*1.35); ax.set_xlabel("AD–ACD similarity"); clean_axes(ax,"x")
    save(fig,3)


def figure4():
    fig,axes=plt.subplots(2,2,figsize=(WIDTH,5.70),layout="constrained")
    d=read(CORE/"tier1_core_genes.tsv")
    cohorts=["logFC__AD_GSE121212_acute","logFC__AD_GSE32924","logFC__AD_GSE36842_acute",
             "logFC__ACD_GSE282562","logFC__ACD_GSE6281_48h"]
    fdrs=[x.replace("logFC__","FDR__") for x in cohorts]
    labels=["AD\nGSE121212","AD\nGSE32924","AD\nGSE36842","ACD\nGSE282562","ACD\nGSE6281"]

    ax=axes[0,0]; panel(ax,"a","All 16 core genes are positive across five cohorts")
    vals=d.set_index("gene")[cohorts]
    vmax=max(.55,float(np.nanmax(np.abs(vals.to_numpy()))))
    im=ax.imshow(vals.to_numpy(),aspect="auto",cmap="RdBu_r",norm=TwoSlopeNorm(vmin=-vmax,vcenter=0,vmax=vmax))
    ax.set_xticks(range(5),labels);ax.set_yticks(range(len(d)),d.gene);ax.tick_params(length=0)
    sig=d[fdrs].to_numpy()<.05
    for i,j in zip(*np.where(sig)):
        ax.text(j,i,"•",ha="center",va="center",color="white",fontsize=10,fontweight="bold")
    cb=plt.colorbar(im,ax=ax,fraction=.04,pad=.025);cb.set_label("log₂ fold change",fontsize=6.2);cb.ax.tick_params(labelsize=5.8)
    ax.text(.98,-.18,"white dot: cohort-level BH q<0.05",transform=ax.transAxes,ha="right",fontsize=5.8,color=MUTED)

    ax=axes[0,1]; panel(ax,"b","Core membership is recurrent across driver pathways")
    x=d.top20_pathway_count.to_numpy();y=np.arange(len(d))
    ax.hlines(y,0,x,color="#BFC7CE",lw=1.1);ax.scatter(x,y,c=ORANGE,s=24,zorder=3)
    ax.set_yticks(y,d.gene);ax.invert_yaxis();ax.set_xlabel("Number of top-20 pathways")
    ax.set_xlim(0,max(x)+2);clean_axes(ax,"x")

    ax=axes[1,0]; panel(ax,"c","Disease-level effects remain directionally concordant")
    ax.scatter(d.AD_meta_logFC,d.ACD_meta_logFC,s=30,c=TEAL,edgecolor="white",lw=.5)
    for _,r in d.iterrows():
        ax.text(r.AD_meta_logFC+.008,r.ACD_meta_logFC,r.gene,fontsize=5.4,color=INK)
    hi=max(d.AD_meta_logFC.max(),d.ACD_meta_logFC.max())+.08
    ax.plot([0,hi],[0,hi],ls="--",lw=.7,color=MUTED);ax.axhline(0,color=GRID,lw=.7);ax.axvline(0,color=GRID,lw=.7)
    ax.set(xlabel="AD meta-effect",ylabel="ACD meta-effect",xlim=(-.03,hi),ylim=(-.03,hi))
    clean_axes(ax,None)
    ax.text(.98,.05,"0/16 pass conservative BH q<0.05 in both diseases",transform=ax.transAxes,ha="right",fontsize=6,color=RED)

    ax=axes[1,1]; panel(ax,"d","Held-out cohorts preserve the selected direction")
    q=read(CORE/"leave_one_cohort_out_direction_validation.tsv")
    names=q.held_out_cohort.str.replace("_acute","",regex=False).str.replace("_","\n",n=1,regex=False)
    colors=[BLUE if x=="AD" else ORANGE for x in q.disease]
    bars=ax.bar(np.arange(len(q)),100*q.held_out_positive_rate,color=colors,zorder=3)
    for b,n,tot in zip(bars,q.held_out_positive_genes,q.genes_selected_from_other_four):
        ax.text(b.get_x()+b.get_width()/2,b.get_height()+1.1,f"{int(n)}/{int(tot)}",ha="center",fontsize=5.9)
    ax.set_xticks(np.arange(len(q)),names,fontsize=5.5);ax.set_ylabel("Held-out positive rate (%)");ax.set_ylim(0,100)
    clean_axes(ax)
    ax.text(.98,.08,"binomial BH q ≤ 0.006 for all five audits",transform=ax.transAxes,ha="right",fontsize=6.1,color=TEAL)
    save(fig,4)


def figure5():
    fig=plt.figure(figsize=(WIDTH,7.60),layout="constrained")
    gs=fig.add_gridspec(3,2,height_ratios=[1,1,0.82])
    axes=np.empty((2,2),dtype=object)
    for i in range(2):
        for j in range(2):
            axes[i,j]=fig.add_subplot(gs[i,j])
    ax_e=fig.add_subplot(gs[2,:])
    score=read(CELL/"celltype_program_scores.tsv")
    order=["KRT","APC","LYMPH","all_cells"]
    score=score.set_index("celltype").loc[order].reset_index()
    colors=[BLUE,ORANGE,PURPLE,"#8A949E"]

    ax=axes[0,0]; panel(ax,"a","The fixed pathway program shows cellular polarity")
    y=np.arange(4);ax.barh(y,score.driver_pathway_score,color=colors,zorder=3)
    ax.axvline(0,color=MUTED,lw=.8);ax.set_yticks(y,["Keratinocytes","APCs","Lymphocytes","All cells"]);ax.invert_yaxis()
    ax.set_xlabel("Mean signed z (allergy − irritant)")
    for yy,r in score.iterrows():
        x=r.driver_pathway_score
        if x < -0.5:
            ax.text(x*.52,yy,f"q={r.driver_pathway_q_BH_4celltypes:.3f}",ha="center",va="center",
                    fontsize=6.1,color="white",fontweight="bold" if r.driver_pathway_q_BH_4celltypes<.05 else "normal")
        else:
            ax.text(x+(.035 if x>=0 else -.035),yy,f"q={r.driver_pathway_q_BH_4celltypes:.3f}",
                    ha="left" if x>=0 else "right",va="center",
                    fontsize=6.1,fontweight="bold" if r.driver_pathway_q_BH_4celltypes<.05 else "normal")
    ax.set_xlim(-1.25,.9);clean_axes(ax,"x")
    ax.text(.02,.05,"n = 5 paired donors",transform=ax.transAxes,fontsize=6.2,color=MUTED)

    eff=read(CELL/"driver_pathway_single_cell_effects.tsv")
    ax=axes[0,1];panel(ax,"b","Driver pathways separate APC and epithelial deployment")
    piv=eff.pivot(index="pathway",columns="celltype",values="signed_z")
    cols=[x for x in order if x in piv.columns]
    piv=piv[cols]
    piv=piv.loc[piv.mean(axis=1).sort_values().index]
    vmax=max(2.7,np.nanmax(np.abs(piv.to_numpy())))
    heatmap(ax,piv.to_numpy(),[compact_pathway(x) for x in piv.index],
            ["KRT","APC","LYMPH","all"],vmin=-vmax,vmax=vmax,center=0,cmap="RdBu_r",cbar_label="signed z")
    ax.tick_params(axis="y", labelsize=5.45)

    ax=axes[1,0];panel(ax,"c","Shared measurable pathways reverse between APCs and KRTs")
    p=eff.pivot(index="pathway",columns="celltype",values="signed_z").dropna(subset=["APC","KRT"])
    ax.scatter(p.KRT,p.APC,s=20,color=TEAL,edgecolor="white",lw=.45)
    ax.axhline(0,color=MUTED,lw=.7);ax.axvline(0,color=MUTED,lw=.7)
    lim=max(np.abs(p[["KRT","APC"]].to_numpy()).max(),1)
    ax.set(xlim=(-lim*1.08,lim*1.08),ylim=(-lim*1.08,lim*1.08),xlabel="KRT signed z",ylabel="APC signed z")
    ax.text(.96,.93,"APC allergy-high\nKRT irritant-high",transform=ax.transAxes,ha="right",va="top",fontsize=6.2,color=ORANGE,fontweight="bold")
    clean_axes(ax,None)

    ax=axes[1,1];panel(ax,"d","Direction is invariant to every single-pathway omission")
    loo=read(CELL/"driver_pathway_leave_one_out.tsv")
    for i,(ct,c) in enumerate([("KRT",BLUE),("APC",ORANGE)]):
        q=loo[loo.celltype.eq(ct)].leave_one_pathway_out_score
        jitter=np.linspace(-.08,.08,len(q))
        ax.scatter(np.full(len(q),i)+jitter,q,s=15,color=c,alpha=.82,edgecolor="white",lw=.35)
        full=float(score.set_index("celltype").loc[ct,"driver_pathway_score"])
        ax.hlines(full,i-.25,i+.25,color=INK,lw=1.3)
    ax.axhline(0,color=MUTED,lw=.7);ax.set_xticks([0,1],["KRT\n16 omissions","APC\n19 omissions"])
    ax.set_ylabel("Leave-one-pathway-out score");ax.set_xlim(-.45,1.45);clean_axes(ax)
    ax.text(.5,.05,"16/16 negative; 19/19 positive",transform=ax.transAxes,ha="center",fontsize=6.2,color=TEAL,fontweight="bold")

    # ---- panel e: the polarity is not carried by mitotic gene content -------
    cci=read(CCI/"compartment_partition_scores.tsv")
    mark=read(CCI/"mitotic_marker_gene_scores.tsv")
    ax=ax_e; panel(ax,"e","Removing mitotic pathway content strengthens the polarity in both compartments")
    sets=[("driver_full","Fixed driver program"),
          ("driver_mitosis_depleted","Driver program, mitosis-depleted"),
          ("mitotic_reference","Mitosis-specific reference set")]
    comps=[("APC","APCs",ORANGE),("KRT","Keratinocytes",BLUE)]
    w=0.26; ypos=np.arange(len(sets))
    for k,(comp,lab,col) in enumerate(comps):
        vals,ps=[],[]
        for key,_ in sets:
            r=cci[(cci.compartment.eq(comp))&(cci.pathway_set.eq(key))]
            vals.append(float(r.score.iloc[0])); ps.append(float(r.permutation_P.iloc[0]))
        off=(k-0.5)*w*1.12
        ax.barh(ypos+off,vals,height=w,color=col,zorder=3,
                label=lab,edgecolor="white",linewidth=.5)
        for yy,(v,pv) in enumerate(zip(vals,ps)):
            txt="P < 0.001" if pv<0.001 else f"P = {pv:.3f}"
            ax.text(v+(0.045 if v>=0 else -0.045),ypos[yy]+off,txt,
                    va="center",ha="left" if v>=0 else "right",fontsize=6.0,
                    fontweight="bold" if pv<.05 else "normal",color=INK)
    ax.axvline(0,color=MUTED,lw=.8)
    ax.set_yticks(ypos,[lab for _,lab in sets]); ax.invert_yaxis()
    ax.set_xlabel("Mean signed z (allergy − irritant)")
    ax.set_xlim(-1.75,1.75); clean_axes(ax,"x")
    ax.legend(loc="upper left",bbox_to_anchor=(0.005,0.99),frameon=False,
              fontsize=6.4,handlelength=1.1,labelspacing=.35)
    apc_n=int(mark[mark.compartment.eq("APC")].n_genes_measured.iloc[0])
    krt=mark[mark.compartment.eq("KRT")]
    ax.text(0,-0.30,
            f"Canonical proliferation markers: {apc_n}/20 measurable in APCs; "
            f"in keratinocytes {int(krt.n_up_in_allergy.iloc[0])}/{int(krt.n_genes_measured.iloc[0])} allergy-high "
            f"(score {float(krt.score.iloc[0]):.3f}, P = {float(krt.permutation_P.iloc[0]):.3f})",
            transform=ax.transAxes,fontsize=6.2,color=MUTED,va="top")
    save(fig,5)


def figureS1():
    fig,axes=plt.subplots(2,2,figsize=(WIDTH,6.45),layout="constrained")
    reg=read(MECH/"apc_regulator_network/candidate_positive_regulators.tsv")

    ax=axes[0,0];panel(ax,"a","Five nominal APC regulators connect to the core")
    ax.axis("off")
    tfs=list(reg.TF); genes=sorted({g for s in reg.core_target_genes.fillna("") for g in s.split(";") if g})
    ty=np.linspace(.86,.14,len(tfs)); gy=np.linspace(.9,.1,len(genes))
    for i,r in reg.iterrows():
        for g in str(r.core_target_genes).split(";"):
            if g in genes:
                ax.plot([.25,.76],[ty[i],gy[genes.index(g)]],color="#C7CDD2",lw=.65,zorder=1)
    for i,tf in enumerate(tfs):
        ax.add_patch(patches.FancyBboxPatch((.02,ty[i]-.045),.22,.09,boxstyle="round,pad=.01",facecolor=ORANGE,edgecolor="white"))
        ax.text(.13,ty[i],tf,ha="center",va="center",color="white",fontweight="bold",fontsize=6.6)
        ax.text(.26,ty[i],f"z={reg.iloc[i].activity_score:.2f}",ha="left",va="center",fontsize=5.7,color=MUTED)
    for i,g in enumerate(genes):
        ax.add_patch(patches.FancyBboxPatch((.77,gy[i]-.038),.2,.076,boxstyle="round,pad=.008",facecolor=BLUE,edgecolor="white"))
        ax.text(.87,gy[i],g,ha="center",va="center",color="white",fontsize=6.2)
    ax.text(.02,.01,"0/306 TFs pass global BH or maximum-statistic correction",transform=ax.transAxes,fontsize=6,color=RED)

    ax=axes[0,1];panel(ax,"b","External TF directions are mixed and not FDR-supported")
    val=read(MECH/"regulator_crossdataset_validation/candidate_TF_validation_synthesis.tsv")
    match=val.external_direction_matches_APC.astype(bool)
    ax.scatter(val.APC_discovery_score,val.external_E_MTAB_9501_score,c=np.where(match,TEAL,RED),s=34,edgecolor="white",lw=.5)
    for _,r in val.iterrows():
        ax.text(r.APC_discovery_score+.025,r.external_E_MTAB_9501_score,r.TF,fontsize=6)
    ax.axhline(0,color=MUTED,lw=.7);ax.axvline(0,color=MUTED,lw=.7)
    ax.set(xlabel="APC discovery activity score",ylabel="External ACD−ICD activity score")
    clean_axes(ax,None)
    ax.text(.98,.05,"0/5 external BH q<0.05",transform=ax.transAxes,ha="right",fontsize=6,color=RED)

    ax=axes[1,0];panel(ax,"c","Virtual knockout nominates YY1, with weak model fit")
    ko=read(MECH/"virtual_knockout/single_tf_virtual_knockout.tsv").sort_values("driver_program_reduction")
    y=np.arange(len(ko));col=np.where(ko.strict_screen_pass.astype(bool),ORANGE,"#9AA4AD")
    ax.hlines(y,ko.bootstrap_CI025,ko.bootstrap_CI975,color=col,lw=1.3)
    ax.scatter(ko.driver_program_reduction,y,c=col,s=27,edgecolor="white",lw=.45,zorder=3)
    ax.axvline(0,color=MUTED,lw=.7);ax.set_yticks(y,ko.TF);ax.set_xlabel("Predicted driver-program reduction (95% bootstrap interval)")
    clean_axes(ax,"x")
    model=read(MECH/"virtual_knockout/virtual_knockout_model_summary.tsv").iloc[0]
    ax.text(.98,.04,f"strict pass: YY1; tenfold CV R² = {model.tenfold_CV_R2:.3f}",transform=ax.transAxes,ha="right",fontsize=6,color=RED)

    ax=axes[1,1];panel(ax,"d","Compound screens stop at exploratory probe nomination")
    ax.axis("off")
    steps=[("Targeted\nSci-Plex","188 compounds",BLUE),
           ("Tier C","6",TEAL),("Tier A/B","0",RED),
           ("LINCS\nbackground","33,609 compounds",PURPLE),
           ("JNJ-7706621","rank 5,343\n15.9th percentile",ORANGE)]
    xs=[.02,.23,.40,.57,.79]; ws=[.17,.13,.13,.18,.19]
    for i,((head,body,color),x,w) in enumerate(zip(steps,xs,ws)):
        ax.add_patch(patches.FancyBboxPatch((x,.35),w,.32,boxstyle="round,pad=.015",facecolor="white",edgecolor=color,lw=1.25))
        ax.text(x+w/2,.56,head,ha="center",va="center",fontsize=6.7,fontweight="bold",color=color)
        ax.text(x+w/2,.42,body,ha="center",va="center",fontsize=6,color=INK)
        if i<len(steps)-1:
            ax.annotate("",xy=(xs[i+1]-.01,.51),xytext=(x+w+.005,.51),xycoords=ax.transAxes,
                        arrowprops=dict(arrowstyle="-|>",lw=.8,color=MUTED))
    ax.text(.5,.18,"No false-discovery-supported cross-resource compound",transform=ax.transAxes,ha="center",fontsize=7,color=RED,fontweight="bold")
    ax.text(.5,.08,"JNJ-7706621 targeted LINCS q = 0.415; computational probe, not therapeutic evidence",transform=ax.transAxes,ha="center",fontsize=6,color=MUTED)
    save(fig,"S1")


if __name__ == "__main__":
    for fn in (figure1, figure2, figure3, figure4, figure5, figureS1):
        fn()
    print("Wrote figure1-figure5 and figureS1 as PNG, TIFF and PDF to", OUT)
