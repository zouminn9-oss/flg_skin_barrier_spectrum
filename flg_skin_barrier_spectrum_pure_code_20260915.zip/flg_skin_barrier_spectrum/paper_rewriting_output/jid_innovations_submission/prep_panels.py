#!/usr/bin/env python3
"""Prepare individual panels for the JID Innovations figures.

Two things journals object to are removed here:
  * in-figure titles that duplicate the legend
  * dead white margins that inflate the display-item page budget
"""
import os
import numpy as np
from PIL import Image
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

FIG = os.path.join(os.path.dirname(os.path.abspath(__file__)), "figures")


def flatten(im):
    if im.mode in ("RGBA", "LA", "P"):
        bg = Image.new("RGB", im.size, "white")
        im = im.convert("RGBA")
        bg.paste(im, mask=im.split()[-1])
        return bg
    return im.convert("RGB")


def ink_rows(im, thresh=245):
    a = np.asarray(im.convert("L"))
    return (a < thresh).any(axis=1), (a < thresh).any(axis=0)


def autocrop(im, pad=8, thresh=245):
    rows, cols = ink_rows(im, thresh)
    if not rows.any():
        return im
    r = np.where(rows)[0]; c = np.where(cols)[0]
    return im.crop((max(0, c[0]-pad), max(0, r[0]-pad),
                    min(im.width, c[-1]+1+pad), min(im.height, r[-1]+1+pad)))


def strip_top_title(im, thresh=245, max_share=0.22):
    """Drop a leading in-figure title: the first ink band, when it is
    followed by a blank gap and is only a small share of the panel.
    Falls back to the untouched panel if no such band is found."""
    rows, _ = ink_rows(im, thresh)
    idx = np.where(rows)[0]
    if not len(idx):
        return im
    gap_needed = max(4, int(im.height * 0.005))
    run, y0 = 0, None
    for y in range(idx[0], im.height):
        run = run + 1 if not rows[y] else 0
        if run >= gap_needed:
            y0 = y
            break
    if y0 is None or y0 > im.height * max_share:
        return im
    return im.crop((0, y0, im.width, im.height))


# ---- panel a: study workflow, regenerated without its embedded title -------
blocks = [
    (0.30, "Cross-disease atlas", "7 inflammatory skin\nconditions\n13 bulk contrasts", "#315B7D"),
    (3.05, "Pathway synthesis", "Cohort-aware effects\nREML sensitivity grid\n1,444 positive pathways", "#3E7C78"),
    (5.80, "Calibrated network", "396 SNF specifications\n10,000 permutations\n500 grid-level nulls", "#C76A35"),
    (8.55, "Program resolution", "20 driver pathways\nDNA repair and\nreplication surveillance\n16-gene core", "#B74D59"),
    (11.30, "Cell localization", "GSE267929\n5 paired donors\nAPC: allergy-high\nKRT: irritant-high", "#6A4C93"),
]
fig, ax = plt.subplots(figsize=(14, 3.15))
ax.set_xlim(0, 14); ax.set_ylim(0, 3.05); ax.axis("off")
Y, H = 0.30, 2.55
for i, (x, head, body, color) in enumerate(blocks):
    w = 2.35 if i == len(blocks) - 1 else 2.25
    ax.add_patch(FancyBboxPatch((x, Y), w, H, boxstyle="round,pad=0.04,rounding_size=0.12",
                                linewidth=1.8, edgecolor=color, facecolor="#FFFFFF"))
    ax.add_patch(FancyBboxPatch((x, Y + H - 0.60), w, 0.60,
                                boxstyle="round,pad=0.04,rounding_size=0.12",
                                linewidth=0, facecolor=color))
    ax.text(x + w/2, Y + H - 0.30, head, ha="center", va="center",
            color="white", fontsize=12.5, fontweight="bold")
    ax.text(x + w/2, Y + H/2 - 0.35, body, ha="center", va="center",
            color="#1E2732", fontsize=11, linespacing=1.35)
    if i < len(blocks) - 1:
        ax.add_patch(FancyArrowPatch((x + w + 0.08, Y + H/2), (blocks[i+1][0] - 0.08, Y + H/2),
                                     arrowstyle="-|>", mutation_scale=18,
                                     linewidth=2.0, color="#536273"))
fig.tight_layout(pad=0.15)
fig.savefig(os.path.join(FIG, "panel_workflow.png"), dpi=300,
            bbox_inches="tight", pad_inches=0.02, facecolor="white")
plt.close(fig)

# ---- remaining panels: flatten, strip embedded titles, trim white ----------
# passes = number of in-figure title lines to remove from the top
jobs = [("src_network.png", "panel_network.png", 2),
        ("src_drivers.png", "panel_drivers.png", 1),
        ("src_coregenes.png", "panel_coregenes.png", 1),
        ("src_singlecell.png", "panel_singlecell.png", 1)]
for src, dst, passes in jobs:
    im = flatten(Image.open(os.path.join(FIG, src)))
    before = im.size
    for _ in range(passes):
        im = strip_top_title(im)
    im = autocrop(im)
    im.save(os.path.join(FIG, dst), dpi=(300, 300))
    print(f"{dst:24s} {before[0]}x{before[1]} -> {im.width}x{im.height}")

w = Image.open(os.path.join(FIG, "panel_workflow.png"))
print(f"{'panel_workflow.png':24s} -> {w.width}x{w.height}")
