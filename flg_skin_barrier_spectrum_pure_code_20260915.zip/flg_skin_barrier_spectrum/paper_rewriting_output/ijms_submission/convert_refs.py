#!/usr/bin/env python3
"""Convert the JID author-year manuscript to MDPI numbered citations.

References are numbered in order of first appearance in the text, and the
reference list is re-emitted in that order. The script fails loudly on any
citation it cannot resolve, so a silent mis-numbering is not possible.
"""
import re, sys, unicodedata
from pathlib import Path

SRC = Path(__file__).resolve().parents[1] / "jid_innovations_submission/manuscript/jid_manuscript_anonymized.md"

TOKEN = re.compile(
    r"([A-ZÀ-ſ][\wÀ-ſ'’-]*(?:-[A-Z][\wÀ-ſ-]*)?)"   # surname
    r"(?:\s+et\s+al\.|\s+and\s+[A-Z][\wÀ-ſ-]+)?"                            # et al. / and X
    r",\s*(\d{4})"                                                                     # , year
)

def norm(s):
    return unicodedata.normalize("NFKD", s).encode("ascii", "ignore").decode().lower()

def parse_reference_list(text):
    """Return {(surname, year): full reference string} from the JID reference block."""
    block = text.split("# References", 1)[1]
    block = block.split("\n# ", 1)[0]
    refs = {}
    for line in block.strip().split("\n\n"):
        line = line.strip()
        if not line:
            continue
        surname = line.split(" ")[0].rstrip(",")
        years = re.findall(r"\b(19|20)(\d{2})\b", line)
        m = re.search(r"\b(19\d{2}|20\d{2})\b;", line) or re.search(r"\b(19\d{2}|20\d{2})\b", line)
        year = m.group(1)
        refs[(norm(surname), year)] = line
    return refs


def main():
    text = SRC.read_text()
    refs = parse_reference_list(text)
    pre, rest = text.split("# References", 1)
    ref_block, post = rest.split("\n# ", 1)
    body = pre + "# " + post          # keep Table, Figure Legends and Supplementary

    order, mapping, unresolved = [], {}, []

    def num_for(surname, year):
        key = (norm(surname), year)
        if key not in refs:
            unresolved.append(f"{surname}, {year}")
            return None
        if key not in mapping:
            order.append(key)
            mapping[key] = len(order)
        return mapping[key]

    def is_pure_citation_group(inner):
        parts = [p.strip() for p in inner.split(";")]
        return all(TOKEN.fullmatch(p) for p in parts) and len(parts) >= 1

    def replace_group(m):
        inner = m.group(1)
        if not is_pure_citation_group(inner):
            return m.group(0)
        nums = []
        for part in (p.strip() for p in inner.split(";")):
            t = TOKEN.fullmatch(part)
            n = num_for(t.group(1), t.group(2))
            if n is None:
                return m.group(0)
            nums.append(n)
        return "[" + ",".join(str(n) for n in nums) + "]"

    # 1. parenthesised citation groups, in reading order
    body = re.sub(r"\(([^()]*?\b(?:19|20)\d{2}\b[^()]*?)\)", replace_group, body)

    # 2. any remaining bare narrative citations
    def replace_bare(m):
        n = num_for(m.group(1), m.group(2))
        return m.group(0) if n is None else f"[{n}]"
    body = TOKEN.sub(replace_bare, body)

    if unresolved:
        sys.exit("UNRESOLVED CITATIONS: " + "; ".join(sorted(set(unresolved))))

    used = set(mapping)
    if used != set(refs):
        missing = {f"{s} {y}" for s, y in set(refs) - used}
        sys.exit(f"REFERENCES NEVER CITED: {sorted(missing)}")

    numbered = "\n\n".join(f"{i}. {refs[k]}" for i, k in enumerate(order, 1))
    Path("manuscript/_body_numbered.md").write_text(body)
    Path("manuscript/_references_numbered.md").write_text(numbered + "\n")
    print(f"{len(order)} references numbered in order of appearance")
    for i, k in enumerate(order, 1):
        print(f"  [{i}] {k[0]} {k[1]}")

if __name__ == "__main__":
    main()
