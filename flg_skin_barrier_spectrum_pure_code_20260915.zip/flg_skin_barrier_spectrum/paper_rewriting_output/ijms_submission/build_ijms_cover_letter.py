#!/usr/bin/env python3
"""Rebuild the IJMS cover letter DOCX from manuscript/cover_letter.md.

Mirrors the JID package's cover-letter path (pandoc -> one-page formatting ->
metadata scrub) so the two submissions stay visually consistent.
"""
import subprocess
from pathlib import Path

from docx import Document
from docx.shared import Inches, Pt

HERE = Path(__file__).resolve().parent
JID = HERE.parent / "jid_innovations_submission"
COVER_MD = HERE / "manuscript" / "cover_letter.md"
COVER_DOCX = HERE / "cover_letter.docx"
UPLOAD = HERE / "upload_ready"
REFERENCE = JID / "archive" / "pre_reconstruction_20260829" / "jid_manuscript_anonymized.docx"
YAML = JID / "manuscript" / "ref.docx.yaml"


def pandoc(source: Path, output: Path) -> None:
    subprocess.run(
        ["pandoc", str(source), "--from=gfm", "--to=docx",
         f"--reference-doc={REFERENCE}", f"--metadata-file={YAML}",
         "--output", str(output)],
        check=True,
    )


def format_cover_letter(path: Path) -> None:
    """Keep the journal cover letter within its required one-page format."""
    doc = Document(path)
    for section in doc.sections:
        section.top_margin = Inches(0.55)
        section.bottom_margin = Inches(0.55)
        section.left_margin = Inches(0.75)
        section.right_margin = Inches(0.75)
    normal = doc.styles["Normal"]
    normal.font.size = Pt(10)
    normal.paragraph_format.space_after = Pt(2)
    normal.paragraph_format.line_spacing = 1.0
    for paragraph in doc.paragraphs:
        paragraph.paragraph_format.space_after = Pt(2)
        paragraph.paragraph_format.line_spacing = 1.0
        for run in paragraph.runs:
            run.font.size = Pt(10)
    doc.save(path)


def scrub_docx(path: Path, title: str, subject: str) -> None:
    doc = Document(path)
    props = doc.core_properties
    props.title = title
    props.subject = subject
    props.author = ""
    props.last_modified_by = ""
    props.comments = ""
    props.keywords = ""
    doc.save(path)


def main() -> None:
    if not COVER_MD.exists():
        raise FileNotFoundError(f"Cover letter source missing: {COVER_MD}")
    pandoc(COVER_MD, COVER_DOCX)
    format_cover_letter(COVER_DOCX)
    scrub_docx(COVER_DOCX, "Cover letter — AD–ACD replication-surveillance program", "Cover letter")
    UPLOAD.mkdir(exist_ok=True)
    (UPLOAD / "cover_letter.docx").write_bytes(COVER_DOCX.read_bytes())
    print(f"Wrote {COVER_DOCX}")
    print(f"Wrote {UPLOAD / 'cover_letter.docx'}")


if __name__ == "__main__":
    main()
