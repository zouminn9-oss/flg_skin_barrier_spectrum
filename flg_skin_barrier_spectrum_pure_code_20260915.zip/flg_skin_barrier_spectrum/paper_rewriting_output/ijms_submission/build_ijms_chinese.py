#!/usr/bin/env python3
"""Build the Chinese review translation of the current IJMS manuscript."""

from pathlib import Path
import subprocess
import tempfile
import uuid
import xml.etree.ElementTree as ET
from zipfile import ZIP_DEFLATED, ZipFile

from docx import Document
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor


HERE = Path(__file__).resolve().parent
SOURCE = HERE / "manuscript/ijms_manuscript_chinese.md"
ENGLISH = HERE / "manuscript/ijms_manuscript.md"
OUTPUT = HERE / "ijms_manuscript_chinese.docx"
REFERENCE = HERE / "ijms_manuscript.docx"
FIGURES = HERE.parent / "jid_innovations_submission" / "figures"

BODY_CJK = "Arial Unicode MS"
HEAD_CJK = "Arial Unicode MS"
FONT_FILE = Path("/System/Library/Fonts/Supplemental/Arial Unicode.ttf")
FONT_KEY = uuid.UUID("8e65a1c4-34cf-4db5-93bb-8be2013dc2e1")

W_NS = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
R_NS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
REL_NS = "http://schemas.openxmlformats.org/package/2006/relationships"
CT_NS = "http://schemas.openxmlformats.org/package/2006/content-types"


def set_run_fonts(run, cjk=BODY_CJK):
    run.font.name = cjk
    rpr = run._element.get_or_add_rPr()
    rfonts = rpr.rFonts
    if rfonts is None:
        rfonts = OxmlElement("w:rFonts")
        rpr.insert(0, rfonts)
    for key in ("ascii", "hAnsi", "eastAsia"):
        rfonts.set(qn(f"w:{key}"), cjk)


def set_style_fonts(style, cjk=BODY_CJK):
    style.font.name = cjk
    rpr = style.element.get_or_add_rPr()
    rfonts = rpr.rFonts
    if rfonts is None:
        rfonts = OxmlElement("w:rFonts")
        rpr.insert(0, rfonts)
    for key in ("ascii", "hAnsi", "eastAsia"):
        rfonts.set(qn(f"w:{key}"), cjk)


def set_cell_margins(cell, top=90, start=110, bottom=90, end=110):
    tc_pr = cell._tc.get_or_add_tcPr()
    tc_mar = tc_pr.first_child_found_in("w:tcMar")
    if tc_mar is None:
        tc_mar = OxmlElement("w:tcMar")
        tc_pr.append(tc_mar)
    for name, value in (("top", top), ("start", start), ("bottom", bottom), ("end", end)):
        node = tc_mar.find(qn(f"w:{name}"))
        if node is None:
            node = OxmlElement(f"w:{name}")
            tc_mar.append(node)
        node.set(qn("w:w"), str(value))
        node.set(qn("w:type"), "dxa")


def style_table(table):
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = True
    for row_index, row in enumerate(table.rows):
        for cell in row.cells:
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            set_cell_margins(cell)
            tc_pr = cell._tc.get_or_add_tcPr()
            if row_index == 0:
                shd = tc_pr.first_child_found_in("w:shd")
                if shd is None:
                    shd = OxmlElement("w:shd")
                    tc_pr.append(shd)
                shd.set(qn("w:fill"), "D9EAF7")
            for paragraph in cell.paragraphs:
                paragraph.paragraph_format.space_after = Pt(2)
                paragraph.paragraph_format.line_spacing = 1.08
                for run in paragraph.runs:
                    set_run_fonts(run)
                    run.font.size = Pt(8.5)


def style_document(path):
    doc = Document(path)
    props = doc.core_properties
    props.title = "抗原呈递细胞与角质形成细胞以相反方向部署共同的复制监视程序"
    props.subject = "最新 IJMS 主文中文审阅译稿"
    props.author = ""
    props.last_modified_by = ""
    props.comments = "中文审阅译稿；统计值、标识符与参考文献均依照英文投稿稿保留"

    for section in doc.sections:
        section.page_width = Inches(8.5)
        section.page_height = Inches(11)
        section.top_margin = Inches(0.75)
        section.bottom_margin = Inches(0.75)
        section.left_margin = Inches(0.8)
        section.right_margin = Inches(0.8)
        section.header_distance = Inches(0.3)
        section.footer_distance = Inches(0.3)

        header = section.header.paragraphs[0]
        header.text = "IJMS 主文中文审阅译稿"
        header.alignment = WD_ALIGN_PARAGRAPH.RIGHT
        for run in header.runs:
            set_run_fonts(run)
            run.font.size = Pt(8)
            run.font.color.rgb = RGBColor(96, 96, 96)

        footer = section.footer.paragraphs[0]
        footer.text = "仅供中文审阅  正式投稿以英文稿为准"
        footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
        for run in footer.runs:
            set_run_fonts(run)
            run.font.size = Pt(8)
            run.font.color.rgb = RGBColor(96, 96, 96)

    for style in doc.styles:
        if style.type == 1:
            set_style_fonts(style, HEAD_CJK if style.name.startswith("Heading") else BODY_CJK)

    normal = doc.styles["Normal"]
    normal.font.size = Pt(10.5)
    normal.paragraph_format.space_after = Pt(4)
    normal.paragraph_format.line_spacing = 1.25

    for name, size, before, after in (
        ("Title", 17, 0, 10),
        ("Heading 1", 15, 12, 6),
        ("Heading 2", 12.5, 10, 5),
        ("Heading 3", 11.5, 8, 4),
    ):
        if name in doc.styles:
            style = doc.styles[name]
            style.font.size = Pt(size)
            style.font.bold = True
            style.font.color.rgb = RGBColor(0, 0, 0)
            style.paragraph_format.space_before = Pt(before)
            style.paragraph_format.space_after = Pt(after)
            style.paragraph_format.keep_with_next = True

    for paragraph in doc.paragraphs:
        is_heading = paragraph.style and paragraph.style.name.startswith("Heading")
        for run in paragraph.runs:
            set_run_fonts(run, HEAD_CJK if is_heading else BODY_CJK)
        text = paragraph.text.strip()
        if text.startswith("图 ") and "." in text[:8]:
            paragraph.paragraph_format.keep_with_next = False
            paragraph.paragraph_format.space_before = Pt(3)
            paragraph.paragraph_format.space_after = Pt(7)
        if any(run._element.xpath(".//w:drawing") for run in paragraph.runs):
            paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
            paragraph.paragraph_format.space_before = Pt(5)
            paragraph.paragraph_format.space_after = Pt(3)

    max_width = Inches(6.55)
    max_height = Inches(7.2)
    for shape in doc.inline_shapes:
        ratio = shape.width / shape.height
        width = min(shape.width, max_width)
        height = int(width / ratio)
        if height > max_height:
            height = max_height
            width = int(height * ratio)
        shape.width = int(width)
        shape.height = int(height)

    for table in doc.tables:
        style_table(table)

    doc.save(path)


def embed_cjk_font(path):
    """Embed an editable-embedding CJK TrueType font for portable rendering."""
    raw = bytearray(FONT_FILE.read_bytes())
    key = FONT_KEY.bytes
    for index in range(min(32, len(raw))):
        raw[index] ^= key[15 - (index % 16)]

    with ZipFile(path, "r") as zin:
        members = {name: zin.read(name) for name in zin.namelist()}

    ET.register_namespace("w", W_NS)
    ET.register_namespace("r", R_NS)
    font_root = ET.fromstring(members["word/fontTable.xml"])
    for old in list(font_root.findall(f"{{{W_NS}}}font")):
        if old.get(f"{{{W_NS}}}name") == BODY_CJK:
            font_root.remove(old)
    font = ET.SubElement(font_root, f"{{{W_NS}}}font", {f"{{{W_NS}}}name": BODY_CJK})
    ET.SubElement(font, f"{{{W_NS}}}charset", {f"{{{W_NS}}}val": "86"})
    ET.SubElement(font, f"{{{W_NS}}}family", {f"{{{W_NS}}}val": "swiss"})
    ET.SubElement(font, f"{{{W_NS}}}pitch", {f"{{{W_NS}}}val": "variable"})
    ET.SubElement(
        font,
        f"{{{W_NS}}}embedRegular",
        {
            f"{{{R_NS}}}id": "rIdCjkFont1",
            f"{{{W_NS}}}fontKey": "{" + str(FONT_KEY).upper() + "}",
            f"{{{W_NS}}}subsetted": "0",
        },
    )
    members["word/fontTable.xml"] = ET.tostring(font_root, encoding="utf-8", xml_declaration=True)

    rel_path = "word/_rels/fontTable.xml.rels"
    if rel_path in members:
        rel_root = ET.fromstring(members[rel_path])
    else:
        rel_root = ET.Element(f"{{{REL_NS}}}Relationships")
    for old in list(rel_root.findall(f"{{{REL_NS}}}Relationship")):
        if old.get("Id") == "rIdCjkFont1":
            rel_root.remove(old)
    ET.SubElement(
        rel_root,
        f"{{{REL_NS}}}Relationship",
        {
            "Id": "rIdCjkFont1",
            "Type": "http://schemas.openxmlformats.org/officeDocument/2006/relationships/font",
            "Target": "fonts/arial-unicode-ms.odttf",
        },
    )
    members[rel_path] = ET.tostring(rel_root, encoding="utf-8", xml_declaration=True)

    content_types = ET.fromstring(members["[Content_Types].xml"])
    if not any(
        node.get("Extension") == "odttf"
        for node in content_types.findall(f"{{{CT_NS}}}Default")
    ):
        new_default = ET.Element(
            f"{{{CT_NS}}}Default",
            {
                "Extension": "odttf",
                "ContentType": "application/vnd.openxmlformats-officedocument.obfuscatedFont",
            },
        )
        first_override = next(
            (
                index
                for index, node in enumerate(list(content_types))
                if node.tag == f"{{{CT_NS}}}Override"
            ),
            len(content_types),
        )
        content_types.insert(first_override, new_default)
    members["[Content_Types].xml"] = ET.tostring(
        content_types, encoding="utf-8", xml_declaration=True
    )
    members["word/fonts/arial-unicode-ms.odttf"] = bytes(raw)

    temp_path = path.with_suffix(".fonttmp.docx")
    with ZipFile(temp_path, "w", ZIP_DEFLATED) as zout:
        for name, payload in members.items():
            zout.writestr(name, payload)
    temp_path.replace(path)


def main():
    english = ENGLISH.read_text(encoding="utf-8")
    refs = english.split("## References", 1)[1].strip()
    chinese = SOURCE.read_text(encoding="utf-8").rstrip() + "\n\n" + refs + "\n"
    with tempfile.TemporaryDirectory(prefix="ijms_zh_") as temp_dir:
        full_source = Path(temp_dir) / "ijms_manuscript_chinese_full.md"
        full_source.write_text(chinese, encoding="utf-8")
        subprocess.run(
            [
                "/usr/local/bin/pandoc",
                str(full_source),
                "--from=gfm",
                "--to=docx",
                f"--reference-doc={REFERENCE}",
                f"--resource-path={SOURCE.parent}:{FIGURES}",
                "--output",
                str(OUTPUT),
            ],
            check=True,
        )
    style_document(OUTPUT)
    print(OUTPUT)


if __name__ == "__main__":
    main()
