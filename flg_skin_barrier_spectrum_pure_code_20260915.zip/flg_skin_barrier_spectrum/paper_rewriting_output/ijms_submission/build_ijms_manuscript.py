#!/usr/bin/env python3
"""Assemble the IJMS (MDPI) manuscript from the numbered body.

Differences from the JID package, all of them format:
  * single-blind: author block restored into the manuscript
  * numbered sections and subsections
  * figures and tables embedded at first citation, as MDPI requires
  * MDPI back matter, including Conclusions, Funding and IRB statements
"""
import re
from pathlib import Path

HERE = Path(__file__).resolve().parent
BODY = (HERE / "manuscript/_body_numbered.md").read_text()
REFS = (HERE / "manuscript/_references_numbered.md").read_text().strip()
OUT = HERE / "manuscript/ijms_manuscript.md"

def section(text, name):
    m = re.search(rf"^# {re.escape(name)}\n(.*?)(?=^# |\Z)", text, re.S | re.M)
    return m.group(1).strip() if m else ""

abstract   = section(BODY, "Abstract")
intro      = section(BODY, "Introduction")
results    = section(BODY, "Results")
discussion = section(BODY, "Discussion")
methods    = section(BODY, "Materials and Methods")
table_blk  = section(BODY, "Table")
legends    = section(BODY, "Figure Legends")
suppl      = section(BODY, "Supplementary Material")

# ---- figure captions, keyed by number -------------------------------------
captions = {}
for m in re.finditer(r"\*\*Figure (\d)\.(.*?)\*\*(.*?)(?=\n\n\*\*Figure|\Z)", legends, re.S):
    n = int(m.group(1))
    captions[n] = f"**Figure {n}.**{m.group(2)}{m.group(3)}".strip()

# ---- embed each figure after the paragraph that first cites it -------------
def embed_figures(text):
    paras = text.split("\n\n")
    placed, out = set(), []
    for para in paras:
        out.append(para)
        for n in sorted(captions):
            if n in placed:
                continue
            if re.search(rf"Figure {n}[a-e]?\b", para):
                out.append(f"![](../../jid_innovations_submission/figures/figure{n}.png)")
                out.append(captions[n])
                placed.add(n)
    missing = set(captions) - placed
    if missing:
        raise SystemExit(f"figures never cited in Results: {sorted(missing)}")
    return "\n\n".join(out)

results = embed_figures(results)

# ---- Table 1 goes after its first citation --------------------------------
table_md = table_blk.replace("**Table 1. Public transcriptomic datasets and analytical roles.**",
                             "**Table 1.** Public transcriptomic datasets and analytical roles.").strip()
paras = results.split("\n\n")
for i, para in enumerate(paras):
    if "Table 1" in para and not para.startswith("|"):
        paras.insert(i + 1, table_md)
        break
results = "\n\n".join(paras)

# ---- number sections and subsections --------------------------------------
def number_subsections(text, major):
    out, minor = [], 0
    for line in text.split("\n"):
        if line.startswith("## "):
            minor += 1
            out.append(f"### {major}.{minor}. {line[3:]}")
        else:
            out.append(line)
    return "\n".join(out)

results_n = number_subsections(results, 2)
methods_n = number_subsections(methods, 4)

conclusions = (
"A shared replication–repair program is allocated to different cellular compartments in allergic and irritant skin "
"inflammation. The recurrent 16-gene set reads this allocation state rather than generic inflammatory intensity. In "
"whole AD biopsies, it measures proliferation-linked tissue renewal; at cell resolution, allergic challenge assigns "
"the program to antigen-presenting cells and irritant injury assigns it to keratinocytes, with stronger polarity after "
"mitotic content is removed. APC allocation therefore marks immune stress adaptation, whereas keratinocyte allocation "
"marks epithelial barrier repair. MIF–CD74, LGALS9/HBEGF, reciprocal glucose use and YY1-centered regulation provide "
"experimental entry points into the switch. The resulting endotype framework turns the cellular distribution of "
"replication–repair demand into a compact molecular coordinate for mechanism stratification, sensitization-related "
"assessment, treatment selection and response monitoring in biopsy, single-cell and spatial studies.")

authors = """Yue-Min Zou ^1^, Si-Ran Bao ^1^, Yi-Ming Qi ^1^ and Jie Ma ^2,\\*^

^1^ Beijing University of Chinese Medicine, Beijing, China; ydkabb@163.com (Y.-M.Z.); 17835489728@163.com (S.-R.B.); 20190125040@bucm.edu.cn (Y.-M.Q.)

^2^ Xiyuan Hospital of China Academy of Chinese Medical Sciences, Beijing, China; majiexyyy@126.com

\\* Correspondence: majiexyyy@126.com; Tel.: +86-10-62835103; No. 1 Xiyuan Caochang, Haidian District, Beijing 100091, P.R. China"""

doc = f"""**Article**

# Antigen-Presenting Cells and Keratinocytes Deploy a Shared Replication-Surveillance Program in Opposite Directions

{authors}

**Abstract:** {abstract}

**Keywords:** allergic contact dermatitis; atopic dermatitis; replication stress; antigen-presenting cells; single-cell transcriptomics; similarity network fusion

## 1. Introduction

{intro}

## 2. Results

{results_n}

## 3. Discussion

{discussion}

## 4. Materials and Methods

{methods_n}

## 5. Conclusions

{conclusions}

## Supplementary Materials

The following supporting information can be downloaded at the journal website. {suppl}

## Author Contributions

Conceptualization, Y.-M.Z. and J.M.; data curation, Y.-M.Z., S.-R.B. and Y.-M.Q.; formal analysis, Y.-M.Z., S.-R.B. and Y.-M.Q.; investigation, Y.-M.Z., S.-R.B. and Y.-M.Q.; methodology, Y.-M.Z., S.-R.B. and J.M.; software, Y.-M.Z. and S.-R.B.; validation, S.-R.B., Y.-M.Z., Y.-M.Q. and J.M.; visualization, Y.-M.Z. and S.-R.B.; resources, J.M. and Y.-M.Q.; supervision, J.M.; project administration, J.M.; writing—original draft preparation, Y.-M.Z., S.-R.B. and Y.-M.Q.; writing—review and editing, J.M., Y.-M.Z., S.-R.B. and Y.-M.Q. All authors have read and agreed to the published version of the manuscript.

## Funding

This research received no external funding.

## Institutional Review Board Statement

Not applicable. This study did not involve new human participants or animals. It reanalyzed only de-identified data from public repositories and did not recruit participants, obtain new specimens or generate new human or animal data, so institutional review board review and approval were not required. Ethics approval and informed consent for each contributing study were obtained by its original investigators and are described in the corresponding source publications and repository records.

## Informed Consent Statement

Not applicable.

## Data Availability Statement

All expression data analyzed in this study are publicly available and were not generated by the authors. Primary expression records are available from the Gene Expression Omnibus under accessions GSE121212, GSE32924, GSE36842, GSE6281, GSE282562, GSE18206, GSE13355, GSE53795, GSE65914, GSE137141, GSE72702, GSE267929 and GSE328048, and from BioStudies/ArrayExpress under accessions E-MTAB-8945 and E-MTAB-9501. The derived cohort-level effect and standard-error tables, pathway meta-analysis grid, all 396 similarity-network-fusion specification results, permutation and bootstrap distributions, pathway-influence tables, core-gene tables, single-cell compartment statistics, cell-cycle-independence outputs, and external-validation scores and null distributions, together with every analysis script, threshold, random seed and source checksum, are available at https://github.com/zouminn9-oss/flg_skin_barrier_spectrum. No restrictions apply to any component.

## Acknowledgments

We acknowledge the investigators who generated and publicly deposited the datasets reanalyzed here. No non-author contributors are declared.

## Conflicts of Interest

The authors declare no conflict of interest.

## References

{REFS}
"""

OUT.write_text(doc)
import subprocess
subprocess.run(["pandoc", str(OUT), "--from=markdown", "--to=docx",
                f"--reference-doc={HERE / 'ijms_manuscript_40refs.docx'}",
                f"--resource-path={OUT.parent}:{HERE.parent}/jid_innovations_submission/figures",
                "--output", str(HERE / "ijms_manuscript.docx")], check=True)
print(f"wrote {OUT.name}: {len(doc.split())} words -> ijms_manuscript.docx")
print("figures embedded:", sorted(captions))
