#!/usr/bin/env python3
"""Rewrite manuscript/_references_numbered.md from Vancouver into MDPI style.

MDPI journal-article form:
    N. Surname, A.B.; Surname, C.D.; et al. Title. *J. Abbrev.* **Year**, *Vol*, pages.

Run AFTER convert_refs.py (which emits Vancouver) and BEFORE
build_ijms_manuscript.py. Idempotent: entries already in MDPI form are left
alone. Fails loudly on any entry or journal it cannot resolve, so a silently
mis-formatted reference list is not possible.
"""
import re
import sys
from pathlib import Path

REFS = Path(__file__).resolve().parent / "manuscript/_references_numbered.md"

# ISO4 / MDPI abbreviations for every journal appearing in this reference list.
JOURNALS = {
    "Allergy": "Allergy",
    "BMC Med Genomics": "BMC Med. Genom.",
    "Bioinformatics": "Bioinformatics",
    "Cancer Discov": "Cancer Discov.",
    "Cell": "Cell",
    "Cell Rep": "Cell Rep.",
    "Cells": "Cells",
    "Genes (Basel)": "Genes",
    "Genome Biol": "Genome Biol.",
    "Genome Res": "Genome Res.",
    "J Allergy Clin Immunol": "J. Allergy Clin. Immunol.",
    "J Clin Immunol": "J. Clin. Immunol.",
    "J Invest Dermatol": "J. Investig. Dermatol.",
    "J R Stat Soc Series B Stat Methodol": "J. R. Stat. Soc. Ser. B Stat. Methodol.",
    "J Stat Softw": "J. Stat. Softw.",
    "Lancet": "Lancet",
    "Mol Cell": "Mol. Cell",
    "NPJ Syst Biol Appl": "npj Syst. Biol. Appl.",
    "Nat Cell Biol": "Nat. Cell Biol.",
    "Nat Commun": "Nat. Commun.",
    "Nat Immunol": "Nat. Immunol.",
    "Nat Methods": "Nat. Methods",
    "Nat Protoc": "Nat. Protoc.",
    "Nat Rev Immunol": "Nat. Rev. Immunol.",
    "Nucleic Acids Res": "Nucleic Acids Res.",
    "Pharmacol Res": "Pharmacol. Res.",
    "Proc Natl Acad Sci U S A": "Proc. Natl. Acad. Sci. USA",
    "Science": "Science",
}

# Non-article entries, keyed by reference number, rewritten in MDPI report form.
SPECIAL = {
    35: ("OECD. Test No. 442D: In Vitro Skin Sensitisation: Assays Addressing the Adverse "
         "Outcome Pathway Key Event on Keratinocyte Activation; OECD Guidelines for the Testing "
         "of Chemicals, Section 4; OECD Publishing: Paris, France, 2026. "
         "https://doi.org/10.1787/9789264229822-en."),
    36: ("OECD. Test No. 442E: In Vitro Skin Sensitisation: Assays Addressing the Key Event on "
         "Activation of Dendritic Cells on the Adverse Outcome Pathway for Skin Sensitisation; "
         "OECD Guidelines for the Testing of Chemicals, Section 4; OECD Publishing: Paris, "
         "France, 2026. https://doi.org/10.1787/9789264264359-en."),
}

ARTICLE = re.compile(
    r"^(?P<num>\d+)\.\s+"
    r"(?P<authors>.*?)\.\s+"
    r"(?P<title>.*?)\.\s+"
    r"(?P<journal>[A-Z][^.;:]*?)\s+"
    r"(?P<year>\d{4});"
    r"(?P<volume>[^:]+):"
    r"(?P<pages>.+?)\.$",
    re.S,
)


def format_author(token: str) -> str:
    """'Di Domizio J' -> 'Di Domizio, J.';  'Tsoi LC' -> 'Tsoi, L.C.'"""
    token = token.strip()
    if token.rstrip(".") == "et al":
        return "et al."
    parts = token.split()
    if len(parts) < 2:
        raise ValueError(f"cannot split author name: {token!r}")
    surname, initials = " ".join(parts[:-1]), parts[-1]
    if not re.fullmatch(r"[A-ZÀ-Þ]{1,4}", initials):
        raise ValueError(f"unexpected initials {initials!r} in {token!r}")
    return f"{surname}, " + "".join(f"{c}." for c in initials)


def convert(entry: str) -> str:
    entry = " ".join(entry.split())
    num = int(entry.split(".", 1)[0])
    if num in SPECIAL:
        return f"{num}. {SPECIAL[num]}"
    if "**" in entry:                      # already MDPI style
        return entry
    m = ARTICLE.match(entry)
    if not m:
        raise ValueError(f"unparsed reference: {entry[:110]}")
    journal = m.group("journal").strip()
    if journal not in JOURNALS:
        raise ValueError(f"unknown journal {journal!r} in reference {num}")
    authors = "; ".join(format_author(a) for a in m.group("authors").split(", "))
    return (f"{num}. {authors} {m.group('title')}. "
            f"*{JOURNALS[journal]}* **{m.group('year')}**, "
            f"*{m.group('volume')}*, {m.group('pages')}.")


def main() -> None:
    entries = [e.strip() for e in REFS.read_text().split("\n\n") if e.strip()]
    out, errors = [], []
    for e in entries:
        try:
            out.append(convert(e))
        except ValueError as exc:
            errors.append(str(exc))
    if errors:
        sys.exit("MDPI REFERENCE CONVERSION FAILED:\n  " + "\n  ".join(errors))
    expected = list(range(1, len(out) + 1))
    got = [int(o.split(".", 1)[0]) for o in out]
    if got != expected:
        sys.exit(f"NUMBERING BROKEN: {got}")
    REFS.write_text("\n\n".join(out) + "\n")
    print(f"{len(out)} references rewritten in MDPI style")


if __name__ == "__main__":
    main()
