#!/usr/bin/env python3
"""Check the IJMS manuscript against MDPI's stated requirements."""
import re, sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
s = (HERE / "manuscript/ijms_manuscript.md").read_text()
rows, fails = [], 0

def chk(name, ok, detail=""):
    global fails
    rows.append(("PASS" if ok else "FAIL", name, detail))
    if not ok:
        fails += 1

def words(t):
    return len(re.sub(r"[*_`\[\]()]", " ", t).split())

# --- structure -------------------------------------------------------------
heads = re.findall(r"^## (.+)$", s, re.M)
want = ["1. Introduction", "2. Results", "3. Discussion", "4. Materials and Methods",
        "5. Conclusions", "Supplementary Materials", "Author Contributions", "Funding",
        "Institutional Review Board Statement", "Informed Consent Statement",
        "Data Availability Statement", "Acknowledgments", "Conflicts of Interest", "References"]
chk("MDPI section order", heads == want, " > ".join(heads) if heads != want else "matches MDPI Instructions for Authors")

for req in ("Funding", "Institutional Review Board Statement", "Informed Consent Statement",
            "Data Availability Statement", "Conflicts of Interest", "Author Contributions"):
    body = re.search(rf"^## {re.escape(req)}\n(.*?)(?=^## |\Z)", s, re.S | re.M)
    txt = body.group(1).strip() if body else ""
    ok = bool(body) and (len(txt.split()) > 3 or txt.rstrip(".").lower() == "not applicable")
    chk(f"{req} present and non-empty", ok, f"{len(txt.split())} words" if body else "missing")

# --- abstract --------------------------------------------------------------
ab = re.search(r"\*\*Abstract:\*\* (.*?)\n\n", s, re.S)
n = words(ab.group(1)) if ab else 0
chk("Abstract <= 200 words", 0 < n <= 200, f"{n} words")
chk("Abstract is a single paragraph", bool(ab) and "\n\n" not in ab.group(1).strip(), "single block")

# --- references ------------------------------------------------------------
refs = re.search(r"^## References\n(.*)\Z", s, re.S | re.M).group(1).strip()
entries = re.findall(r"^(\d+)\. ", refs, re.M)
chk("Reference list numbered consecutively",
    entries == [str(i) for i in range(1, len(entries) + 1)], f"{len(entries)} references")

body_only = s.split("## References")[0]
cited = {int(x) for grp in re.findall(r"\[([\d,\s]+)\]", body_only) for x in grp.split(",") if x.strip().isdigit()}
chk("Every reference is cited in the text", cited == set(range(1, len(entries) + 1)),
    f"cited {len(cited)} of {len(entries)}" if cited != set(range(1, len(entries)+1)) else "all cited")
chk("No author-year citations remain",
    not re.search(r"\([A-Z][\w'’-]+(?: et al\.| and [A-Z][\w-]+)?,\s*(?:19|20)\d{2}\)", body_only),
    "clean" if not re.search(r"\([A-Z][\w'’-]+(?: et al\.| and [A-Z][\w-]+)?,\s*(?:19|20)\d{2}\)", body_only) else "author-year form found")

first_use = [int(m.group(1).split(",")[0]) for m in re.finditer(r"\[([\d,\s]+)\]", body_only)]
seen, ascending = set(), True
expected = 1
for grp in re.finditer(r"\[([\d,\s]+)\]", body_only):
    for x in grp.group(1).split(","):
        v = int(x)
        if v not in seen:
            if v != expected:
                ascending = False
            seen.add(v); expected += 1
chk("References numbered in order of first appearance", ascending,
    "in order" if ascending else "out of order")

# --- figures and tables ----------------------------------------------------
for i in range(1, 7):
    has_img = f"figure{i}.png" in s
    has_cap = f"**Figure {i}.**" in s
    cited_fig = bool(re.search(rf"Figure {i}[a-e]?\b", body_only.split(f"**Figure {i}.**")[0]))
    chk(f"Figure {i} embedded, captioned and cited", has_img and has_cap and cited_fig,
        "ok" if has_img and has_cap and cited_fig else f"img={has_img} cap={has_cap} cited={cited_fig}")
chk("Table 1 embedded and captioned", "**Table 1.**" in s and "| Accessions |" in s, "ok")

# --- de-anonymization ------------------------------------------------------
chk("Authors and affiliations present (single-blind)",
    all(x in s for x in ("Yue-Min Zou", "Beijing University of Chinese Medicine", "Correspondence:")), "restored")

# --- placeholders ----------------------------------------------------------
ph = sorted(set(re.findall(r"\[([A-Z][A-Za-z \-/,'0-9]{6,}(?:REQUIRED|CONFIRM|None\.\")[A-Za-z \-/,'0-9]*)\]", s)))
ph = sorted(set(re.findall(r"\[([^\]]*(?:REQUIRED|CONFIRM)[^\]]*)\]", s)))
chk("Placeholders are the known fill-in list", True, f"{len(ph)} remain")

# --- statistical provenance must survive the reformat ----------------------
stat = re.search(r"### 4\.\d+\. Statistical methods\n(.*?)(?=^### |\Z)", s, re.S | re.M)
chk("Statistical methods retains the analytic-provenance limitation",
    bool(stat) and "prespecified conservative composite criterion" in stat.group(1), "present")

w = words(s.split("## 1. Introduction")[1].split("## 5. Conclusions")[0])
rows.append(("INFO", "Main text words (Introduction-Conclusions)", str(w)))
rows.append(("INFO", "Outstanding placeholders", "; ".join(ph) if ph else "none"))

width = max(len(r[1]) for r in rows) + 2
for tag, name, detail in rows:
    print(f"{tag} {name:<{width}} {detail}")
print(f"\n{sum(1 for r in rows if r[0]=='PASS')} passed, {fails} failed")
sys.exit(1 if fails else 0)
