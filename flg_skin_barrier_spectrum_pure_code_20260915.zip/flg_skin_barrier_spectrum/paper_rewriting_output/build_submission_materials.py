#!/usr/bin/env python3
"""Build the data-grounded supplement and submission documents."""

from __future__ import annotations

import csv
from pathlib import Path

from docx import Document
from docx.enum.section import WD_ORIENT
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "paper_rewriting_output"
SUP_DOCX = OUT / "final_paper" / "supplementary_information.docx"
SUP_MD = OUT / "final_paper" / "supplementary_information.md"

SENS = ROOT / "results/exploratory_sensitivity/method_grid_summary.tsv"
BRANCH = ROOT / "results/exploratory_snf/selected_positive_reml_z_q05/optimized_AD_ACD_branch"
EDGES = BRANCH / "optimized_edge_statistics.tsv"
DRIVERS = BRANCH / "mechanism/top_AD_ACD_pathway_drivers.tsv"
GENES = BRANCH / "mechanism/core_genes/tier1_core_genes.tsv"
CELLS = BRANCH / "mechanism/single_cell_localization/celltype_program_scores.tsv"
G4 = ROOT / "results/posthoc_exploratory_gate4_positive_branch"
LAYERS = G4 / "layer_coverage_audit.tsv"
CANDIDATE = G4 / "downstream_candidate_annotation_audit.tsv"


def read_tsv(path: Path):
    with path.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def fmt(value, digits=3):
    if value is None or value == "":
        return "—"
    try:
        x = float(value)
    except ValueError:
        return str(value)
    if x != 0 and abs(x) < 0.001:
        return f"{x:.2e}"
    return f"{x:.{digits}f}"


def shade(cell, fill):
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:fill"), fill)
    tc_pr.append(shd)


def set_cell_text(cell, text, bold=False, color=None, size=7.4):
    cell.text = ""
    p = cell.paragraphs[0]
    p.paragraph_format.space_after = Pt(0)
    p.paragraph_format.space_before = Pt(0)
    run = p.add_run(str(text))
    run.bold = bold
    run.font.name = "Arial"
    run.font.size = Pt(size)
    if color:
        run.font.color.rgb = RGBColor(*color)
    cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER


def add_table(doc, headers, rows, widths=None, font_size=7.4):
    table = doc.add_table(rows=1, cols=len(headers))
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.style = "Table Grid"
    table.autofit = False
    for i, header in enumerate(headers):
        set_cell_text(table.rows[0].cells[i], header, bold=True, color=(255, 255, 255), size=font_size)
        shade(table.rows[0].cells[i], "17365D")
        if widths:
            table.rows[0].cells[i].width = Inches(widths[i])
    table.rows[0]._tr.get_or_add_trPr().append(OxmlElement("w:tblHeader"))
    for ridx, row in enumerate(rows):
        cells = table.add_row().cells
        for i, value in enumerate(row):
            set_cell_text(cells[i], value, size=font_size)
            if widths:
                cells[i].width = Inches(widths[i])
            if ridx % 2:
                shade(cells[i], "EAF0F7")
    doc.add_paragraph()
    return table


def add_heading(doc, text, level=1):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(10 if level == 1 else 7)
    p.paragraph_format.space_after = Pt(4)
    run = p.add_run(text)
    run.bold = True
    run.font.name = "Arial"
    run.font.size = Pt(14 if level == 1 else 11)
    run.font.color.rgb = RGBColor(23, 54, 93)
    return p


def add_body(doc, text, italic=False):
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(5)
    p.paragraph_format.line_spacing = 1.05
    run = p.add_run(text)
    run.font.name = "Arial"
    run.font.size = Pt(9)
    run.italic = italic
    return p


def page_break(doc):
    doc.add_page_break()


def set_page_number(paragraph):
    paragraph.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    run = paragraph.add_run("Supplementary Information  |  ")
    run.font.name = "Arial"
    run.font.size = Pt(8)
    fld = OxmlElement("w:fldSimple")
    fld.set(qn("w:instr"), "PAGE")
    paragraph._p.append(fld)


def md_table(headers, rows):
    def clean(x):
        return str(x).replace("|", "\\|").replace("\n", " ")
    lines = ["| " + " | ".join(map(clean, headers)) + " |"]
    lines.append("| " + " | ".join(["---"] * len(headers)) + " |")
    lines.extend("| " + " | ".join(clean(v) for v in row) + " |" for row in rows)
    return "\n".join(lines)


def build():
    sens = [r for r in read_tsv(SENS) if r["disease"] in {"AD", "ACD"}]
    sens_rows = [
        [r["disease"], r["method_id"], r["estimator"], r["test"], r["fdr_threshold"],
         r["significant"], r["significant_direction_complete"], r["significant_lodo_stable"], r["role"]]
        for r in sens
    ]

    edges = sorted(read_tsv(EDGES), key=lambda r: -float(r["fused_similarity"]))
    edge_rows = [[
        str(i), f'{r["disease_1"]}–{r["disease_2"]}', fmt(r["fused_similarity"], 6),
        f'{fmt(r["bootstrap_ci_low"], 3)}–{fmt(r["bootstrap_ci_high"], 3)}',
        fmt(r["bootstrap_coclustering"], 3), fmt(r["nominal_permutation_p"], 4),
        fmt(r["nominal_permutation_q"], 6), r["same_cluster"].title()
    ] for i, r in enumerate(edges, 1)]

    drivers = read_tsv(DRIVERS)[:20]
    driver_rows = [[
        str(i), r["pathway"], r["theme"].replace("_", " "), fmt(r["support_influence"], 6),
        fmt(r["effect_AD"], 3), fmt(r["effect_ACD"], 3), r["effect_same_direction"]
    ] for i, r in enumerate(drivers, 1)]

    genes = read_tsv(GENES)
    gene_rows = [[
        r["gene"], r["top20_pathway_count"], fmt(r["weighted_pathway_support"], 4),
        fmt(r["logFC__AD_GSE121212_acute"], 3), fmt(r["logFC__AD_GSE32924"], 3),
        fmt(r["logFC__AD_GSE36842_acute"], 3), fmt(r["logFC__ACD_GSE282562"], 3),
        fmt(r["logFC__ACD_GSE6281_48h"], 3), fmt(r["AD_meta_logFC"], 3), fmt(r["ACD_meta_logFC"], 3)
    ] for r in genes]

    cells = read_tsv(CELLS)
    cell_rows = [[
        r["celltype"], r["paired_donors"], f'{r["driver_pathways_measured"]}/{r["driver_pathways_total"]}',
        r["driver_pathways_up"], fmt(r["driver_pathway_score"], 3),
        fmt(r["driver_pathway_empirical_p_two_sided"], 4), fmt(r["driver_pathway_q_BH_4celltypes"], 4),
        r["driver_program_direction"].replace("_", " ")
    ] for r in cells]

    layers = read_tsv(LAYERS)
    # The executed audit preserves a legacy column-name inversion: the numeric
    # count is stored under discovery_nodes_with_comparable_features and the
    # node list under covered_discovery_nodes. Normalize it for presentation.
    layer_rows = [[
        r["layer"].replace("_", " "), r["planned_weight"],
        f'{r["discovery_nodes_with_comparable_features"]}/{r["total_discovery_nodes"]}',
        r["covered_discovery_nodes"].replace(";", ", "),
        r["eligible_for_complete_fusion"], r["missing_value_handling"].replace("_", " "), r["limitation"]
    ] for r in layers]

    candidate = read_tsv(CANDIDATE)[0]
    candidate_rows = [[
        candidate["candidate"], candidate["annotation"],
        candidate["role"].replace("_", " "), fmt(candidate["targeted_BH_q"], 6),
        candidate["used_as_disease_network_layer"], candidate["clinical_efficacy_evidence"],
        candidate["safety_evidence"]
    ]]

    assets = [
        ["Disease-level sensitivity grid", "results/exploratory_sensitivity/method_grid_summary.tsv"],
        ["Selected SNF edge statistics", "results/exploratory_snf/selected_positive_reml_z_q05/optimized_AD_ACD_branch/optimized_edge_statistics.tsv"],
        ["Pathway deletion drivers", "…/mechanism/top_AD_ACD_pathway_drivers.tsv"],
        ["Recurrent core genes", "…/mechanism/core_genes/tier1_core_genes.tsv"],
        ["Single-cell localization", "…/mechanism/single_cell_localization/celltype_program_scores.tsv"],
        ["Four-layer coverage audit", "results/posthoc_exploratory_gate4_positive_branch/layer_coverage_audit.tsv"],
        ["Candidate annotation audit", "results/posthoc_exploratory_gate4_positive_branch/downstream_candidate_annotation_audit.tsv"],
        ["Frozen analysis plan", "gate12_snapshot/05_analysis_plan.md"],
        ["Main manuscript source", "paper_rewriting_output/final_paper/main.tex"],
    ]

    doc = Document()
    sec = doc.sections[0]
    sec.orientation = WD_ORIENT.LANDSCAPE
    sec.page_width, sec.page_height = Inches(11), Inches(8.5)
    sec.top_margin = sec.bottom_margin = Inches(0.55)
    sec.left_margin = sec.right_margin = Inches(0.55)
    sec.header_distance = Inches(0.25)
    sec.footer_distance = Inches(0.25)
    for section in doc.sections:
        set_page_number(section.footer.paragraphs[0])

    normal = doc.styles["Normal"]
    normal.font.name = "Arial"
    normal.font.size = Pt(9)
    normal.paragraph_format.space_after = Pt(4)

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(100)
    run = p.add_run("Supplementary Information")
    run.bold = True
    run.font.name = "Arial"
    run.font.size = Pt(24)
    run.font.color.rgb = RGBColor(23, 54, 93)
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run("A replication-surveillance transcriptomic network links atopic and allergic contact dermatitis")
    run.bold = True
    run.font.name = "Arial"
    run.font.size = Pt(15)
    add_body(doc, "This supplement reports the complete sensitivity grid and downstream numerical audits supporting the manuscript. It preserves the frozen confirmatory result while providing full resolution for the additional exploratory branch.")

    page_break(doc)
    add_heading(doc, "Supplementary methods")
    add_body(doc, "The pathway meta-analysis sensitivity grid crossed estimator (REML, DerSimonian–Laird, or fixed effect), test calibration (Hartung–Knapp or conventional normal approximation), and false-discovery threshold (0.05 or 0.10). Direction-complete counts require an available direction in every contributing cohort; leave-one-dataset-out (LODO) stability requires retention after each dataset omission.")
    add_body(doc, "The selected transcriptomic branch used four pathway views—positive, negative, immune/barrier, and stress/damage—and similarity network fusion with K=2, alpha=0.2, and 10 iterations. The specification space contained 396 branches. Edge inference used 10,000 label permutations; stability used 1,000 bootstrap resamples; the selected-branch calibration used 500 repetitions over the SNF grid.")
    add_body(doc, "Mechanistic resolution proceeded by pathway deletion influence, recurrent-gene tracing across the top 20 drivers, and donor-aware single-cell localization. The four-layer audit required a comparable seven-node matrix within each planned layer. Missing layers were left missing and were neither imputed nor coded as zero.")

    add_heading(doc, "Table S1. AD and ACD pathway meta-analysis sensitivity grid", 2)
    add_table(doc, ["Disease", "Cell", "Estimator", "Test", "FDR", "BH-significant", "Direction complete", "LODO stable", "Role"], sens_rows,
              [0.55, 1.18, 0.55, 0.52, 0.40, 0.72, 0.86, 0.65, 1.0], 7.1)
    add_body(doc, "REML-z at BH q<0.05 yielded 613/1,590 pathways in AD and 894/1,639 in ACD. Of these, 429 pathways appeared in both disease-specific BH-selected lists with concordant effects; this is an overlap of two marginal lists, not a separately controlled conjunction-FDR set.", italic=True)

    page_break(doc)
    add_heading(doc, "Table S2. Complete 21-edge selected transcriptomic network", 2)
    add_table(doc, ["Rank", "Disease pair", "Fused similarity", "Bootstrap 95% interval", "Co-clustering", "Permutation P", "BH q", "Same cluster"], edge_rows,
              [0.4, 1.2, 0.92, 1.12, 0.75, 0.82, 0.82, 0.72], 7.3)
    add_body(doc, "The AD–ACD edge ranked third among 21 disease pairs (similarity 0.259194; branch-level q=0.00052495). Its grid-calibrated permutation probability was 0.00998, and conditional co-clustering support was 1.00.", italic=True)

    page_break(doc)
    add_heading(doc, "Table S3. Top 20 AD–ACD pathway-deletion drivers", 2)
    add_table(doc, ["Rank", "Pathway", "Theme", "Influence", "AD effect", "ACD effect", "Same direction"], driver_rows,
              [0.38, 4.05, 1.0, 0.72, 0.62, 0.62, 0.70], 7.0)
    add_body(doc, "The top-decile enrichment for stress/damage pathways was OR=17.91 (P=3.91×10⁻³⁷). The leading three drivers were retained in all 1,000 random 10% pathway-deletion resamples.", italic=True)

    page_break(doc)
    add_heading(doc, "Table S4. Sixteen-gene recurrent replication-surveillance core", 2)
    add_table(doc, ["Gene", "Top-20 count", "Weighted support", "AD 121212", "AD 32924", "AD 36842", "ACD 282562", "ACD 6281", "AD meta", "ACD meta"], gene_rows,
              [0.58, 0.62, 0.78, 0.72, 0.68, 0.68, 0.76, 0.68, 0.66, 0.66], 6.9)
    add_body(doc, "Values are log2 fold changes. All 16 genes were represented recurrently across the top 20 pathway drivers and showed positive effects in all five contributing cohorts. Meta-analytic effects are provided as descriptive disease-level summaries.", italic=True)

    page_break(doc)
    add_heading(doc, "Table S5. Donor-aware single-cell localization of the fixed driver program", 2)
    add_table(doc, ["Cell type", "Paired donors", "Pathways measured", "Pathways up", "Program score", "Empirical P", "BH q", "Direction"], cell_rows,
              [0.8, 0.72, 0.96, 0.72, 0.78, 0.78, 0.70, 1.0], 7.4)
    add_body(doc, "In GSE267929 (five paired donors), the fixed driver program was enriched in antigen-presenting cells (APC; score 0.556, q=0.0436) and shifted in the opposite direction in keratinocytes (KRT; score −0.941, q=0.00880). P values are donor-aware empirical gene-set tests; q values adjust across the four reported compartments.", italic=True)

    add_heading(doc, "Table S6. Four-layer evidence-coverage audit", 2)
    add_table(doc, ["Layer", "Planned weight", "Coverage", "Nodes with comparable features", "Fusion eligible", "Missing handling", "Principal limitation"], layer_rows,
              [1.18, 0.72, 0.55, 1.6, 0.70, 1.0, 3.1], 6.8)
    add_body(doc, "Disposition: exploratory_gate4_transcriptomic_positive_multilayer_incomplete. Transcriptomic pathway coverage was complete for all seven diseases; the GWAS/QTL, direct genetic-functional, and network/cell/spatial layers did not supply comparable seven-node matrices.", italic=True)

    page_break(doc)
    add_heading(doc, "Table S7. Downstream candidate annotation", 2)
    add_table(doc, ["Candidate", "LINCS label", "Role", "Targeted BH q", "Disease-network layer", "Clinical efficacy", "Safety"], candidate_rows,
              [1.0, 1.0, 2.6, 0.85, 1.05, 0.85, 0.65], 7.4)
    add_body(doc, "JNJ-7706621 is retained as a downstream computational annotation. It does not contribute evidence to the disease network, replace a missing Gate 4 layer, establish biological replication, or support claims of clinical efficacy or safety.", italic=True)

    add_heading(doc, "Table S8. Reproducibility and source-artifact index", 2)
    add_table(doc, ["Component", "Repository-relative source"], assets, [2.25, 7.0], 7.2)
    add_body(doc, "All tables in this supplement were generated directly from the listed repository artifacts. The frozen Gate 3 result remains 0/3 prespecified axes; the additional positive transcriptomic branch is reported as exploratory and does not modify that frozen result.", italic=True)

    doc.core_properties.title = "Supplementary Information — AD–ACD transcriptomic network"
    doc.core_properties.subject = "Data-grounded supplementary tables and audits"
    doc.core_properties.keywords = "atopic dermatitis; allergic contact dermatitis; transcriptomics; SNF"
    doc.save(SUP_DOCX)

    sections = [
        "# Supplementary Information",
        "## A replication-surveillance transcriptomic network links atopic and allergic contact dermatitis",
        "This supplement reports the complete numerical sensitivity and downstream evidence audits supporting the manuscript.",
        "## Supplementary methods",
        "The pathway sensitivity grid crossed estimator, test calibration, and false-discovery threshold. The selected transcriptomic branch used four pathway views and similarity network fusion (K=2, alpha=0.2, 10 iterations) across 396 specifications, followed by 10,000 label permutations, 1,000 bootstrap resamples, and 500 SNF-grid calibration repetitions.",
        "## Table S1. AD and ACD pathway meta-analysis sensitivity grid",
        md_table(["Disease", "Cell", "Estimator", "Test", "FDR", "BH-significant", "Direction complete", "LODO stable", "Role"], sens_rows),
        "## Table S2. Complete 21-edge selected transcriptomic network",
        md_table(["Rank", "Disease pair", "Fused similarity", "Bootstrap 95% interval", "Co-clustering", "Permutation P", "BH q", "Same cluster"], edge_rows),
        "## Table S3. Top 20 AD–ACD pathway-deletion drivers",
        md_table(["Rank", "Pathway", "Theme", "Influence", "AD effect", "ACD effect", "Same direction"], driver_rows),
        "## Table S4. Sixteen-gene recurrent replication-surveillance core",
        md_table(["Gene", "Top-20 count", "Weighted support", "AD 121212", "AD 32924", "AD 36842", "ACD 282562", "ACD 6281", "AD meta", "ACD meta"], gene_rows),
        "## Table S5. Donor-aware single-cell localization",
        md_table(["Cell type", "Paired donors", "Pathways measured", "Pathways up", "Program score", "Empirical P", "BH q", "Direction"], cell_rows),
        "## Table S6. Four-layer evidence-coverage audit",
        md_table(["Layer", "Planned weight", "Coverage", "Nodes", "Fusion eligible", "Missing handling", "Limitation"], layer_rows),
        "## Table S7. Downstream candidate annotation",
        md_table(["Candidate", "LINCS label", "Role", "Targeted BH q", "Disease-network layer", "Clinical efficacy", "Safety"], candidate_rows),
        "## Table S8. Reproducibility and source-artifact index",
        md_table(["Component", "Repository-relative source"], assets),
        "Disposition: `exploratory_gate4_transcriptomic_positive_multilayer_incomplete`. Missing evidence layers were not filled or imputed."
    ]
    SUP_MD.write_text("\n\n".join(sections) + "\n", encoding="utf-8")


if __name__ == "__main__":
    build()
