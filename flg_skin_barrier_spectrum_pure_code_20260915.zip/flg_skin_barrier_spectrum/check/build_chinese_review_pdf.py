#!/usr/bin/env python3
"""Create a Chinese review PDF with an embedded CJK font."""

from html import escape
from pathlib import Path
import re

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (
    BaseDocTemplate,
    Frame,
    Image,
    KeepTogether,
    PageBreak,
    PageTemplate,
    Paragraph,
    Spacer,
    Table,
    TableStyle,
)


HERE = Path(__file__).resolve().parent
SOURCE = HERE / "jid_manuscript_chinese_review.md"
OUTPUT = HERE / "jid_manuscript_chinese_review.pdf"
FONT_PATH = Path("/System/Library/Fonts/Supplemental/Arial Unicode.ttf")
FONT = "ArialUnicodeReview"


def inline_markup(text: str) -> str:
    text = text.replace("–", "-").replace("—", "-").replace("−", "-")
    text = escape(text, quote=False)
    text = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", text)
    text = re.sub(r"(?<!\*)\*([^*]+?)\*(?!\*)", r"<i>\1</i>", text)
    return text


def page_decor(canvas, doc):
    canvas.saveState()
    width, height = letter
    canvas.setFont(FONT, 7.5)
    canvas.setFillColor(colors.HexColor("#6B7280"))
    canvas.drawString(doc.leftMargin, height - 0.38 * inch, "JID Innovations 文稿中文审阅译本")
    canvas.drawRightString(width - doc.rightMargin, height - 0.38 * inch, "仅供内部审阅")
    canvas.setStrokeColor(colors.HexColor("#D8DEE6"))
    canvas.setLineWidth(0.4)
    canvas.line(doc.leftMargin, height - 0.47 * inch, width - doc.rightMargin, height - 0.47 * inch)
    canvas.drawCentredString(width / 2, 0.34 * inch, f"{doc.page}")
    canvas.drawString(doc.leftMargin, 0.34 * inch, "正式投稿以英文稿为准")
    canvas.restoreState()


def make_styles():
    pdfmetrics.registerFont(TTFont(FONT, str(FONT_PATH)))
    pdfmetrics.registerFontFamily(FONT, normal=FONT, bold=FONT, italic=FONT, boldItalic=FONT)
    styles = getSampleStyleSheet()
    common = dict(fontName=FONT, textColor=colors.HexColor("#18212B"), wordWrap="CJK")
    return {
        "body": ParagraphStyle(
            "BodyCN", parent=styles["BodyText"], fontSize=9.4, leading=14.2,
            spaceAfter=5.2, alignment=TA_LEFT, **common
        ),
        "h1": ParagraphStyle(
            "H1CN", parent=styles["Heading1"], fontSize=15.2, leading=20,
            spaceBefore=9, spaceAfter=8, keepWithNext=True,
            textColor=colors.HexColor("#1F5D7A"), fontName=FONT, wordWrap="CJK"
        ),
        "h2": ParagraphStyle(
            "H2CN", parent=styles["Heading2"], fontSize=11.8, leading=16,
            spaceBefore=8, spaceAfter=5, keepWithNext=True,
            textColor=colors.HexColor("#2E6F89"), fontName=FONT, wordWrap="CJK"
        ),
        "meta": ParagraphStyle(
            "MetaCN", parent=styles["BodyText"], fontSize=9.5, leading=14,
            spaceAfter=4, fontName=FONT, wordWrap="CJK", textColor=colors.HexColor("#17202A")
        ),
        "note": ParagraphStyle(
            "NoteCN", parent=styles["BodyText"], fontSize=8.8, leading=13.2,
            leftIndent=10, rightIndent=10, borderPadding=7, borderColor=colors.HexColor("#C8D7E1"),
            borderWidth=0.6, backColor=colors.HexColor("#F4F8FA"), spaceAfter=8,
            fontName=FONT, wordWrap="CJK", textColor=colors.HexColor("#334155")
        ),
        "reference": ParagraphStyle(
            "ReferenceCN", parent=styles["BodyText"], fontSize=7.8, leading=10.5,
            spaceAfter=3.8, fontName=FONT, wordWrap="CJK", textColor=colors.HexColor("#27313B")
        ),
        "caption": ParagraphStyle(
            "CaptionCN", parent=styles["BodyText"], fontSize=8.6, leading=12.7,
            spaceAfter=5, fontName=FONT, wordWrap="CJK", textColor=colors.HexColor("#263746")
        ),
        "supp": ParagraphStyle(
            "SuppCN", parent=styles["BodyText"], fontSize=9.2, leading=14,
            spaceAfter=3, fontName=FONT, wordWrap="CJK", textColor=colors.HexColor("#263746")
        ),
    }


def next_nonblank(lines, start):
    idx = start
    while idx < len(lines) and not lines[idx].strip():
        idx += 1
    return idx


def parse_table(lines, start, styles):
    rows = []
    idx = start
    while idx < len(lines) and lines[idx].lstrip().startswith("|"):
        raw = lines[idx].strip().strip("|")
        cells = [cell.strip() for cell in raw.split("|")]
        if not all(re.fullmatch(r"[-: ]+", cell or "-") for cell in cells):
            rows.append([Paragraph(inline_markup(cell), styles["reference"]) for cell in cells])
        idx += 1
    widths = [1.62 * inch, 0.72 * inch, 1.48 * inch, 2.68 * inch]
    table = Table(rows, colWidths=widths, repeatRows=1, hAlign="LEFT", splitByRow=1)
    table.setStyle(TableStyle([
        ("FONTNAME", (0, 0), (-1, -1), FONT),
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#E8F0F5")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.HexColor("#173A4D")),
        ("GRID", (0, 0), (-1, -1), 0.35, colors.HexColor("#B8C6D1")),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("LEFTPADDING", (0, 0), (-1, -1), 4),
        ("RIGHTPADDING", (0, 0), (-1, -1), 4),
        ("TOPPADDING", (0, 0), (-1, -1), 4),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
    ]))
    return table, idx


def build_story(styles):
    lines = SOURCE.read_text(encoding="utf-8").splitlines()
    story = []
    in_references = False
    in_supp = False
    idx = 0
    paragraph_lines = []

    def flush():
        nonlocal paragraph_lines
        if not paragraph_lines:
            return
        text = " ".join(item.strip() for item in paragraph_lines).strip()
        paragraph_lines = []
        if not text:
            return
        style = styles["reference"] if in_references else styles["supp"] if in_supp else styles["body"]
        if text.startswith("> "):
            text = text[2:]
            style = styles["note"]
        elif text.startswith("**文章类型") or text.startswith("**题目") or text.startswith("**短标题") or text.startswith("**关键词") or text.startswith("**展示项目"):
            style = styles["meta"]
        story.append(Paragraph(inline_markup(text), style))

    while idx < len(lines):
        line = lines[idx]
        stripped = line.strip()
        if not stripped:
            flush()
            idx += 1
            continue
        if stripped.startswith("# "):
            flush()
            heading = stripped[2:].strip()
            in_references = heading == "参考文献"
            in_supp = heading == "补充材料"
            if heading in {"参考文献", "表", "图注", "补充材料"}:
                story.append(PageBreak())
            story.append(Paragraph(inline_markup(heading), styles["h1"]))
            idx += 1
            continue
        if stripped.startswith("## "):
            flush()
            story.append(Paragraph(inline_markup(stripped[3:].strip()), styles["h2"]))
            idx += 1
            continue
        if stripped.startswith("|"):
            flush()
            table, idx = parse_table(lines, idx, styles)
            story.extend([Spacer(1, 4), table, Spacer(1, 6)])
            continue
        if re.match(r"\*\*图 [1-6]\.", stripped):
            flush()
            figure_no = int(re.match(r"\*\*图 ([1-6])\.", stripped).group(1))
            if figure_no > 1:
                story.append(PageBreak())
            image_idx = next_nonblank(lines, idx + 1)
            caption = Paragraph(inline_markup(stripped), styles["caption"])
            group = [caption]
            if image_idx < len(lines):
                match = re.match(r"!\[[^]]*\]\(([^)]+)\)", lines[image_idx].strip())
                if match:
                    path = HERE / match.group(1)
                    from PIL import Image as PILImage
                    with PILImage.open(path) as im:
                        ratio = im.width / im.height
                    max_w, max_h = 6.32 * inch, 6.45 * inch
                    width = max_w
                    height = width / ratio
                    if height > max_h:
                        height = max_h
                        width = height * ratio
                    group.extend([Spacer(1, 2), Image(str(path), width=width, height=height)])
                    idx = image_idx + 1
                else:
                    idx += 1
            story.append(KeepTogether(group))
            continue
        if stripped.startswith("!["):
            idx += 1
            continue
        paragraph_lines.append(line)
        if line.endswith("  "):
            flush()
        idx += 1
    flush()
    return story


def main():
    styles = make_styles()
    doc = BaseDocTemplate(
        str(OUTPUT), pagesize=letter,
        leftMargin=0.78 * inch, rightMargin=0.78 * inch,
        topMargin=0.62 * inch, bottomMargin=0.62 * inch,
        title="连接特应性皮炎与变应性接触性皮炎的复制监视转录组网络 - 中文审阅译稿",
        author="", subject="JID Innovations 英文匿名稿中文审阅译本",
    )
    frame = Frame(doc.leftMargin, doc.bottomMargin, doc.width, doc.height, id="review")
    doc.addPageTemplates([PageTemplate(id="main", frames=[frame], onPage=page_decor)])
    doc.build(build_story(styles))
    print(OUTPUT)


if __name__ == "__main__":
    main()
