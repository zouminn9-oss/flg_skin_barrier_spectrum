#!/usr/bin/env python3
"""Build and style the Chinese manuscript review copy from Markdown."""

from pathlib import Path
import subprocess

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor


HERE = Path(__file__).resolve().parent
SOURCE = HERE / "jid_manuscript_chinese_review.md"
OUTPUT = HERE / "jid_manuscript_chinese_review.docx"
REFERENCE = HERE.parent / "paper_rewriting_output" / "jid_innovations_submission" / "jid_manuscript_review_copy.docx"

BODY_CJK = "Arial Unicode MS"
HEAD_CJK = "Arial Unicode MS"
LATIN = "Arial Unicode MS"


def set_run_fonts(run, cjk=BODY_CJK, latin=LATIN):
    run.font.name = latin
    rpr = run._element.get_or_add_rPr()
    rfonts = rpr.rFonts
    if rfonts is None:
        rfonts = OxmlElement("w:rFonts")
        rpr.insert(0, rfonts)
    rfonts.set(qn("w:ascii"), latin)
    rfonts.set(qn("w:hAnsi"), latin)
    rfonts.set(qn("w:eastAsia"), cjk)


def set_style_fonts(style, cjk=BODY_CJK, latin=LATIN):
    style.font.name = latin
    rpr = style.element.get_or_add_rPr()
    rfonts = rpr.rFonts
    if rfonts is None:
        rfonts = OxmlElement("w:rFonts")
        rpr.insert(0, rfonts)
    rfonts.set(qn("w:ascii"), latin)
    rfonts.set(qn("w:hAnsi"), latin)
    rfonts.set(qn("w:eastAsia"), cjk)


def set_cell_margins(cell, top=90, start=120, bottom=90, end=120):
    tc_pr = cell._tc.get_or_add_tcPr()
    tc_mar = tc_pr.first_child_found_in("w:tcMar")
    if tc_mar is None:
        tc_mar = OxmlElement("w:tcMar")
        tc_pr.append(tc_mar)
    for name, value in (("top", top), ("start", start), ("bottom", bottom), ("end", end)):
        node = tc_mar.find(qn(f"w:{name}"))
        if node is None:
            node = OxmlElement(f"w:{name}")
            tc_mar.append(node)
        node.set(qn("w:w"), str(value))
        node.set(qn("w:type"), "dxa")


def set_table_geometry(table, widths_dxa):
    table.alignment = WD_TABLE_ALIGNMENT.LEFT
    table.autofit = False
    tbl_pr = table._tbl.tblPr
    tbl_w = tbl_pr.first_child_found_in("w:tblW")
    if tbl_w is None:
        tbl_w = OxmlElement("w:tblW")
        tbl_pr.append(tbl_w)
    tbl_w.set(qn("w:w"), str(sum(widths_dxa)))
    tbl_w.set(qn("w:type"), "dxa")
    tbl_ind = tbl_pr.first_child_found_in("w:tblInd")
    if tbl_ind is None:
        tbl_ind = OxmlElement("w:tblInd")
        tbl_pr.append(tbl_ind)
    tbl_ind.set(qn("w:w"), "120")
    tbl_ind.set(qn("w:type"), "dxa")
    layout = tbl_pr.first_child_found_in("w:tblLayout")
    if layout is None:
        layout = OxmlElement("w:tblLayout")
        tbl_pr.append(layout)
    layout.set(qn("w:type"), "fixed")

    grid = table._tbl.tblGrid
    for child in list(grid):
        grid.remove(child)
    for width in widths_dxa:
        col = OxmlElement("w:gridCol")
        col.set(qn("w:w"), str(width))
        grid.append(col)

    for row_idx, row in enumerate(table.rows):
        for idx, cell in enumerate(row.cells):
            width = widths_dxa[min(idx, len(widths_dxa) - 1)]
            tc_pr = cell._tc.get_or_add_tcPr()
            tc_w = tc_pr.first_child_found_in("w:tcW")
            if tc_w is None:
                tc_w = OxmlElement("w:tcW")
                tc_pr.append(tc_w)
            tc_w.set(qn("w:w"), str(width))
            tc_w.set(qn("w:type"), "dxa")
            set_cell_margins(cell)
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            if row_idx == 0:
                shd = tc_pr.first_child_found_in("w:shd")
                if shd is None:
                    shd = OxmlElement("w:shd")
                    tc_pr.append(shd)
                shd.set(qn("w:fill"), "E8EEF5")
            for paragraph in cell.paragraphs:
                paragraph.paragraph_format.space_after = Pt(2)
                paragraph.paragraph_format.line_spacing = 1.1
                for run in paragraph.runs:
                    set_run_fonts(run)
                    run.font.size = Pt(8.5)


def style_document(path):
    doc = Document(path)
    props = doc.core_properties
    props.title = "连接特应性皮炎与变应性接触性皮炎的复制监视转录组网络｜中文审阅译稿"
    props.subject = "JID Innovations 英文匿名稿中文审阅译本"
    props.author = ""
    props.last_modified_by = ""
    props.comments = "仅供内部审阅；正式投稿以英文稿为准"

    for section in doc.sections:
        section.top_margin = Inches(0.8)
        section.bottom_margin = Inches(0.75)
        section.left_margin = Inches(0.85)
        section.right_margin = Inches(0.85)
        section.header_distance = Inches(0.35)
        section.footer_distance = Inches(0.35)

        header_p = section.header.paragraphs[0]
        header_p.text = "JID Innovations 文稿中文审阅译本"
        header_p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
        header_p.paragraph_format.space_after = Pt(0)
        for run in header_p.runs:
            set_run_fonts(run, cjk=HEAD_CJK)
            run.font.size = Pt(8)
            run.font.color.rgb = RGBColor(100, 108, 116)

        footer_p = section.footer.paragraphs[0]
        footer_p.text = "仅供内部审阅｜正式投稿以英文稿为准"
        footer_p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        footer_p.paragraph_format.space_before = Pt(0)
        for run in footer_p.runs:
            set_run_fonts(run, cjk=HEAD_CJK)
            run.font.size = Pt(8)
            run.font.color.rgb = RGBColor(100, 108, 116)

    for style in doc.styles:
        if style.type != 1:
            continue
        name = style.name
        is_heading = name.startswith("Heading") or name in {"Title", "Subtitle"}
        set_style_fonts(style, cjk=HEAD_CJK if is_heading else BODY_CJK)

    normal = doc.styles["Normal"]
    normal.font.size = Pt(10.5)
    normal.paragraph_format.space_after = Pt(4)
    normal.paragraph_format.line_spacing = 1.25

    heading_tokens = {
        "Heading 1": (16, "1F4D78", 14, 7),
        "Heading 2": (12.5, "2E627D", 10, 5),
        "Heading 3": (11.5, "2E627D", 8, 4),
    }
    for name, (size, color, before, after) in heading_tokens.items():
        if name in doc.styles:
            style = doc.styles[name]
            style.font.size = Pt(size)
            style.font.bold = True
            style.font.color.rgb = RGBColor.from_string(color)
            style.paragraph_format.space_before = Pt(before)
            style.paragraph_format.space_after = Pt(after)
            style.paragraph_format.keep_with_next = True

    figure_caption_index = 0
    major_breaks = {"参考文献", "表", "图注", "补充材料"}
    for paragraph in doc.paragraphs:
        text = paragraph.text.strip()
        style_name = paragraph.style.name if paragraph.style else ""
        is_heading = style_name.startswith("Heading")
        for run in paragraph.runs:
            set_run_fonts(run, cjk=HEAD_CJK if is_heading else BODY_CJK)
        if style_name == "Heading 1" and text in major_breaks:
            paragraph.paragraph_format.page_break_before = True
        if text.startswith("图 ") and len(text) > 3 and text[2].isdigit() and "." in text[:8]:
            figure_caption_index += 1
            paragraph.paragraph_format.keep_with_next = True
            paragraph.paragraph_format.space_after = Pt(5)
            if figure_caption_index > 1:
                paragraph.paragraph_format.page_break_before = True
        if any(run._element.xpath(".//w:drawing") for run in paragraph.runs):
            paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
            paragraph.paragraph_format.space_before = Pt(0)
            paragraph.paragraph_format.space_after = Pt(6)

    max_width = Inches(6.25)
    max_height = Inches(6.35)
    for shape in doc.inline_shapes:
        ratio = shape.width / shape.height
        width = min(shape.width, max_width)
        height = int(width / ratio)
        if height > max_height:
            height = max_height
            width = int(height * ratio)
        shape.width = int(width)
        shape.height = int(height)

    for table in doc.tables:
        if len(table.columns) == 4:
            set_table_geometry(table, [2200, 1100, 1900, 4160])

    doc.save(path)


def main():
    subprocess.run(
        [
            "pandoc",
            str(SOURCE),
            "--from=gfm",
            "--to=docx",
            f"--reference-doc={REFERENCE}",
            f"--resource-path={HERE}",
            "--output",
            str(OUTPUT),
        ],
        check=True,
    )
    style_document(OUTPUT)
    print(OUTPUT)


if __name__ == "__main__":
    main()
