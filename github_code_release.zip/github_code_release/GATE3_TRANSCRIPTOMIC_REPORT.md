# Gate 3 confirmatory transcriptomic report

Date: 2026-08-25  
Seed: `20260825`  
Decision: **NEGATIVE — 0 of 3 frozen axes pass**

## Executive result

The public-data pipeline was completed through sample reconstruction, dataset-specific QC, cohort-level effects, random-effects gene and pathway synthesis, direct ACD–ICD comparison, donor-level single-cell pseudobulk validation, background specificity, and sensitivity analyses.

The final confirmatory analysis does not support the frozen project-positive claim. Cohort-level and competitive pathway signals are present, but none of the four multi-cohort diseases has a Reactome pathway passing the required cohort-first random-effects meta FDR<0.05. Axis C additionally fails agent/donor robustness. Because at least two axes must pass and all three already fail a necessary transcriptomic condition, confirmatory SNF/bootstrap was not run.

## Data and QC

- Twelve GEO series were reconstructed from SOFT metadata (697 GEO samples total); E-MTAB-8945 and E-MTAB-9501 were conservatively treated as one study family.
- Eleven bulk expression datasets entered QC and cohort modeling. Fourteen diagnostic sample flags were retained for review; no samples were excluded automatically or after viewing effects.
- Thirteen bulk cohort contrasts were estimated separately. Raw matrices were never concatenated across studies and cross-study ComBat was not used.
- E-MTAB-9501 used both raw archives: 48 two-color arrays, 88 author-QC-passing channel samples/participants, 23,462 mapped gene symbols. The direct model compared 34 ACD with 41 ICD participants and adjusted age, sex, dye and within-array correlation.
- GSE267929 contained 50,820 cells. Main pseudobulk inference used the donor as the unit and retained five paired donors with at least 20 cells in both Day-4 allergy and irritant conditions.

## Confirmatory synthesis

### Gene level

Modified Hartung–Knapp REML gene meta-analysis produced zero FDR<0.05 genes for AD, ACD, psoriasis and HS. This conservative result is retained; small cohort counts are not used to justify switching to a less conservative test.

### Pathway level

The frozen analysis order was implemented as follows: Reactome v97 scores were computed within each cohort; each pathway then received a cohort-specific effect and SE under the original participant/covariate model; effects were combined using REML modified Hartung–Knapp with LODO direction checks.

| Disease | Cohorts | Pathways tested | Meta FDR<0.05 | Direction-complete | LODO direction-stable |
|---|---:|---:|---:|---:|---:|
| AD | 3 | 1,590 | 0 | 948 | 1,306 |
| ACD | 2 | 1,639 | 0 | 1,326 | 1,326 |
| Psoriasis | 2 | 1,585 | 0 | 1,379 | 1,379 |
| HS | 2 | 1,603 | 0 | 655 | 655 |

Earlier gene-meta-then-`cameraPR` pathway files are explicitly exploratory and do not determine the axis decisions.

## Direct ACD–ICD evidence

E-MTAB-9501 had no individual genes at FDR<0.05, but 80 Reactome competitive pathways passed FDR<0.05. Th2 differentiation and T-cell differentiation were higher in ACD. GSE267929 all-cell pseudobulk had no FDR-significant genes but 18 Reactome pathways at FDR<0.05, including immunoregulatory/TCR-proximal signaling higher in allergy and cornified-envelope/keratinization lower in allergy.

These main pathway observations were not robust enough for confirmation. The combined adaptive module was non-significant in the E-MTAB-9501 main model (p=0.354) and changed direction or significance in multiple leave-one-stimulus-out fits. It was significant in the five-donor GSE267929 main model (p=0.0021), but one of five donor-deletion analyses exceeded 0.05 (P3 deletion p=0.0508). Axis C therefore fails the frozen sensitivity requirement.

## Background specificity

Using the corrected cohort-first pathway effects, AD–ACD Spearman similarity was 0.641. It exceeded the frozen background median + 0.5 SD threshold (0.625) and passed 10,000 pathway-label permutations (q<0.001). However, AD–acne (0.726), ACD–acne (0.754) and AD–psoriasis (0.679) were larger than AD–ACD. More importantly, there were zero shared AD/ACD pathways passing confirmatory pathway meta FDR<0.05 in both diseases, so similarity alone cannot satisfy Axis B.

## Frozen axis decisions

| Axis | Decision | Decisive reason |
|---|---|---|
| A — AD–IV barrier | FAIL | Direct IV/FLG evidence exists, but the required replicated AD FLG/keratinization/barrier transcriptomic module did not pass the frozen meta-FDR/direction criteria. |
| B — AD–ACD shared axis | FAIL | Background similarity passed, but the required shared replicated meta-significant module did not exist. |
| C — ACD–ICD distinction | FAIL | Individual pathway signals were present in two sources, but the adaptive module failed stimulus/donor sensitivity. |

Overall: **NEGATIVE (0/3 axes)**. The result is interpreted as insufficient robust public-data support for the prespecified multilayer disease-spectrum claim, not evidence that the underlying biology is absent.

## Stop rationale

The project-positive definition requires at least two passing axes and cannot rely on Axis C alone. Each axis has already failed a necessary transcriptomic prerequisite. Running SNF/bootstrap after that point could only create an exploratory clustering result and cannot make the frozen confirmatory claim positive. The confirmatory pipeline therefore stops here without changing thresholds, switching cohorts, or selecting a more favorable method.
