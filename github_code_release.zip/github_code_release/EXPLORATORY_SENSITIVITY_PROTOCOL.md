# Post-hoc exploratory sensitivity protocol

Date: 2026-08-25  
Status: explicitly requested after the frozen Gate 3 result was known  
Confirmatory result preserved: negative, 0/3 axes

## Purpose

Assess how conclusions change under less conservative or more favorable statistical choices. This analysis is hypothesis-generating and cannot replace the frozen confirmatory result.

## Complete method grid

All methods use the same cohort-level sample pathway effects and standard errors. No cohort, disease, pathway or sample is added or removed after viewing results.

1. REML with modified Knapp–Hartung, BH FDR 0.05 (frozen reference).
2. REML with conventional normal-theory test, BH FDR 0.05.
3. REML with conventional normal-theory test, BH FDR 0.10.
4. DerSimonian–Laird random effects with normal-theory test, BH FDR 0.05.
5. Fixed-effect inverse-variance model, BH FDR 0.05.
6. Fixed-effect inverse-variance model, BH FDR 0.10.

The full grid is reported. The analysis may identify the most favorable branch, but it may not present that branch without its less favorable neighbors.

## Exploratory axis rules

- Axis A candidate support: at least one predefined Reactome barrier/lipid pathway is meta-significant, direction-complete and LODO-direction-stable in AD, plus the already curated direct IV/FLG anchor. This is weaker than the frozen module rule.
- Axis B candidate support: at least one AD/ACD shared same-direction meta-significant pathway plus the frozen background-similarity threshold.
- Axis C candidate support: each of E-MTAB-9501 and GSE267929 has at least one adaptive-immune Reactome pathway higher in ACD/allergy at FDR<0.05. This deliberately omits the frozen stimulus/donor robustness requirement and is therefore favorable but fragile.

No branch is called confirmatory positive. SNF/bootstrap remains a separate downstream requirement.
