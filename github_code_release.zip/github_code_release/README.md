# A replication-surveillance transcriptomic network links atopic and allergic contact dermatitis

Analysis code for the manuscript of the same title. The repository reconstructs the public-cohort transcriptomic workflow, the specification-calibrated AD–ACD similarity network, pathway and core-gene analyses, paired single-cell localization, regulator prioritization, virtual knockout, and perturbational screens.

> Review-stage note: the manuscript is anonymized. Keep this repository private until the journal's double-anonymous-review policy permits public release. Replace the archive URL, DOI, author list, and citation after acceptance or preprint posting.

## Repository contents

- `scripts/`: 69 numbered R, Python, and zsh scripts. The numbering records execution order and preserves the analysis history.
- `config/datasets.tsv`: public cohort registry and analytical roles.
- `environment/`: R installer and the exact package versions observed in the frozen run.
- `notebooks/`: source-only LINCS full-background preflight notebook.
- `docs/`: pipeline, data, audit, and reproducibility documentation.
- Root-level `*_PROTOCOL.md` and `*_REPORT.md`: frozen decision rules and validation reports used by the validator scripts.

Raw data, installed package trees, executed notebooks, intermediate matrices, cached downloads, and generated results are intentionally excluded from the GitHub code repository.

## Installation

The frozen analysis used Python 3.9.5 and R 4.6.1 on arm64 macOS. A Linux run with the pinned Python packages and the documented R/Bioconductor versions is expected to be portable, but has not yet been rerun end to end on a clean Linux host.

```bash
git clone https://github.com/zouminn9-oss/flg_skin_barrier_spectrum.git
cd flg_skin_barrier_spectrum
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
Rscript environment/install_r_packages.R
```

For R commands, expose the repository-local library:

```bash
export R_LIBS_USER="$PWD/environment/R_libs"
```

## Quick start

The release checker does not download data or run the statistical workflow:

```bash
python scripts/check_release.py
python scripts/01_fetch_metadata.py
python scripts/02_parse_soft_samples.py
python scripts/03_build_sample_maps.py
```

The metadata steps require network access and may change only if an upstream archive changes. Each downloader records source URLs, sizes, timestamps, and SHA-256 checksums under `records/`.

## Reproducing the analysis

1. Install dependencies as above.
2. Obtain the public inputs and place them at the exact paths in [docs/DATA.md](docs/DATA.md).
3. Run from the repository root. Scripts infer the project root from their own path or the current working directory; no author-machine paths are required.
4. Follow the numbered stages and validation pairs in [docs/PIPELINE_MAP.md](docs/PIPELINE_MAP.md).

The main stages are:

```text
00–14  environment, acquisition, QC, cohort effects, pathway meta-analysis
15–24  sensitivity branch, four-view SNF, 396-specification calibration
25–40  pathway influence, core genes, single-cell localization, regulators
41–63  Sci-Plex/LINCS/CMap perturbational analyses and full-background checks
64–67  frozen post-hoc package, report, and strict validation
```

Large LINCS/CMap matrices require substantial storage and are not needed to reproduce the primary transcriptomic network through script 40. Scripts 51a and 58 perform resumable downloads for the optional full-background screens.

## Random seeds and inference

The main seed is `20260825`; the independent GSE201278 audit uses `20260826`. Seeds, permutation counts, bootstrap counts, thresholds, and selected SNF parameters are fixed in code and the root-level protocol documents. Empirical P values use plus-one correction, and multiplicity correction is applied within the evidence family defined in the manuscript.

## Data availability

All expression datasets are public. GEO accessions are GSE121212, GSE32924, GSE36842, GSE6281, GSE282562, GSE18206, GSE13355, GSE53795, GSE65914, GSE137141, GSE72702, GSE267929, and GSE201278. BioStudies/ArrayExpress accessions are E-MTAB-8945 and E-MTAB-9501. External pathway, regulon, Sci-Plex, and LINCS/CMap resources are listed in [docs/DATA.md](docs/DATA.md).

Derived tables and frozen result distributions are not included in this code-only GitHub bundle. For exact numerical reproduction, deposit that companion archive in Zenodo or another DOI-bearing repository and add its URL here before submission.

## Validation status

The release copy passes static syntax, structure, sensitive-string, and hardcoded-path checks. The source project reports 174/174 frozen post-analysis checks passing, but the code-only bundle cannot repeat result-level validators until public inputs and the companion derived-data archive are restored. See [docs/REPRODUCIBILITY_CHECKLIST.md](docs/REPRODUCIBILITY_CHECKLIST.md).

## Citation

Replace this review-stage record with the final paper citation:

```bibtex
@article{authors2026replication,
  title   = {A replication-surveillance transcriptomic network links atopic and allergic contact dermatitis},
  author  = {Authors},
  year    = {2026},
  note    = {Manuscript under review}
}
```

## License

The analysis code is released under the [MIT License](LICENSE). External datasets and resources remain subject to their original providers' terms.
