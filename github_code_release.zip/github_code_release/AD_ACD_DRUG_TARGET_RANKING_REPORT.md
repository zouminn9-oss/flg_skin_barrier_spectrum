# AD–ACD 候选的独立 bulk 核验与药物靶点排序

## 结论先行

独立 E‑MTAB‑9501 ACD–ICD bulk 检验中，五个候选 TF **没有一个达到五候选 BH q<0.05**。因此不能称为“独立 bulk 已确认候选”。可以保留的较弱证据层级为：

- 方向支持但未显著：IRF1、HSF1、E2F6。
- 与 APC 发现方向不一致：YY1、E2F4。

综合独立 bulk、内部程序/虚拟敲除、直接药理、临床阶段、皮肤相关性以及干预方向安全性后，推荐顺序为：

1. **IRF1 — I-2 / I-19**：首选 APC 皮肤相关药理探针。
2. **HSF1 — DTHIB（SISU-102）**：首选直接 TF 结合/降解探针。
3. **ATR — camonsertib / ceralasertib / elimusertib**：机制探针，不作为当前皮肤病治疗候选。
4. **PCNA — AOH1996**：机制探针；独立 bulk 基因方向相反。
5. **CDK2 — INX-315 / AZD8421**：细胞周期机制探针。
6. E2F4 — HLM006474：非选择性、独立 bulk 方向相反，降级。
7. YY1：虚拟敲除强，但无可靠直接药物且独立 bulk 不复现。
8. E2F6：无直接药物，内部五队列方向也不支持。

该排序用于选择实验用药理探针，不是临床用药建议。

## 独立 bulk 核验

| TF | 独立 bulk 活性 | 五TF BH q | 与 APC 方向一致 | 内部正向队列 | 判定 |
|---|---:|---:|:---:|---:|---|
| IRF1 | 1.244 | 0.398 | 是 | 5/5 | 方向支持，未确认 |
| HSF1 | 1.168 | 0.398 | 是 | 5/5 | 方向支持，未确认 |
| E2F6 | 0.439 | 0.823 | 是 | 0/5 | 弱方向支持，内部不一致 |
| E2F4 | −2.392 | 0.077 | 否 | 5/5 | 区室/对比方向冲突 |
| YY1 | −0.033 | 0.972 | 否 | 3/5 | 独立数据不支持 |

IRF1 和 HSF1 是唯一同时满足“独立 bulk 方向一致”和“内部五队列全部正向”的候选，但校正后均不显著。E2F6 虽在独立 bulk 同向，内部五队列却为 0/5 正向，因此不进入药理优先级。

## 综合排名

总分 85 分，组成如下：独立 bulk 0–20、内部程序/虚拟敲除 0–15、开发阶段 0–20、药理选择性 0–10、皮肤相关证据 0–10、方向与安全性 0–10。完整规则保存在 `SCORING_RULES.json`。

| 排名 | 靶点 | 层级 | 总分 | 代表探针 | 建议用途 |
|---:|---|---|---:|---|---|
| 1 | IRF1 | 直接 TF | 44 | I-2 / I-19 | APC 皮肤相关首选探针 |
| 2 | HSF1 | 直接 TF | 40 | DTHIB / SISU-102 | 直接 TF 药理验证 |
| 3 | ATR | 核心机制 | 34 | camonsertib 等 | 复制压力机制对照 |
| 4 | PCNA | 核心机制 | 32 | AOH1996 | PCNA 程序机制对照 |
| 5 | CDK2 | 核心机制 | 30 | INX-315 / AZD8421 | 细胞周期对照 |
| 6 | E2F4 | 直接 TF | 22 | HLM006474 | 不建议作为首轮探针 |
| 7 | YY1 | 直接 TF | 18 | 无可靠直接探针 | 先做遗传扰动 |
| 8 | E2F6 | 直接 TF | 10 | 无 | 降级 |

## 药理证据

### 1. IRF1

I-2 和 I-19 是针对 IRF1 DNA-binding domain 筛选的早期化合物。在细胞和小鼠辐射性皮肤损伤模型中，它们降低炎症性损伤并改善愈合；证据仍停留在单篇临床前研究，且疾病并非 AD/ACD。来源：[IRF1 皮肤损伤实验研究](https://pmc.ncbi.nlm.nih.gov/articles/PMC11291999/)。

优点：独立 bulk 与 APC 同向、内部 5/5 正向，并具有直接皮肤模型证据。限制：本项目虚拟敲除效应很小，化合物尚无临床药代和选择性验证。

### 2. HSF1

DTHIB 在纯化蛋白和细胞中直接结合 HSF1 DNA-binding domain，并促进核内 HSF1 降解；现有证据来自肿瘤细胞和动物模型。来源：[DTHIB 原始研究](https://pmc.ncbi.nlm.nih.gov/articles/PMC10571035/)、[ChEMBL HSF1 靶点页](https://www.ebi.ac.uk/chembl/explore/target/CHEMBL5869)。

优点：直接药理机制较清楚，独立 bulk 同向且内部 5/5 正向。限制：没有 AD/ACD 或皮肤 APC 药理验证，也没有已确认临床阶段。

### 3. ATR

ATR 是复制叉停滞时的保护性检查点。camonsertib 已有 DNA-damage-response 缺陷肿瘤的一期临床结果，多种 ATR 抑制剂仍在肿瘤试验中。来源：[camonsertib 一期研究](https://pmc.ncbi.nlm.nih.gov/articles/PMC10287555/)、[ClinicalTrials.gov NCT04497116](https://clinicaltrials.gov/study/NCT04497116)、[Reactome ATR 复制压力通路](https://reactome.org/content/detail/R-HSA-176187)。

ATR 在本项目中是 16 基因核心成员，但独立 bulk 仅为正向未显著。抑制 ATR 可能降低转录程序，同时破坏基因组保护和组织修复，因此仅作短时、低剂量机制对照。

### 4. PCNA

AOH1996 是处于一期肿瘤试验的 PCNA 抑制剂；登记研究仍聚焦难治性恶性肿瘤。来源：[AOH1996 一期试验 NCT05227326](https://clinicaltrials.gov/study/NCT05227326)、[AOH1996 原始机制研究](https://pmc.ncbi.nlm.nih.gov/articles/PMC10592352/)。

PCNA 在核心程序中覆盖 12/20 条通路，但独立 ACD–ICD bulk 中 logFC 为 −0.182，与“继续抑制阳性程序”的方向不吻合。不能因临床阶段较高而把它排成治疗首选。

### 5. CDK2

INX-315 和 AZD8421 是选择性 CDK2 抑制剂；截至 2026-08-25，INX-315 与 AZD8421 的早期肿瘤试验登记为招募中。来源：[INX-315 原始药理研究](https://pmc.ncbi.nlm.nih.gov/articles/PMC10905675/)、[NCT05735080](https://clinicaltrials.gov/study/NCT05735080)、[NCT06188520](https://clinicaltrials.gov/study/NCT06188520)。

CDK2 在内部五队列均为正向核心基因，但独立 bulk 接近零且方向略负。其抑制会造成广泛细胞周期停滞，实验必须配套 EdU、细胞周期和活率护栏。

### E2F4、YY1、E2F6

HLM006474 可抑制 E2F DNA binding，但不是 E2F4 选择性化合物。来源：[HLM006474 原始研究](https://pmc.ncbi.nlm.nih.gov/articles/PMC3615411/)。YY1 当前更适合 CRISPRi/siRNA；可检索到的近期研究主要是其他靶向治疗间接降低 YY1，而不是选择性 YY1 药物。E2F6 没有足够的直接药理和内部方向支持。

## 建议的首轮药理实验

为避免一次改变多个变量，第一轮只做两个独立实验臂：

1. IRF1：vehicle、I-2 低/中剂量、I-19 低/中剂量，并加入 IRF1 CRISPRi/siRNA 作为靶向依赖性对照。
2. HSF1：vehicle、DTHIB 低/中剂量，并加入 HSF1 CRISPRi/siRNA 与 inactive analogue（如可获得）。

主终点为预先锁定的 232 基因程序分数；次级终点为 TF target engagement、PCNA/BRCA1/UBB 等支路；护栏为活率、细胞数、EdU、细胞周期、γH2AX/53BP1。ATR、PCNA、CDK2 抑制剂只作为短时机制阳性对照，不能与治疗候选混为一类。

## 输出与复现

- 总排名：`drug_target_ranking/drug_target_ranking.tsv`
- 直接 TF 排名：`drug_target_ranking/direct_TF_target_ranking.tsv`
- 核心机制节点：`drug_target_ranking/core_mechanism_target_ranking.tsv`
- 独立 bulk 摘要：`drug_target_ranking/independent_bulk_confirmation_summary.tsv`
- 评分规则：`drug_target_ranking/SCORING_RULES.json`
- 执行：`python3 scripts/39_rank_drug_targets.py`
- 校验：`python3 scripts/40_validate_drug_target_ranking.py`

