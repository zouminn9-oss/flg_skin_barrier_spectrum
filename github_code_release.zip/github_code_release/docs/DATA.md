# Data and external resources

No raw or derived data are committed to this GitHub code bundle. The analysis expects the following public resources under `data/raw/`; downloader scripts create checksummed receipts wherever automated retrieval is available.

## Expression cohorts

The authoritative cohort registry is `config/datasets.tsv`.

- GEO: GSE121212, GSE32924, GSE36842, GSE6281, GSE282562, GSE18206, GSE13355, GSE53795, GSE65914, GSE137141, GSE72702, and GSE267929.
- BioStudies/ArrayExpress: E-MTAB-8945 and E-MTAB-9501.
- Independent perturbation audit: GSE201278.

Scripts 01 and 05 retrieve GEO/BioStudies metadata and the GEO series matrices/supplementary files used by the main workflow. E-MTAB-9501 array-level files and some source-specific supplementary inputs must be restored according to their provider manifests before scripts 09 and later validators can run.

## Pathways and regulons

| Resource | Expected location | Role |
|---|---|---|
| Reactome v97 GMT | `data/raw/pathways/reactome_v97/ReactomePathways.gmt` | Pathway scoring, influence, and core-gene membership |
| CollecTRI human snapshot | `data/raw/regulons/collectri/omnipath_collectri_human_2026-08-25.tsv` | Signed transcription-factor activity |

The filename dates/version labels are part of the frozen provenance and should not be silently replaced with newer releases. If a newer source is tested, store it under a new path and treat the run as a sensitivity analysis.

## Perturbational resources

| Resource | Acquisition | Expected location |
|---|---|---|
| Sci-Plex / perturbseqR signatures | Provider package/source archive | `data/raw/perturbations/sciplex_perturbseqr/` |
| Targeted LINCS 2021 | `44_prepare_lincs_targeted_signatures.py` via SigCom LINCS metadata API | `data/raw/perturbations/lincs_2021_targeted/` |
| Full LINCS 2021 coefficient matrix | `51a_download_lincs_full_parallel.py` | `data/raw/perturbations/lincs_2021_full/` |
| GSE201278 expression | GEO | `data/raw/perturbations/GSE201278/` |
| CMap 2020 MODZ Level 5 | `58_download_cmap2020_modz_parallel.py` | `data/raw/perturbations/cmap2020_modz/` |

Do not commit provider matrices to Git. Store derived cohort-level effects and frozen result distributions in a DOI-bearing companion archive, preserving paths relative to the repository root so the validator scripts can run without edits.
