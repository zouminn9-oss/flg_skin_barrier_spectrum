# Release audit

Audit date: 2026-08-29

## Included

- 69 numbered analysis scripts: 51 Python, 15 R, and 3 zsh.
- Public cohort configuration, source notebook, frozen protocols/reports, analysis plan, and GWAS harmonization protocol.
- Pinned Python requirements and recorded R package versions.
- MIT license, Git ignore rules, pipeline/data documentation, and an automated static release checker.

## Excluded

- Raw expression, pathway, regulon, Sci-Plex, LINCS, and CMap data.
- Intermediate and processed matrices, generated figures/tables, runtime logs, and download segments.
- Local R/Python package installations, compiled bytecode, executed notebooks, QA renders, submission documents, author details, and archive copies.
- macOS `._*` AppleDouble files and `.DS_Store` artifacts.

## Sensitive-content and portability findings

- No API key, token, password, private key, private URL, email address, or author identity was found in the released code/configuration scan.
- Four author-machine absolute-path occurrences were found in the source scripts/notebook. All were replaced in this release copy with paths derived from the repository root or current working directory.
- Downloader URLs point only to public GEO, BioStudies, SigCom LINCS, or public S3 endpoints.
- External scientific resources remain under their providers' licenses/terms and are not redistributed here.

## Remaining release decisions

- Replace the review-stage citation, repository URL, archive URL/DOI, and `The Authors` copyright holder when disclosure is permitted.
- Keep the GitHub repository private if the target journal uses double-anonymous review.
- Attach the companion derived-data archive before claiming end-to-end numerical reproducibility from this GitHub bundle alone.
