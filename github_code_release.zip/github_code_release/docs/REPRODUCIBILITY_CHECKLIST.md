# Reproducibility checklist

| Item | Status | Evidence / limitation |
|---|---|---|
| Analysis scripts mapped to manuscript stages | Complete | `docs/PIPELINE_MAP.md`; scripts 00–67 |
| Public cohort registry | Complete | `config/datasets.tsv` |
| Random seeds documented | Complete | Main seed 20260825; GSE201278 seed 20260826 |
| SNF configuration and search space retained | Complete | Scripts 18, 21, 22 and frozen protocol/report files |
| Permutation/bootstrap counts retained | Complete | Analysis scripts and protocol files |
| Python dependencies pinned | Complete | `requirements.txt` |
| R versions recorded | Complete | `environment/r-packages.tsv` |
| Raw data redistribution | Not applicable | Public/provider data are downloaded separately |
| Derived-data companion archive | Pending | Add DOI-bearing archive URL before release |
| Static syntax and release-hygiene check | Complete | `python scripts/check_release.py` |
| Clean-environment installation test | Partial | Original macOS environment recorded; clean Linux test pending |
| End-to-end rerun from raw inputs | Pending | Requires all public inputs and large LINCS/CMap matrices |
| Result-level validators | Blocked in code-only bundle | Run after restoring generated results/companion archive |

## Experiment-level coverage

| Manuscript analysis | Code | Configuration/seed | Result validation in code-only bundle |
|---|---|---|---|
| Cohort effects and pathway meta-analysis | Scripts 06–14 | Present | Requires downloaded expression inputs |
| Sensitivity grid and AD–ACD SNF | Scripts 15–24 | Present | Requires upstream cohort/pathway tables |
| Pathway influence and recurrent core | Scripts 25–28 | Present | Requires optimized SNF outputs |
| Single-cell localization | Scripts 29–30 | Present | Requires GSE267929 pseudobulk outputs |
| Regulators and virtual knockout | Scripts 31–40 | Present | Requires CollecTRI and upstream tables |
| Sci-Plex/LINCS/CMap screens | Scripts 41–63 | Present | Requires provider matrices; full screens are storage intensive |
| Frozen package audit | Scripts 64–67 | Present | Requires the complete derived-results tree |
