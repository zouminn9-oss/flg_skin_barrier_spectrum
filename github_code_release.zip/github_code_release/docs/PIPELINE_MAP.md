# Pipeline map

Run every command from the repository root. Python scripts use the active virtual environment. Set `R_LIBS_USER="$PWD/environment/R_libs"` before running R scripts.

## Stage 1: acquisition and cohort-level effects

| Order | Script | Purpose | Principal output |
|---|---|---|---|
| 00 | `00_capture_environment.sh` | Capture software and source checksums | `logs/environment_session.txt` |
| 01–05 | `01_fetch_metadata.py` to `05_fetch_expression_inputs.py` | Download/audit metadata and GEO expression inputs | `metadata/`, `records/`, `data/raw/` |
| 06 | `06_qc_expression.R` | Expression and sample QC | `results/tables/qc_*` |
| 07 | `07_fit_cohort_effects.R` | Cohort-level differential effects | `results/tables/cohort_effects/` |
| 08–10 | `08_meta_and_pathways.R`, `09_fit_emt9501_direct.R`, `10_gse267929_pseudobulk.R` | Disease meta-effects, direct contrast, donor-aware pseudobulk | `results/tables/meta/`, `direct_comparison/`, `single_cell_validation/` |
| 11–13 | `11_transcriptome_similarity.R` to `13_pathway_effect_meta.R` | Similarity, sensitivity, pathway effects and meta-analysis | `results/tables/similarity/`, `pathway_effects/`, `pathway_meta/` |
| 14 | `14_validate_gate3.py` | Frozen Gate 3 result checks | validator console output |

Typical execution:

```bash
zsh scripts/00_capture_environment.sh
python scripts/01_fetch_metadata.py
python scripts/02_parse_soft_samples.py
python scripts/03_build_sample_maps.py
python scripts/04_audit_inputs.py
python scripts/05_fetch_expression_inputs.py
Rscript scripts/06_qc_expression.R
Rscript scripts/07_fit_cohort_effects.R
Rscript scripts/08_meta_and_pathways.R
Rscript scripts/09_fit_emt9501_direct.R
Rscript scripts/10_gse267929_pseudobulk.R
Rscript scripts/11_transcriptome_similarity.R
Rscript scripts/12_axis_c_sensitivity.R
Rscript scripts/13_pathway_effect_meta.R
python scripts/14_validate_gate3.py
```

## Stage 2: sensitivity branch and network calibration

| Order | Script | Purpose |
|---|---|---|
| 15–16 | Post-hoc method grid and validation | Enumerate estimator/test/FDR sensitivity |
| 17–20 | SNF inputs, baseline four-view network, rendering, validation | Build the seven-disease network |
| 21–24 | Parameter grid, optimized AD–ACD branch, validation, rendering | Enumerate 396 specifications and calibrate the selected edge |

```bash
Rscript scripts/15_posthoc_method_grid.R
python scripts/16_validate_exploratory.py
Rscript scripts/17_prepare_snf_inputs.R
Rscript scripts/18_run_exploratory_snf.R
Rscript scripts/19_render_snf_network.R
python scripts/20_validate_snf.py
Rscript scripts/21_snf_parameter_grid.R
Rscript scripts/22_run_optimized_ad_acd_snf.R
python scripts/23_validate_optimized_snf.py
Rscript scripts/24_render_optimized_snf_figure.R
```

## Stage 3: mechanism and cellular localization

Scripts 25–40 form analysis/validation pairs:

- 25–26: exact/random pathway influence and mechanism audit.
- 27–28: recurrent 16-gene core and leave-one-cohort audit.
- 29–30: donor-aware APC/keratinocyte localization.
- 31–34: CollecTRI regulator inference and cross-dataset validation.
- 35–38: virtual knockout and sensitivity analyses.
- 39–40: downstream target ranking.

Run the scripts in numeric order, using `python scripts/<name>.py`.

## Stage 4: perturbational evidence

- 41–43: prepare and score Sci-Plex signatures, then validate.
- 44–46: targeted LINCS 2021 preparation, cross-resource scoring, and validation.
- 47–50: positive-boundary sensitivity and JNJ-7706621 candidate audit.
- 51–54: complete LINCS coefficient-matrix inspection, scoring, validation, and report.
- 55–57: independent GSE201278 skin-line direction audit.
- 58–63: CMap 2020 MODZ download, inspection, scoring, validation, report, and orchestrator.

The complete LINCS and CMap matrices are optional for the primary network result and require large downloads. Use `python scripts/51a_download_lincs_full_parallel.py` and `python scripts/58_download_cmap2020_modz_parallel.py` only after checking disk capacity and provider availability.

## Stage 5: frozen package validation

```bash
zsh scripts/67_run_posthoc_gate4_positive_branch.sh
```

This runs scripts 64, 66, and 65 in the required build-report-validate order.
