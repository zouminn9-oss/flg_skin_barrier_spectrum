# Exploratory computational drug-signature reversal protocol

Protocol frozen: 2026-08-25, before inspection of any drug-reversal result.

Resource-QC amendment, also before scoring: the initially selected Perturb-Seqr
CMap Build 02 limma-log2FC file was downloaded and found to contain only 3,478
drug-by-cell-line aggregates (`drug__cell__trt_cp`), with dose, time, and batch
removed. It was excluded before any reversal score was calculated. The signed
Sci-Plex resource below was substituted because it passes the locked metadata
requirement. Scoring, robustness, toxicity, and tier rules were not changed.

Missingness-QC amendment, before scoring: the Sci-Plex derivative contains
condition-specific missing coefficients. To keep every condition on the same
gene universe and make the 1,000 global gene-label permutations exact, the
primary score uses source genes with finite coefficients in all 2,302
conditions. This leaves 3,692 APC genes and 213 of the 232 APC-measured locked
program genes. Selection uses missingness only, never a drug or disease effect.
The full 4,267/219 source overlaps, missingness exclusions, and per-condition
coverage are retained in QC/sensitivity outputs.

## Status and scope

This is a post hoc, exploratory, computational analysis. It does not modify the
frozen negative Gate 3 result, does not constitute evidence of causal target
biology, and cannot establish clinical efficacy or safety. No wet-lab work is
proposed or performed.

The question is whether public drug perturbations reproducibly oppose both the
APC Day-4 allergy-minus-irritant transcriptomic contrast and the locked
DNA-damage/replication-stress driver program, without the apparent reversal being
explained primarily by generic cell death, translation shutdown, or cell-cycle
arrest.

## Locked disease inputs

1. Primary APC gene statistic:
   `results/tables/single_cell_validation/GSE267929_APC_gene_effects.tsv`.
   The signed statistic is `sign(logFC) * sqrt(F)`; zero-F genes are zero.
2. Locked driver-program membership:
   `results/exploratory_snf/selected_positive_reml_z_q05/optimized_AD_ACD_branch/mechanism/core_genes/top20_pathway_gene_membership.tsv`.
   Repeated genes are collapsed by summing the already computed
   `pathway_support_influence`; no pathway or gene is reselected.
3. Tier-1 core genes:
   `results/exploratory_snf/selected_positive_reml_z_q05/optimized_AD_ACD_branch/mechanism/core_genes/tier1_core_genes.tsv`.
4. Independent disease contrast:
   `results/tables/direct_comparison/E-MTAB-9501_ACD_vs_ICD_gene_effects.tsv`.
   The signed statistic is the moderated `t` statistic.
5. Internal, non-independent audit contrasts: the three `AD_*.tsv` and two
   `ACD_*.tsv` files in `results/tables/cohort_effects`, using their `t`
   statistics. These cohorts contributed upstream and are never called
   independent validation.
6. Pre-existing candidate compounds/targets:
   `results/exploratory_snf/selected_positive_reml_z_q05/optimized_AD_ACD_branch/mechanism/drug_target_ranking/drug_target_ranking.tsv`.

The primary genome-wide signature contains every APC-tested gene with a finite
statistic. The program signature contains all locked program genes measurable in
APC. Its direction is the APC signed statistic and its fixed weight is the
gene-level sum of `pathway_support_influence`, normalized to sum to one. Tier-1
genes are reported as an audit and do not receive an extra fitted weight.

## Perturbation resource

The fixed analysis resource is **Sci-Plex drug perturbations, Perturb-Seqr full
characteristic-direction-coefficient derivative snapshot**, downloaded from the
Ma'ayan Lab Perturb-Seqr download page on 2026-08-25:

- full signed effects:
  `https://s3.perturbseqr.maayanlab.cloud/data/sciplex-full.txt.gz`
- cell-line metadata:
  `https://s3.perturbseqr.maayanlab.cloud/data/sciplex-cell_line_metadata.parquet`
- drug metadata:
  `https://s3.perturbseqr.maayanlab.cloud/data/sciplex-drug_metadata.parquet`
- source page: `https://perturbseqr.maayanlab.cloud/download`
- license page: `https://perturbseqr.maayanlab.cloud/license`
- original Sci-Plex citation: Srivatsan et al., *Science* 2020,
  PMID `31806696`, DOI `10.1126/science.aax6234`.

The dataset identifier is **Sci-Plex** (Srivatsan et al. 2020); the distributed
file snapshot has HTTP last-modified date 2026-04-29. The exact downloaded bytes,
HTTP last-modified/ETag values, access date, and SHA-256 checksums are recorded in
`data/raw/perturbations/sciplex_perturbseqr/PROVENANCE.md` and
`DOWNLOAD_MANIFEST.tsv`; releases are not mixed. Perturb-Seqr states that its
web tools/services are free for academic, non-profit use and require contacting
Mount Sinai for commercial licensing. The resource is explicitly not for
treating or diagnosing human subjects.

This derivative was chosen because it is the smallest located reproducible
full-effect resource that retains drug, cell line, dose, and time at the
condition level. Its important limitations are transformed derivative status,
only three cancer cell lines (A549, K562, MCF7), no APC/skin cell, mostly 24-hour
exposures, and incomplete coverage of modern candidate agents. These limitations
are retained in the report. The excluded CMap aggregate snapshot and exclusion
reason are also retained in provenance rather than silently discarded.

## Condition inclusion and identifiers

- Include chemical perturbation columns with a parseable drug name and at least
  100 common-complete genes overlapping the APC signature and at least 20
  common-complete locked program genes.
- Preserve every eligible signature; do not select doses, time points, batches,
  or cell lines using the observed reversal score.
- A condition ID is the complete original signature label. Parsed drug, cell
  line, time, and dose are stored separately; Sci-Plex has no batch field in this
  derivative.
- Duplicate gene symbols in the source are collapsed by arithmetic mean before
  scoring. There are no duplicates in this snapshot. Primary scores use the
  common-complete gene set described above; full pairwise coverage is retained
  as a missingness sensitivity/QC comparison and is not used for tiering.
- Compound normalization is lower case, surrounding whitespace removed, and
  repeated internal whitespace collapsed. No pharmacologic synonyms are merged
  after results are seen. A prespecified alias table is used only for matching
  the eight pre-existing candidates and is retained in the output. The
  candidate-versus-background audit has two prespecified flags: exact match to a
  named lead-agent alias, and an exact target token in the distributed
  Perturb-Seqr `drh_target` annotation matching IRF1, HSF1, ATR, PCNA, CDK2,
  E2F4, YY1, or E2F6. Both flags and all unmatched candidates are retained.

## Locked condition-level scores

Positive scores always mean reversal.

1. **Genome rank reversal**: negative Spearman correlation between drug log2FC
   and the APC signed statistic across all overlapping genes.
2. **Genome weighted reversal**: negative weighted Pearson correlation, using
   `abs(APC signed statistic)` capped at its 95th percentile as fixed gene
   weights.
3. **Program rank reversal**: negative Spearman correlation on the locked program
   genes.
4. **Program weighted reversal**: negative weighted Pearson correlation on the
   locked program genes, using normalized `pathway_support_influence` weights.
5. **Primary composite**: arithmetic mean of the four reversal scores. No score
   is chosen or reweighted based on results.

Gene-label empirical P values use 1,000 deterministic permutations (seed
`20260825`) of disease-statistic labels within the observed overlapping genes.
The one-sided P value is `(1 + null >= observed) / 1001`. Condition-level P
values are descriptive because the formal multiplicity unit is the compound.

The same four definitions are applied separately to the independent
E-MTAB-9501 disease statistic. Program weights remain frozen; only genes
measurable in that contrast are used.

## Locked compound aggregation and robustness

- Aggregate only after saving the full condition table.
- Each compound score is the median of its condition-level score.
- Direction consistency is the fraction of conditions with composite reversal
  greater than zero.
- Multi-condition stability requires at least two conditions, at least two cell
  lines, direction consistency at least 2/3, a positive minimum
  leave-one-condition median, and a positive minimum leave-one-cell-line median.
  Compounds represented in only one cell line fail multi-cell-line stability;
  missing leave-one-out quantities are retained as missing, not treated as pass.
- Compound-label P values use 1,000 deterministic permutations of condition
  labels, preserving every compound's observed number of conditions and using
  the median composite as the statistic. One-sided empirical P values are
  adjusted across all screened compounds by Benjamini-Hochberg. No shortlist-only
  FDR is reported.
- The primary APC reversal screen requires median genome rank, genome weighted,
  program rank, program weighted, and composite scores all greater than zero.

## Independent and internal audits

- Independent direction support requires a positive median E-MTAB-9501 composite
  across the compound's same conditions. Its effect and empirical P value are
  reported, but the primary compound FDR is not recomputed on a validation-selected
  subset.
- For each of the five internal cohorts, the genome-wide rank and weighted
  reversal scores are computed. The number with positive median compound reversal
  is reported as an internal direction audit only.
- No TF is described as independently bulk-confirmed: the preceding five-TF
  validation remains 0/5 at BH q<0.05.

## Anti-toxicity and cell-cycle sensitivity

Toxicity-control gene sets are frozen from local Reactome v97 before scoring:

- cell death: pathway names matching `apoptosis|programmed cell death`;
- translation/ribosome: names matching `translation|ribosom`;
- cell cycle/DNA replication: names matching
  `cell cycle|mitotic|G1/S|S phase|DNA replication|DNA strand elongation|synthesis of DNA`.

Within each condition, drug effects are standardized over all measured genes.
The three axes are mean standardized effect for cell-death genes, negative mean
for translation/ribosome genes, and negative mean for cell-cycle/replication
genes. The toxicity index is their maximum. A condition is toxicity-dominated if
the index is at least 0.5 and removing the union of the three sets makes the
composite non-positive or attenuates it by at least 50%.

A compound is toxicity-dominated if at least half its conditions are
toxicity-dominated, or its median cell-cycle/replication-removed composite is
non-positive, or that median is less than half its unfiltered median when the
unfiltered median is positive. Both the complete and the cell-cycle/replication-
removed grid are retained.

## Evidence tiers

- **Tier A**: passes the five-score primary screen; compound-label BH q<0.05;
  multi-condition stability; independent median direction support; and not
  toxicity-dominated.
- **Tier B**: passes the primary screen, BH q<0.05, stability, and toxicity rule,
  but independent direction is absent or discordant.
- **Tier C**: positive primary composite with empirical P<0.05 but lacking FDR,
  stability, coverage, or independent support; single-condition signals are here.
- **Reject**: non-positive primary composite, inconsistent component direction,
  or toxicity-dominated. Toxicity dominance overrides a nominal statistical tier.

These are evidence tiers for hypothesis generation, not treatment
recommendations.

## Required outputs and validation

Outputs are written under
`results/exploratory_snf/selected_positive_reml_z_q05/optimized_AD_ACD_branch/mechanism/drug_signature_reversal/`:

- `condition_level_reversal.tsv`
- `compound_level_ranking.tsv`
- `candidate_vs_background.tsv`
- `independent_validation.tsv`
- `internal_five_cohort_direction_audit.tsv`
- `toxicity_cell_cycle_sensitivity.tsv`
- locked disease-signature and resource-QC tables

Scripts `41_prepare_drug_signatures.py`, `42_score_drug_signature_reversal.py`,
and `43_validate_drug_signature_reversal.py` respectively prepare, score, and
independently assert file integrity, row completeness, score calculations,
multiplicity, tier rules, candidate-background completeness, negative-result
retention, and reporting boundaries.
