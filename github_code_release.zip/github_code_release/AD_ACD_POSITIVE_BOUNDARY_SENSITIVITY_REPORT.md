# AD–ACD positive-boundary sensitivity analysis

Date: 2026-08-25  
Status: explicitly post hoc, exploratory and computational

## Selected favorable result

**JNJ-7706621 is the least-relaxed balanced exploratory positive candidate.**
The favorable label is obtained by changing one statistical-evidence rule:

- Original: targeted LINCS BH q<0.05.
- Relaxed: LINCS empirical P<0.05, with no multiplicity-control claim.

All four biological/robustness requirements remain unchanged. JNJ-7706621 has
all four LINCS component medians positive, passes the original multi-condition
stability rule, has positive independent E-MTAB-9501 direction, and is not
toxicity dominated. Its empirical `P=0.04695`, while its targeted `q=0.4146`.

Sci-Plex also has a positive JNJ-7706621 composite (`+0.01209`), positive
independent direction and no toxicity-dominance flag, but it does not pass the
Sci-Plex all-four/stability gates and has `P=0.07393`. Therefore the defensible
label is **`balanced_posthoc_nominal_candidate`**, not replicated,
FDR-supported, confirmatory or clinical evidence.

## Why this is the minimum-change option

Under the original rules, no Sci-Plex or LINCS compound passes. Only one
compound in each resource passes all non-statistical gates:

- Sci-Plex: Andarine, empirical `P=0.01399`, full-background `q=0.5259`.
- LINCS: JNJ-7706621, empirical `P=0.04695`, targeted `q=0.4146`.

Thus no relaxation of component direction, condition stability, independent
direction or toxicity is necessary to obtain a nominal single-resource positive.
Only multiplicity control must be dropped. Keeping a q-value rule instead would
require raising the LINCS q threshold from 0.05 to at least 0.4146 and the
Sci-Plex q threshold to at least 0.5259. Those are very high tolerated false-
discovery proportions and are less defensible than an explicitly nominal,
hypothesis-generating label.

## Complete threshold grid

| Resource | Evidence rule | First grid threshold with a positive | Candidate | Interpretation |
|---|---|---:|---|---|
| LINCS | BH q | 0.50 | JNJ-7706621 | Highly relaxed q; not recommended |
| LINCS | nominal P | 0.05 | JNJ-7706621 | Selected nominal sensitivity result |
| Sci-Plex | BH q | 0.75 | Andarine | Highly relaxed q; not recommended |
| Sci-Plex | nominal P | 0.025 | Andarine | Single-resource nominal result |

No positive appears at q thresholds 0.05, 0.10, 0.20 or 0.25 in either resource.
The complete 22-cell grid is retained rather than reporting only the favorable
cells.

## Why Andarine is not selected across resources

Andarine is the cleaner Sci-Plex-only nominal positive: all four Sci-Plex scores
are positive, it is stable, independent-direction positive and non-toxicity-
dominated. Its LINCS result is much weaker: composite `+0.00310`, empirical
`P=0.3177`, non-positive independent direction, failed stability and a toxicity-
dominance flag. It therefore fails the balanced cross-resource rule.

## Balanced cross-resource rule

The favorable cross-resource sensitivity label requires:

1. Positive median composites in both resources.
2. Positive independent directions in both resources.
3. No toxicity-dominance flag in either resource.
4. At least one resource retaining all-four positivity and stability with
   nominal empirical P<0.05.

JNJ-7706621 is the only one of the 10 covered compounds satisfying this relaxed
rule. Iniparib has positive composites, positive external directions and no
toxicity flag in both resources, but neither resource is structurally stable and
nominally positive. Droxinostat has positive composites but fails the independent
direction check in Sci-Plex. Other candidates fail direction or toxicity gates.

## Permissible positive wording

> In a post hoc threshold-sensitivity analysis, JNJ-7706621 showed nominal LINCS
> support for reversal (empirical P=0.04695), while retaining all four score
> directions, multi-condition stability, independent-direction support and the
> non-toxicity-dominance criterion. Its Sci-Plex composite was directionally
> concordant. The result did not survive targeted FDR correction (q=0.4146) and
> was not a formal cross-resource replication.

Do not shorten this to “JNJ-7706621 was replicated” or “JNJ-7706621 was
significant” without the nominal/post-hoc qualifier.

## Evidence boundaries

- The original result remains `replicated=0`.
- JNJ-7706621 remains `direction_only` in the frozen cross-resource table.
- Gate 3 remains negative and unchanged.
- This is not clinical evidence, a treatment recommendation, a safety result or
  target-specific causal evidence.
- The threshold was selected after observing results, so its false-positive risk
  is higher than a prespecified nominal test.

## Outputs

- Protocol: `LINCS_POSITIVE_BOUNDARY_SENSITIVITY_PROTOCOL.md`
- Analysis: `scripts/47_run_positive_boundary_sensitivity.py`
- Validation: `scripts/48_validate_positive_boundary_sensitivity.py`
- Result directory:
  `results/exploratory_snf/selected_positive_reml_z_q05/optimized_AD_ACD_branch/mechanism/positive_boundary_sensitivity/`
- Full threshold grid: `complete_threshold_grid.tsv`
- Compound gates: `resource_level_boundary_gates.tsv`
- Cross-resource selection: `cross_resource_balanced_sensitivity.tsv`
- Machine-readable selected result: `SELECTED_EXPLORATORY_POSITIVE.json`
