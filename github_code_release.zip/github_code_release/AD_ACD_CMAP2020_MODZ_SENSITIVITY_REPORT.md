# AD–ACD CMap2020 MODZ full-background sensitivity report

## Executive conclusion

This post hoc, exploratory, computational analysis evaluates JNJ-7706621 with
Broad CMap2020 Level-5 MODZ signatures as a processing-method sensitivity check.
The frozen MODZ disposition is **`modz_full_background_not_supported`**.

This is not an independent biological replication. It does not alter the CD
label `positive_not_top5`, the independent GSE201278 label
`independent_skin_line_not_supported`, the targeted LINCS q=0.4146, or the
negative Gate 3 result.

## Source and scope

- Version-pinned Broad object:
  `level5_beta_trt_cp_n720216x12328.gctx`, S3 version
  `ljLz1nWDJ4co.kG6bSrfEs7mrklxiVS4`.
- Exact bytes: 35,518,405,386.
- Local SHA-256: `fbb04a94d8aa8a4fa6daf01f7d94dcd938fb9b7937730f81bfba3d8d0f1472a8`.
- Matrix: 720,216 compound-treatment conditions by
  12,328 Entrez rows.
- Canonical scoring universe: 12,327 unique gene
  symbols; duplicated MIA2 was resolved before scoring by retaining Entrez 4253
  and excluding legacy Entrez 117153.
- Complete provider-name background: 33,609 compounds; stable-
  eligible background: 21,730 compounds.
- The audit retains all 720,216 conditions. Exactly
  62 source signatures were constant
  all-zero vectors and therefore mathematically unscorable; they were retained
  with missing scores and transparently excluded from compound aggregation.
  The remaining 720,154 conditions were scored before
  aggregation. None of the all-zero signatures was JNJ-7706621 or part of the
  frozen 2,787-condition CD/MODZ comparison.

## JNJ-7706621 MODZ result

| Score | Compound median | Direction |
|---|---:|---|
| APC genome rank | 0.006079 | positive |
| APC genome weighted | 0.005051 | positive |
| Program rank | 0.023622 | positive |
| Program weighted | 0.053450 | positive |
| Composite | 0.024424 | positive |

- Conditions: 297; cell lines: 98.
- All-compound rank: 5,343/33,609;
  competitive upper-tail fraction:
  0.15900.
- Stable-eligible rank: 2,451/
  21,730; competitive upper-tail fraction:
  0.11283.
- Multi-condition stable: True.
- External direction supported: True.
- Toxicity dominated: True.

Competitive fractions are descriptive ranks, not null P values and not FDR.

## Complete CD/MODZ method comparison

| Score | Overlap | Spearman | Sign agreement | Median MODZ − CD |
|---|---:|---:|---:|---:|
| APC genome rank | 2,787 | 0.5872 | 0.7130 | 0.000010 |
| APC genome weighted | 2,787 | 0.5391 | 0.6893 | -0.003480 |
| Program rank | 2,787 | 0.4975 | 0.6649 | 0.001447 |
| Program weighted | 2,787 | 0.4931 | 0.6710 | 0.010072 |
| Composite | 2,787 | 0.5002 | 0.6685 | 0.002293 |

The comparison retains all 2,787 prespecified targeted conditions. Correlation
is diagnostic because CD and MODZ estimate different processed signatures; no
post-score compatibility threshold was introduced.

## Interpretation and limits

- A favorable MODZ result supports processing-method robustness only.
- A non-favorable MODZ result indicates that the earlier CD signal is sensitive
  to signature-estimation method.
- Neither outcome is an independent JNJ experiment.
- The analysis does not establish skin efficacy, safety, CDK2 selectivity, or
  clinical utility.
- Formal replication remains false and no library-wide FDR was computed.
- Validation: `pass` with
  65 checks passed.

Primary machine-readable outputs are in:
`results/exploratory_snf/selected_positive_reml_z_q05/optimized_AD_ACD_branch/mechanism/cmap2020_modz_full_background_sensitivity/`.
