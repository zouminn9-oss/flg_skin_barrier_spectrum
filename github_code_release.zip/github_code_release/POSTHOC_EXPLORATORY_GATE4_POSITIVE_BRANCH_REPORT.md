# Post-hoc exploratory Gate 4 positive-branch report

## Executive disposition

The user-directed, post-hoc, exploratory Gate 4 disposition is
**`exploratory_gate4_transcriptomic_positive_multilayer_incomplete`**.

All seven frozen transcriptomic entry checks passed. However, only the
transcriptomic/pathway layer provides comparable features for all seven
discovery disease nodes. A complete multilayer fusion requires at least two
eligible layers, so the full multilayer Gate 4 is not evaluable and no
multilayer-positive claim is made.

This is not confirmatory Gate 4, not independent replication, and not a rescue
or replacement of frozen Gate 3. Gate 3 remains negative with 0/3 core axes
passing.

## Fixed positive-branch entry signal

- Selected branch: `all_positive+stress_damage`
  (`B0073`), K=2,
  alpha=0.2, 10
  fusion iterations.
- Complete search: 396 branches.
- Resampling: 10,000 nominal permutations,
  1,000 bootstraps, and
  500 whole-search selection
  permutations.
- AD–ACD similarity: 0.259194; edge rank:
  3/21.

| Frozen check | Observed | Threshold | Result |
|---|---:|---:|---|
| complete_branch_grid | 396 | =396 | PASS |
| selection_adjusted_permutation | 0.0099800399201596 | <0.05 | PASS |
| nominal_permutation_BH | 0.0005249475052494 | <0.05 | PASS |
| same_observed_cluster | True | =true | PASS |
| AD_ACD_bootstrap_coclustering | 1.0 | >=0.75 | PASS |
| AD_cluster_support | 1.0 | >=0.75 | PASS |
| ACD_cluster_support | 1.0 | >=0.75 | PASS |

No threshold was relaxed after inspecting this result.

## Four-layer evidence coverage audit

| Layer | Evidence layer | Comparable discovery nodes | Covered nodes | Eligible for complete fusion | Limitation |
|---:|---|---:|---|---|---|
| 1 | transcriptomic_pathway | 7/7 | AD;ACD;PSORIASIS;HS;ACNE;ROSACEA;ICD | yes | outcome-selected post-hoc transcriptomic branch |
| 2 | GWAS_QTL_colocalization | 1/7 | AD | no | no harmonized comparable GWAS/QTL/colocalization features across all seven discovery diseases |
| 3 | direct_genetic_functional | 1/7 | AD | no | IV is an anchor outside the seven discovery disease nodes; no comparable seven-node feature matrix exists |
| 4 | network_cell_spatial | 2/7 | AD;ACD | no | mechanistic follow-up is not a comparable network/cell/spatial feature layer across all seven diseases |

The frozen planned weights remain 0.40, 0.30, 0.20 and 0.10. They were not
renormalized into an invented multilayer result because only one complete
seven-node layer exists. No missing layer was filled with zero, mean-imputed,
copied between diseases, or replaced with the drug score. Consequently, no
`multilayer_fused_similarity.tsv` was produced.

## JNJ-7706621 annotation boundary

JNJ-7706621 retains the LINCS characteristic-direction full-background label
**`positive_not_top5`** and targeted BH q=0.414585.
It is a downstream computational candidate annotation only, not a
disease-network layer and not evidence that supplies the missing genetic,
functional, network, cell, or spatial coverage.

This candidate label is not formal or independent replication. It is not
evidence of clinical efficacy, safety, skin-disease benefit, target
specificity, or treatment suitability.

## Interpretation

The allowed conclusion is narrow: the user-selected transcriptomic AD–ACD
positive branch passes its frozen exploratory Gate 4 transcriptomic sub-gate,
including adjustment for the 396-branch search. The available project data do
not identify a complete multilayer disease graph. Therefore the result cannot
be described as full, confirmatory, or independently replicated Gate 4.

Unfavorable prior results remain visible: frozen Gate 3 is negative 0/3; no
compound achieved frozen cross-resource replication; the independent
GSE201278 JNJ direction check was unsupported; and the MODZ sensitivity result
was `modz_full_background_not_supported`.

## Reproducibility outputs

- `results/posthoc_exploratory_gate4_positive_branch/GATE4_DISPOSITION.json`
- `results/posthoc_exploratory_gate4_positive_branch/positive_branch_entry_audit.tsv`
- `results/posthoc_exploratory_gate4_positive_branch/layer_coverage_audit.tsv`
- `results/posthoc_exploratory_gate4_positive_branch/downstream_candidate_annotation_audit.tsv`
- `results/posthoc_exploratory_gate4_positive_branch/RUN_PARAMETERS.json`
- `results/posthoc_exploratory_gate4_positive_branch/SOURCE_MANIFEST.json`
- `results/posthoc_exploratory_gate4_positive_branch/VALIDATION_SUMMARY.json`
- `results/posthoc_exploratory_gate4_positive_branch/pipeline.log`
