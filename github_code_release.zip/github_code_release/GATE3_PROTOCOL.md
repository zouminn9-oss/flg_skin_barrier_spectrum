# Gate 3 execution protocol

Freeze date: 2026-08-25  
Global seed: `20260825`

## Blockers to resolve before effect estimation

1. Reconstruct sample–participant–site–time–exposure maps from GEO SOFT/MINiML, SRA RunInfo, ArrayExpress SDRF, and primary supplements where needed.
2. Audit participant/recruitment overlap between E-MTAB-8945 and E-MTAB-9501.
3. Resolve GSE282562 and GSE267929 participant–sample–time mappings.
4. Freeze GWAS cohort-overlap, genome-build, allele-alignment, and harmonization rules before genetic analysis.
5. Record every download URL, timestamp, byte count, SHA-256, exclusion, and amendment.

## Initial expression-analysis order

1. AD primary cohorts: GSE121212, GSE32924, GSE36842.
2. ACD primary cohorts: GSE6281, GSE282562; E-MTAB studies remain one dependency family.
3. ICD direct/reference cohorts: E-MTAB-9501 and GSE18206; GSE267929 is auxiliary cell-level validation.
4. Background diseases: GSE13355, GSE53795, GSE65914, GSE137141, GSE72702.

Each dataset is normalized and modeled separately. Cross-study ComBat and raw-matrix concatenation are prohibited. Dataset-level effects and standard errors are the inputs to random-effects synthesis.

