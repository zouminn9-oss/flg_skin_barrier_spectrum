# GSE201278 JNJ-7706621 independent skin-line validation protocol

Frozen: 2026-08-26, before expression values or reversal scores were inspected.

Pre-score schema amendment: the downloaded FPKM file exposes two CTRL and two
JNJ columns, whereas GEO/SRA registers only one GSM, one BioSample and one raw
run per arm. The four processed columns therefore cannot be counted as four
independent biological libraries. The primary contrast is the difference
between the within-arm means of `log2(FPKM + 1)`. All four JNJ-column versus
CTRL-column contrasts are retained as an undocumented-subcolumn robustness
audit, and every pairwise composite must be positive for the strongest label.
No variance, P value or replication claim is derived from these columns.

## Evidence question and boundary

This post-hoc, exploratory, computational analysis asks whether an independently
generated JNJ-7706621 RNA-seq contrast from a skin-derived cell line points in
the same reversal direction as the carried-forward APC disease signature and
locked DNA-damage/replication-stress program.

It cannot establish formal replication, clinical efficacy, safety, target
causality, CDK2 specificity, or normal-keratinocyte transportability. The GEO
series has one deposited DMSO library and one deposited JNJ library, so there is
no treatment-level biological variance estimate. A gene-label permutation is
an alignment diagnostic, not a treatment-effect P value.

## Frozen source

- GEO series: GSE201278, BioProject PRJNA830706.
- Cell line: SK-MEL-2 human skin melanoma cells.
- Treatment: JNJ-7706621, 1.75 uM, 48 h.
- Comparator: DMSO, 48 h.
- Deposited libraries: GSM6057316 (DMSO) and GSM6057317 (JNJ), one per arm.
- Expression file:
  `https://ftp.ncbi.nlm.nih.gov/geo/series/GSE201nnn/GSE201278/suppl/GSE201278_fpkm.txt.gz`
- Frozen remote properties: 1,383,358 bytes; Last-Modified
  `Fri, 22 Apr 2022 11:53:26 GMT`.
- Series and sample SOFT records are downloaded separately and checksummed.

The file is accepted only if the sample columns map exactly to the two GEO
libraries, gene identifiers can be reconciled without one-to-many expansion,
all retained FPKM values are finite and non-negative, and at least 80% of the
3,735-gene APC primary signature plus 80% of the 214-gene locked program are
covered. Exact bytes, SHA-256, dimensions, duplicates, missingness and coverage
are reported before interpretation.

## Frozen contrast and scores

The primary JNJ effect is

`log2(FPKM_JNJ + 1) - log2(FPKM_DMSO + 1)`.

Duplicate gene symbols, if present after identifier reconciliation, are reduced
by the median contrast. No gene is selected by observed fold change or P value.

On the overlap with `locked_disease_signatures.tsv`, compute the same four
signed reversal scores used in the LINCS analyses:

1. negative Spearman correlation with the APC signed disease statistic across
   the full covered signature;
2. negative weighted Pearson correlation, using absolute APC statistic capped
   at its 95th percentile as the weight;
3. negative Spearman correlation within the locked program;
4. negative weighted Pearson correlation within the locked program, using the
   frozen program weights.

The composite is the equal-weight mean of the four scores. The independent
E-MTAB-9501 external disease statistic is scored with the same rank/weighted
panel and reported separately.

## Toxicity and robustness audits

The frozen cell-death, translation/ribosome-shutdown and
cell-cycle/replication-arrest gene axes are evaluated exactly as in the LINCS
full-background analysis. A contrast is toxicity dominated only when the
maximum signed toxicity-axis mean is at least 0.5 and either the toxicity-gene-
removed composite is non-positive or at least 50% of the primary composite is
attenuated after removal.

Robustness requires a positive composite under each of these prespecified
transformations:

- log2(FPKM + 0.5);
- log2(FPKM + 2);
- primary transform restricted to genes with mean FPKM at least 1;
- primary transform with contrasts winsorized at the 1st and 99th percentiles.

With seed 20260826, 10,000 gene-label permutations of the primary contrast are
used to compute `(1 + number of permuted composites >= observed) / 10001`.
This quantity is named `gene_label_alignment_fraction`; it is not a biological-
replicate P value and is not an FDR.

## Frozen disposition

- `independent_skin_line_direction_supported`: all four primary scores and the
  primary composite are positive; external composite is positive; toxicity is
  not dominant; all four robustness composites are positive; and the gene-label
  alignment fraction is below 0.05; all four processed-column pairwise
  composites are positive.
- `independent_skin_line_directional_but_fragile`: the primary composite is
  positive but at least one other frozen support requirement fails.
- `independent_skin_line_not_supported`: the primary composite is non-positive.

Every label remains skin-melanoma-line directional evidence only. It cannot
change Gate 3, the targeted LINCS q=0.4146, the full-background
`positive_not_top5` label, or formal replication=false.

## Outputs and validation

Outputs will include source/schema QC, the complete gene-level contrast, the
four-score and robustness table, permutation summary, frozen disposition, an
executed notebook, a technical report artifact, and an independent validator.
All negative and sensitivity results are retained.
