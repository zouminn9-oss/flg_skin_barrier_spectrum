# JNJ-7706621 candidate-specific computational audit

Date: 2026-08-25  
Status: post hoc nominal candidate audit; data only

## Answer first

JNJ-7706621 passes the frozen candidate-audit labels
`broad_transportable` and `class_leading_inferential` **for composite
transcriptomic direction within this targeted LINCS analysis**. It remains a
post-hoc nominal candidate, not formally replicated.

The favorable composite direction was positive across all three dose groups,
all three time groups, skin and non-skin conditions, and after every leave-one-
dose/time/tissue deletion. Overall cell-line-cluster bootstrap 95% interval was
`0.01008 to 0.02508`; the skin-labeled interval was `0.00249 to 0.06424`.
JNJ ranked first among the six provider-CDK2-token compounds and exceeded all
five in matched-stratum median differences; three of five paired comparisons
passed BH q<0.05.

However, this favorable summary has material context limits: seven of 23 tissue
medians were non-positive, the toxicity/cell-cycle-removed median reversed at
10 µM and 6 h, the external median reversed at 48 h, and the five skin-labeled
cell lines were melanoma lines rather than normal skin or APCs. JNJ-7706621 is a
known multi-CDK/Aurora inhibitor, so this audit does not establish CDK2
specificity, skin-disease efficacy or safety.

## Fixed baseline

- 297 LINCS conditions across 98 cell lines and 23 tissue annotations.
- Original median composite: `0.017759`.
- Empirical P: `0.046953`; targeted BH q: `0.414585`.
- Frozen cross-resource class: `direction_only`.
- Carried-forward sensitivity label: `balanced_posthoc_nominal_candidate`.

No score, condition, target, dose or time was changed for this audit.

## Dose, time and skin context

| Factor | Level | n | Median composite | Cluster-bootstrap 95% interval | Positive fraction | External median | Toxicity-removed median |
|---|---|---:|---:|---:|---:|---:|---:|
| Overall | all | 297 | 0.01776 | 0.01008, 0.02508 | 0.667 | 0.01541 | 0.01816 |
| Dose | 0.12 µM | 93 | 0.01329 | −0.00259, 0.02363 | 0.602 | 0.03410 | 0.05740 |
| Dose | 1.11 µM | 92 | 0.01683 | 0.00219, 0.02593 | 0.630 | 0.01199 | 0.02850 |
| Dose | 10 µM | 112 | 0.02432 | 0.01463, 0.02855 | 0.750 | 0.01205 | **−0.01885** |
| Time | 6 h | 17 | 0.02508 | 0.00969, 0.03095 | 0.941 | 0.06694 | **−0.05445** |
| Time | 24 h | 271 | 0.01555 | 0.00809, 0.02102 | 0.638 | 0.01640 | 0.02246 |
| Time | 48 h | 9 | 0.05339 | 0.02046, 0.05624 | 1.000 | **−0.01056** | 0.08954 |
| Skin context | skin | 16 | 0.04366 | 0.00249, 0.06424 | 0.750 | 0.06892 | 0.10222 |
| Skin context | non-skin | 281 | 0.01713 | 0.00861, 0.02448 | 0.662 | 0.01386 | 0.00904 |

All three dose and time composite medians were positive, but not all four
component medians were positive within every stratum: at 1.11 µM the two genome
components were negative. The higher 10-µM composite coincided with a negative
toxicity-removed median. Therefore the dose pattern cannot be interpreted as a
clean therapeutic dose response.

Among 91 matched cell-line × time dose-trend strata, median Spearman rho was
`0.5`, but only 57.1% had a positive trend. Among 12 matched cell-line × dose
time-trend strata, 66.7% had a positive trend. These results show heterogeneity
rather than a uniform monotonic response.

## Skin-labeled conditions

The 16 skin conditions came from five melanoma cell lines: A375, IGR37, MELHO,
SH4 and SKMEL3. Twelve of 16 composites were positive. Low-dose conditions were
negative in IGR37, MELHO and SKMEL3, while all three dose levels were positive in
A375 and SH4.

The positive skin aggregate is therefore useful as oncology-cell-line context
transportability, but it is not independent validation in normal keratinocytes,
APCs, lesional skin or patients.

## Tissue and deletion robustness

Sixteen of 23 tissue medians were positive. Seven were non-positive: blastocyst,
central nervous system, colon, connective tissue, endometrium, pancreas and
stomach. Several tissue groups contained only one or two cell lines, so their
cluster intervals should not be read as population uncertainty estimates.

Despite those negative tissues, every leave-one-tissue aggregate remained
positive; the minimum remaining composite was `0.01648`. Minimum leave-one-dose
and leave-one-time composites were `0.01517` and `0.01589`, respectively. This is
why the prespecified composite/deletion label is `broad_transportable`, while the
complete tissue table still documents context-specific failures.

## CDK2-token comparator audit

JNJ had the highest full-condition median among all six compounds:

| Rank | Compound | Median composite | Targeted q |
|---:|---|---:|---:|
| 1 | JNJ-7706621 | 0.01776 | 0.4146 |
| 2 | Roscovitine | 0.00201 | 0.7309 |
| 3 | Bosutinib | −0.00443 | 0.9261 |
| 4 | BMS-536924 | −0.00622 | 0.9261 |
| 5 | PF-573228 | −0.00772 | 0.9261 |
| 6 | BMS-265246 | −0.02107 | 0.9261 |

Exact cell-line × dose × time matching found positive JNJ-minus-comparator median
differences against all five compounds. Comparisons with Bosutinib (BH
`q=0.000219`), PF-573228 (`q=0.000219`) and Roscovitine (`q=0.00221`) passed the
five-test BH screen. BMS-265246 and BMS-536924 each had only four matched strata
and did not pass (`q=0.4375`). This supports a class-leading transcriptomic
pattern, not a kinase-selectivity claim.

## Pharmacology audit

The original primary study describes JNJ-7706621 as inhibiting several CDKs and
Aurora kinases, producing cell-cycle arrest and apoptosis; it also reports that
higher concentrations induced cytotoxicity in tumor cells
([Emanuel et al., 2005](https://pubmed.ncbi.nlm.nih.gov/16204078/),
DOI 10.1158/0008-5472.CAN-05-0882). A later mechanistic study similarly reports
G1/G2 arrest and mitotic defects consistent with combined CDK/Aurora pathway
interference ([Matsuhashi et al., 2012](https://pubmed.ncbi.nlm.nih.gov/22463590/)).
The official LINCS small-molecule record confirms the identity used here as
LSM-5294/PubChem CID 5330790
([LINCS Small Molecules Portal](https://lincsportal.ccs.miami.edu/SmallMolecules/view/LSM-5294)).

These sources are preclinical oncology evidence. Together with the negative
toxicity-removed high-dose result, they argue against calling the observed
signature a selective CDK2-mediated skin effect.

## Disposition

Carry JNJ-7706621 forward only as a **prioritized computational multi-kinase/cell-
cycle mechanism candidate**. The strongest favorable statement is:

> JNJ-7706621 retained a positive composite reversal direction across dose,
> time, skin-labeled and non-skin LINCS strata, and ranked first among six
> provider-CDK2-token compounds. This was a post-hoc nominal result, did not pass
> targeted FDR, and showed context-specific toxicity-removal and external-
> direction failures.

The next statistically useful data-only step is full-background LINCS calibration
under the frozen four-score method. Candidate-specific subset analysis cannot
convert q=0.4146 into full-library evidence.

## Outputs

- Protocol: `JNJ7706621_CANDIDATE_AUDIT_PROTOCOL.md`
- Analysis: `scripts/49_audit_jnj7706621_candidate.py`
- Validation: `scripts/50_validate_jnj7706621_candidate_audit.py`
- Results:
  `results/exploratory_snf/selected_positive_reml_z_q05/optimized_AD_ACD_branch/mechanism/jnj7706621_candidate_audit/`

The result directory contains the full context grid, all skin conditions,
matched dose/time trends, every leave-one-context result, class ranking, paired
comparator tests, pharmacology evidence matrix, run parameters and machine-
readable disposition.
