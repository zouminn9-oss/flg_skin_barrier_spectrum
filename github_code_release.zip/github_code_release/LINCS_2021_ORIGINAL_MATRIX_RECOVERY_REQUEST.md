# Request draft — original 2021 `cp_coeff_mat.gctx`

This file contains drafts only. Nothing has been submitted or emailed.

## Preferred request: SigCom LINCS GitHub issue

Suggested destination: <https://github.com/MaayanLab/sigcom-lincs/issues/new>

### Title

Request for immutable original 2021 `cp_coeff_mat.gctx` object or checksum/version ID

### Body

Hello,

I am conducting a computational version-sensitivity analysis using the SigCom LINCS 2021 chemical-perturbation characteristic-direction coefficient matrix.

The SigCom LINCS metadata and retrieval documentation identify the following release:

- URL: `https://lincs-dcic.s3.amazonaws.com/LINCS-sigs-2021/gctx/cd-coefficient/cp_coeff_mat.gctx`
- release date: `2021-06-10`
- version: `1`
- documented size: `35,565,630,496` bytes

The object currently served at that URL is different:

- Last-Modified: `Tue, 10 Oct 2023 18:32:10 GMT`
- Content-Length: `36,084,518,760` bytes
- multipart ETag: `23b8c0e7d2cdafc12c0f76c38904ab9b-4302`
- SHA-256 after local download: `5597abf71005158931beb9d89af0f37f2bc31a7e05fa869ca77df17d351b474d`

The public S3 `ListObjectVersions` operation is access-denied, and anonymous HEAD does not return an `x-amz-version-id`.

Internet Archive recorded the same URL on `2023-09-12 05:00:40 UTC`, before the current object's modification date. Its CDX payload digest is SHA-1 `aaf1c4ef1092b3058848bb203615598e84a99ec0`, but the corresponding WARC is private and raw replay is currently unavailable/rate-limited.

Could you please provide any one of the following for the originally documented 35,565,630,496-byte object?

1. an immutable download URL;
2. the prior S3 `versionId`;
3. an archived copy plus SHA-256/MD5 checksum; or
4. confirmation that the Internet Archive SHA-1 above identifies the intended version-1 matrix.

The purpose is reproducibility and version-sensitivity only. I will keep the 2023-revised object and the original 2021 object analytically separate.

Thank you.

## Alternate request: Archive-It collection owner / Internet Archive

Archive coordinates:

- collection: `5818` (`Institutional Archives`)
- organization: `Center for the History of Medicine`
- capture: `20230912050040`
- source payload SHA-1: `aaf1c4ef1092b3058848bb203615598e84a99ec0`
- archive item: `ARCHIVEIT-5818-2023091903-00003`
- WARC: `ARCHIVEIT-5818-TEST-JOB1861906-SEED1402487-20230912045055456-00021-h3.warc.gz`

### Subject

Access request for one publicly sourced payload in Archive-It collection 5818

### Body

Hello,

I am trying to reproduce a public computational biology dataset release. Archive-It captured the public source URL below on `2023-09-12 05:00:40 UTC`:

`https://lincs-dcic.s3.amazonaws.com/LINCS-sigs-2021/gctx/cd-coefficient/cp_coeff_mat.gctx`

The capture is indexed with source-payload SHA-1 `aaf1c4ef1092b3058848bb203615598e84a99ec0`. The raw replay is listed as available, but it does not currently return bytes, and the containing WARC is access-restricted.

Would it be possible to enable a functioning raw replay for this capture or provide the single archived response payload and its original HTTP headers? I do not need unrelated WARC contents.

This request is solely for reproducibility/version-sensitivity of the originally public dataset.

Thank you.

## Acceptance after receipt

Do not use a supplied file until all of the following pass:

1. exact size `35,565,630,496` bytes;
2. SHA-1 `aaf1c4ef1092b3058848bb203615598e84a99ec0`, unless the provider supplies a stronger authoritative checksum and explains any mismatch;
3. valid HDF5/GCTX structure;
4. a newly recorded local SHA-256;
5. scoring under a separately frozen version-sensitivity protocol, with no promotion to independent replication.
