# JNJ-7706621 candidate-specific computational audit protocol

Frozen: 2026-08-25, before inspecting JNJ-7706621 stratum-level reversal scores.

## Question and baseline

The carried-forward result is the explicitly post-hoc
`balanced_posthoc_nominal_candidate` label for JNJ-7706621. The baseline is the
complete targeted LINCS result: 297 conditions, median composite `0.017759`,
empirical `P=0.046953`, targeted `q=0.414585`, with all-four positivity,
multi-condition stability, positive independent direction and no compound-level
toxicity-dominance flag.

The audit asks:

1. Is the favorable direction broadly transportable across dose, time, tissue
   and especially the available skin conditions?
2. Is JNJ-7706621 descriptively or inferentially stronger than the other five
   provider-CDK2-token compounds under matched LINCS condition strata?
3. Is the signal plausibly a selective CDK2 effect, or is that interpretation
   undermined by known multi-kinase/cell-cycle pharmacology?

The dependent variables are the already frozen four reversal components,
composite, external composite, toxicity index and toxicity-removed composite.
No condition or score is changed.

## Experiment matrix

| Run | Single factor | Levels | Fixed configuration | Expected outcome before scoring |
|---|---|---|---|---|
| E0 | Baseline | all 297 JNJ conditions | frozen scores/seed | reproduce published aggregate |
| E1 | Dose | 0.12, 1.11, 10 µM | all cells/times retained | positive medians; higher-dose toxicity may increase |
| E2 | Time | 6, 24, 48 h | all cells/doses retained | 24 h strongest because it dominates coverage; short/long times uncertain |
| E3 | Tissue context | skin, non-skin, each of 23 tissues | all doses/times retained | skin direction uncertain because only 16 conditions |
| E4 | Deletion robustness | leave one dose/time/tissue out | no threshold changes | positive medians if no context drives the signal |
| E5 | CDK2-token comparator | BMS-265246, BMS-536924, Bosutinib, PF-573228, Roscovitine | match cell line × dose × time | JNJ expected to rank highest overall; matched inferential support uncertain |
| E6 | Pharmacology audit | primary/official sources | compound identity fixed | multi-CDK/Aurora activity expected; CDK2 specificity unlikely |

## Statistical plan

- Report every dose, time and tissue level; do not select favorable contexts.
- For every stratum report n conditions, n cell lines, four medians, composite,
  positive fraction, external composite, toxicity-dominated fraction and
  toxicity-removed composite.
- Use 5,000 cell-line cluster bootstraps, seed `20260825`, for median-composite
  95% intervals. These intervals describe condition heterogeneity and do not
  repair the post-hoc candidate selection.
- Dose-response audit: within each cell-line × time stratum, median-collapse
  replicates by dose and calculate a Spearman trend when at least two doses exist.
- Time audit is analogous within cell-line × dose.
- Comparator audit: median-collapse each compound within exact
  cell-line × dose × time strata, compare JNJ with each comparator on common
  strata using one-sided paired Wilcoxon tests, and BH-correct five tests.
- Retain unmatched conditions and report overlap counts; matched tests are not a
  replacement for full condition results.

## Fixed interpretation

- `broad_transportable`: dose and time medians all positive; skin and non-skin
  medians positive; minimum leave-one-dose/time/tissue median positive; and both
  overall and skin cluster-bootstrap lower bounds positive.
- `directionally_broad_uncertain`: all preceding median/deletion directions are
  positive, but at least one required bootstrap lower bound is non-positive.
- `context_limited`: any required median or deletion direction is non-positive.
- `class_leading_descriptive`: JNJ has the highest full-condition composite among
  six CDK2-token compounds and positive matched median differences versus at
  least four of five comparators.
- `class_leading_inferential`: additionally, at least three paired comparator
  tests have BH q<0.05.

None of these labels means clinical efficacy, skin safety, CDK2 target
specificity, or formal cross-resource replication.

## Resource estimate and execution

- Runs: 7 audit modules over already materialized tables.
- Compute: CPU only, expected under 2 minutes; GPU hours 0.
- External paid API cost: 0; literature verification uses public sources.
- Storage: expected under 20 MB of tabular outputs.
- Execution: `python3 scripts/49_audit_jnj7706621_candidate.py`, followed by
  `python3 scripts/50_validate_jnj7706621_candidate_audit.py`.

## Required outputs

- full context-stratum table;
- dose/time matched trends;
- deletion robustness;
- skin-condition table;
- matched CDK2-token comparison and BH results;
- pharmacology evidence matrix;
- candidate disposition and report;
- independent validator.
