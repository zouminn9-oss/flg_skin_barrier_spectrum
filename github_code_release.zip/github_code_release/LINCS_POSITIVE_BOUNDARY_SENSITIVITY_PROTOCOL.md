# Post-hoc positive-boundary sensitivity protocol

Frozen for execution: 2026-08-25, **after** the negative Sci-Plex and targeted
LINCS results were observed.

## Purpose and evidence status

This analysis answers a sensitivity question: what is the smallest explicit
rule relaxation that yields a favorable exploratory candidate, and how much
evidential strength is lost? It is intentionally post hoc. It cannot relabel the
original Sci-Plex tiers or the targeted LINCS cross-resource classification, and
it cannot alter the frozen negative Gate 3 result.

No condition is removed, no score is recomputed, and no target is added. The
inputs are the complete validated compound tables from the existing Sci-Plex and
LINCS analyses.

## Rules that remain fixed

For a resource-level robust candidate, all of the following remain required:

1. All four median reversal components and the composite are positive.
2. The original multi-condition stability rule passes.
3. Independent E-MTAB-9501 median direction is positive.
4. The compound is not toxicity dominated.

Only the statistical-evidence rule is varied. Component-count, stability,
external-direction and toxicity thresholds are not relaxed in the primary
boundary search.

## Complete statistical grid

Two explicitly different evidence modes are evaluated:

- Multiple-testing mode: the existing BH q value is compared with
  `0.05, 0.10, 0.20, 0.25, 0.50, 0.75, 1.00`.
- Nominal mode: the existing empirical P value is compared with
  `0.01, 0.025, 0.05, 0.10` without claiming FDR control.

Every resource × threshold cell and every compound is retained. Nominal-positive
is labeled `post_hoc_nominal_positive`, never replicated or FDR-supported.

## Cross-resource favorable rule

The least-relaxed balanced exploratory rule is defined before executing the
grid summary:

- both Sci-Plex and LINCS median composites are positive;
- both independent external median directions are positive;
- neither resource labels the compound toxicity dominated;
- at least one resource passes all four component and multi-condition stability
  gates and has empirical P<0.05.

The other resource is required to provide direction/external/toxicity support,
but is not required to be nominally significant or stable. A compound passing
this rule is labeled `balanced_posthoc_nominal_candidate`, not cross-resource
replicated.

## Selection principle

The recommended favorable candidate is chosen only among compounds passing the
balanced rule. If more than one passes, order by: (1) number of resource-level
robust nominal passes, (2) smaller best empirical P, (3) larger minimum of the
two resource composites, then alphabetical target key. All other one-resource
nominal positives remain visible.

## Required outputs

- full resource × threshold sensitivity grid;
- all compound-level resource gates and failure reasons;
- cross-resource balanced-rule table;
- selected favorable candidate and explicit relaxed rule;
- report contrasting original, nominal and highly relaxed q interpretations;
- independent validation script.
