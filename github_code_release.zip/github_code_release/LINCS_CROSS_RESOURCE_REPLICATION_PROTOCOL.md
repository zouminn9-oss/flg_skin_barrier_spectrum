# Targeted LINCS cross-resource replication protocol

Frozen: 2026-08-25, before downloading or inspecting any LINCS reversal score.

## Status and question

This is a post hoc, exploratory, computational cross-resource replication of
the completed Sci-Plex drug-signature analysis. It does not alter the frozen
negative Gate 3 result and cannot establish efficacy, safety, target specificity,
or causality. No wet-lab work is proposed or performed.

The question is whether the previously selected drug set shows the same APC and
locked-program reversal direction in an independently generated perturbation
resource without selecting favorable LINCS cell lines, doses, or times.

## Fixed LINCS release and access route

- Library: SigCom LINCS `l1000_cp`, library UUID
  `54198d6e-fe17-5ef8-91ac-02b425761653`.
- Release: LINCS L1000 Chemical Perturbations 2021, Level 5 characteristic-
  direction coefficients, version 1, library date 2021-06-10.
- Center: LINCS Center for Transcriptomics, Broad Institute.
- Metadata API: `https://maayanlab.cloud/sigcom-lincs/metadata-api`.
- Individual signed files: the `persistent_id` stored in each returned signature.
- Full 35.57-GB matrix is not downloaded; every matched condition-level file is
  fetched from its persistent URL, verified against the API SHA-256, parsed, and
  represented in a targeted matrix.

API query payloads, query time, library response, signature metadata, persistent
URLs, expected/observed hashes, and coverage failures are retained. The API does
not expose CLUE signature-strength metrics in these records; this missing quality
field is reported, not inferred.

### Pre-score integrity amendment

The first persistent-object fetch, performed before any reversal score was
computed, revealed that the API `sha256` and `md5` fields do not match the bytes
currently served at the API's own immutable-looking S3 `persistent_id`. A
one-file-per-target audit found this mismatch in all 10 covered compounds; two
of the 10 sampled records also had stale byte counts. In every sampled object,
however, the computed body MD5 exactly matched the S3 response ETag, the ETag
was a single-part 32-hex digest, the file retained the expected two-column
schema, and S3 reported a June 2021 last-modified date.

Consequently, the mechanically impossible API-SHA requirement is amended before
scoring as follows: retain and flag every API hash/size comparison, compute a new
SHA-256 over the retrieved body, and require the computed MD5 to equal the
single-part S3 ETag. Any ETag mismatch, multipart ETag, schema failure, gene-order
difference, or non-2021 object date stops the analysis. This amendment changes
only transport-integrity verification; it does not change coverage, conditions,
genes, scores, permutations, thresholds, or classifications.

One later pre-score fetch exposed a header-only schema variant: the two columns
were `Unnamed: 0` and `CD-coefficient`, with gene symbols present in the first
column, rather than `symbol` and `CD-coefficient`. The accepted schema is therefore
fixed to exactly two columns, a second column named `CD-coefficient`, and a first
column named either `symbol` or `Unnamed: 0`; the observed first-column label is
retained per file. No other column count or label is accepted.

## Target set locked before scoring

### Sci-Plex discovery/target audit set

The union of the six Sci-Plex Tier-C compounds and six provider-CDK2-token
compounds contains 11 unique compounds:

`BMS-265246, AC480, Andarine, Droxinostat, Iniparib, G007-LK, JNJ-7706621,
Bosutinib, Roscovitine, PF-573228, BMS-536924`.

They are matched primarily by the PubChem CIDs already present in the frozen
Sci-Plex metadata:

- AC480/BMS-599626: 10437018
- Andarine: 9824562
- BMS-265246: 135402864
- BMS-536924: 135440466
- Bosutinib: 5328940
- Droxinostat: 568416
- G007-LK: 67960134
- Iniparib: 9796068
- JNJ-7706621: 5330790
- PF-573228: 11612883
- Roscovitine: 160355

### Previously named lead agents

All previously named agents are retained even when absent. Stable PubChem IDs
and public development-code aliases are used only for coverage matching:

- IRF1: `I-2`, `I-19` (exact names only; ambiguous generic identifiers are not
  assigned a PubChem identity).
- HSF1: DTHIB/SISU-102; PubChem 108866909; aliases `DTHIB`, `SISU-102`.
- ATR: camonsertib, PubChem 156487652, aliases `RP-3500`, `RP3500`;
  ceralasertib, PubChem 54761306/121596701, aliases `AZD6738`, `AZD-6738`;
  elimusertib, PubChem 118869362/129893299, aliases `BAY-1895344`, `BAY1895344`.
- PCNA: AOH1996, PubChem 126718388.
- CDK2: INX-315, PubChem 162360412; AZD8421, PubChem 171364438.
- E2F4: HLM006474, PubChem 2895500, alias `HLM-006474`.

Matching is the union of exact PubChem CID and exact prespecified alias fields.
No synonym is added after scores are observed. Duplicate signature UUIDs are
collapsed once. A signature that matches more than one alias remains one
condition.

## Locked disease signatures and scores

The disease inputs, gene-statistic definitions, program weights, Reactome v97
toxicity sets, and four reversal scores are identical to
`DRUG_SIGNATURE_REVERSAL_PROTOCOL.md`:

1. APC genome rank reversal.
2. APC genome weighted reversal.
3. Locked-program rank reversal.
4. Locked-program weighted reversal.
5. Equal-weight four-score composite.

The primary LINCS universe is the intersection of the locked disease genes and
genes finite in every downloaded Level-5 file. It is selected by availability
only. All matched signatures are retained; no cell, dose, time, batch, tissue,
or disease metadata value is used to select a condition.

The same scores are separately applied to E-MTAB-9501. Five internal cohorts are
an explicitly non-independent direction audit.

## Permutations, stability, and toxicity

- Use seed `20260825` and 1,000 global gene-label permutations on the common
  complete gene universe.
- The compound empirical P value is obtained by taking, within each gene-label
  permutation, the median null composite over all conditions of that compound.
- BH correction is across **covered targeted compounds only**. It is labeled
  `targeted_BH_q` and is never compared with or substituted for the 188-compound
  Sci-Plex full-background q.
- Multi-condition stability is unchanged: at least two conditions, at least two
  cell lines, positive fraction >=2/3, positive minimum leave-one-condition
  median, and positive minimum leave-one-cell-line median.
- Toxicity axes and removal sensitivity use the same Reactome patterns and the
  same compound-dominance rule as the Sci-Plex protocol.

## Fixed cross-resource classifications

For a compound with a prior Sci-Plex result:

- **replicated**: all four LINCS medians and the composite are positive;
  targeted BH q<0.05; multi-condition stable; independent E-MTAB-9501 median
  direction positive; not toxicity dominated; and LINCS/Sci-Plex composites have
  the same positive direction.
- **direction_only**: LINCS and Sci-Plex composite medians are both positive but
  one or more replication requirements fail.
- **discordant**: LINCS composite is non-positive while the Sci-Plex composite
  was positive, or vice versa.
- **negative_both**: both resource composite medians are non-positive.
- **not_covered**: no LINCS signature matched the locked identifiers.

For a previously named lead agent without a Sci-Plex signature, a passing LINCS
screen is labeled `LINCS_support_only`, never replicated. Absent agents remain
`not_covered`.

The complete condition and compound grids, including negative and unmatched
rows, are required outputs.

## Planned outputs

- `scripts/44_prepare_lincs_targeted_signatures.py`
- `scripts/45_score_lincs_cross_resource_replication.py`
- `scripts/46_validate_lincs_cross_resource_replication.py`
- condition-level LINCS reversal table
- covered-compound aggregation
- all-target coverage/classification table
- Sci-Plex-versus-LINCS comparison
- independent and internal direction audits
- toxicity/cell-cycle sensitivity
- provenance, API-query, checksum, and QC tables
- full report retaining positive, negative, discordant, and absent results
