# CMap2020 MODZ full-background sensitivity protocol

Frozen: 2026-08-26 (America/Los_Angeles), before downloading the full MODZ
matrix or inspecting any MODZ reversal score.

## Status and question

This is a post hoc, exploratory, computational **processing-method sensitivity
analysis** of JNJ-7706621. It asks whether the favorable direction and
full-background position observed with SigCom LINCS characteristic-direction
(CD) coefficients are retained in Broad CMap2020 Level-5 MODZ signatures.

MODZ and CD signatures are derived from overlapping LINCS perturbation
experiments. This analysis is not an independent biological replication, does
not alter the negative Gate 3 result, and cannot establish clinical efficacy,
safety, or CDK2 specificity.

## Immutable source freeze

Primary matrix:

- object: `level5_beta_trt_cp_n720216x12328.gctx`;
- semantic content: Broad CMap2020 Level-5 compound-treatment MODZ signatures;
- URL: `https://s3.amazonaws.com/macchiato.clue.io/builds/LINCS2020/level5/level5_beta_trt_cp_n720216x12328.gctx`;
- frozen S3 version ID: `ljLz1nWDJ4co.kG6bSrfEs7mrklxiVS4`;
- version-pinned URL: the URL above plus
  `?versionId=ljLz1nWDJ4co.kG6bSrfEs7mrklxiVS4`;
- expected bytes: 35,518,405,386;
- Last-Modified: `2020-12-16 23:54:09 GMT`;
- multipart ETag: `d342ab7f3fa6ece699099bc2d8fc94b8-2118`.

Row metadata:

- object: `geneinfo_beta.txt`;
- URL: `https://s3.amazonaws.com/macchiato.clue.io/builds/LINCS2020/geneinfo_beta.txt`;
- frozen S3 version ID: `zMQVoz8KI8QHbXRa2UHS.ta3VQhg3lgq`;
- expected bytes: 1,141,389;
- Last-Modified: `2020-12-16 19:38:56 GMT`;
- single-part ETag: `45c725d17ce6c377f1e7de07b821a5f0`.

Column and compound metadata are the already checksum-pinned official Broad
`siginfo_beta.txt` and `compoundinfo_beta.txt` recorded in
`LINCS_FULL_BACKGROUND_CALIBRATION_PROTOCOL.md`. The signature metadata has
1,201,944 unique rows, including 720,216 `trt_cp` records and all 297 frozen
JNJ-7706621 conditions.

The full matrix must match the frozen byte count and S3 version ID, receive a
local SHA-256, open as HDF5/GCTX, contain exactly 720,216 unique columns and
12,328 unique rows, and crosswalk exactly to the `trt_cp` `sig_id` records.
Every locked gene and coefficient used for scoring must be finite. Any failure
stops scoring.

### Post-start source-QC amendment: all-zero signatures

The streaming scorer stopped before aggregation when it first encountered a
condition with zero within-condition gene variance. A subsequent matrix-wide
QC scan, performed without inspecting any compound ranks or JNJ aggregate,
found exactly 62 of 720,216 signatures whose 12,327 canonical coefficients are
all exactly zero. They are confined to JURKAT or THP1 at 24 h and five
compounds (AT-7519, MG-132, bortezomib, carfilzomib, and dinaciclib). None is a
JNJ-7706621 condition and none overlaps the 2,787 frozen targeted CD/MODZ
comparison conditions.

These 62 rows are retained in the condition-level audit with
`condition_scorable=false` and missing reversal/toxicity scores, but are
excluded from compound medians and stability summaries because correlation and
z-score quantities are undefined for a constant vector. The remaining 720,154
conditions are scored normally. An explicit unscorable-condition table is
required. This source-QC treatment does not change any score formula, threshold,
top-5% boundary, candidate selection, or disposition rule.

### Pre-score gene-symbol amendment

Inspection of the frozen 12,328-row `geneinfo_beta.txt`, before matrix scoring,
showed 12,327 unique symbols because `MIA2` occurs twice: Entrez 4253 is marked
`best inferred` and Entrez 117153 is marked `inferred`. The canonical scoring
crosswalk retains Entrez 4253 and excludes Entrez 117153, yielding the same
12,327-unique-symbol universe as the CD coefficient resource. This rule was
fixed before any MODZ score was inspected. A sensitivity including the legacy
duplicate may be reported, but it cannot replace the canonical result.

## Frozen disease scores and filters

The disease table, program membership, signs, weights, 95th-percentile caps,
external E-MTAB-9501 audit, five internal-cohort audits, toxicity gene sets,
seed `20260825`, and formulas are unchanged from
`LINCS_FULL_BACKGROUND_CALIBRATION_PROTOCOL.md`:

1. APC genome rank reversal.
2. APC genome weighted reversal.
3. Locked-program rank reversal.
4. Locked-program weighted reversal.
5. Equal-weight mean of the four scores.

All 720,216 compound-treatment conditions are scored. No cell line, dose,
time, batch, compound identity, prior status, or observed score is used to
select conditions. Condition-level results are retained before exact
provider-`cmap_name` aggregation.

## CD/MODZ reconciliation

All 297 JNJ conditions and all other exact `sig_id` overlaps with the previous
CD analysis are retained for method comparison. Report per-score Spearman
correlation, sign agreement, median difference, and compound-level direction.
No minimum CD/MODZ correlation is imposed because the methods estimate
different signature quantities. The comparison is diagnostic and complete.

## Full-background aggregation and frozen disposition

Aggregation, leave-one-condition/cell-line stability, external direction,
toxicity/removal summaries, all-compound rank, stable-eligible rank, and
competitive upper-tail fractions are identical to the CD full-background
protocol.

JNJ-7706621 is labeled `modz_full_background_method_robust` only if:

- all four MODZ compound-median scores and the composite are positive;
- it is in the top 5% of both the all-compound and stable-eligible backgrounds;
- unchanged multi-condition stability and external-positive direction pass;
- the MODZ result is not toxicity dominated.

If all non-rank gates pass but either rank is outside the top 5%, label
`modz_positive_not_top5`. If a non-rank gate fails, label
`modz_full_background_not_supported`.

These labels are post hoc processing-method sensitivity labels, not formal
replication, P values, FDR, or treatment evidence. The targeted LINCS q=0.4146,
CD label `positive_not_top5`, GSE201278 label
`independent_skin_line_not_supported`, and Gate 3 remain unchanged.

## Required outputs

- source headers, S3 version IDs, local SHA-256 and HDF5/schema QC;
- condition-level score parts for every MODZ condition;
- complete compound aggregation and both ranked backgrounds;
- complete CD/MODZ overlap reconciliation;
- JNJ disposition JSON;
- validation summary and durable report;
- updated `HANDOVER.md` and `PROJECT_STATUS.md`.
