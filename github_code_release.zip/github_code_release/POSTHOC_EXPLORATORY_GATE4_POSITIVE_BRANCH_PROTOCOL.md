# Post-hoc exploratory Gate 4 positive-branch protocol

Frozen: 2026-08-26 (America/Los_Angeles), before packaging the user-directed
Gate 4 disposition.

## Status and entry signal

The user explicitly requested Gate 4 under the previously obtained positive
computational results. This execution is therefore an isolated, post-hoc,
exploratory positive-branch Gate 4. It does not overwrite the frozen Gate 3
decision, which remains negative with 0/3 axes passing.

The entry signals are fixed as:

- the complete 396-branch selected-positive transcriptomic SNF screen, whose
  selected branch is `all_positive+stress_damage`, K=2, alpha=0.2, 10 fusion
  iterations; and
- the JNJ-7706621 LINCS characteristic-direction full-background label
  `positive_not_top5`.

JNJ is carried as a downstream computational candidate annotation only. It is
not a disease-network layer and cannot determine the Gate 4 network result.

## Frozen Gate 4 checks

The selected AD–ACD transcriptomic branch passes the exploratory Gate 4
transcriptomic sub-gate only if all are true:

1. all 396 enumerated branches are retained;
2. the selected AD–ACD edge has selection-adjusted permutation P<0.05;
3. nominal 10,000-permutation BH q<0.05;
4. AD and ACD are in the same observed cluster;
5. 1,000-bootstrap AD–ACD coclustering is at least 0.75; and
6. both AD and ACD node cluster-support values are at least 0.75.

No threshold is relaxed after inspecting the result.

## Evidence-layer coverage audit

The four layers from the frozen analysis plan are audited separately:

1. transcriptomic/pathway effects;
2. GWAS/QTL/colocalization;
3. direct genetic/family/functional evidence; and
4. network plus cell/spatial localization.

A layer is eligible for full network fusion only when it provides comparable
features across the seven discovery disease nodes. Missing layers are not
filled with zero, copied across diseases, or replaced with the JNJ drug score.

The full multilayer Gate 4 is called evaluable only if at least two distinct
eligible evidence layers can be fused across all seven discovery nodes.
Otherwise the output is explicitly limited to a transcriptomic sub-gate.

## Disposition labels

- `exploratory_gate4_multilayer_positive`: the transcriptomic checks pass and
  at least two eligible layers support a complete multilayer fusion.
- `exploratory_gate4_transcriptomic_positive_multilayer_incomplete`: all
  transcriptomic checks pass, but a complete multilayer fusion is not
  identifiable from the available comparable layers.
- `exploratory_gate4_not_supported`: any frozen transcriptomic check fails.

These labels are not confirmatory Gate 4, independent replication, clinical
evidence, treatment recommendations, or a change to Gate 3.

## Required outputs

- layer-coverage audit;
- frozen entry-signal audit;
- machine-readable Gate 4 disposition;
- validation summary;
- durable report;
- updated handover and project status.
