# Full-background LINCS calibration protocol

Frozen: 2026-08-25 (America/Los_Angeles), before downloading the complete matrix or inspecting any full-library reversal score.

## Status and question

This is a post hoc, exploratory, computational calibration of the carried-forward
`balanced_posthoc_nominal_candidate`, JNJ-7706621. It asks where the candidate
falls in the complete LINCS chemical-perturbation background when the already
frozen disease signatures and four reversal scores are applied without changing
their signs, weights, program membership, toxicity sets, or context rules.

The analysis does not alter the negative Gate 3 result, convert the targeted
LINCS q value into a library-wide FDR, establish efficacy or safety, establish
CDK2 specificity, or initiate wet-lab work.

## Source freeze and pre-score deviation

- Semantic library: SigCom LINCS `l1000_cp`, library UUID
  `54198d6e-fe17-5ef8-91ac-02b425761653`.
- Named release: LINCS L1000 Chemical Perturbations 2021, Level 5
  characteristic-direction coefficients, version 1, library date 2021-06-10.
- Full-matrix URL:
  `https://lincs-dcic.s3.amazonaws.com/LINCS-sigs-2021/gctx/cd-coefficient/cp_coeff_mat.gctx`.
- Previously documented object size: 35,565,630,496 bytes.
- Object observed at freeze: 36,084,518,760 bytes; Last-Modified
  `2023-10-10 18:32:10 GMT`; multipart ETag
  `23b8c0e7d2cdafc12c0f76c38904ab9b-4302`; AES256; byte ranges supported.

The currently served object is 518,888,264 bytes (1.459%) larger than the
previously documented object and has a 2023 modification date. It is therefore
treated as a revised object under the 2021 library path, not as byte-identical
proof of the originally documented 2021 snapshot. This is a material provenance
limitation, recorded before scoring.

### Pre-score metadata amendments

Before the matrix download completed and before any full-library score was
inspected, a current SigCom ranker metadata object was located at
`https://s3.dev.maayanlab.cloud/sigcom-lincs/ranker/signatures_meta.json`
(redirecting to the Ma'ayan Lab object store). The object observed at freeze is
96,978,667 bytes, Last-Modified `2026-06-30 14:08:34 GMT`, ETag
`12ec763ccc466ed3f3f94b0797e622f4`, and local SHA-256
`a1179dc7a9e730869d020fee576b0b20d75d7e92ead4f8fdfd5fed0d800f921b`.
It contains 718,055 UUID-keyed records with `cell_line`, `pert_dose`,
`pert_name`, and `pert_time`; all 2,787 frozen targeted UUIDs are present and
JNJ-7706621 has the expected 297 records. It lacks tissue and PubChem fields.

Pre-score HDF5 inspection showed that the matrix has 718,157 columns keyed by
Broad CMap `sig_id`, not the 718,055 UUID keys in this current ranker object.
The 102-record difference is exactly the number of matrix conditions lacking a
reported dose in the Broad metadata. The ranker object is therefore retained
only as a secondary current-system consistency reference; it is not used as the
GCTX primary key source. The frozen targeted metadata remains authoritative for
prior tissue and PubChem annotations.

The authoritative column crosswalk is the official Broad CMap 2020
`siginfo_beta.txt` at
`https://s3.amazonaws.com/macchiato.clue.io/builds/LINCS2020/siginfo_beta.txt`:

- observed bytes: 465,242,319;
- Last-Modified: `2021-12-07 13:24:26 GMT`;
- multipart ETag: `f1f854d7675f5dfd0a3ae3664640f70e-28`;
- S3 version ID: `IdjZYad8vgq4Fste7egTLfio9nCf9bkI`;
- local SHA-256:
  `1a38d7ea2a804be79804af4a27aff9f2537af8f13d3c8af1fdc1fef780f40201`.

It contains 1,201,944 unique `sig_id` rows and covers all 718,157 GCTX
columns exactly once. The GCTX subset contains 33,609 unique `cmap_name`
values, zero missing cell names, zero missing compound names, zero missing
times, and 102 missing doses. All 2,787 frozen targeted `cmap_id` values match
the GCTX `sig_id` exactly, with identical compound names, including all 297
JNJ-7706621 conditions.

The companion official Broad `compoundinfo_beta.txt` is retained for
perturbagen-identity provenance (4,631,014 bytes; Last-Modified
`2021-01-28 22:46:50 GMT`; ETag `bf8e3a15ad026b47903c98d625195d24`;
SHA-256 `a71fca6de41dcc46a5063858be7e04155f3c09832c8b3fb35814f03db8d9fdff`).
The per-signature `cmap_name` from `siginfo_beta.txt` is the frozen aggregation
key; no post-score synonym or mechanism merging is allowed.

Download is resumable. After completion, the exact byte count and a computed
SHA-256 are required. The multipart ETag is retained as an object identifier but
is not interpreted as a whole-file MD5. A size mismatch, incomplete HDF5 file,
missing coefficient matrix, missing row/column identifiers, duplicate column
identifier, or non-finite locked-gene coefficient stops scoring.

## Frozen disease inputs and scores

The following remain identical to `DRUG_SIGNATURE_REVERSAL_PROTOCOL.md` and
`LINCS_CROSS_RESOURCE_REPLICATION_PROTOCOL.md`:

1. APC genome rank reversal.
2. APC genome weighted reversal.
3. Locked-program rank reversal.
4. Locked-program weighted reversal.
5. Equal-weight mean of the four scores.

The locked disease table is
`results/exploratory_snf/selected_positive_reml_z_q05/optimized_AD_ACD_branch/mechanism/drug_signature_reversal/locked_disease_signatures.tsv`.
Weights, 95th-percentile caps, external E-MTAB-9501 direction audit, five
non-independent internal-cohort audits, Reactome toxicity axes, toxicity-gene
removal, seed `20260825`, and all signs are unchanged.

All available chemical-perturbation columns are scored. No cell line, tissue,
dose, time, batch, target annotation, prior candidate status, or observed score
is used to select conditions.

## Source reconciliation before ranking

The full matrix is a later-served object than the targeted individual files.
Before full-library conclusions are accepted, every overlapping targeted
signature identifier that can be matched must be compared between the new
matrix-derived scores and the frozen targeted condition table. The reconciliation
reports overlap count, maximum absolute difference for every score, rank
correlation, sign agreement, and missing/duplicate identifiers.

- `compatible`: all four primary scores agree within absolute tolerance
  `1e-6`, with identical composite signs.
- `near_compatible`: all four score correlations are at least 0.999 and composite
  sign agreement is at least 99.9%, but exact tolerance fails.
- `version_divergent`: either near-compatible criterion fails.

Only `compatible` permits direct numerical pooling with the targeted results.
`near_compatible` or `version_divergent` retains the full-background rank as a
separate revised-object sensitivity analysis.

## Full-background aggregation and calibration

Condition-level results are retained before aggregation. Compound identity is
the provider `cmap_name` keyed by exact GCTX `sig_id` in Broad
`siginfo_beta.txt`;
no post-score synonym merging is allowed. Replicate conditions are not selected
or collapsed before scoring.

For every compound, report:

- medians of all four primary scores and their composite;
- condition, cell-line, dose, and time counts;
- positive-condition fraction;
- minimum leave-one-condition and leave-one-cell-line medians;
- the unchanged multi-condition stability flag;
- external direction and toxicity/removal summaries.

Two background ranks are required:

1. `all_compound_rank`: every identifiable compound, including singletons.
2. `stable_eligible_rank`: compounds with at least two conditions and at least
   two cell lines, evaluated with the unchanged stability rule.

The primary full-background calibration is the empirical competitive upper-tail
fraction of the observed compound median composite:

`(1 + number of background compounds with composite >= candidate composite) /
 (1 + number of background compounds)`.

This quantity is labeled `competitive_upper_tail_fraction` and percentile/rank,
not a null-hypothesis P value and not an FDR. The earlier JNJ-7706621 targeted
gene-label empirical P=0.046953 and targeted BH q=0.414585 remain frozen and
separately labeled. No BH correction is applied to competitive rank fractions.

The 1,000-permutation gene-label null is not expanded to every full-library
condition because that would change the analysis into an infeasible approximate
null. Candidate-specific permutation results may be recomputed only as a
revised-object sensitivity check and cannot become a library-wide q value.

## Frozen candidate disposition

JNJ-7706621 is labeled `full_background_competitive` only if all of the following
hold in the full-matrix result:

- all four compound-median primary scores and the composite are positive;
- the candidate is in the top 5% of the all-compound background and in the top
  5% of the stable-eligible background;
- the unchanged multi-condition stability, external-positive direction, and
  non-toxicity-dominated gates pass;
- the targeted-to-full source reconciliation is `compatible` or
  `near_compatible`.

If direction and robustness pass but either rank is outside the top 5%, use
`positive_not_top5`. If any non-rank gate fails, use
`full_background_not_supported`. These labels are descriptive post-hoc
calibration labels, never formal replication or clinical evidence.

## Required outputs

- exact source headers, local SHA-256, HDF5 schema and QC summary;
- an executed source/data-quality notebook;
- condition-level score dataset in a streamable format;
- complete compound aggregation and ranked background;
- targeted/full-object reconciliation table;
- JNJ-7706621 full-background disposition JSON;
- figures and bounded report snapshot;
- validation script and validation summary;
- a durable technical report retaining negative and positive findings;
- updated `HANDOVER.md` and `PROJECT_STATUS.md`.
