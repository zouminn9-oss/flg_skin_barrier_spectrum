# AD–ACD 药物扰动签名反转报告

日期：2026-08-25  
状态：**事后、探索性、纯计算分析**

## 结论先行

在 188 个 Sci-Plex 药物、2,302 个细胞系×剂量×时间条件的完整背景中，**没有任何药物达到 Tier A 或 Tier B**。仅 6 个药物达到 Tier C，182 个被拒绝；全部药物中最小的全背景 BH q 为 0.3756，因此没有 FDR 支持的可重复反转候选。

排名最高的 BMS-265246 的 APC 综合反转中位数为 0.03070、化合物标签置换 p=0.00699，但 BH q=0.3756，且多条件稳定性失败。唯一同时满足“原始五分量筛选、名义 p<0.05、多条件稳定、外部方向一致、非毒性主导”的药物是 Andarine，但其 BH q=0.5259，仍只能保留为 Tier C 探索性信号。

因此，本分析支持的硬结论是：**在这个有限的公共扰动资源中，没有获得可升级为 Tier A/B 的计算药物反转证据。** 这些结果只用于假设生成，不是临床疗效或安全性证据，也不构成治疗建议。

## 与冻结结论的关系

- Gate 3 在冻结方案下仍为阴性：Axis A、B、C 均失败；Gate 4 未运行。
- 本分析不改变、不“挽救”该冻结结论。
- 五个 TF 在独立 bulk 验证中仍为 **0/5 在 BH q<0.05 确认**。
- 内部五队列参与了上游发现，只做方向审计，不是独立验证。
- 虚拟敲除是网络归因，不是因果生物学敲除；E2F4 的放宽阈值阳性仍是阈值依赖、事后结果。

## 数据源与资源 QC

### 最终使用资源

使用 Perturb-Seqr 分发的 Sci-Plex 全 characteristic-direction 系数快照：

- 18,124 个源基因；
- 2,302 个唯一条件；
- 188 个药物；
- A549、K562、MCF7 三个肿瘤细胞系；
- 10 nM、100 nM、1 µM、10 µM 四个剂量；
- 24 h 与 72 h 两个时间点；
- 2,302/2,302 条件标签均可无修复解析。

原始实验为 Srivatsan 等的 Sci-Plex（Science 2020，PMID 31806696，DOI 10.1126/science.aax6234）。下载 URL、访问日期、HTTP ETag/Last-Modified、许可和 SHA-256 见 `data/raw/perturbations/sciplex_perturbseqr/PROVENANCE.md` 与 `DOWNLOAD_MANIFEST.tsv`。

### 被排除资源

最初下载的 Perturb-Seqr CMap Build 02 limma-log2FC 文件在结构检查后被排除：其 3,478 列仅为 `drug__cell__trt_cp` 聚合，剂量、时间和批次已丢失，无法执行预定的逐条件稳健性分析。排除发生在任何药物反转得分计算之前；文件、校验和及排除理由均被保留，没有静默切换数据源。

### 基因覆盖与缺失处理

- APC 输入：4,621 个基因；Sci-Plex 可匹配 4,267 个。
- 锁定程序：APC 中原有 232 个可测程序基因；Sci-Plex 可匹配 219 个。
- Tier-1 核心基因：可匹配 14/16。
- 为使所有条件使用相同基因宇宙并精确执行全局基因标签置换，主分析采用所有 2,302 条件均有限的共同完整集：3,692 个 APC 基因、213 个程序基因。
- 使用全部条件特异可用基因的逐条件敏感性综合分数与共同完整集分数相关系数为 0.9983；2,302 条件中 44 个（1.91%）发生符号改变。完整比较仍在条件级表中保留。

## 锁定评分与统计

每个条件计算四个正值代表反转的分数：APC 全基因秩反转、APC 全基因加权反转、锁定程序秩反转、锁定程序加权反转；综合分数为四者等权平均。程序权重只使用既有 `pathway_support_influence`，未重新挑选基因或通路。

每个条件使用 1,000 次基因标签置换；每个药物按所有条件的中位数聚合，再使用 1,000 次保持组大小的化合物标签置换。BH 校正在全部 188 个药物上完成。逐条件表先于聚合表保存。

多条件稳定性要求：至少两个条件、至少两个细胞系、正向条件比例至少 2/3、留一条件最差中位数为正、留一细胞系最差中位数为正。

## 主筛选结果

| 筛选节点 | 药物数 |
|---|---:|
| 全部背景 | 188 |
| APC 综合反转中位数 >0 | 70 |
| 五个主筛选量均 >0 | 14 |
| 化合物标签置换名义 p<0.05 | 11 |
| 多条件稳定（不考虑其他规则） | 13 |
| BH q<0.05 | **0** |
| Tier A | **0** |
| Tier B | **0** |
| Tier C | 6 |
| Reject | 182 |

### 全部 Tier C 信号

| 药物 | APC 综合反转 | 置换 p | BH q | 多条件稳定 | 外部方向 | 内部正向队列/5 |
|---|---:|---:|---:|---|---|---:|
| BMS-265246 | 0.03070 | 0.00699 | 0.3756 | 否 | 同向 | 3 |
| AC480 | 0.02898 | 0.00500 | 0.3756 | 否 | 反向 | 5 |
| Andarine | 0.02446 | 0.01399 | 0.5259 | 是 | 同向 | 0 |
| Droxinostat | 0.02073 | 0.03097 | 0.6469 | 否 | 反向 | 3 |
| Iniparib | 0.01970 | 0.04096 | 0.7700 | 否 | 同向 | 2 |
| G007-LK | 0.01833 | 0.02298 | 0.6171 | 否 | 同向 | 0 |

六个信号均未通过 FDR。AC480 与 Droxinostat 的外部方向相反；BMS-265246、AC480、Droxinostat、Iniparib、G007-LK 还未通过预定的多条件稳定性。内部队列一致性与外部结果可明显冲突，例如 AC480 为内部 5/5 正向但外部反向，说明内部审计不能替代独立验证。

## 独立 E-MTAB-9501 验证

在独立 ACD-minus-ICD 对照中，188 个药物中 88 个综合中位数方向为正，15 个达到名义置换 p<0.05，但 **0 个达到 BH q<0.05**；最小外部 BH q=0.1878。Tier C 的 6 个药物中 4 个外部方向为正，但没有任何一个在外部全背景校正后显著。

这一区分很重要：外部“方向支持”只是符号一致，不能写成独立确认。

## 候选靶点药物与全背景比较

既有排名中的所有具名 lead agent——I-2、I-19、DTHIB/SISU-102、camonsertib、ceralasertib、elimusertib、AOH1996、INX-315、AZD8421、HLM006474——在这 188 个药物的 Sci-Plex 屏幕中均未被直接测试。因此不能由本资源判定这些具名药物失败。

分发元数据仅为 CDK2 提供了精确 target-token 匹配，共 6 个药物：

- BMS-265246：Tier C，排名 1，BH q=0.3756，多条件稳定性失败；
- JNJ-7706621、Bosutinib、Roscovitine、PF-573228、BMS-536924：均 Reject。

这 6 个 CDK2 标注药物的综合反转中位数为 0.00814，其他 182 个药物为 −0.00445，单侧 Mann–Whitney p=0.0107。该比较是探索性候选组审计，且这些药物常为多靶点激酶抑制剂；它没有全筛 FDR 支持，不能解释为 CDK2 特异性药理证据。其余 IRF1、HSF1、ATR、PCNA、E2F4、YY1、E2F6 均无具名或精确靶点标注匹配。

## 毒性与细胞周期敏感性

Reactome v97 预先定义了三类代理轴：细胞死亡上调、翻译/核糖体关闭、细胞周期/DNA 复制抑制。再移除三类基因联合集，重算全部四个反转分数。

- 102/188 药物按预定规则被判为毒性/细胞周期主导，86/188 未被判定主导。
- 六个 Tier C 均未被判为毒性主导。
- PFI-1、JQ1 等虽有名义 APC 反转，但去除代理基因后明显衰减，按规则保留为 Reject。

这里的“毒性主导”是表达签名代理，不是实测活率、安全性或毒理学结论。由于锁定程序本身富集 DNA 复制/细胞周期基因，去除分析是有意保守的，也可能同时移除真实机制成分。

## 解释边界与局限

1. Sci-Plex 只有三种肿瘤细胞系，没有 APC、原代免疫细胞或皮肤相关细胞；可迁移性有限。
2. 资源只有两个时间点且绝大多数条件为 24 h；时间稳健性信息有限。
3. 使用的是 Perturb-Seqr 派生 characteristic-direction 系数，不是重新处理的原始单细胞计数。
4. 许多现代具名候选药物不在 188 药物屏幕内；“未覆盖”不等于“负向药理证据”。
5. 多条件一致、外部方向和表达毒性代理都只是计算过滤，不提供临床疗效、安全性或因果证据。
6. 本分析为事后探索，所有阈值、负结果和完整比较网格均保留；没有把宽松结果重新标为确认性结果。

## 可复现命令

```bash
cd <repository-root>
PYTHONPATH=environment/python_packages python3 scripts/41_prepare_drug_signatures.py
PYTHONPATH=environment/python_packages OPENBLAS_NUM_THREADS=4 python3 scripts/42_score_drug_signature_reversal.py
PYTHONPATH=environment/python_packages python3 scripts/43_validate_drug_signature_reversal.py
```

## 主要输出

结果目录：`results/exploratory_snf/selected_positive_reml_z_q05/optimized_AD_ACD_branch/mechanism/drug_signature_reversal/`

- `condition_level_reversal.tsv`：2,302 条完整逐条件结果；
- `compound_level_ranking.tsv`：188 个药物的完整聚合排名与证据层级；
- `candidate_vs_background.tsv` 与 `candidate_matched_compounds.tsv`：候选和全背景比较；
- `independent_validation.tsv`：独立 E-MTAB-9501 反转；
- `internal_five_cohort_direction_audit.tsv`：非独立内部方向审计；
- `toxicity_cell_cycle_sensitivity.tsv`：毒性代理与去除敏感性；
- `locked_disease_signatures.tsv`、`condition_metadata.tsv`、`resource_qc_summary.tsv`：锁定输入与资源 QC；
- `RUN_PARAMETERS.json`：种子、置换数、覆盖和运行参数。
