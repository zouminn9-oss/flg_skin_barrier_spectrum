# Frozen GWAS harmonization protocol

Freeze date: 2026-08-25  
Applies before any association, colocalization, or genetic-layer score is calculated.

1. `GCST90503109` (European ancestry, GRCh38) is primary for LD-aware and skin/eQTL integration. `GCST90503108` is a non-independent multi-ancestry sensitivity analysis.
2. Ancestry-specific datasets use ancestry-matched LD references. Cross-ancestry effects may be compared but are not forced through a single European LD matrix.
3. No two accessions from the same publication are counted as independent evidence.
4. The older `GCST003184`/EAGLE endpoint is replication/sensitivity only because cohort overlap with the newer study is unresolved.
5. Liftover, when required, must preserve the original coordinate and record chain version, mapping status, and multi-mapping failures. Primary data are retained on their native build.
6. Match variants by normalized chromosome, position, REF, ALT and effect allele; never by rsID alone.
7. Flip effect signs only after an exact allele swap. Strand complements require allele-frequency corroboration. Unresolved A/T and C/G variants are removed.
8. Multi-allelic variants and indels require left normalization against the named reference genome. Unresolved representations are excluded.
9. Record beta/log-odds scale, standard error, p value, sample size, imputation quality, effect allele frequency, and source accession. Odds ratios are converted to log odds with documented direction.
10. Palindromic, duplicate, impossible-frequency, nonpositive-SE, or inconsistent-coordinate records are written to an exclusion table; they are never silently dropped.

