# AD–ACD targeted LINCS cross-resource replication

Date: 2026-08-25  
Status: post hoc exploratory computational analysis; data only

## Answer first

**No compound met the frozen LINCS cross-resource replication rule.** Across
2,787 condition-level LINCS signatures for 10 covered compounds, the targeted
screen produced `replicated = 0`. The lowest nominal compound P value was
JNJ-7706621 (`P = 0.04695`), but its targeted BH q value was `0.4146`. This is a
targeted 10-compound q value, not a full-background LINCS FDR and not a reason to
override the earlier 188-compound Sci-Plex result.

Six compounds had a positive median composite in both resources and are labeled
`direction_only`; two were discordant, two were negative in both, and G007-LK was
not covered. All 10 previously named lead agents were absent from the fixed 2021
LINCS chemical-perturbation library. Absence means no resource coverage, not
pharmacologic failure.

This result does not alter the frozen negative Gate 3 conclusion. It is not
clinical evidence and does not support efficacy, safety, dosing, or treatment
recommendations.

## Fixed resource and coverage

The analysis used SigCom LINCS library `l1000_cp`, UUID
`54198d6e-fe17-5ef8-91ac-02b425761653`: LINCS L1000 Chemical Perturbations
(2021), Level 5 characteristic-direction coefficients, version 1, dated
2021-06-10. The official retrieval documentation identifies this library, its
35.57-GB full matrix, its Level-5 status, and the metadata/persistent-file query
route ([official retrieval documentation](https://maayanlab.github.io/dex-benchmark/L1000_data/Retrieving_L1000_Data.html)).
SigCom LINCS is described as a searchable resource for more than a million gene
expression signatures in its primary publication
([Evangelista et al., 2022](https://academic.oup.com/nar/article/50/W1/W697/6582159)).

The fixed union contained 21 named entities:

- 11 Sci-Plex audit compounds: 10 covered, G007-LK not covered.
- 10 prior named lead agents: 0 covered, after exact prespecified PubChem-ID and
  alias queries.
- Covered signatures: 2,787 unique UUIDs, all retained.
- Matrix: 12,327 genes × 2,787 conditions.
- Primary APC overlap: 3,735 common-complete genes.
- Locked program overlap: 214 genes.
- Independent E-MTAB-9501 overlap: 11,889 genes; 212 program genes.

Cell line, tissue, disease annotation, dose, time, data level, persistent URL and
creation metadata were retained for every condition. The API did not expose a
CLUE signature-strength field; it was marked unavailable and was not imputed.

## Pre-score integrity deviation

Before any reversal score was computed, the first S3 object failed the planned
API-SHA comparison. A one-file-per-covered-target audit showed that the API
`sha256` and `md5` values were stale for all 10 sampled compounds; two sampled
API byte counts were also stale. The protocol was amended at that point, before
scoring and without changing target selection or statistics.

For all 2,787 retrieved objects:

- API SHA-256 matches: 0/2,787; retained as explicit failures.
- API MD5 matches: 0/2,787; retained as explicit failures.
- API byte-count matches: 1,790/2,787.
- Computed body MD5 equals single-part S3 ETag: 2,787/2,787.
- First-column schema: `symbol` in 2,781 files and the header-only variant
  `Unnamed: 0` in 6 files; every second column was `CD-coefficient`.
- Every object had a 2021 S3 last-modified date, an identical 12,327-gene order,
  and finite coefficients.

For the object type observed here, AWS documents when an S3 ETag can equal the
object-data MD5 and distinguishes that case from multipart ETags
([AWS object-integrity documentation](https://docs.aws.amazon.com/AmazonS3/latest/userguide/checking-object-integrity-upload.html)).
Every observed ETag was a single 32-hex digest with no multipart suffix. The
computed SHA-256, S3 ETag, body MD5, API comparisons, schema variant and URL are
retained per file. This transport-integrity amendment does not repair or conceal
the stale API digest fields.

## Frozen analysis

The analysis reused the existing APC statistic, locked 232-gene program weights,
Reactome v97 toxicity sets and four equal-weight scores without retuning:

1. APC genome rank reversal.
2. APC genome weighted reversal.
3. Locked-program rank reversal.
4. Locked-program weighted reversal.
5. Their equal-weight composite.

All matched cell lines, doses and times entered the condition table. Compound
inference used 1,000 global gene-label permutations with seed `20260825`; within
each permutation, the null composite was median-aggregated across every condition
of that compound. BH adjustment was across the 10 covered fixed targets only and
is therefore labeled **targeted BH**, explicitly not full-background FDR.

Multi-condition stability required at least two conditions and two cell lines,
positive direction in at least two thirds of conditions, and positive minimum
leave-one-condition and leave-one-cell-line medians. Independent E-MTAB-9501
direction and the frozen toxicity-removal rule were applied without changing
thresholds.

## Compound results

| Target key | Conditions | LINCS median composite | Nominal P | Targeted BH q | Stable | External + | Toxicity dominated | Cross-resource class |
|---|---:|---:|---:|---:|---|---|---|---|
| Droxinostat | 22 | 0.02002 | 0.08292 | 0.4146 | no | yes | no | direction_only |
| JNJ-7706621 | 297 | 0.01776 | 0.04695 | 0.4146 | yes | yes | no | direction_only |
| Andarine | 149 | 0.00310 | 0.3177 | 0.7309 | no | no | yes | direction_only |
| Roscovitine | 708 | 0.00201 | 0.3906 | 0.7309 | no | no | no | direction_only |
| Iniparib | 413 | 0.00142 | 0.3986 | 0.7309 | no | yes | no | direction_only |
| AC480 | 161 | 0.00085 | 0.4386 | 0.7309 | no | yes | yes | direction_only |
| Bosutinib | 498 | −0.00443 | 0.8232 | 0.9261 | no | yes | no | discordant |
| BMS-536924 | 202 | −0.00622 | 0.7612 | 0.9261 | no | no | no | negative_both |
| PF-573228 | 287 | −0.00772 | 0.9261 | 0.9261 | no | yes | no | negative_both |
| BMS-265246 | 50 | −0.02107 | 0.8841 | 0.9261 | no | yes | no | discordant |
| G007-LK | 0 | — | — | — | — | — | — | not_covered |

JNJ-7706621 was the only covered compound with all four median component scores
positive, multi-condition stability, positive independent direction and no
toxicity-dominance flag. It still failed the required targeted FDR rule
(`q = 0.4146`) and is therefore not replicated. Droxinostat had the largest
LINCS composite, but its program-rank median was negative and only 59.1% of its
conditions were positive, so it failed both the all-component and stability
requirements.

## Sci-Plex discovery-set audit

Among the six prior Sci-Plex Tier-C compounds:

- Direction-only: AC480, Andarine, Droxinostat and Iniparib.
- Discordant: BMS-265246, which changed from `+0.03070` in Sci-Plex to `−0.02107`
  in LINCS.
- Not covered: G007-LK.

Among the six provider-CDK2-token compounds, JNJ-7706621 was the strongest LINCS
signal but failed targeted FDR; Roscovitine was direction-only; BMS-265246 and
Bosutinib were discordant; BMS-536924 and PF-573228 were negative in both
resources. These are perturbational transcriptome comparisons, not evidence of
CDK2 target specificity.

## Interpretation and limits

The data do not provide FDR-supported cross-resource replication for any fixed
candidate. The strongest potentially favorable observation is a stable,
four-component-positive JNJ-7706621 direction pattern, but its multiple-testing
result is decisively non-significant. Promoting it would require relaxing the
already frozen q rule, which was not done.

The LINCS conditions span many non-skin and cancer cell lines. The analysis asks
whether a direction generalizes across a heterogeneous perturbation resource;
it does not model skin exposure, therapeutic index, cell-type specificity or
clinical benefit. The previously named IRF1, HSF1, ATR, PCNA, CDK2 and E2F4 lead
agents cannot be evaluated in this fixed library because none was covered.

## Reproducible outputs

- Protocol: `LINCS_CROSS_RESOURCE_REPLICATION_PROTOCOL.md`
- Preparation: `scripts/44_prepare_lincs_targeted_signatures.py`
- Scoring: `scripts/45_score_lincs_cross_resource_replication.py`
- Validation: `scripts/46_validate_lincs_cross_resource_replication.py`
- Results directory:
  `results/exploratory_snf/selected_positive_reml_z_q05/optimized_AD_ACD_branch/mechanism/lincs_cross_resource_replication/`
- Provenance:
  `data/raw/perturbations/lincs_2021_targeted/PROVENANCE.md`

The result directory retains raw API responses and payloads, condition metadata,
all-target coverage, per-object integrity comparisons, the prepared matrix,
condition-level scores, covered-compound aggregation, independent and internal
audits, toxicity sensitivity, cross-resource classifications, run parameters and
validation summary.
